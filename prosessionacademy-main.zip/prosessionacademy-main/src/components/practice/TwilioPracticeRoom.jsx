import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Video, VideoOff, Mic, MicOff, StopCircle, Loader2, Camera, AlertCircle, XCircle, Users, MessageSquare } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function TwilioPracticeRoom({ 
  session, 
  user, 
  userRole, 
  onEnd, 
  moduleType, 
  productContext 
}) {
  const [room, setRoom] = useState(null);
  const [participants, setParticipants] = useState([]);
  const [connecting, setConnecting] = useState(true); // Renamed from isConnecting
  const [error, setError] = useState(null);
  // const [permissionError, setPermissionError] = useState(null); // Removed as per outline
  const [videoEnabled, setVideoEnabled] = useState(true); // Renamed from isVideoEnabled
  const [audioEnabled, setAudioEnabled] = useState(true); // Renamed from isAudioEnabled
  const [screenshots, setScreenshots] = useState([]);
  const [liveTranscript, setLiveTranscript] = useState([]);
  const [participantConnected, setParticipantConnected] = useState(false); // New state

  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const canvasRef = useRef(null);
  const screenshotIntervalRef = useRef(null);
  const liveRecognitionRef = useRef(null);
  const isLiveRecordingRef = useRef(false);
  // const currentUserEmail = useRef(null); // Removed as `user` prop is available
  const localTracksRef = useRef([]);

  // Removed useEffect to get current user, now using `user` prop

  // Cleanup function to stop all processes
  const cleanup = () => {
    console.log('🧹 Starting cleanup...');
    
    if (screenshotIntervalRef.current) {
      clearInterval(screenshotIntervalRef.current);
      screenshotIntervalRef.current = null;
    }
    
    if (liveRecognitionRef.current) {
      isLiveRecordingRef.current = false;
      try { 
        liveRecognitionRef.current.stop(); 
        liveRecognitionRef.current = null;
      } catch(e) {}
    }
    
    // CRITICAL: Stop all local tracks to turn off camera/mic
    localTracksRef.current.forEach(track => {
      try { 
        console.log('Stopping track:', track.kind);
        track.stop(); 
      } catch (e) {
        console.error('Error stopping track:', e);
      }
    });
    localTracksRef.current = [];
    
    // Disconnect from Twilio room
    if (room) {
      try { 
        console.log('Disconnecting from room...');
        room.disconnect(); 
      } catch(e) {}
    }

    // Clear video elements
    if (localVideoRef.current) localVideoRef.current.innerHTML = '';
    if (remoteVideoRef.current) remoteVideoRef.current.innerHTML = '';
    
    console.log('✅ Cleanup complete');
  };

  const handleEndSession = () => {
    const transcriptText = liveTranscript.map(t => t.text).join(' ').trim();
    
    if (!transcriptText || transcriptText.length < 15) {
      if (!confirm('⚠️ No significant speech detected. End without feedback?')) {
        return;
      }
    }
    
    cleanup();
    if (onEnd) onEnd({ screenshots, liveTranscript });
  };

  const handleForceExit = () => {
    console.log('🚪 FORCE EXIT - IMMEDIATE CLEANUP AND EXIT');
    
    // Stop everything first
    if (screenshotIntervalRef.current) clearInterval(screenshotIntervalRef.current);
    if (liveRecognitionRef.current) {
      isLiveRecordingRef.current = false;
      try { liveRecognitionRef.current.stop(); } catch(e) {}
    }
    if (room) {
      try { room.disconnect(); } catch(e) {}
    }
    localTracksRef.current.forEach(track => {
      try { track.stop(); } catch (e) {}
    });
    
    // Call parent's onComplete DIRECTLY - skip all analysis
    if (window.history && window.history.length > 1) {
      window.history.back();
    } else if (onEnd) {
      // Pass forceExit flag that parent MUST respect
      onEnd({ forceExit: true, screenshots: [], liveTranscript: [] });
    }
  };

  useEffect(() => {
    let twilioRoom;

    const attachLocalPreview = (room) => {
      const videoEl = document.getElementById("local-preview");
      if (!videoEl) {
        console.error("❌ local-preview element not found");
        return;
      }

      // Try attaching immediately if track exists
      for (const publication of room.localParticipant.videoTracks.values()) {
        if (publication.track) {
          console.log("📸 Attaching local video track NOW");
          publication.track.attach(videoEl);
          return;
        }
      }

      // Otherwise, wait for track to be published
      console.log("⏳ Waiting for local video track...");
      room.localParticipant.on("trackPublished", (pub) => {
        if (pub.track && pub.track.kind === "video") {
          console.log("📸 Local video published → attaching...");
          pub.track.attach(videoEl);
        }
      });
    };

    const connectToRoom = async () => {
      try {
        console.log('🎬 Connecting to Twilio...');
        
        // Test permissions first
        try {
          const testStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
          console.log('✅ Permissions granted');
          testStream.getTracks().forEach(track => track.stop());
        } catch (permissionErr) {
          console.error('❌ Permission Error:', permissionErr);
          setError(`Media device access denied. Please allow camera and microphone access to join the room. (${permissionErr.name})`);
          setConnecting(false);
          return;
        }

        const TwilioVideo = await import('https://cdn.jsdelivr.net/npm/twilio-video@2.28.1/+esm');
        const { connect, createLocalTracks } = TwilioVideo.default || TwilioVideo;

        const response = await base44.functions.invoke('generateTwilioToken', {
          roomName: session.session_code,
          identity: user?.email || `${userRole}_${Date.now()}` // Use user email if available
        });

        const { token } = response.data;

        const localTracks = await createLocalTracks({
          video: { width: 1280, height: 720, frameRate: 20 },
          audio: true
        });

        console.log('✅ Local tracks created:', localTracks.length);
        localTracksRef.current = localTracks;

        twilioRoom = await connect(token, {
          name: session.session_code,
          tracks: localTracks
        });

        console.log('✅ Connected to room');
        setRoom(twilioRoom);
        setConnecting(false);

        twilioRoom.on('participantConnected', handleParticipantConnected);
        twilioRoom.on('participantDisconnected', participant => {
          setParticipants(prev => {
            const newParticipants = prev.filter(p => p.sid !== participant.sid);
            if (newParticipants.length === 0) {
              setParticipantConnected(false); // No more remote participants
            }
            return newParticipants;
          });
        });

        twilioRoom.participants.forEach(handleParticipantConnected);
        if (twilioRoom.participants.size > 0) {
          setParticipantConnected(true);
        }
        
        // Start transcription after a delay to ensure everything is ready
        setTimeout(() => {
          console.log('🎬 Starting live transcription...');
          startLiveTranscription();
        }, 2000);

      } catch (err) {
        console.error('❌ Error:', err);
        setError(`Failed to connect to video room: ${err.message}`);
        setConnecting(false);
      }
    };

    const handleParticipantConnected = (participant) => {
      setParticipants(prev => {
        if (prev.find(p => p.sid === participant.sid)) return prev;
        return [...prev, participant];
      });
      setParticipantConnected(true); // At least one remote participant is connected

      participant.on('trackSubscribed', track => {
        if (track.kind === 'video' && remoteVideoRef.current) {
          const videoElement = track.attach();
          videoElement.autoplay = true;
          videoElement.playsInline = true;
          videoElement.style.width = '100%';
          videoElement.style.height = '100%';
          videoElement.style.objectFit = 'cover';
          
          remoteVideoRef.current.innerHTML = '';
          remoteVideoRef.current.appendChild(videoElement);
          videoElement.play().catch(() => {});
        } else if (track.kind === 'audio') {
          const audioElement = track.attach();
          audioElement.autoplay = true;
          document.body.appendChild(audioElement);
        }
      });

      participant.tracks.forEach(publication => {
        if (publication.track) {
          if (publication.track.kind === 'video' && remoteVideoRef.current) {
            const videoElement = publication.track.attach();
            videoElement.autoplay = true;
            videoElement.playsInline = true;
            videoElement.style.width = '100%';
            videoElement.style.height = '100%';
            videoElement.style.objectFit = 'cover';
            
            remoteVideoRef.current.innerHTML = ''; // Clear previous if any
            remoteVideoRef.current.appendChild(videoElement);
            videoElement.play().catch(() => {});
          } else if (publication.track.kind === 'audio') {
            const audioElement = publication.track.attach();
            audioElement.autoplay = true;
            document.body.appendChild(audioElement);
          }
        }
      });
    };

    connectToRoom();

    return () => {
      cleanup(); // Use the general cleanup function
    };
  }, [session.session_code, userRole, user?.email]);

  // Attach local preview after room is connected AND DOM is ready
  useEffect(() => {
    if (!room || connecting) return;

    const attachLocalPreview = (room) => {
      const videoEl = document.getElementById("local-preview");
      if (!videoEl) {
        console.error("❌ local-preview element not found");
        return;
      }

      // Try attaching immediately if track exists
      for (const publication of room.localParticipant.videoTracks.values()) {
        if (publication.track) {
          console.log("📸 Attaching local video track NOW");
          publication.track.attach(videoEl);
          
          // Start screenshot interval
          screenshotIntervalRef.current = setInterval(() => {
            captureScreenshot(videoEl);
          }, 3000);
          return;
        }
      }

      // Otherwise, wait for track to be published
      console.log("⏳ Waiting for local video track...");
      room.localParticipant.on("trackPublished", (pub) => {
        if (pub.track && pub.track.kind === "video") {
          console.log("📸 Local video published → attaching...");
          pub.track.attach(videoEl);
          
          screenshotIntervalRef.current = setInterval(() => {
            captureScreenshot(videoEl);
          }, 3000);
        }
      });
    };

    console.log('🟦 DOM ready, calling attachLocalPreview...');
    attachLocalPreview(room);
  }, [room, connecting]);

  const captureScreenshot = (videoElement) => {
    if (!videoElement || !canvasRef.current) return;
    if (!videoElement.videoWidth || !videoElement.videoHeight) return;

    const canvas = canvasRef.current;
    canvas.width = videoElement.videoWidth;
    canvas.height = videoElement.videoHeight;

    const ctx = canvas.getContext('2d');
    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);

    canvas.toBlob((blob) => {
      if (blob) {
        const file = new File([blob], `screenshot-${Date.now()}.jpg`, { type: 'image/jpeg' });
        setScreenshots(prev => [...prev, file]);
      }
    }, 'image/jpeg', 0.8);
  };

  const startLiveTranscription = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn("⚠️ Speech Recognition API not supported in this browser.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    isLiveRecordingRef.current = true;

    recognition.onstart = () => {
      console.log('🎤 Speech recognition started');
    };

    recognition.onresult = (event) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) {
          const text = event.results[i][0].transcript;
          console.log('🗣️ Transcript:', text);
          if (text && text.trim()) {
            const entry = {
              speaker: user?.email || 'user',
              text: text.trim(),
              timestamp: new Date().toISOString()
            };
            setLiveTranscript(prev => {
              console.log('Adding to transcript:', entry);
              return [...prev, entry];
            });
          }
        }
      }
    };

    recognition.onerror = (event) => {
      console.error('🔴 Speech recognition error:', event.error);
    };

    recognition.onend = () => {
      console.log('⏹️ Recognition ended, restarting...');
      if (isLiveRecordingRef.current) {
        setTimeout(() => {
          try { 
            recognition.start();
            console.log('🔄 Recognition restarted');
          } catch (e) {
            console.error('Failed to restart transcription:', e);
          }
        }, 100);
      }
    };

    try {
      recognition.start();
      liveRecognitionRef.current = recognition;
      console.log('✅ Speech recognition initialized');
    } catch (e) {
      console.error('❌ Failed to start transcription:', e);
    }
  };

  const toggleVideo = () => {
    if (room) {
      room.localParticipant.videoTracks.forEach(publication => {
        if (videoEnabled) {
          publication.track.disable();
        } else {
          publication.track.enable();
        }
      });
      setVideoEnabled(!videoEnabled);
    }
  };

  const toggleAudio = () => {
    if (room) {
      room.localParticipant.audioTracks.forEach(publication => {
        if (audioEnabled) {
          publication.track.disable();
        } else {
          publication.track.enable();
        }
      });
      setAudioEnabled(!audioEnabled);
    }
  };

  // Removed original handleEnd and handleForceExit, now using the new ones above

  return (
    <div className="min-h-screen bg-slate-900">
      <canvas ref={canvasRef} className="hidden" />
      
      {error && (
        <div className="p-6 max-w-2xl mx-auto">
          <Card className="border-red-500 bg-red-50">
            <CardContent className="p-8 text-center">
              <p className="text-red-700 font-semibold text-lg mb-4">{error}</p>
              <Button onClick={() => onEnd({ screenshots: [], liveTranscript: [], forceExit: true })} variant="outline">
                Exit
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {connecting && !error && (
        <div className="flex items-center justify-center min-h-screen">
          <Card className="border-none shadow-2xl">
            <CardContent className="p-12 text-center">
              <Loader2 className="w-16 h-16 text-blue-500 animate-spin mx-auto mb-4" />
              <p className="text-lg font-semibold text-white">Connecting to video room...</p>
            </CardContent>
          </Card>
        </div>
      )}

      {!connecting && !error && (
        <div className="p-4 space-y-4">
          {/* Top Controls */}
          <div className="flex justify-between items-center bg-slate-800 rounded-xl p-4 shadow-lg">
            <div className="flex items-center gap-3">
              <Badge className="bg-blue-600 text-white">
                {userRole}
              </Badge>
              {productContext && (
                <Badge variant="outline" className="text-white border-white/30">
                  {productContext}
                </Badge>
              )}
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleForceExit}
                variant="destructive"
                size="sm"
                className="bg-red-600 hover:bg-red-700"
              >
                <XCircle className="w-4 h-4 mr-2" />
                Force Exit
              </Button>
              <Button
                onClick={toggleVideo}
                variant={videoEnabled ? "default" : "outline"}
                size="sm"
                className={videoEnabled ? "bg-blue-600" : "bg-slate-700 text-white hover:bg-slate-600"}
              >
                {videoEnabled ? <Video className="w-4 h-4 mr-2" /> : <VideoOff className="w-4 h-4 mr-2" />}
                Camera
              </Button>
              <Button
                onClick={toggleAudio}
                variant={audioEnabled ? "default" : "outline"}
                size="sm"
                className={audioEnabled ? "bg-blue-600" : "bg-slate-700 text-white hover:bg-slate-600"}
              >
                {audioEnabled ? <Mic className="w-4 h-4 mr-2" /> : <MicOff className="w-4 h-4 mr-2" />}
                Mic
              </Button>
              <Button
                onClick={handleEndSession}
                variant="destructive"
                className="bg-purple-600 hover:bg-purple-700" // Changed color for distinction from force exit
              >
                <StopCircle className="w-4 h-4 mr-2" />
                End & Analyze
              </Button>
            </div>
          </div>

          {/* Video Grid - 2 columns */}
          <div className="grid grid-cols-2 gap-4">
            {/* My Video - LEFT SIDE */}
            <Card className="border-2 border-blue-500 bg-slate-800 shadow-xl">
              <CardContent className="p-0 aspect-video relative">
                <div className="w-full h-full bg-slate-900 rounded-lg overflow-hidden relative">
                  <video
                    id="local-preview"
                    autoPlay
                    muted
                    playsInline
                    style={{ width: '100%', height: '100%', objectFit: 'cover', transform: 'scaleX(-1)' }}
                  />
                  {!videoEnabled && (
                    <div className="absolute inset-0 flex items-center justify-center text-center text-white bg-slate-900">
                      <div>
                        <VideoOff className="w-16 h-16 mx-auto mb-2 opacity-50" />
                        <p className="text-sm opacity-70">Your camera is off</p>
                      </div>
                    </div>
                  )}
                </div>
                <div className="absolute bottom-3 left-3 bg-blue-600 text-white px-3 py-1.5 rounded-lg font-bold text-sm z-10">
                  You ({userRole})
                </div>
              </CardContent>
            </Card>

            {/* Partner Video - RIGHT SIDE */}
            <Card className="border-2 border-purple-500 bg-slate-800 shadow-xl">
              <CardContent className="p-0 aspect-video relative">
                <div ref={remoteVideoRef} className="w-full h-full bg-slate-900 rounded-lg flex items-center justify-center overflow-hidden">
                  {!participantConnected && (
                    <div className="text-center text-white">
                      <Users className="w-16 h-16 mx-auto mb-2 opacity-50" />
                      <p className="text-sm opacity-70">Waiting for partner...</p>
                    </div>
                  )}
                </div>
                {participantConnected && (
                  <div className="absolute bottom-3 left-3 bg-purple-600 text-white px-3 py-1.5 rounded-lg font-bold text-sm">
                    Partner
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Live Transcript */}
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-4">
              <h3 className="font-bold text-white mb-3 flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Live Transcript {liveTranscript.length > 0 && <Badge className="bg-green-600">{liveTranscript.length}</Badge>}
              </h3>
              <div className="space-y-2 max-h-48 overflow-y-auto bg-slate-900 rounded-lg p-3 min-h-[100px]">
                {liveTranscript.length === 0 ? (
                  <p className="text-slate-500 text-sm text-center py-4">🎤 Speak to see transcript...</p>
                ) : (
                  liveTranscript.slice(-10).map((t, idx) => (
                    <div key={idx} className="text-sm text-slate-300 py-1 border-b border-slate-700 last:border-0">
                      <span className="font-semibold text-blue-400">{t.speaker === user?.email ? 'You' : 'Partner'}:</span>{' '}
                      <span>{t.text}</span>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}