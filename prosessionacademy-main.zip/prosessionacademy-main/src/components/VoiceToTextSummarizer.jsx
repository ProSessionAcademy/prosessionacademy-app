import React, { useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Mic, StopCircle, Loader2, FileText, Copy, X, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

export default function VoiceToTextSummarizer({ isOpen, onClose }) {
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [wordCount, setWordCount] = useState(0);
  const [analyzing, setAnalyzing] = useState(false);
  const [summary, setSummary] = useState(null);

  const recognitionRef = useRef(null);
  const isRecordingRef = useRef(false);
  const transcriptPartsRef = useRef([]);

  const startRecording = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('⚠️ Speech recognition not supported in this browser');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    isRecordingRef.current = true;
    setIsRecording(true);
    transcriptPartsRef.current = [];
    setTranscript('');
    setWordCount(0);
    setSummary(null);

    recognition.onresult = (event) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) {
          const text = event.results[i][0].transcript;
          if (text && text.trim()) {
            transcriptPartsRef.current = [...transcriptPartsRef.current, text.trim()];
            const fullText = transcriptPartsRef.current.join(' ');
            setTranscript(fullText);
            setWordCount(fullText.split(' ').filter(w => w).length);
          }
        }
      }
    };

    recognition.onerror = (event) => {
      console.error('Recognition error:', event.error);
      if (event.error === 'not-allowed') {
        alert('⚠️ Microphone access denied!');
        setIsRecording(false);
        isRecordingRef.current = false;
      }
    };

    recognition.onend = () => {
      if (isRecordingRef.current) {
        setTimeout(() => {
          try {
            recognition.start();
          } catch (e) {}
        }, 100);
      }
    };

    try {
      recognition.start();
      recognitionRef.current = recognition;
    } catch (e) {
      alert('⚠️ Failed to start microphone: ' + e.message);
      setIsRecording(false);
      isRecordingRef.current = false;
    }
  };

  const stopRecording = async () => {
    setIsRecording(false);
    isRecordingRef.current = false;
    
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }

    if (!transcript || transcript.trim().length < 20) {
      alert('⚠️ Not enough speech detected. Please try again.');
      setTranscript('');
      setWordCount(0);
      transcriptPartsRef.current = [];
      return;
    }

    setAnalyzing(true);

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Summarize the following voice recording transcript into clear, organized notes:

TRANSCRIPT:
${transcript}

Provide:
1. A concise summary (2-3 sentences)
2. Key points (bullet points)
3. Action items if any (bullet points)
4. Main topics covered

Be clear and professional.`,
        response_json_schema: {
          type: "object",
          properties: {
            summary: { type: "string" },
            key_points: { type: "array", items: { type: "string" } },
            action_items: { type: "array", items: { type: "string" } },
            topics: { type: "array", items: { type: "string" } }
          }
        }
      });

      setSummary(result);
    } catch (error) {
      alert('❌ Failed to summarize: ' + error.message);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text);
    alert('✅ Copied to clipboard!');
  };

  const handleReset = () => {
    setTranscript('');
    setWordCount(0);
    setSummary(null);
    transcriptPartsRef.current = [];
    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch (e) {}
      recognitionRef.current = null;
    }
    setIsRecording(false);
    isRecordingRef.current = false;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-4xl w-full max-h-[90vh] overflow-y-auto"
      >
        <Card className="border-none shadow-2xl">
          <CardHeader className="bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 text-white p-6 sticky top-0 z-10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center">
                  <Mic className="w-7 h-7" />
                </div>
                <div>
                  <CardTitle className="text-3xl font-black">🎤 Voice Summarizer</CardTitle>
                  <p className="text-white/90 text-sm">Record • Transcribe • Summarize with AI</p>
                </div>
              </div>
              <Button onClick={onClose} variant="ghost" className="text-white hover:bg-white/20" size="icon">
                <X className="w-6 h-6" />
              </Button>
            </div>
          </CardHeader>

          <CardContent className="p-6 space-y-6">
            {!summary && !analyzing && (
              <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-300">
                <CardContent className="p-6 text-center">
                  <Mic className={`w-20 h-20 mx-auto mb-4 ${isRecording ? 'text-red-600 animate-pulse' : 'text-blue-600'}`} />
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">
                    {isRecording ? '🔴 Recording...' : '🎤 Ready to Record'}
                  </h3>
                  <p className="text-slate-600 mb-4">
                    {isRecording 
                      ? 'Speak your thoughts, ideas, or notes' 
                      : 'Click start to begin recording'}
                  </p>
                  
                  {isRecording && (
                    <div className="mb-4">
                      <Badge className="bg-red-600 text-white text-lg px-4 py-2">
                        {wordCount} words captured
                      </Badge>
                    </div>
                  )}

                  {!isRecording ? (
                    <Button
                      onClick={startRecording}
                      className="bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 text-white py-8 px-12 text-xl font-bold shadow-xl"
                      size="lg"
                    >
                      <Mic className="w-6 h-6 mr-2" />
                      Start Recording
                    </Button>
                  ) : (
                    <Button
                      onClick={stopRecording}
                      className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white py-8 px-12 text-xl font-bold shadow-xl"
                      size="lg"
                    >
                      <StopCircle className="w-6 h-6 mr-2" />
                      Stop & Summarize
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}

            {transcript && !summary && !analyzing && (
              <Card className="bg-white border-2 border-green-300">
                <CardHeader className="bg-green-50">
                  <CardTitle className="flex items-center gap-2 text-green-900">
                    <CheckCircle className="w-6 h-6" />
                    Transcript Captured ({wordCount} words)
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="bg-slate-50 rounded-lg p-4 max-h-64 overflow-y-auto">
                    <p className="text-slate-800 leading-relaxed whitespace-pre-wrap">{transcript}</p>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button onClick={() => handleCopy(transcript)} variant="outline" className="flex-1">
                      <Copy className="w-4 h-4 mr-2" />
                      Copy Transcript
                    </Button>
                    <Button onClick={handleReset} variant="outline" className="flex-1">
                      Record Again
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {analyzing && (
              <Card className="border-none bg-gradient-to-br from-purple-600 to-pink-600 text-white">
                <CardContent className="p-12 text-center">
                  <Loader2 className="w-20 h-20 animate-spin mx-auto mb-6" />
                  <h3 className="text-3xl font-bold mb-2">AI Analyzing...</h3>
                  <p className="text-white/90 text-lg">Creating smart summary from {wordCount} words</p>
                </CardContent>
              </Card>
            )}

            {summary && (
              <div className="space-y-4">
                <Card className="border-none shadow-xl bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-2xl">
                      <FileText className="w-6 h-6" />
                      Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-white/95 text-lg leading-relaxed">{summary.summary}</p>
                  </CardContent>
                </Card>

                {summary.topics?.length > 0 && (
                  <Card className="border-2 border-purple-300 bg-purple-50">
                    <CardHeader>
                      <CardTitle className="text-lg text-purple-900">📚 Topics Covered</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {summary.topics.map((topic, idx) => (
                          <Badge key={idx} className="bg-purple-600 text-white">
                            {topic}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {summary.key_points?.length > 0 && (
                  <Card className="border-2 border-blue-300 bg-blue-50">
                    <CardHeader>
                      <CardTitle className="text-lg text-blue-900 flex items-center justify-between">
                        🔑 Key Points
                        <Button onClick={() => handleCopy(summary.key_points.join('\n'))} size="sm" variant="outline">
                          <Copy className="w-4 h-4 mr-1" />
                          Copy
                        </Button>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {summary.key_points.map((point, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-blue-900">
                            <span className="text-blue-600 font-bold">•</span>
                            <span>{point}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                )}

                {summary.action_items?.length > 0 && (
                  <Card className="border-2 border-green-300 bg-green-50">
                    <CardHeader>
                      <CardTitle className="text-lg text-green-900 flex items-center justify-between">
                        ✅ Action Items
                        <Button onClick={() => handleCopy(summary.action_items.join('\n'))} size="sm" variant="outline">
                          <Copy className="w-4 h-4 mr-1" />
                          Copy
                        </Button>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {summary.action_items.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-green-900">
                            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <Button onClick={handleReset} variant="outline" className="py-6 text-lg font-bold">
                    New Recording
                  </Button>
                  <Button onClick={onClose} className="bg-gradient-to-r from-blue-600 to-purple-600 py-6 text-lg font-bold">
                    Done
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}