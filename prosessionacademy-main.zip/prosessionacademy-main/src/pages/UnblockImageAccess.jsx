import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Shield,
  Unlock,
  Search,
  AlertTriangle,
  CheckCircle2,
  Lock,
  ArrowLeft,
  Eye
} from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function UnblockImageAccess() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [searchEmail, setSearchEmail] = useState('');
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error('Error:', error);
      }
    };
    fetchUser();
  }, []);

  const { data: blockedUsers = [] } = useQuery({
    queryKey: ['blockedUsers'],
    queryFn: async () => {
      const allUsers = await base44.entities.User.list();
      return allUsers.filter(u => u.image_generation_blocked === true);
    },
    initialData: []
  });

  const { data: userStrikes = [] } = useQuery({
    queryKey: ['userStrikes', selectedUser?.email],
    queryFn: () => base44.entities.ContentStrike.filter({ user_email: selectedUser.email }),
    enabled: !!selectedUser,
    initialData: []
  });

  const unblockMutation = useMutation({
    mutationFn: async (userEmail) => {
      const users = await base44.entities.User.filter({ email: userEmail });
      if (users.length > 0) {
        await base44.entities.User.update(users[0].id, { image_generation_blocked: false });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['blockedUsers'] });
      alert('✅ User unblocked successfully!');
      setSelectedUser(null);
    }
  });

  const isAdmin = user?.role === 'admin';

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-indigo-900 flex items-center justify-center p-6">
        <Card className="max-w-md">
          <CardContent className="p-12 text-center">
            <Shield className="w-16 h-16 text-slate-400 mx-auto mb-6" />
            <Button onClick={() => base44.auth.redirectToLogin()} size="lg">Sign In</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-indigo-900 flex items-center justify-center p-6">
        <Card className="max-w-md border-2 border-red-500">
          <CardContent className="p-12 text-center">
            <Lock className="w-16 h-16 text-red-500 mx-auto mb-6" />
            <h2 className="text-2xl font-bold text-red-900 mb-4">Admin Access Only</h2>
            <p className="text-slate-600">This page is restricted to administrators.</p>
            <Link to={createPageUrl('Dashboard')}>
              <Button className="mt-6">Back to Dashboard</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-indigo-900 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-black text-white mb-2">🔓 Unblock Image Access</h1>
            <p className="text-purple-200">Manage users blocked from AI image generation</p>
          </div>
          <Link to={createPageUrl('AccountStrikes')}>
            <Button variant="outline" className="bg-white/10 text-white border-white/20">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Strikes
            </Button>
          </Link>
        </div>

        <Card className="border-none shadow-2xl bg-white">
          <CardContent className="p-6">
            <div className="flex items-center gap-4 mb-6">
              <Shield className="w-8 h-8 text-purple-600" />
              <div>
                <h3 className="font-bold text-xl text-slate-900">Blocked Users: {blockedUsers.length}</h3>
                <p className="text-sm text-slate-600">Users who reached 3 strikes and lost image generation access</p>
              </div>
            </div>

            {blockedUsers.length === 0 ? (
              <div className="text-center py-16">
                <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <p className="text-lg font-bold text-slate-700">No blocked users</p>
                <p className="text-slate-500 text-sm">All users currently have image generation access</p>
              </div>
            ) : (
              <div className="space-y-4">
                {blockedUsers.map(blockedUser => (
                  <Card key={blockedUser.id} className="border-2 border-red-300 bg-red-50">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-3">
                            <div className="w-12 h-12 rounded-full bg-red-600 flex items-center justify-center text-white font-bold text-lg">
                              {blockedUser.full_name?.charAt(0) || blockedUser.email?.charAt(0)}
                            </div>
                            <div>
                              <p className="font-bold text-lg text-slate-900">{blockedUser.full_name || 'No name'}</p>
                              <p className="text-sm text-slate-600">{blockedUser.email}</p>
                            </div>
                          </div>
                          
                          <Badge className="bg-red-600 text-white">
                            <Lock className="w-3 h-3 mr-1" />
                            BLOCKED
                          </Badge>
                        </div>

                        <div className="flex gap-2">
                          <Button
                            onClick={() => setSelectedUser(blockedUser)}
                            variant="outline"
                            size="sm"
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            View Strikes
                          </Button>
                          <Button
                            onClick={() => {
                              if (confirm(`Unblock ${blockedUser.full_name || blockedUser.email}?\n\nThis will restore their image generation access.`)) {
                                unblockMutation.mutate(blockedUser.email);
                              }
                            }}
                            className="bg-green-600 hover:bg-green-700"
                            size="sm"
                          >
                            <Unlock className="w-4 h-4 mr-2" />
                            Unblock
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {selectedUser && (
          <Card className="border-none shadow-2xl bg-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-slate-900">
                  Strike History: {selectedUser.full_name || selectedUser.email}
                </h3>
                <Button onClick={() => setSelectedUser(null)} variant="outline" size="sm">
                  Close
                </Button>
              </div>

              {userStrikes.length === 0 ? (
                <p className="text-slate-500 text-center py-8">No strikes found</p>
              ) : (
                <div className="space-y-4">
                  {userStrikes.map((strike, idx) => (
                    <Card key={strike.id} className="border-2 border-orange-300 bg-orange-50">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <Badge className="bg-orange-600 text-white mb-2">
                              Strike #{idx + 1}
                            </Badge>
                            <p className="text-xs text-slate-500">
                              {new Date(strike.created_date).toLocaleString()}
                            </p>
                          </div>
                          <Badge className={
                            strike.severity === 'extreme' ? 'bg-red-600 text-white' :
                            strike.severity === 'high' ? 'bg-orange-600 text-white' :
                            'bg-yellow-600 text-white'
                          }>
                            {strike.severity}
                          </Badge>
                        </div>

                        <div className="bg-white rounded-lg p-3 mb-3">
                          <p className="text-sm font-bold text-slate-700 mb-1">Prompt:</p>
                          <p className="text-slate-900">{strike.prompt || 'N/A'}</p>
                        </div>

                        {strike.image_url && (
                          <div className="bg-white rounded-lg p-3 mb-3">
                            <p className="text-sm font-bold text-red-700 mb-2">⚠️ Generated Image:</p>
                            <img src={strike.image_url} alt="Violation" className="w-full max-w-xs rounded-lg border-2 border-red-500" />
                          </div>
                        )}

                        <div className="bg-white rounded-lg p-3">
                          <p className="text-sm font-bold text-slate-700 mb-1">AI Analysis:</p>
                          <p className="text-sm text-slate-600 whitespace-pre-line">{strike.ai_analysis}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}