
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Vote as VoteIcon, TrendingUp, Award, CheckCircle, Plus, Upload, Trash2, Image as ImageIcon } from "lucide-react";
import { format } from "date-fns";

export default function Voting() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [newVote, setNewVote] = useState({
    title: '',
    description: '',
    type: 'course',
    options: [
      { option: '', votes: 0, voters: [], image_url: '' },
      { option: '', votes: 0, voters: [], image_url: '' }
    ],
    end_date: '',
    status: 'active',
    total_votes: 0
  });

  useEffect(() => {
    const fetchUser = async () => {
      const authenticated = await base44.auth.isAuthenticated();
      setIsAuthenticated(authenticated);
      if (authenticated) {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      }
    };
    fetchUser();
  }, []);

  const { data: votes, isLoading } = useQuery({
    queryKey: ['votes'],
    queryFn: () => base44.entities.Vote.list('-created_date'),
    initialData: [],
  });

  const createVoteMutation = useMutation({
    mutationFn: (data) => base44.entities.Vote.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['votes'] });
      setShowCreateDialog(false);
      setNewVote({
        title: '',
        description: '',
        type: 'course',
        options: [
          { option: '', votes: 0, voters: [], image_url: '' },
          { option: '', votes: 0, voters: [], image_url: '' }
        ],
        end_date: '',
        status: 'active',
        total_votes: 0
      });
      alert('✅ Poll created successfully!');
    },
  });

  const castVoteMutation = useMutation({
    mutationFn: ({ voteId, optionIndex, currentOptions }) => {
      const updatedOptions = currentOptions.map((opt, idx) => {
        if (idx === optionIndex) {
          return {
            ...opt,
            votes: (opt.votes || 0) + 1,
            voters: [...(opt.voters || []), user.email]
          };
        }
        return opt;
      });
      
      const totalVotes = updatedOptions.reduce((sum, opt) => sum + (opt.votes || 0), 0);
      
      return base44.entities.Vote.update(voteId, {
        options: updatedOptions,
        total_votes: totalVotes
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['votes'] });
    },
  });

  const handleVote = (voteId, optionIndex, currentOptions) => {
    if (!isAuthenticated) {
      base44.auth.redirectToLogin();
      return;
    }
    castVoteMutation.mutate({ voteId, optionIndex, currentOptions });
  };

  const handleCreateVote = () => {
    if (!newVote.title || !newVote.description || !newVote.end_date) {
      alert('⚠️ Please fill in all required fields!');
      return;
    }

    const validOptions = newVote.options.filter(opt => opt.option.trim() !== '');
    if (validOptions.length < 2) {
      alert('⚠️ Please add at least 2 voting options!');
      return;
    }

    createVoteMutation.mutate({
      ...newVote,
      options: validOptions
    });
  };

  const addOption = () => {
    setNewVote({
      ...newVote,
      options: [...newVote.options, { option: '', votes: 0, voters: [], image_url: '' }]
    });
  };

  const removeOption = (index) => {
    if (newVote.options.length <= 2) {
      alert('⚠️ You need at least 2 options!');
      return;
    }
    setNewVote({
      ...newVote,
      options: newVote.options.filter((_, i) => i !== index)
    });
  };

  const updateOption = (index, field, value) => {
    const updatedOptions = newVote.options.map((opt, i) => 
      i === index ? { ...opt, [field]: value } : opt
    );
    setNewVote({ ...newVote, options: updatedOptions });
  };

  const handleImageUpload = async (event, optionIndex) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('⚠️ Please select an image file!');
      return;
    }

    setUploadingImage(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      updateOption(optionIndex, 'image_url', response.file_url);
      alert('✅ Image uploaded!');
    } catch (error) {
      alert('❌ Upload failed: ' + error.message);
    } finally {
      setUploadingImage(false);
      event.target.value = '';
    }
  };

  const hasUserVoted = (vote) => {
    if (!user) return false;
    return vote.options?.some(opt => opt.voters?.includes(user?.email));
  };

  const activeVotes = votes.filter(v => v.status === 'active' && new Date(v.end_date) >= new Date());
  const closedVotes = votes.filter(v => v.status === 'closed' || new Date(v.end_date) < new Date());

  const isAdmin = user?.admin_level === 'top_tier_admin' || 
                  user?.admin_level === 'super_admin' || 
                  user?.admin_level === 'supervisor_admin';

  return (
    <div className="min-h-screen bg-slate-950 relative overflow-hidden">
      {/* Animated background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-1/4 w-96 h-96 bg-green-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-40 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:24px_24px]"></div>
      </div>

      <div className="relative z-10 p-6 lg:p-8 space-y-8">
        {/* Premium Header */}
        <div className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 rounded-3xl blur-xl opacity-75 group-hover:opacity-100 transition duration-1000 animate-pulse"></div>
          <div className="relative bg-gradient-to-r from-slate-900/90 via-slate-800/90 to-slate-900/90 backdrop-blur-2xl rounded-3xl p-8 border border-white/10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-blue-500 rounded-2xl flex items-center justify-center shadow-2xl">
                  <VoteIcon className="w-9 h-9 text-white" />
                </div>
                <div>
                  <h1 className="text-4xl lg:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-green-400 via-blue-400 to-purple-400">
                    Community Voting
                  </h1>
                  <p className="text-blue-200 text-lg">Shape the future • Your voice matters</p>
                </div>
              </div>
              
              {isAdmin && (
                <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
                  <DialogTrigger asChild>
                    <Button className="bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 text-white shadow-2xl hover:shadow-green-500/50 transition-all transform hover:scale-105">
                      <Plus className="w-5 h-5 mr-2" />
                      Create Poll
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto bg-slate-900 text-white border-white/10">
                    <DialogHeader>
                      <DialogTitle className="text-white">Create New Poll</DialogTitle>
                    </DialogHeader>

                    <div className="space-y-6 py-4">
                      <div>
                        <Label className="text-slate-200">Poll Title *</Label>
                        <Input
                          value={newVote.title}
                          onChange={(e) => setNewVote({ ...newVote, title: e.target.value })}
                          placeholder="What should we vote on?"
                          className="bg-slate-800 text-white border-white/10 placeholder:text-slate-400"
                        />
                      </div>

                      <div>
                        <Label className="text-slate-200">Description *</Label>
                        <Textarea
                          value={newVote.description}
                          onChange={(e) => setNewVote({ ...newVote, description: e.target.value })}
                          placeholder="Explain what this vote is about..."
                          rows={3}
                          className="bg-slate-800 text-white border-white/10 placeholder:text-slate-400"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label className="text-slate-200">Type *</Label>
                          <Select value={newVote.type} onValueChange={(value) => setNewVote({ ...newVote, type: value })}>
                            <SelectTrigger className="bg-slate-800 text-white border-white/10">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-slate-800 text-white border-white/10">
                              <SelectItem value="course">Course</SelectItem>
                              <SelectItem value="project">Project</SelectItem>
                              <SelectItem value="feature">Feature</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label className="text-slate-200">End Date *</Label>
                          <Input
                            type="date"
                            value={newVote.end_date}
                            onChange={(e) => setNewVote({ ...newVote, end_date: e.target.value })}
                            min={new Date().toISOString().split('T')[0]}
                            className="bg-slate-800 text-white border-white/10"
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <Label className="text-slate-200">Voting Options * (Text and/or Images)</Label>
                          <Button onClick={addOption} size="sm" variant="outline" className="border-white/10 text-slate-200 hover:bg-slate-700">
                            <Plus className="w-4 h-4 mr-1" />
                            Add Option
                          </Button>
                        </div>

                        <div className="space-y-4">
                          {newVote.options.map((option, index) => (
                            <Card key={index} className="border-2 border-white/10 bg-slate-800">
                              <CardContent className="p-4">
                                <div className="space-y-3">
                                  <div className="flex gap-2">
                                    <div className="flex-1">
                                      <Label className="text-xs text-slate-300">Option {index + 1} Text</Label>
                                      <Input
                                        value={option.option}
                                        onChange={(e) => updateOption(index, 'option', e.target.value)}
                                        placeholder="Enter option text..."
                                        className="bg-slate-700 text-white border-white/10 placeholder:text-slate-400"
                                      />
                                    </div>
                                    {newVote.options.length > 2 && (
                                      <Button
                                        onClick={() => removeOption(index)}
                                        variant="destructive"
                                        size="icon"
                                        className="mt-6 bg-red-600 hover:bg-red-700"
                                      >
                                        <Trash2 className="w-4 h-4" />
                                      </Button>
                                    )}
                                  </div>

                                  <div>
                                    <Label className="text-xs text-slate-300">Option Image (Optional)</Label>
                                    <div className="flex gap-2">
                                      <input
                                        type="file"
                                        accept="image/*"
                                        onChange={(e) => handleImageUpload(e, index)}
                                        className="hidden"
                                        id={`image-upload-${index}`}
                                        disabled={uploadingImage}
                                      />
                                      <Button
                                        onClick={() => document.getElementById(`image-upload-${index}`).click()}
                                        variant="outline"
                                        size="sm"
                                        disabled={uploadingImage}
                                        className="flex-1 border-white/10 text-slate-200 hover:bg-slate-700"
                                      >
                                        <Upload className="w-4 h-4 mr-2" />
                                        {uploadingImage ? 'Uploading...' : 'Upload Image'}
                                      </Button>

                                      {option.image_url && (
                                        <Button
                                          onClick={() => updateOption(index, 'image_url', '')}
                                          variant="destructive"
                                          size="sm"
                                          className="bg-red-600 hover:bg-red-700"
                                        >
                                          Remove
                                        </Button>
                                      )}
                                    </div>

                                    {option.image_url && (
                                      <div className="mt-2 border-2 border-white/10 rounded-lg overflow-hidden">
                                        <img 
                                          src={option.image_url} 
                                          alt={`Option ${index + 1}`}
                                          className="w-full h-32 object-cover"
                                        />
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>

                      <div className="flex justify-end gap-3 pt-4">
                        <Button variant="outline" onClick={() => setShowCreateDialog(false)} className="border-white/10 text-slate-200 hover:bg-slate-700">
                          Cancel
                        </Button>
                        <Button onClick={handleCreateVote} className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white">
                          <VoteIcon className="w-4 h-4 mr-2" />
                          Create Poll
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </div>
            
            {!isAuthenticated && (
              <div className="mt-6 p-4 bg-green-500/10 border border-green-500/30 rounded-xl">
                <p className="text-green-300 text-sm">
                  <button onClick={() => base44.auth.redirectToLogin()} className="underline font-semibold">Login</button> to cast your vote
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="relative group">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-2xl blur opacity-25 group-hover:opacity-75 transition"></div>
            <Card className="relative border border-white/10 bg-slate-900/80 backdrop-blur-xl">
              <CardContent className="p-6">
                <VoteIcon className="w-8 h-8 text-blue-400 mb-3" />
                <h3 className="text-3xl font-black text-white">{activeVotes.length}</h3>
                <p className="text-sm text-slate-400">Active Polls</p>
              </CardContent>
            </Card>
          </div>

          <div className="relative group">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-green-600 to-emerald-600 rounded-2xl blur opacity-25 group-hover:opacity-75 transition"></div>
            <Card className="relative border border-white/10 bg-slate-900/80 backdrop-blur-xl">
              <CardContent className="p-6">
                <TrendingUp className="w-8 h-8 text-green-400 mb-3" />
                <h3 className="text-3xl font-black text-white">
                  {votes.reduce((sum, v) => sum + (v.total_votes || 0), 0)}
                </h3>
                <p className="text-sm text-slate-400">Total Votes Cast</p>
              </CardContent>
            </Card>
          </div>

          <div className="relative group">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl blur opacity-25 group-hover:opacity-75 transition"></div>
            <Card className="relative border border-white/10 bg-slate-900/80 backdrop-blur-xl">
              <CardContent className="p-6">
                <Award className="w-8 h-8 text-purple-400 mb-3" />
                <h3 className="text-3xl font-black text-white">{closedVotes.length}</h3>
                <p className="text-sm text-slate-400">Completed Polls</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Active Votes */}
        <div>
          <h2 className="text-3xl font-bold text-white mb-6">Active Polls</h2>
          <div className="space-y-6">
            {activeVotes.map((vote) => {
              const userVoted = hasUserVoted(vote);
              const totalVotes = vote.total_votes || 0;
              
              return (
                <div key={vote.id} className="relative group">
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-green-600 to-blue-600 rounded-2xl blur opacity-0 group-hover:opacity-50 transition duration-500"></div>
                  <Card className="relative border border-white/10 shadow-2xl bg-slate-900/80 backdrop-blur-xl">
                    <CardHeader>
                      <div className="flex items-start justify-between mb-3">
                        <Badge className="bg-blue-500/20 border-blue-500 text-blue-300">
                          {vote.type?.replace(/_/g, ' ')}
                        </Badge>
                        <Badge variant="outline" className="text-xs border-slate-600 text-slate-400">
                          Ends {format(new Date(vote.end_date), 'MMM d, yyyy')}
                        </Badge>
                      </div>
                      <CardTitle className="text-3xl text-white">{vote.title}</CardTitle>
                      <p className="text-slate-300 mt-2">{vote.description}</p>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between text-sm text-slate-400 mb-6">
                        <span>{totalVotes} total votes</span>
                        {userVoted && (
                          <Badge className="bg-green-500/20 border-green-500 text-green-300">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            You voted
                          </Badge>
                        )}
                      </div>

                      <div className="grid gap-4">
                        {vote.options?.map((option, idx) => {
                          const percentage = totalVotes > 0 ? Math.round((option.votes / totalVotes) * 100) : 0;
                          const userVotedThis = option.voters?.includes(user?.email);
                          
                          return (
                            <div key={idx} className="space-y-2">
                              {option.image_url && (
                                <div className="rounded-xl overflow-hidden border-2 border-white/10">
                                  <img 
                                    src={option.image_url} 
                                    alt={option.option}
                                    className="w-full h-48 object-cover"
                                  />
                                </div>
                              )}
                              
                              <div className="flex items-center gap-4">
                                <div className="flex-1">
                                  <div className="flex items-center justify-between mb-2">
                                    <span className={`font-bold ${userVotedThis ? 'text-blue-400' : 'text-white'}`}>
                                      {option.option}
                                      {userVotedThis && ' ✓'}
                                    </span>
                                    <span className="text-sm text-slate-400">
                                      {option.votes || 0} votes ({percentage}%)
                                    </span>
                                  </div>
                                  <Progress value={percentage} className="h-3 bg-slate-700 [&::-webkit-progress-bar]:bg-slate-700 [&::-webkit-progress-value]:bg-gradient-to-r from-green-500 to-blue-500" />
                                </div>
                                {!userVoted && (
                                  <Button
                                    size="lg"
                                    onClick={() => handleVote(vote.id, idx, vote.options)}
                                    className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 min-w-[100px] text-white"
                                  >
                                    Vote
                                  </Button>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              );
            })}

            {activeVotes.length === 0 && (
              <Card className="border border-white/10 shadow-2xl bg-slate-900/80 backdrop-blur-xl">
                <CardContent className="p-16 text-center">
                  <VoteIcon className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">No active polls</h3>
                  <p className="text-slate-400">Check back soon for new voting opportunities</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Closed Votes */}
        {closedVotes.length > 0 && (
          <div>
            <h2 className="text-3xl font-bold text-white mb-6">Past Polls</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {closedVotes.slice(0, 4).map((vote) => {
                const winningOption = vote.options?.reduce((max, opt) => 
                  (opt.votes || 0) > (max.votes || 0) ? opt : max
                , vote.options[0]);
                
                return (
                  <Card key={vote.id} className="border border-white/10 shadow-xl bg-slate-900/70 backdrop-blur-xl opacity-90">
                    <CardHeader>
                      <Badge variant="outline" className="w-fit mb-2 text-xs border-slate-600 text-slate-500">
                        Closed
                      </Badge>
                      <CardTitle className="text-xl text-white">{vote.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {winningOption?.image_url && (
                        <div className="mb-3 rounded-lg overflow-hidden border border-white/10">
                          <img 
                            src={winningOption.image_url} 
                            alt={winningOption.option}
                            className="w-full h-32 object-cover"
                          />
                        </div>
                      )}
                      <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-xl">
                        <p className="text-sm font-bold text-green-300 mb-1">
                          Winner: {winningOption?.option}
                        </p>
                        <p className="text-xs text-green-400">
                          {winningOption?.votes} votes ({vote.total_votes} total)
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
