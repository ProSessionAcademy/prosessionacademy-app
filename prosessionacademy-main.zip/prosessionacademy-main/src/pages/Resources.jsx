import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  FileDown,
  Search,
  Download,
  FileText,
  CheckSquare,
  BookOpen,
  FileCheck,
  Upload,
  Plus,
  Trash2,
  Loader2,
  Lock,
  Key,
  Folder,
  Globe,
  ArrowRight,
  FolderOpen
} from "lucide-react";
import { motion } from "framer-motion";

export default function Resources() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [showLibraryDialog, setShowLibraryDialog] = useState(false);
  const [showResourceDialog, setShowResourceDialog] = useState(false);
  const [showAccessDialog, setShowAccessDialog] = useState(false);
  const [showLibraryView, setShowLibraryView] = useState(false);
  const [selectedLibrary, setSelectedLibrary] = useState(null);
  const [accessCode, setAccessCode] = useState('');
  const [unlockedLibraries, setUnlockedLibraries] = useState([]);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [uploadingThumbnail, setUploadingThumbnail] = useState(false);

  const [newLibrary, setNewLibrary] = useState({
    name: "",
    description: "",
    access_code: "",
    thumbnail_url: "",
    is_public: false
  });

  const [newResource, setNewResource] = useState({
    title: "",
    description: "",
    type: "document",
    category: "general",
    file_url: "",
    thumbnail_url: "",
    file_size: "",
    library_id: ""
  });

  useEffect(() => {
    const checkAuth = async () => {
      const authenticated = await base44.auth.isAuthenticated();
      setIsAuthenticated(authenticated);

      if (authenticated) {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      }
    };
    checkAuth();
  }, []);

  const { data: libraries = [] } = useQuery({
    queryKey: ['libraries'],
    queryFn: () => base44.entities.Library.list('-created_date'),
    initialData: [],
  });

  const { data: resources = [] } = useQuery({
    queryKey: ['resources'],
    queryFn: () => base44.entities.Resource.list('-created_date'),
    initialData: [],
  });

  const createLibraryMutation = useMutation({
    mutationFn: (data) => base44.entities.Library.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['libraries'] });
      setShowLibraryDialog(false);
      resetLibraryForm();
      alert('✅ Library aangemaakt!');
    }
  });

  const createResourceMutation = useMutation({
    mutationFn: async (data) => {
      const resource = await base44.entities.Resource.create(data);
      
      if (data.library_id) {
        const library = libraries.find(l => l.id === data.library_id);
        await base44.entities.Library.update(data.library_id, {
          resource_count: (library.resource_count || 0) + 1
        });
      }
      
      return resource;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['resources'] });
      queryClient.invalidateQueries({ queryKey: ['libraries'] });
      setShowResourceDialog(false);
      resetResourceForm();
      alert('✅ Resource geüpload!');
    }
  });

  const deleteResourceMutation = useMutation({
    mutationFn: async (resource) => {
      await base44.entities.Resource.delete(resource.id);
      
      if (resource.library_id) {
        const library = libraries.find(l => l.id === resource.library_id);
        await base44.entities.Library.update(resource.library_id, {
          resource_count: Math.max(0, (library.resource_count || 0) - 1)
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['resources'] });
      queryClient.invalidateQueries({ queryKey: ['libraries'] });
      alert('✅ Resource verwijderd!');
    }
  });

  const deleteLibraryMutation = useMutation({
    mutationFn: async (libraryId) => {
      const libraryResources = resources.filter(r => r.library_id === libraryId);
      for (const resource of libraryResources) {
        await base44.entities.Resource.delete(resource.id);
      }
      await base44.entities.Library.delete(libraryId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['libraries'] });
      queryClient.invalidateQueries({ queryKey: ['resources'] });
      alert('✅ Library verwijderd!');
    }
  });

  const downloadMutation = useMutation({
    mutationFn: ({ resourceId, currentDownloads }) => {
      return base44.entities.Resource.update(resourceId, {
        downloads: currentDownloads + 1
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['resources'] });
    }
  });

  const handleFileUpload = async (event) => {
    event.preventDefault();
    event.stopPropagation();
    
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadingFile(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      const sizeInMB = (file.size / (1024 * 1024)).toFixed(2);
      setNewResource(prev => ({
        ...prev,
        file_url: response.file_url,
        file_size: `${sizeInMB} MB`
      }));
      alert('✅ Bestand geüpload!');
    } catch (error) {
      alert('❌ Upload mislukt: ' + error.message);
    } finally {
      setUploadingFile(false);
      event.target.value = '';
    }
  };

  const handleThumbnailUpload = async (event, forLibrary = false) => {
    event.preventDefault();
    event.stopPropagation();
    
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Selecteer een afbeelding');
      event.target.value = '';
      return;
    }

    setUploadingThumbnail(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      if (forLibrary) {
        setNewLibrary(prev => ({ ...prev, thumbnail_url: response.file_url }));
      } else {
        setNewResource(prev => ({ ...prev, thumbnail_url: response.file_url }));
      }
      alert('✅ Thumbnail geüpload!');
    } catch (error) {
      alert('❌ Upload mislukt: ' + error.message);
    } finally {
      setUploadingThumbnail(false);
      event.target.value = '';
    }
  };

  const handleCreateLibrary = (e) => {
    e?.preventDefault();
    
    if (!newLibrary.name || !newLibrary.access_code) {
      alert('Voer naam en toegangscode in');
      return;
    }

    createLibraryMutation.mutate({
      ...newLibrary,
      created_by: user.email,
      resource_count: 0,
      total_downloads: 0
    });
  };

  const handleCreateResource = (e) => {
    e?.preventDefault();
    
    if (!newResource.title || !newResource.file_url) {
      alert('Voer titel in en upload bestand');
      return;
    }

    createResourceMutation.mutate({
      ...newResource,
      created_by: user.email
    });
  };

  const resetLibraryForm = () => {
    setNewLibrary({
      name: "",
      description: "",
      access_code: "",
      thumbnail_url: "",
      is_public: false
    });
  };

  const resetResourceForm = () => {
    setNewResource({
      title: "",
      description: "",
      type: "document",
      category: "general",
      file_url: "",
      thumbnail_url: "",
      file_size: "",
      library_id: ""
    });
  };

  const handleAccessRequest = (library) => {
    setSelectedLibrary(library);
    setAccessCode('');
    setShowAccessDialog(true);
  };

  const handleUnlock = () => {
    if (accessCode === selectedLibrary.access_code) {
      setUnlockedLibraries([...unlockedLibraries, selectedLibrary.id]);
      setShowAccessDialog(false);
      setShowLibraryView(true);
      alert('✅ Library ontgrendeld!');
    } else {
      alert('❌ Verkeerde toegangscode!');
    }
  };

  const handleDownload = (resource) => {
    if (!isAuthenticated) {
      base44.auth.redirectToLogin();
      return;
    }

    window.open(resource.file_url, '_blank');
    downloadMutation.mutate({
      resourceId: resource.id,
      currentDownloads: resource.downloads || 0
    });
  };

  const publicResources = resources.filter(r => !r.library_id);
  const filteredPublicResources = publicResources.filter(resource => {
    const matchesSearch = resource.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === "all" || resource.type === typeFilter;
    return matchesSearch && matchesType;
  });

  const types = [
    { value: "all", label: "All Types" },
    { value: "document", label: "Documents" },
    { value: "checklist", label: "Checklists" },
    { value: "template", label: "Templates" },
    { value: "guide", label: "Guides" },
    { value: "ebook", label: "E-Books" }
  ];

  const getResourceIcon = (type) => {
    switch (type) {
      case 'checklist': return CheckSquare;
      case 'template': return FileCheck;
      case 'guide': return BookOpen;
      case 'ebook': return BookOpen;
      default: return FileText;
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'checklist': return 'from-green-500 to-emerald-600';
      case 'template': return 'from-blue-500 to-indigo-600';
      case 'guide': return 'from-purple-500 to-violet-600';
      case 'ebook': return 'from-orange-500 to-red-600';
      default: return 'from-slate-500 to-slate-600';
    }
  };

  if (showLibraryView && selectedLibrary) {
    const libraryResources = resources.filter(r => r.library_id === selectedLibrary.id);
    const isOwner = selectedLibrary.created_by === user?.email;

    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-rose-50 p-6 lg:p-8">
        <div className="max-w-7xl mx-auto space-y-6">
          <Button onClick={() => { setShowLibraryView(false); setSelectedLibrary(null); }} variant="outline">
            <ArrowRight className="w-4 h-4 mr-2 rotate-180" />
            Terug naar Libraries
          </Button>

          <Card className="border-none shadow-2xl bg-white">
            <CardContent className="p-8">
              <div className="flex items-center gap-6 mb-6">
                {selectedLibrary.thumbnail_url ? (
                  <img src={selectedLibrary.thumbnail_url} alt={selectedLibrary.name} className="w-24 h-24 rounded-xl object-cover shadow-lg" />
                ) : (
                  <div className="w-24 h-24 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center shadow-lg">
                    <FolderOpen className="w-12 h-12 text-white" />
                  </div>
                )}
                <div className="flex-1">
                  <h2 className="text-3xl font-bold text-slate-900 mb-2">{selectedLibrary.name}</h2>
                  <p className="text-slate-600">{selectedLibrary.description}</p>
                  <div className="flex gap-3 mt-3">
                    <Badge className="bg-purple-100 text-purple-700">
                      <Lock className="w-3 h-3 mr-1" />
                      Private Library
                    </Badge>
                    <Badge variant="outline">{libraryResources.length} resources</Badge>
                  </div>
                </div>
                {isOwner && (
                  <Button onClick={() => {
                    setNewResource(prev => ({ ...prev, library_id: selectedLibrary.id }));
                    setShowResourceDialog(true);
                  }} className="bg-purple-600">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Resource
                  </Button>
                )}
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {libraryResources.map(resource => {
                  const Icon = getResourceIcon(resource.type);
                  
                  return (
                    <Card key={resource.id} className="border-2 hover:shadow-lg transition-all">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${getTypeColor(resource.type)} flex items-center justify-center`}>
                            <Icon className="w-5 h-5 text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-bold text-sm truncate">{resource.title}</h4>
                            <p className="text-xs text-slate-500">{resource.file_size}</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button onClick={() => handleDownload(resource)} size="sm" className="flex-1 bg-blue-600">
                            <Download className="w-3 h-3 mr-1" />
                            Download
                          </Button>
                          {isOwner && (
                            <Button
                              onClick={() => {
                                if (confirm('Verwijder resource?')) {
                                  deleteResourceMutation.mutate(resource);
                                }
                              }}
                              size="sm"
                              variant="destructive"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              {libraryResources.length === 0 && (
                <div className="text-center py-12">
                  <FileDown className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-600">Nog geen resources in deze library</p>
                  {isOwner && (
                    <Button onClick={() => {
                      setNewResource(prev => ({ ...prev, library_id: selectedLibrary.id }));
                      setShowResourceDialog(true);
                    }} className="mt-4 bg-purple-600">
                      <Plus className="w-4 h-4 mr-2" />
                      Eerste Resource Toevoegen
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="border-none shadow-2xl overflow-hidden bg-white">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 opacity-10"></div>
              <CardContent className="relative p-8 lg:p-12">
                <div className="flex items-center justify-between flex-wrap gap-6">
                  <div className="flex items-center gap-6">
                    <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-xl">
                      <FileDown className="w-10 h-10 text-white" />
                    </div>
                    <div>
                      <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-2">
                        Resource Library
                      </h1>
                      <p className="text-lg text-slate-600">
                        Public resources • Private libraries met toegangscodes
                      </p>
                    </div>
                  </div>

                  {isAuthenticated && (
                    <div className="flex gap-3">
                      <Button 
                        onClick={() => setShowResourceDialog(true)} 
                        className="bg-gradient-to-r from-blue-600 to-indigo-600" 
                        size="lg"
                      >
                        <Globe className="w-5 h-5 mr-2" />
                        Upload Public
                      </Button>
                      <Button 
                        onClick={() => setShowLibraryDialog(true)} 
                        className="bg-gradient-to-r from-purple-600 to-pink-600" 
                        size="lg"
                      >
                        <Lock className="w-5 h-5 mr-2" />
                        Create Private Library
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </div>
          </Card>
        </motion.div>

        <Tabs defaultValue="public" className="space-y-6">
          <TabsList>
            <TabsTrigger value="public">Public Resources</TabsTrigger>
            <TabsTrigger value="libraries">Private Libraries</TabsTrigger>
          </TabsList>

          <TabsContent value="public" className="space-y-6">
            <Card className="border-none shadow-xl bg-white">
              <CardContent className="p-6">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    placeholder="Zoek resources..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-12 h-12"
                  />
                </div>
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPublicResources.map((resource) => {
                const Icon = getResourceIcon(resource.type);

                return (
                  <Card key={resource.id} className="border-none shadow-lg hover:shadow-xl transition-all">
                    <CardContent className="p-6">
                      <div className={`h-32 rounded-lg bg-gradient-to-br ${getTypeColor(resource.type)} flex items-center justify-center mb-4`}>
                        {resource.thumbnail_url ? (
                          <img src={resource.thumbnail_url} alt={resource.title} className="w-full h-full object-cover rounded-lg" />
                        ) : (
                          <Icon className="w-12 h-12 text-white" />
                        )}
                      </div>
                      <h3 className="font-bold mb-2">{resource.title}</h3>
                      <p className="text-sm text-slate-600 mb-4 line-clamp-2">{resource.description}</p>
                      <div className="flex gap-2">
                        <Button onClick={() => handleDownload(resource)} className="flex-1 bg-blue-600" size="sm">
                          <Download className="w-4 h-4 mr-1" />
                          Download
                        </Button>
                        {resource.created_by === user?.email && (
                          <Button
                            onClick={() => {
                              if (confirm('Verwijder?')) deleteResourceMutation.mutate(resource);
                            }}
                            size="sm"
                            variant="destructive"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {filteredPublicResources.length === 0 && (
              <Card>
                <CardContent className="p-12 text-center">
                  <FileDown className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-600">Geen publieke resources gevonden</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="libraries" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {libraries.map(library => {
                const isUnlocked = unlockedLibraries.includes(library.id) || library.created_by === user?.email;
                const libraryResourceCount = resources.filter(r => r.library_id === library.id).length;

                return (
                  <Card key={library.id} className="border-none shadow-lg hover:shadow-xl transition-all">
                    <CardContent className="p-6">
                      <div className="h-40 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center mb-4 relative overflow-hidden">
                        {library.thumbnail_url ? (
                          <img src={library.thumbnail_url} alt={library.name} className="w-full h-full object-cover" />
                        ) : (
                          <Folder className="w-16 h-16 text-white" />
                        )}
                        <div className="absolute inset-0 bg-black/20"></div>
                        {!isUnlocked && (
                          <Lock className="w-12 h-12 text-white absolute" />
                        )}
                      </div>

                      <h3 className="font-bold text-xl mb-2">{library.name}</h3>
                      <p className="text-sm text-slate-600 mb-4 line-clamp-2">{library.description}</p>

                      <div className="flex gap-2 mb-4">
                        <Badge className="bg-purple-100 text-purple-700">
                          {libraryResourceCount} resources
                        </Badge>
                        <Badge variant="outline">
                          {library.total_downloads || 0} downloads
                        </Badge>
                      </div>

                      <div className="flex gap-2">
                        {isUnlocked ? (
                          <Button
                            onClick={() => {
                              setSelectedLibrary(library);
                              setShowLibraryView(true);
                            }}
                            className="flex-1 bg-purple-600"
                          >
                            <FolderOpen className="w-4 h-4 mr-2" />
                            Open Library
                          </Button>
                        ) : (
                          <Button
                            onClick={() => handleAccessRequest(library)}
                            className="flex-1 bg-purple-600"
                          >
                            <Key className="w-4 h-4 mr-2" />
                            Enter Code
                          </Button>
                        )}
                        {library.created_by === user?.email && (
                          <Button
                            onClick={() => {
                              if (confirm('Hele library verwijderen inclusief alle resources?')) {
                                deleteLibraryMutation.mutate(library.id);
                              }
                            }}
                            size="sm"
                            variant="destructive"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {libraries.length === 0 && (
              <Card>
                <CardContent className="p-16 text-center">
                  <Lock className="w-20 h-20 text-slate-300 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold mb-2">Geen Private Libraries</h3>
                  <p className="text-slate-600 mb-6">Maak je eerste privé library</p>
                  {isAuthenticated && (
                    <Button onClick={() => setShowLibraryDialog(true)} className="bg-purple-600">
                      <Lock className="w-4 h-4 mr-2" />
                      Create Private Library
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={showLibraryDialog} onOpenChange={(open) => {
        setShowLibraryDialog(open);
        if (!open) resetLibraryForm();
      }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-purple-600" />
              Create Private Library
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCreateLibrary} className="space-y-4">
            <Card className="bg-purple-50 border-2 border-purple-300">
              <CardContent className="p-4">
                <p className="text-sm text-purple-900">
                  🔒 Create een beveiligde ruimte voor je documenten. Alleen mensen met de toegangscode kunnen erin.
                </p>
              </CardContent>
            </Card>

            <div>
              <Label>Library Naam *</Label>
              <Input
                value={newLibrary.name}
                onChange={(e) => setNewLibrary({ ...newLibrary, name: e.target.value })}
                placeholder="b.v. Executive Documents"
                required
              />
            </div>

            <div>
              <Label>Beschrijving</Label>
              <Textarea
                value={newLibrary.description}
                onChange={(e) => setNewLibrary({ ...newLibrary, description: e.target.value })}
                placeholder="Wat zit er in deze library..."
                rows={3}
              />
            </div>

            <div>
              <Label>Toegangscode *</Label>
              <Input
                value={newLibrary.access_code}
                onChange={(e) => setNewLibrary({ ...newLibrary, access_code: e.target.value })}
                placeholder="b.v. SECRET2024"
                required
              />
              <p className="text-xs text-slate-500 mt-1">Deel deze code met mensen die toegang moeten hebben</p>
            </div>

            <div>
              <Label>Cover Afbeelding (optioneel)</Label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleThumbnailUpload(e, true)}
                className="hidden"
                id="library-thumbnail"
              />
              <Button
                type="button"
                variant="outline"
                className="w-full"
                disabled={uploadingThumbnail}
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById('library-thumbnail').click();
                }}
              >
                {uploadingThumbnail ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Uploading...</>
                ) : newLibrary.thumbnail_url ? (
                  '✅ Cover Uploaded'
                ) : (
                  <><Upload className="w-4 h-4 mr-2" />Upload Cover</>
                )}
              </Button>
              {newLibrary.thumbnail_url && (
                <img src={newLibrary.thumbnail_url} alt="Preview" className="mt-2 w-full h-32 object-cover rounded" />
              )}
            </div>

            <Button type="submit" className="w-full bg-purple-600" disabled={createLibraryMutation.isPending}>
              {createLibraryMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Lock className="w-4 h-4 mr-2" />}
              Create Library
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={showResourceDialog} onOpenChange={(open) => {
        setShowResourceDialog(open);
        if (!open) resetResourceForm();
      }}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Upload Resource</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCreateResource} className="space-y-4">
            <div>
              <Label>Titel *</Label>
              <Input
                value={newResource.title}
                onChange={(e) => setNewResource({ ...newResource, title: e.target.value })}
                placeholder="Resource naam"
                required
              />
            </div>

            <div>
              <Label>Beschrijving</Label>
              <Textarea
                value={newResource.description}
                onChange={(e) => setNewResource({ ...newResource, description: e.target.value })}
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Type *</Label>
                <Select value={newResource.type} onValueChange={(value) => setNewResource({ ...newResource, type: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="document">Document</SelectItem>
                    <SelectItem value="checklist">Checklist</SelectItem>
                    <SelectItem value="template">Template</SelectItem>
                    <SelectItem value="guide">Guide</SelectItem>
                    <SelectItem value="ebook">E-Book</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Category *</Label>
                <Select value={newResource.category} onValueChange={(value) => setNewResource({ ...newResource, category: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General</SelectItem>
                    <SelectItem value="business">Business</SelectItem>
                    <SelectItem value="leadership">Leadership</SelectItem>
                    <SelectItem value="sales">Sales</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Upload File *</Label>
              <input 
                type="file" 
                onChange={handleFileUpload} 
                className="hidden" 
                id="res-file"
              />
              <Button 
                type="button" 
                variant="outline" 
                className="w-full"
                disabled={uploadingFile}
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById('res-file').click();
                }}
              >
                {uploadingFile ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Uploading...</>
                ) : newResource.file_url ? (
                  `✅ Uploaded ${newResource.file_size}`
                ) : (
                  <><Upload className="w-4 h-4 mr-2" />Choose File</>
                )}
              </Button>
            </div>

            <Button type="submit" className="w-full bg-blue-600" disabled={!newResource.title || !newResource.file_url || createResourceMutation.isPending}>
              {createResourceMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
              Upload
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={showAccessDialog} onOpenChange={setShowAccessDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-purple-600" />
              Private Library Access
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {selectedLibrary && (
              <div className="p-4 bg-purple-50 rounded-lg">
                <p className="font-bold text-purple-900">{selectedLibrary.name}</p>
                <p className="text-sm text-slate-600 mt-1">{selectedLibrary.description}</p>
              </div>
            )}
            <div>
              <Label>Toegangscode</Label>
              <Input
                value={accessCode}
                onChange={(e) => setAccessCode(e.target.value)}
                placeholder="Voer code in..."
              />
            </div>
            <Button onClick={handleUnlock} className="w-full bg-purple-600">
              <Key className="w-4 h-4 mr-2" />
              Unlock Library
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}