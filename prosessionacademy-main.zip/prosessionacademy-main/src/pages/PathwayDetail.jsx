
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import {
  BookOpen,
  ArrowLeft,
  CheckCircle,
  Clock,
  PlayCircle,
  Award,
  TrendingUp,
  Star,
  Edit2,
  Save,
  Target,
  Rocket,
  Sparkles,
  Trophy,
  Zap,
  Crown,
  Flame
} from "lucide-react";
import { motion } from "framer-motion";

export default function PathwayDetail() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const pathwayId = urlParams.get('pathwayId');
  const [user, setUser] = useState(null);
  const [editingNotes, setEditingNotes] = useState(false);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        if (currentUser.pathway_notes && currentUser.pathway_notes[pathwayId]) {
          setNotes(currentUser.pathway_notes[pathwayId]);
        }
      } catch (error) {
        console.error("Error:", error);
      }
    };
    fetchUser();
  }, [pathwayId]);

  const { data: pathway } = useQuery({
    queryKey: ['pathway', pathwayId],
    queryFn: async () => {
      const pathways = await base44.entities.Pathway.filter({ id: pathwayId });
      return pathways[0];
    },
    enabled: !!pathwayId,
  });

  const { data: allCourses = [] } = useQuery({
    queryKey: ['allCourses'],
    queryFn: () => base44.entities.Course.list(),
    initialData: [],
  });

  const { data: allChapters = [] } = useQuery({
    queryKey: ['allChapters'],
    queryFn: () => base44.entities.Chapter.list(),
    initialData: [],
  });

  const { data: userProgress = [] } = useQuery({
    queryKey: ['userProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      return await base44.entities.UserProgress.filter({ user_email: user.email });
    },
    enabled: !!user?.email,
    initialData: [],
  });

  const saveNotes = async () => {
    if (!user) return;
    
    const updatedNotes = {
      ...user.pathway_notes,
      [pathwayId]: notes
    };
    
    await base44.auth.updateMe({
      pathway_notes: updatedNotes
    });
    
    setEditingNotes(false);
  };

  if (!pathway) {
    return (
      <div className="p-6 lg:p-8">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-500">Loading pathway...</p>
        </div>
      </div>
    );
  }

  const pathwayCourses = pathway.courses && pathway.courses.length > 0
    ? pathway.courses
        .sort((a, b) => (a.order || 0) - (b.order || 0))
        .map(pc => {
          const course = allCourses.find(c => c.id === pc.course_id);
          return course ? { ...course, pathway_order: pc.order, pathway_level: pc.level } : null;
        })
        .filter(Boolean)
    : [];

  const getCourseProgress = (courseId) => {
    const courseChapters = allChapters.filter(ch => ch.course_id === courseId);
    if (courseChapters.length === 0) return 0;
    
    // Find the UserProgress record for this course
    const courseProgressRecord = userProgress.find(p => p.course_id === courseId);
    if (!courseProgressRecord) return 0;
    
    const completedChapters = courseProgressRecord.completed_chapters || [];
    const completedCount = courseChapters.filter(ch => completedChapters.includes(ch.id)).length;
    
    return Math.round((completedCount / courseChapters.length) * 100);
  };

  const totalProgress = pathwayCourses.length > 0
    ? Math.round(pathwayCourses.reduce((sum, course) => sum + getCourseProgress(course.id), 0) / pathwayCourses.length)
    : 0;

  const completedCount = pathwayCourses.filter(course => getCourseProgress(course.id) === 100).length;

  // Calculate actual total hours from existing courses
  const totalHours = pathwayCourses.reduce((sum, course) => {
    return sum + (course.duration_hours || 0);
  }, 0);

  // Level indicators
  const getLevelIcon = (level) => {
    const icons = {
      beginner: { icon: Sparkles, color: 'text-green-500', bg: 'bg-green-100' },
      intermediate: { icon: TrendingUp, color: 'text-blue-500', bg: 'bg-blue-100' },
      advanced: { icon: Trophy, color: 'text-purple-500', bg: 'bg-purple-100' },
      expert: { icon: Crown, color: 'text-yellow-500', bg: 'bg-yellow-100' }
    };
    return icons[level] || icons.beginner;
  };

  const rocketPosition = (totalProgress / 100) * 90; // 90% to keep rocket on track

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 p-6 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <Button
          variant="ghost"
          onClick={() => navigate(createPageUrl("Pathways"))}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Pathways
        </Button>

        {/* Header Card */}
        <Card className="border-none shadow-2xl overflow-hidden">
          <div className="h-2 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600"></div>
          <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 p-8">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <Badge className="mb-3">{pathway.category?.replace(/_/g, ' ')}</Badge>
                <CardTitle className="text-4xl mb-3">{pathway.title}</CardTitle>
                <p className="text-slate-600 text-lg">{pathway.description}</p>
              </div>
              {pathway.thumbnail_url && (
                <img src={pathway.thumbnail_url} className="w-32 h-32 rounded-xl object-cover shadow-lg" />
              )}
            </div>
          </CardHeader>
          <CardContent className="p-8">
            <div className="grid md:grid-cols-3 gap-6 mb-6">
              <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl">
                <BookOpen className="w-10 h-10 text-blue-600 mx-auto mb-3" />
                <p className="text-3xl font-bold text-slate-900">{pathwayCourses.length}</p>
                <p className="text-sm text-slate-600">Total Courses</p>
              </div>
              <div className="text-center p-6 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl">
                <CheckCircle className="w-10 h-10 text-green-600 mx-auto mb-3" />
                <p className="text-3xl font-bold text-slate-900">{completedCount}</p>
                <p className="text-sm text-slate-600">Completed</p>
              </div>
              <div className="text-center p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl">
                <Clock className="w-10 h-10 text-purple-600 mx-auto mb-3" />
                <p className="text-3xl font-bold text-slate-900">{totalHours}h</p>
                <p className="text-sm text-slate-600">Total Duration</p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="font-semibold text-slate-700">Your Progress</span>
                <span className="text-2xl font-bold text-blue-600">{totalProgress}%</span>
              </div>
              <Progress value={totalProgress} className="h-4" />
              <p className="text-sm text-slate-500">
                {completedCount} of {pathwayCourses.length} courses completed
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Notes Card */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Edit2 className="w-5 h-5" />
                Your Pathway Notes
              </CardTitle>
              {editingNotes ? (
                <Button onClick={saveNotes} size="sm">
                  <Save className="w-4 h-4 mr-2" />
                  Save Notes
                </Button>
              ) : (
                <Button onClick={() => setEditingNotes(true)} size="sm" variant="outline">
                  <Edit2 className="w-4 h-4 mr-2" />
                  Edit
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {editingNotes ? (
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Write your notes here..."
                rows={6}
                className="w-full"
              />
            ) : (
              <p className="text-slate-600 whitespace-pre-wrap">
                {notes || 'No notes yet. Click Edit to add your thoughts!'}
              </p>
            )}
          </CardContent>
        </Card>

        {/* ROCKET PROGRESS VISUALIZATION */}
        <Card className="border-none shadow-2xl bg-gradient-to-br from-blue-900 via-purple-900 to-pink-900 text-white overflow-hidden relative">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=1200')] opacity-20 bg-cover bg-center"></div>
          <CardContent className="p-8 relative z-10">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <Rocket className="w-6 h-6" />
              Your Journey to Mastery
            </h2>
            
            {/* Progress Track with Rocket */}
            <div className="relative h-24 mb-4">
              {/* Track Line */}
              <div className="absolute top-1/2 left-0 right-0 h-2 bg-white/20 rounded-full"></div>
              <div className="absolute top-1/2 left-0 h-2 bg-gradient-to-r from-green-400 via-blue-400 to-purple-400 rounded-full" style={{ width: `${totalProgress}%` }}></div>
              
              {/* Level Markers */}
              <div className="absolute top-1/2 left-0 transform -translate-y-1/2 -translate-x-2">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center shadow-lg">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <p className="text-xs mt-2 text-center font-bold">Beginner</p>
              </div>
              
              <div className="absolute top-1/2 left-1/3 transform -translate-y-1/2 -translate-x-2">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center shadow-lg">
                  <TrendingUp className="w-4 h-4 text-white" />
                </div>
                <p className="text-xs mt-2 text-center font-bold">Intermediate</p>
              </div>
              
              <div className="absolute top-1/2 left-2/3 transform -translate-y-1/2 -translate-x-2">
                <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center shadow-lg">
                  <Trophy className="w-4 h-4 text-white" />
                </div>
                <p className="text-xs mt-2 text-center font-bold">Advanced</p>
              </div>
              
              <div className="absolute top-1/2 right-0 transform -translate-y-1/2 translate-x-2">
                <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center shadow-lg">
                  <Crown className="w-4 h-4 text-white" />
                </div>
                <p className="text-xs mt-2 text-center font-bold">Master</p>
              </div>
              
              {/* Animated Rocket */}
              <motion.div
                className="absolute top-1/2 transform -translate-y-1/2"
                animate={{
                  left: `${rocketPosition}%`,
                  rotate: [0, -5, 0, 5, 0],
                  y: [-2, 2, -2]
                }}
                transition={{
                  left: { duration: 0.5 },
                  rotate: { duration: 2, repeat: Infinity },
                  y: { duration: 1.5, repeat: Infinity }
                }}
              >
                <div className="relative">
                  <Rocket className="w-12 h-12 text-yellow-400 drop-shadow-2xl rotate-45" />
                  <motion.div
                    className="absolute -bottom-2 -right-2"
                    animate={{
                      scale: [1, 1.2, 1],
                      opacity: [0.7, 1, 0.7]
                    }}
                    transition={{
                      duration: 0.8,
                      repeat: Infinity
                    }}
                  >
                    <Flame className="w-6 h-6 text-orange-400" />
                  </motion.div>
                </div>
              </motion.div>
            </div>

            <div className="text-center mt-8">
              <p className="text-lg">
                {totalProgress === 0 && "🚀 Start your journey to mastery!"}
                {totalProgress > 0 && totalProgress < 33 && "🌱 You're taking your first steps!"}
                {totalProgress >= 33 && totalProgress < 66 && "📈 Great progress! Keep going!"}
                {totalProgress >= 66 && totalProgress < 100 && "🏆 Almost there! You're doing amazing!"}
                {totalProgress === 100 && "👑 Congratulations! You've mastered this pathway!"}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Course List */}
        <div>
          <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
            <Target className="w-6 h-6 text-blue-600" />
            Your Learning Journey
          </h2>
          
          {pathwayCourses.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center">
                <BookOpen className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No courses in this pathway yet</h3>
                <p className="text-slate-500">Check back soon!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {pathwayCourses.map((course, idx) => {
                const progress = getCourseProgress(course.id);
                const isCompleted = progress === 100;
                const isInProgress = progress > 0 && progress < 100;
                const levelInfo = getLevelIcon(course.pathway_level);
                const LevelIcon = levelInfo.icon;

                return (
                  <motion.div
                    key={course.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.1 }}
                  >
                    <Card className={`border-2 hover:shadow-xl transition-all ${
                      isCompleted 
                        ? 'border-green-300 bg-gradient-to-r from-green-50 to-emerald-50'
                        : isInProgress
                        ? 'border-blue-300 bg-gradient-to-r from-blue-50 to-purple-50'
                        : 'border-slate-200 bg-white'
                    }`}>
                      <CardContent className="p-6">
                        <div className="flex items-center gap-6">
                          <div className={`w-16 h-16 rounded-full ${levelInfo.bg} flex items-center justify-center flex-shrink-0`}>
                            <LevelIcon className={`w-8 h-8 ${levelInfo.color}`} />
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-xl font-bold text-slate-900">{course.title}</h3>
                              <Badge variant="outline" className="capitalize">
                                {course.pathway_level}
                              </Badge>
                              {isCompleted && (
                                <Badge className="bg-green-600">
                                  <Star className="w-3 h-3 mr-1 fill-white" />
                                  Completed
                                </Badge>
                              )}
                            </div>
                            <p className="text-slate-600 text-sm mb-3 line-clamp-2">{course.description}</p>
                            
                            {progress > 0 && (
                              <div className="space-y-2">
                                <div className="flex items-center justify-between text-xs">
                                  <span className="text-slate-500">Progress</span>
                                  <span className="font-bold text-blue-600">{progress}%</span>
                                </div>
                                <Progress value={progress} className="h-2" />
                              </div>
                            )}
                          </div>

                          <Link to={`${createPageUrl("Learning")}?courseId=${course.id}`}>
                            <Button className={`${
                              isCompleted
                                ? 'bg-green-600 hover:bg-green-700'
                                : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700'
                            }`}>
                              {isCompleted ? (
                                <>
                                  <Award className="w-4 h-4 mr-2" />
                                  Review
                                </>
                              ) : isInProgress ? (
                                <>
                                  <PlayCircle className="w-4 h-4 mr-2" />
                                  Continue
                                </>
                              ) : (
                                <>
                                  <PlayCircle className="w-4 h-4 mr-2" />
                                  Start
                                </>
                              )}
                            </Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
