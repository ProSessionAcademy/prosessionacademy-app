import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { FileText, Upload, Download, Copy, Check, AlertTriangle, Lock } from "lucide-react";

export default function Summarizer() {
  const [text, setText] = useState("");
  const [copied, setCopied] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleFileUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      // Fetch the file content (text files only)
      if (file.type === 'text/plain') {
        const response = await fetch(file_url);
        const content = await response.text();
        setText(content);
      } else {
        alert("⚠️ AI file extraction is disabled. Please paste text directly or upload .txt files only.");
      }
    } catch (error) {
      alert("Failed to upload file");
    } finally {
      setUploading(false);
    }
  };

  const handleReset = () => {
    setText("");
  };

  const copyText = (textToCopy) => {
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadText = (content, filename) => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <Card className="border-none shadow-2xl overflow-hidden">
          <div className="h-32 bg-gradient-to-r from-blue-600 to-purple-600 relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center text-white">
                <div className="flex items-center justify-center gap-3 mb-2">
                  <FileText className="w-12 h-12" />
                  <Lock className="w-8 h-8 bg-slate-700 rounded-full p-1" />
                </div>
                <h1 className="text-4xl font-bold">Study Tools</h1>
                <p className="text-blue-100">View and organize your study content</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Notice */}
        <Card className="border-2 border-amber-300 bg-amber-50">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <AlertTriangle className="w-8 h-8 text-amber-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-amber-900 mb-2 text-lg">AI Features Temporarily Disabled</h3>
                <p className="text-amber-800 mb-2">
                  AI-powered summarization, flashcard generation, quiz creation, and study guide generation have been disabled to reduce costs.
                </p>
                <p className="text-sm text-amber-700">
                  You can still paste and view your content below. These AI features may return in a future premium tier.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Input Section */}
        <Card className="border-none shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-600" />
              Your Study Content
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              placeholder="Paste your study content here (lecture notes, textbook chapters, articles, etc.)..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="min-h-[300px] text-base"
            />
            
            <div className="flex items-center gap-3">
              <input
                type="file"
                accept=".txt"
                onChange={handleFileUpload}
                className="hidden"
                id="file-upload"
              />
              <Button
                onClick={() => document.getElementById('file-upload').click()}
                variant="outline"
                disabled={uploading}
                className="flex-1"
              >
                <Upload className="w-4 h-4 mr-2" />
                {uploading ? 'Uploading...' : 'Upload Text File (.txt)'}
              </Button>
              
              <Button onClick={handleReset} variant="outline">
                Clear
              </Button>

              <Badge variant="outline" className="px-4 py-2">
                {text.length} characters
              </Badge>
            </div>

            {text && (
              <div className="flex gap-2 pt-4 border-t">
                <Button
                  onClick={() => copyText(text)}
                  variant="outline"
                  className="flex-1"
                >
                  {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                  {copied ? 'Copied!' : 'Copy Text'}
                </Button>
                <Button
                  onClick={() => downloadText(text, 'study-content.txt')}
                  variant="outline"
                  className="flex-1"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Info Card */}
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-purple-50">
          <CardContent className="p-6">
            <h3 className="font-bold text-slate-900 mb-3">💡 Manual Study Tips:</h3>
            <ul className="space-y-2 text-slate-700">
              <li className="flex items-start gap-2">
                <span className="text-blue-600 font-bold">•</span>
                <span>Read through your content and manually highlight key concepts</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-purple-600 font-bold">•</span>
                <span>Create your own flashcards with questions on one side, answers on the other</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-pink-600 font-bold">•</span>
                <span>Test yourself by covering sections and trying to recall information</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 font-bold">•</span>
                <span>Use the Student Space for note-taking and study session tracking</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}