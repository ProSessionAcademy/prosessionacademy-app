import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Shield,
  Unlock,
  Lock,
  AlertTriangle,
  Search,
  User,
  Image,
  Calendar,
  ArrowLeft
} from "lucide-react";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

export default function ImageGenerationAdmin() {
  const [user, setUser] = useState(null);
  const [searchEmail, setSearchEmail] = useState('');
  const queryClient = useQueryClient();

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error('Error:', error);
      }
    };
    fetchUser();
  }, []);

  const { data: allStrikes = [] } = useQuery({
    queryKey: ['contentStrikes'],
    queryFn: () => base44.entities.ContentStrike.list('-created_date', 100),
    initialData: []
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    enabled: user?.role === 'admin',
    initialData: []
  });

  const updateUserMutation = useMutation({
    mutationFn: ({ userEmail, blocked }) => 
      base44.entities.User.update(
        allUsers.find(u => u.email === userEmail)?.id,
        { image_generation_blocked: blocked }
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allUsers'] });
      alert('✅ User status updated!');
    }
  });

  const deleteStrikeMutation = useMutation({
    mutationFn: (strikeId) => base44.entities.ContentStrike.delete(strikeId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contentStrikes'] });
    }
  });

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6 flex items-center justify-center">
        <Card><CardContent className="p-12 text-center">Loading...</CardContent></Card>
      </div>
    );
  }

  if (user.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-900 to-orange-900 p-6 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-12 text-center">
            <Shield className="w-16 h-16 text-red-500 mx-auto mb-6" />
            <h2 className="text-2xl font-bold text-red-900 mb-4">Admin Access Required</h2>
            <p className="text-slate-600">You don't have permission to access this page.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Group strikes by user
  const strikesByUser = allStrikes.reduce((acc, strike) => {
    if (!acc[strike.user_email]) {
      acc[strike.user_email] = [];
    }
    acc[strike.user_email].push(strike);
    return acc;
  }, {});

  const blockedUsers = allUsers.filter(u => u.image_generation_blocked === true);
  
  const filteredUsers = searchEmail.trim() 
    ? Object.keys(strikesByUser).filter(email => email.toLowerCase().includes(searchEmail.toLowerCase()))
    : Object.keys(strikesByUser);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-black text-slate-900 mb-2">🛡️ Image Generation Security</h1>
            <p className="text-slate-600">Manage content violations and user access</p>
          </div>
          <Link to={createPageUrl("Dashboard")}>
            <Button variant="outline">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="border-none shadow-lg bg-gradient-to-br from-red-600 to-orange-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-red-100 text-sm mb-1">Total Violations</p>
                  <p className="text-5xl font-black">{allStrikes.length}</p>
                </div>
                <AlertTriangle className="w-12 h-12 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-orange-600 to-yellow-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm mb-1">Users with Strikes</p>
                  <p className="text-5xl font-black">{Object.keys(strikesByUser).length}</p>
                </div>
                <User className="w-12 h-12 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-red-700 to-red-900 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-red-100 text-sm mb-1">Blocked Users</p>
                  <p className="text-5xl font-black">{blockedUsers.length}</p>
                </div>
                <Lock className="w-12 h-12 opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <Card className="border-none shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Search className="w-5 h-5 text-slate-400" />
              <Input
                placeholder="Search by email..."
                value={searchEmail}
                onChange={(e) => setSearchEmail(e.target.value)}
                className="border-0 focus-visible:ring-0"
              />
            </div>
          </CardContent>
        </Card>

        {/* Blocked Users Section */}
        {blockedUsers.length > 0 && (
          <Card className="border-2 border-red-500 bg-red-50">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold text-red-900 mb-4 flex items-center gap-2">
                <Lock className="w-6 h-6" />
                🚫 Blocked Users ({blockedUsers.length})
              </h3>
              <div className="space-y-3">
                {blockedUsers.map(blockedUser => {
                  const userStrikes = strikesByUser[blockedUser.email] || [];
                  return (
                    <Card key={blockedUser.id} className="border-2 border-red-400 bg-white">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <p className="font-bold text-lg">{blockedUser.full_name}</p>
                            <p className="text-sm text-slate-600">{blockedUser.email}</p>
                            <Badge className="bg-red-600 text-white mt-2">
                              {userStrikes.length} Strikes
                            </Badge>
                          </div>
                          <Button
                            onClick={() => {
                              if (confirm(`Unlock image generation for ${blockedUser.full_name}?\n\nTheir strikes will remain on record.`)) {
                                updateUserMutation.mutate({ userEmail: blockedUser.email, blocked: false });
                              }
                            }}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <Unlock className="w-5 h-5 mr-2" />
                            Unlock Access
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* All Users with Strikes */}
        <Card className="border-none shadow-xl">
          <CardContent className="p-6">
            <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
              <AlertTriangle className="w-7 h-7 text-orange-600" />
              Content Violations by User
            </h3>
            
            <div className="space-y-4">
              {filteredUsers.map(email => {
                const userStrikes = strikesByUser[email];
                const userData = allUsers.find(u => u.email === email);
                const isBlocked = userData?.image_generation_blocked === true;
                
                return (
                  <Card key={email} className={`border-2 ${isBlocked ? 'border-red-500 bg-red-50' : 'border-orange-300 bg-orange-50'}`}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <p className="font-bold text-xl">{userData?.full_name || 'Unknown User'}</p>
                            {isBlocked && (
                              <Badge className="bg-red-600 text-white">
                                <Lock className="w-3 h-3 mr-1" />
                                BLOCKED
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-slate-600 mb-1">{email}</p>
                          <Badge className={`${
                            userStrikes.length >= 3 ? 'bg-red-600' : 
                            userStrikes.length >= 2 ? 'bg-orange-600' : 
                            'bg-yellow-600'
                          } text-white`}>
                            {userStrikes.length} Strike{userStrikes.length !== 1 ? 's' : ''}
                          </Badge>
                        </div>
                        
                        {isBlocked ? (
                          <Button
                            onClick={() => {
                              if (confirm(`Unlock ${userData?.full_name || email}?\n\nStrikes remain on record. User can generate images again.`)) {
                                updateUserMutation.mutate({ userEmail: email, blocked: false });
                              }
                            }}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <Unlock className="w-5 h-5 mr-2" />
                            Unlock
                          </Button>
                        ) : userStrikes.length >= 2 && (
                          <Button
                            onClick={() => {
                              if (confirm(`Block ${userData?.full_name || email} from generating images?`)) {
                                updateUserMutation.mutate({ userEmail: email, blocked: true });
                              }
                            }}
                            variant="outline"
                            className="border-red-600 text-red-600 hover:bg-red-50"
                          >
                            <Lock className="w-5 h-5 mr-2" />
                            Block Now
                          </Button>
                        )}
                      </div>
                      
                      <div className="space-y-3 mt-4">
                        {userStrikes.slice(0, 5).map(strike => (
                          <Card key={strike.id} className="bg-white border border-slate-200">
                            <CardContent className="p-4">
                              <div className="flex items-start justify-between mb-3">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-2">
                                    <Badge className={`${
                                      strike.severity === 'extreme' ? 'bg-red-700' :
                                      strike.severity === 'high' ? 'bg-red-600' :
                                      strike.severity === 'medium' ? 'bg-orange-500' :
                                      'bg-yellow-500'
                                    } text-white text-xs`}>
                                      {strike.severity?.toUpperCase() || 'HIGH'}
                                    </Badge>
                                    <p className="text-xs text-slate-500">
                                      {new Date(strike.created_date).toLocaleString()}
                                    </p>
                                  </div>
                                  
                                  <div className="bg-slate-50 rounded-lg p-3 mb-2">
                                    <p className="text-xs text-slate-500 mb-1 font-semibold">Prompt Attempted:</p>
                                    <p className="text-sm text-slate-900 font-mono">"{strike.prompt}"</p>
                                  </div>
                                  
                                  {strike.image_url && (
                                    <div className="bg-blue-50 border border-blue-300 rounded-lg p-2 mb-2">
                                      <p className="text-xs text-blue-700">
                                        <Image className="w-3 h-3 inline mr-1" />
                                        Image was generated (blocked from user)
                                      </p>
                                      <a 
                                        href={strike.image_url} 
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                        className="text-xs text-blue-600 hover:underline"
                                      >
                                        View blocked image (admin only)
                                      </a>
                                    </div>
                                  )}
                                  
                                  <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                                    <p className="text-xs text-red-600 font-semibold mb-1">AI Analysis:</p>
                                    <p className="text-xs text-red-800 whitespace-pre-line">{strike.ai_analysis}</p>
                                  </div>
                                </div>
                                
                                <Button
                                  onClick={() => {
                                    if (confirm('Delete this strike record?\n\nThis will reduce the user\'s strike count.')) {
                                      deleteStrikeMutation.mutate(strike.id);
                                    }
                                  }}
                                  variant="ghost"
                                  size="sm"
                                  className="text-red-600 hover:bg-red-50"
                                >
                                  Delete
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                        
                        {userStrikes.length > 5 && (
                          <p className="text-xs text-slate-500 text-center">
                            ... and {userStrikes.length - 5} more violations
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
            
            {filteredUsers.length === 0 && (
              <div className="text-center py-12">
                <Shield className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <p className="text-xl font-bold text-green-900">✅ No Violations Found</p>
                <p className="text-slate-600 mt-2">
                  {searchEmail ? 'No matches for your search' : 'All users are following content policies'}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}