
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Clock,
  Upload,
  Brain,
  Target,
  AlertCircle,
  CheckCircle2,
  X,
  FileText,
  Sparkles,
  Timer,
  GraduationCap,
  Lightbulb,
  Zap,
  Loader2,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ExamFocusSpace() {
  const [step, setStep] = useState("setup");
  const [difficulty, setDifficulty] = useState("");
  const [subject, setSubject] = useState("");
  const [examPrompt, setExamPrompt] = useState("");
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [exam, setExam] = useState(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [userAnswers, setUserAnswers] = useState({});
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [timerActive, setTimerActive] = useState(false);
  const [examStarted, setExamStarted] = useState(false);
  const [results, setResults] = useState(null);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generationStep, setGenerationStep] = useState('');

  // NEW: Extra filters voor precisie
  const [examType, setExamType] = useState("tentamen");
  const [university, setUniversity] = useState("");
  const [studyYear, setStudyYear] = useState("");
  const [specificTopics, setSpecificTopics] = useState("");
  const [allowCalculator, setAllowCalculator] = useState(false);
  const [allowFormulaSheet, setAllowFormulaSheet] = useState(false);

  useEffect(() => {
    if (step === "exam" || step === "results") {
      if (document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen().catch(err => {
          console.log("Fullscreen failed:", err);
        });
      }
    }

    const handleEscape = (e) => {
      if (e.key === 'Escape' && (step === "exam" || step === "results")) {
        if (confirm('Wil je het examen verlaten? Je voortgang gaat verloren.')) {
          resetExam();
          if (document.exitFullscreen) {
            document.exitFullscreen();
          }
        }
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [step]);

  useEffect(() => {
    if (timerActive && timeRemaining > 0) {
      const interval = setInterval(() => {
        setTimeRemaining(t => {
          if (t <= 1) {
            setTimerActive(false);
            handleSubmitExam();
            return 0;
          }
          return t - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [timerActive, timeRemaining]);

  const handleFileUpload = async (event) => {
    const files = Array.from(event.target.files || []);
    if (files.length === 0) return;

    setUploading(true);
    try {
      const fileUrls = [];
      for (let file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        fileUrls.push({ name: file.name, url: file_url });
      }
      setUploadedFiles([...uploadedFiles, ...fileUrls]);
      alert(`✅ ${files.length} bestand(en) geüpload!`);
    } catch (error) {
      alert("❌ Upload mislukt: " + error.message);
    } finally {
      event.target.value = ''; // Clear file input
      setUploading(false);
    }
  };

  const removeFile = (index) => {
    setUploadedFiles(uploadedFiles.filter((_, i) => i !== index));
  };

  const getDifficultySettings = (level) => {
    const settings = {
      basic: { questions: 8, timeMinutes: 45, passingScore: 55 },
      intermediate: { questions: 12, timeMinutes: 90, passingScore: 60 },
      advanced: { questions: 15, timeMinutes: 120, passingScore: 65 },
      extreme: { questions: 20, timeMinutes: 150, passingScore: 70 }
    };
    return settings[level] || settings.basic;
  };

  const handleGenerateExam = async () => {
    if (!difficulty) {
      alert("⚠️ Selecteer een moeilijkheidsgraad!");
      return;
    }

    if (!subject.trim()) {
      alert("⚠️ Voer het VAK in (bijv. Economie, Marketing, Wiskunde)!");
      return;
    }

    if (uploadedFiles.length === 0 && !examPrompt.trim() && !specificTopics.trim()) {
      alert("⚠️ Upload bestanden OF voer onderwerpen/beschrijving in!");
      return;
    }

    setGenerating(true);
    setGenerationProgress(0);
    setGenerationStep('🚀 Examen wordt voorbereid...');
    
    try {
      const settings = getDifficultySettings(difficulty);

      const updateProgress = (progress, step) => {
        setGenerationProgress(progress);
        setGenerationStep(step);
      };

      updateProgress(10, '📚 Bestanden en context analyseren...');
      await new Promise(resolve => setTimeout(resolve, 500));

      // Detect subject type
      const subjectLower = subject.toLowerCase();
      const isMath = subjectLower.includes('wiskunde') || subjectLower.includes('math') || 
                     subjectLower.includes('calculus') || subjectLower.includes('algebra') ||
                     subjectLower.includes('ingenieur') || subjectLower.includes('wis');
      const isMarketing = subjectLower.includes('marketing') || subjectLower.includes('sales') ||
                          subjectLower.includes('verkoop') || subjectLower.includes('reclame');
      const isEconomics = !isMarketing && (subjectLower.includes('econom') || subjectLower.includes('business') ||
                          subjectLower.includes('bedrijf'));
      const isScience = subjectLower.includes('physic') || subjectLower.includes('chemi') || 
                        subjectLower.includes('biology') || subjectLower.includes('natuur') ||
                        subjectLower.includes('scheikunde') || subjectLower.includes('natuurkunde');

      updateProgress(20, '🎯 Examentype en niveau bepalen...');
      await new Promise(resolve => setTimeout(resolve, 300));

      // Build comprehensive context
      let examContext = `
===== EXAMEN CONTEXT =====
TYPE EXAMEN: ${examType.toUpperCase()}
${university ? `UNIVERSITEIT/HOGESCHOOL: ${university}` : ''}
${studyYear ? `STUDIEJAAR: ${studyYear}` : ''}
${specificTopics ? `SPECIFIEKE ONDERWERPEN: ${specificTopics}` : ''}
${examPrompt ? `EXTRA INSTRUCTIES: ${examPrompt}` : ''}

HULPMIDDELEN TOEGESTAAN:
${allowCalculator ? '✅ Rekenmachine' : '❌ Geen rekenmachine'}
${allowFormulaSheet ? '✅ Formuleblad' : '❌ Geen formuleblad'}
`;

      updateProgress(30, '🔍 Vakspecifieke instructies laden...');
      await new Promise(resolve => setTimeout(resolve, 300));

      let subjectInstructions = '';
      
      if (isMath) {
        subjectInstructions = `
===== ${subject.toUpperCase()} - UNIVERSITAIR NIVEAU =====

JE MAAKT EEN EXAMEN VOOR HET VAK: ${subject.toUpperCase()}
DIT IS EEN ${examType.toUpperCase()} VOOR UNIVERSITEIT/HOGESCHOOL

VERPLICHTE KENMERKEN VOOR WISKUNDE/EXACTE WETENSCHAPPEN:

1️⃣ GEBRUIK WISKUNDIGE NOTATIE:
   - Functies: f(x), g(x), h(t), sin(θ), cos(φ), e^x, ln(x), log(x)
   - Operatoren: ∫, d/dx, lim, Σ, ∏, ∇
   - Variabelen: x, y, z, t, θ, φ, λ, α, β
   
2️⃣ WISKUNDIGE CONCEPTEN:
   - Functies en grafieken
   - Afgeleiden en integralen
   - Limieten en reeksen
   - Differentiaalvergelijkingen
   - Lineaire algebra (matrices, vectoren)
   - Trigonometrie
   
3️⃣ UNIVERSITAIRE VRAAGSTELLING:
   - "Bereken de afgeleide van..."
   - "Los de vergelijking op..."
   - "Bepaal het domein van..."
   - "Bewijs dat..."
   - "Gegeven de functie f(x) = ..."
   
4️⃣ TABELLEN VOOR WISKUNDE:
   Voorbeeld:
   | x | f(x)=x² | f'(x) | f''(x) |
   |---|---------|-------|--------|
   | 0 |    0    |   0   |   2    |
   | 1 |    1    |   2   |   2    |
   
5️⃣ EENHEDEN VOOR WISKUNDE:
   - Geen euro's of stuks!
   - Wel: meter (m), seconde (s), radiaal (rad), newton (N)
   - Of dimensieloos bij zuivere wiskunde

🚫 VERBODEN VOOR WISKUNDE:
   ❌ NOOIT kosten/opbrengsten (TCK, TVK, TO)
   ❌ NOOIT breakeven of productie-aantallen
   ❌ NOOIT marketing/verkoop terminologie
   ❌ NOOIT bedrijfseconomische cases
`;

      } else if (isMarketing) {
        subjectInstructions = `
===== ${subject.toUpperCase()} - UNIVERSITAIR NIVEAU =====

JE MAAKT EEN EXAMEN VOOR HET VAK: ${subject.toUpperCase()}
DIT IS EEN ${examType.toUpperCase()} VOOR UNIVERSITEIT/HOGESCHOOL

VERPLICHTE KENMERKEN VOOR MARKETING:

1️⃣ MARKETING TERMINOLOGIE:
   - Digital: CTR, CPC, CPM, ROI, ROAS, bounce rate, conversion rate
   - Strategy: Segmentatie, targeting, positioning (STP)
   - Branding: Brand awareness, brand equity, brand loyalty
   - Content: Engagement rate, reach, impressions, virality
   - Consumer: Customer journey, touchpoints, buyer persona
   
2️⃣ MARKETING CONCEPTEN:
   - 4 P's: Product, Price, Place, Promotion
   - 7 P's: + People, Process, Physical Evidence
   - SWOT/PESTEL analyses
   - Porter's Five Forces
   - Ansoff Matrix
   - BCG Matrix
   
3️⃣ UNIVERSITAIRE VRAAGSTELLING:
   - "Analyseer de marketingstrategie..."
   - "Bereken de ROI van campagne..."
   - "Welke segmentatiestrategie..."
   - "Bepaal de optimale marketing mix..."
   
4️⃣ TABELLEN VOOR MARKETING:
   Voorbeeld:
   | Campagne | Impressions | Clicks | CTR | Cost | Conversies | CPA |
   |----------|-------------|--------|-----|------|------------|-----|
   | Social   | 50.000      | 2.500  | 5%  | €500 | 125        | €4  |
   
5️⃣ METRICS VOOR MARKETING:
   - Engagement rate, reach, conversion rate
   - Customer lifetime value (CLV)
   - Cost per acquisition (CPA)
   - Return on ad spend (ROAS)

🚫 VERBODEN VOOR MARKETING:
   ❌ NOOIT zuivere productiekosten (TCK, TVK, GCK)
   ❌ NOOIT basis breakeven zonder marketing context
   ❌ NOOIT wiskundige functies (f(x), integralen)
`;

      } else if (isEconomics) {
        subjectInstructions = `
===== ${subject.toUpperCase()} - UNIVERSITAIR NIVEAU =====

JE MAAKT EEN EXAMEN VOOR HET VAK: ${subject.toUpperCase()}
DIT IS EEN ${examType.toUpperCase()} VOOR UNIVERSITEIT/HOGESCHOOL

VERPLICHTE KENMERKEN VOOR ECONOMIE:

1️⃣ ECONOMISCHE TERMINOLOGIE:
   - Kosten: TCK, TVK, TK, GCK, GVK, GTK, MK
   - Opbrengsten: TO, GO, MO
   - Winst: TW, GW
   - Markt: Vraag, aanbod, elasticiteit
   
2️⃣ ECONOMISCHE CONCEPTEN:
   - Breakeven analyse
   - Winstmaximalisatie
   - Marktvormen (volkomen concurrentie, monopolie)
   - Supply & demand curves
   - Elasticiteit
   
3️⃣ TABELLEN VOOR ECONOMIE:
   | Productie (Q) | TCK (€) | TVK (€) | TK (€) | GCK | GVK | GTK | MK | TO (€) |
   |---------------|---------|---------|--------|-----|-----|-----|----|----|-------|
   | 0             | 1.200   | 0       | 1.200  | -   | -   | -   | -  | 0      |
`;

      } else if (isScience) {
        subjectInstructions = `
===== ${subject.toUpperCase()} - UNIVERSITAIR NIVEAU =====

JE MAAKT EEN EXAMEN VOOR HET VAK: ${subject.toUpperCase()}
DIT IS EEN ${examType.toUpperCase()} VOOR UNIVERSITEIT/HOGESCHOOL

VERPLICHTE KENMERKEN VOOR NATUURWETENSCHAPPEN:

1️⃣ WETENSCHAPPELIJKE TERMINOLOGIE:
   - Metingen, experimenten, hypotheses
   - Formules uit natuurkunde/scheikunde
   - Wetenschappelijke notatie
   
2️⃣ TABELLEN MET EXPERIMENTELE DATA:
   | Experiment | Temperatuur (°C) | Druk (bar) | Resultaat |
   |------------|------------------|------------|-----------|
   | A          | 25               | 1.0        | ...       |
`;
      }

      updateProgress(40, `✍️ ${settings.questions} ${subject} vragen genereren...`);

      // ULTRA STRICT PROMPT
      let prompt = `
🎓 JE BENT EEN UNIVERSITEITSPROFESSOR IN ${subject.toUpperCase()}
📝 JE MAAKT NU EEN OFFICIEEL ${examType.toUpperCase()}

${examContext}

${uploadedFiles.length > 0 ? `
🔴🔴🔴 KRITIEK - LEES DIT ZORGVULDIG 🔴🔴🔴

JE HEBT ${uploadedFiles.length} BESTAND(EN) ONTVANGEN VAN DE STUDENT.
DEZE BESTANDEN BEVATTEN DE STUDIESTOF VOOR ${subject.toUpperCase()}.

VERPLICHT:
✅ ALLE ${settings.questions} VRAGEN MOETEN 100% GEBASEERD ZIJN OP DEZE BESTANDEN
✅ GEBRUIK EXACTE FORMULES, TABELLEN, VOORBEELDEN UIT DE BESTANDEN
✅ GEEN ALGEMENE VRAGEN - ALLEEN UIT DE GEÜPLOADE BESTANDEN!

Bestanden:
${uploadedFiles.map((f, i) => `${i + 1}. ${f.name}`).join('\n')}
` : ''}

${subjectInstructions}

===== EXAMEN SPECIFICATIES =====
VAK: ${subject.toUpperCase()}
AANTAL VRAGEN: ${settings.questions} (NIET MINDER, NIET MEER - EXACT ${settings.questions}!)
TIJD: ${settings.timeMinutes} minuten
SLAGINGSEIS: ${settings.passingScore}%

===== VRAAG VERDELING =====
Maak EXACT deze aantallen:
- ${Math.ceil(settings.questions * 0.30)} TABELLEN/DATA VRAGEN (30%)
- ${Math.ceil(settings.questions * 0.25)} BEREKENINGEN MET MEERDERE DELEN (25%)
- ${Math.ceil(settings.questions * 0.25)} CASE STUDIES (25%)  
- ${Math.floor(settings.questions * 0.20)} GRAFIEK/ANALYSE VRAGEN (20%)

TOTAAL = ${settings.questions} VRAGEN

===== VRAAG STRUCTUUR =====

ELKE vraag heeft deze structuur:

{
  "question_type": "data_table_complex" | "calculation_multipart" | "graph_analysis" | "case_study_academic",
  
  "exercise_number": "Opgave [nummer] - ${subject}",
  
  "context": "Minimaal 10 regels uitgebreide context specifiek voor ${subject}. Geef ALLE benodigde informatie.",
  
  "table_data": {
    "headers": ["relevante kolommen voor ${subject}"],
    "rows": [
      ["waarde1", "waarde2", ...],
      ["waarde1", "waarde2", ...]
    ]
  },
  
  "sub_questions": [
    {
      "number": 1,
      "question": "Concrete vraag",
      "answer_type": "number" | "text",
      "unit": "juiste eenheid voor ${subject}",
      "correct_answer": 123.45,
      "tolerance": 5,
      "explanation": "Hoe kom je aan dit antwoord",
      "points": 3
    }
  ],
  
  "total_points": [som van alle sub_questions.points]
}

===== JSON OUTPUT FORMAT =====
{
  "exam_title": "Tentamen ${subject.toUpperCase()}",
  "subtitle": "${examType} - Academiejaar ${new Date().getFullYear()}",
  "subject": "${subject.toUpperCase()}",
  "total_time_minutes": ${settings.timeMinutes},
  "passing_score": ${settings.passingScore},
  "total_points": [bereken totaal van alle questions.total_points],
  "questions": [
    ... EXACT ${settings.questions} vragen ...
    ... nummering: Opgave 1, Opgave 2, ... Opgave ${settings.questions} ...
  ]
}

===== FINALE VERIFICATIE =====
Voor je de output geeft, check:
✅ Aantal vragen = ${settings.questions} (tel ze!)
✅ Alle vragen passen bij ${subject.toUpperCase()}
✅ ${uploadedFiles.length > 0 ? 'Alle vragen komen uit de bestanden' : 'Vragen zijn universitair niveau'}
✅ Correcte terminologie voor ${subject}
✅ Alle sub_questions hebben points
✅ total_points is correct berekend

START NU MET HET MAKEN VAN ${settings.questions} VRAGEN!
`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        file_urls: uploadedFiles.length > 0 ? uploadedFiles.map(f => f.url) : undefined,
        response_json_schema: {
          type: "object",
          properties: {
            exam_title: { type: "string" },
            subtitle: { type: "string" },
            subject: { type: "string" },
            total_time_minutes: { type: "number" },
            passing_score: { type: "number" },
            total_points: { type: "number" },
            questions: {
              type: "array",
              minItems: settings.questions,
              maxItems: settings.questions,
              items: {
                type: "object",
                properties: {
                  question_type: {
                    type: "string",
                    enum: ["data_table_complex", "calculation_multipart", "graph_analysis", "case_study_academic"]
                  },
                  exercise_number: { type: "string" },
                  context: { type: "string" },
                  table_title: { type: "string" },
                  case_title: { type: "string" },
                  table_data: {
                    type: "object",
                    properties: {
                      headers: { type: "array", items: { type: "string" } },
                      rows: { 
                        type: "array",
                        items: {
                          type: "array",
                          items: { type: "string" }
                        }
                      }
                    }
                  },
                  graph_description: { type: "string" },
                  question: { type: "string" },
                  options: { type: "array", items: { type: "string" } },
                  correct_answer: { anyOf: [{ type: "number" }, { type: "string" }] },
                  explanation: { type: "string" },
                  sub_questions: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        number: { type: "number" },
                        question: { type: "string" },
                        answer_type: { type: "string" },
                        unit: { type: "string" },
                        options: { type: "array", items: { type: "string" } },
                        correct_answer: { anyOf: [{ type: "number" }, { type: "string" }] },
                        tolerance: { type: "number" },
                        explanation: { type: "string" },
                        points: { type: "number" }
                      },
                      required: ["number", "question", "points"]
                    }
                  },
                  total_points: { type: "number" },
                  points: { type: "number" }
                },
                required: ["question_type", "exercise_number", "context"]
              }
            }
          },
          required: ["exam_title", "subject", "total_time_minutes", "passing_score", "total_points", "questions"]
        }
      });

      updateProgress(80, '🔍 Examen wordt gecontroleerd...');
      await new Promise(resolve => setTimeout(resolve, 500));

      if (!response || !response.questions || response.questions.length === 0) {
        throw new Error("AI genereerde geen vragen");
      }

      updateProgress(90, '✅ Laatste controles...');
      await new Promise(resolve => setTimeout(resolve, 300));

      if (response.questions.length < settings.questions) {
        throw new Error(`FOUT: Slechts ${response.questions.length}/${settings.questions} vragen gegenereerd!\n\n` +
          `Mogelijke oorzaken:\n` +
          `• De geüploade bestanden bevatten niet genoeg informatie\n` +
          `• De AI kon de bestanden niet goed lezen\n• Het onderwerp is te complex\n\n` +
          `Probeer:\n` +
          `✅ Upload meer of betere bestanden met studiestof\n` +
          `✅ Voeg specifieke onderwerpen toe in het tekstveld\n` +
          `✅ Kies een lagere moeilijkheidsgraad (minder vragen)\n` +
          `✅ Probeer opnieuw`);
      }

      setExam(response);
      setStep("exam");
      setTimeRemaining(response.total_time_minutes * 60);
      
      updateProgress(100, '🎉 Examen klaar!');
      
      alert(`✅ ${subject.toUpperCase()} EXAMEN SUCCESVOL GEGENEREERD!\n\n` +
            `📊 ${response.questions.length} vragen (${examType})\n` +
            `⭐ ${response.total_points} punten totaal\n` +
            `⏰ ${response.total_time_minutes} minuten\n` +
            `📈 Slagingseis: ${response.passing_score}%\n\n` +
            `Veel succes! 🚀`);
      
    } catch (error) {
      console.error("Generation error:", error);
      setGenerationProgress(0);
      setGenerationStep('');
      alert("❌ FOUT BIJ GENEREREN:\n\n" + error.message);
    } finally {
      setGenerating(false);
      setGenerationProgress(0);
      setGenerationStep('');
    }
  };

  const handleStartExam = () => {
    setExamStarted(true);
    setTimerActive(true);
  };

  const handleAnswerSelect = (key, value) => {
    setUserAnswers({
      ...userAnswers,
      [key]: value
    });
  };

  const handleSubmitExam = () => {
    setTimerActive(false);

    let totalPointsEarned = 0;
    const questionResults = exam.questions.map((q, qIdx) => {
      let questionScore = 0;
      let maxPoints = q.total_points || q.points || 1;
      
      const subResults = [];

      if (q.sub_questions) {
        q.sub_questions.forEach((subQ, subIdx) => {
          const answerKey = `${qIdx}_${subIdx}`;
          const userAnswer = userAnswers[answerKey];
          let isCorrect = false;

          if (subQ.answer_type === "number") {
            const userNum = parseFloat(userAnswer);
            const correctNum = parseFloat(subQ.correct_answer);
            const tolerance = subQ.tolerance || 0;
            
            if (!isNaN(userNum) && !isNaN(correctNum)) {
              isCorrect = Math.abs(userNum - correctNum) <= tolerance;
            }
          } else if (subQ.options) {
            isCorrect = userAnswer === subQ.correct_answer;
          } else { // Assume text if not number or options
            isCorrect = String(userAnswer).toLowerCase() === String(subQ.correct_answer).toLowerCase();
          }

          if (isCorrect) {
            questionScore += subQ.points;
          }

          subResults.push({
            number: subQ.number,
            question: subQ.question,
            userAnswer: userAnswer || "Niet beantwoord",
            correctAnswer: subQ.correct_answer,
            isCorrect,
            points: subQ.points,
            unit: subQ.unit
          });
        });
      } else {
        const userAnswer = userAnswers[qIdx];
        let isCorrect = false;
        
        if (q.options) {
          isCorrect = userAnswer === q.correct_answer;
        } else { // Assume text if no sub_questions and no options
          isCorrect = String(userAnswer).toLowerCase() === String(q.correct_answer).toLowerCase();
        }
        
        if (isCorrect) {
          questionScore = maxPoints;
        }

        subResults.push({
          question: q.question,
          userAnswer: userAnswer !== undefined ? (q.options ? q.options[userAnswer] : userAnswer) : "Niet beantwoord",
          correctAnswer: q.options ? q.options[q.correct_answer] : q.correct_answer,
          isCorrect,
          points: maxPoints
        });
      }

      totalPointsEarned += questionScore;

      return {
        ...q,
        subResults,
        earnedPoints: questionScore,
        maxPoints
      };
    });

    const percentage = Math.round((totalPointsEarned / exam.total_points) * 100);
    const passed = percentage >= exam.passing_score;

    setResults({
      percentage,
      totalPointsEarned,
      totalPoints: exam.total_points,
      passed,
      passingScore: exam.passing_score,
      questionResults
    });

    setStep("results");
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const resetExam = () => {
    setStep("setup");
    setDifficulty("");
    setSubject("");
    setExamPrompt("");
    setUploadedFiles([]);
    setExam(null);
    setCurrentQuestion(0);
    setUserAnswers({});
    setTimeRemaining(0);
    setTimerActive(false);
    setExamStarted(false);
    setResults(null);
    // NEW: Reset new state variables
    setExamType("tentamen");
    setUniversity("");
    setStudyYear("");
    setSpecificTopics("");
    setAllowCalculator(false);
    setAllowFormulaSheet(false);

    if (document.exitFullscreen) {
      document.exitFullscreen();
    }
  };

  // Setup Screen
  if (step === "setup") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 p-4 lg:p-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-block mb-6">
              <div className="w-24 h-24 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-3xl flex items-center justify-center shadow-2xl transform rotate-3 animate-pulse">
                <GraduationCap className="w-14 h-14 text-white transform -rotate-3" />
              </div>
            </div>
            <h1 className="text-5xl lg:text-6xl font-bold text-white mb-4">
              🎯 Exam Focus Space
            </h1>
            <p className="text-2xl text-white/90 mb-2">Persoonlijke Universitaire Examens</p>
            <Badge className="bg-green-500 text-white text-lg px-6 py-2">
              <Sparkles className="w-5 h-5 mr-2" />
              VERNIEUWD - Nog realistischer!
            </Badge>
          </div>

          <Card className="border-none shadow-xl bg-white/10 backdrop-blur-xl mb-8">
            <CardContent className="p-8 space-y-6">
              {/* Stap 1: Basis Info */}
              <div className="bg-white/10 rounded-xl p-6 border-2 border-white/20">
                <h3 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                  <span className="bg-blue-500 text-white w-8 h-8 rounded-full flex items-center justify-center">1</span>
                  Basis Informatie
                </h3>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white text-lg mb-2 block">Vak (VERPLICHT) ⭐</Label>
                    <Input
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      placeholder="bijv. Wiskunde, Marketing, Economie..."
                      className="text-xl p-6 bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                    />
                  </div>
                  
                  <div>
                    <Label className="text-white text-lg mb-2 block">Type Examen</Label>
                    <Select value={examType} onValueChange={setExamType}>
                      <SelectTrigger className="text-xl p-6 bg-slate-700 border-slate-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="tentamen">Tentamen</SelectItem>
                        <SelectItem value="deeltentamen">Deeltentamen</SelectItem>
                        <SelectItem value="hertentamen">Hertentamen</SelectItem>
                        <SelectItem value="oefententamen">Oefententamen</SelectItem>
                        <SelectItem value="tussentoets">Tussentoets</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 gap-4 mt-4">
                  <div>
                    <Label className="text-white text-lg mb-2 block">Universiteit/Hogeschool (Optioneel)</Label>
                    <Input
                      value={university}
                      onChange={(e) => setUniversity(e.target.value)}
                      placeholder="bijv. TU Delft, Erasmus, HvA..."
                      className="p-4 bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                    />
                  </div>
                  
                  <div>
                    <Label className="text-white text-lg mb-2 block">Studiejaar (Optioneel)</Label>
                    <Select value={studyYear} onValueChange={setStudyYear}>
                      <SelectTrigger className="p-4 bg-slate-700 border-slate-600 text-white">
                        <SelectValue placeholder="Selecteer..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">Jaar 1 (Bachelor)</SelectItem>
                        <SelectItem value="2">Jaar 2 (Bachelor)</SelectItem>
                        <SelectItem value="3">Jaar 3 (Bachelor)</SelectItem>
                        <SelectItem value="4">Jaar 4 (Bachelor)</SelectItem>
                        <SelectItem value="master1">Jaar 1 (Master)</SelectItem>
                        <SelectItem value="master2">Jaar 2 (Master)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              {/* Stap 2: Moeilijkheidsgraad */}
              <div className="bg-white/10 rounded-xl p-6 border-2 border-white/20">
                <h3 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                  <span className="bg-purple-500 text-white w-8 h-8 rounded-full flex items-center justify-center">2</span>
                  Moeilijkheidsgraad
                </h3>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { value: "basic", label: "Basic", icon: "📚", desc: "8 vragen - 45 min", color: "from-green-500 to-emerald-600" },
                    { value: "intermediate", label: "Intermediate", icon: "📖", desc: "12 vragen - 90 min", color: "from-blue-500 to-cyan-600" },
                    { value: "advanced", label: "Advanced", icon: "🎓", desc: "15 vragen - 120 min", color: "from-orange-500 to-red-600" },
                    { value: "extreme", label: "Extreme", icon: "🔥", desc: "20 vragen - 150 min", color: "from-purple-500 to-pink-600" }
                  ].map(level => (
                    <button
                      key={level.value}
                      onClick={() => setDifficulty(level.value)}
                      className={`p-6 rounded-2xl text-center transition-all transform hover:scale-105 ${
                        difficulty === level.value
                          ? `bg-gradient-to-br ${level.color} shadow-2xl ring-4 ring-white`
                          : 'bg-white/20 hover:bg-white/30'
                      }`}
                    >
                      <div className="text-5xl mb-2">{level.icon}</div>
                      <p className="text-xl font-bold text-white mb-1">{level.label}</p>
                      <p className="text-sm text-white/80">{level.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Stap 3: Specifieke Onderwerpen */}
              <div className="bg-white/10 rounded-xl p-6 border-2 border-white/20">
                <h3 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                  <span className="bg-yellow-500 text-white w-8 h-8 rounded-full flex items-center justify-center">3</span>
                  Specifieke Onderwerpen (STERK AANBEVOLEN)
                </h3>
                
                <Textarea
                  value={specificTopics}
                  onChange={(e) => setSpecificTopics(e.target.value)}
                  placeholder="Welke specifieke onderwerpen/hoofdstukken moeten in het examen komen?&#10;&#10;Bijvoorbeeld:&#10;• Hoofdstuk 3: Differentiaalrekening&#10;• Integralen en limieten&#10;• Toepassingen van afgeleiden&#10;&#10;Hoe specifieker, hoe beter!"
                  rows={5}
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 text-base"
                  disabled={generating}
                />
              </div>

              {/* Stap 4: Extra Details */}
              <div className="bg-white/10 rounded-xl p-6 border-2 border-white/20">
                <h3 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                  <span className="bg-pink-500 text-white w-8 h-8 rounded-full flex items-center justify-center">4</span>
                  Extra Instructies (Optioneel)
                </h3>
                
                <Textarea
                  value={examPrompt}
                  onChange={(e) => setExamPrompt(e.target.value)}
                  placeholder="Andere instructies of details..."
                  rows={3}
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                  disabled={generating}
                />
                
                <div className="flex gap-4 mt-4">
                  <label className="flex items-center gap-2 text-white cursor-pointer">
                    <input
                      type="checkbox"
                      checked={allowCalculator}
                      onChange={(e) => setAllowCalculator(e.target.checked)}
                      className="w-5 h-5"
                      disabled={generating}
                    />
                    <span>🔢 Rekenmachine toegestaan</span>
                  </label>
                  
                  <label className="flex items-center gap-2 text-white cursor-pointer">
                    <input
                      type="checkbox"
                      checked={allowFormulaSheet}
                      onChange={(e) => setAllowFormulaSheet(e.target.checked)}
                      className="w-5 h-5"
                      disabled={generating}
                    />
                    <span>📋 Formuleblad toegestaan</span>
                  </label>
                </div>
              </div>

              {/* Stap 5: Upload Studiemateriaal */}
              <div className="bg-white/10 rounded-xl p-6 border-2 border-white/20">
                <h3 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                  <span className="bg-red-500 text-white w-8 h-8 rounded-full flex items-center justify-center">5</span>
                  Upload Studiemateriaal (STERK AANBEVOLEN ⭐)
                </h3>
                
                <input
                  type="file"
                  multiple
                  onChange={handleFileUpload}
                  className="hidden"
                  id="exam-file-upload"
                  accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png,.xlsx,.xls,.csv"
                  disabled={uploading || generating}
                />
                <label
                  htmlFor="exam-file-upload"
                  className={`block border-4 border-dashed rounded-2xl p-8 text-center transition-all ${
                    uploading || generating
                      ? 'opacity-50 border-slate-300 cursor-not-allowed' 
                      : 'border-blue-300 hover:border-blue-500 hover:bg-blue-50/10 cursor-pointer'
                  }`}
                >
                  {uploading ? (
                    <Loader2 className="w-12 h-12 text-white mx-auto mb-3 animate-spin" />
                  ) : (
                    <>
                      <Upload className="w-12 h-12 text-blue-400 mx-auto mb-3" />
                      <p className="text-lg font-semibold text-white">Klik om te uploaden</p>
                      <p className="text-sm text-white/70 mt-1">Syllabus, slides, samenvatting, oefeningen</p>
                      <p className="text-xs text-yellow-300 mt-2">💡 Upload voor EXACTE vragen uit jouw studiemateriaal!</p>
                    </>
                  )}
                </label>

                {uploadedFiles.length > 0 && (
                  <div className="mt-4 space-y-2">
                    {uploadedFiles.map((file, idx) => (
                      <div key={idx} className="flex items-center justify-between bg-blue-50/10 rounded-lg p-3 border border-blue-200/20">
                        <div className="flex items-center gap-3">
                          <FileText className="w-5 h-5 text-blue-400" />
                          <span className="font-medium text-white">{file.name}</span>
                        </div>
                        <Button
                          onClick={() => removeFile(idx)}
                          variant="ghost"
                          size="sm"
                          className="text-red-400 hover:bg-red-500/50"
                          disabled={generating}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Generate Button */}
              <Button
                onClick={handleGenerateExam}
                disabled={generating || !difficulty || !subject.trim()}
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white py-8 text-2xl font-bold shadow-2xl"
                size="lg"
              >
                {generating ? (
                  <>
                    <Loader2 className="w-8 h-8 mr-4 animate-spin" />
                    Examen wordt gegenereerd...
                  </>
                ) : (
                  <>
                    <Zap className="w-8 h-8 mr-3" />
                    Genereer {subject.toUpperCase() || 'Mijn'} Examen!
                  </>
                )}
              </Button>

              {(!difficulty || !subject.trim()) && (
                <Alert className="bg-yellow-500/20 border-yellow-400">
                  <AlertCircle className="w-5 h-5 text-yellow-300" />
                  <AlertDescription className="text-white text-lg">
                    {!subject.trim() ? '⚠️ Voer eerst het VAK in!' : '⚠️ Kies een moeilijkheidsgraad'}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </div>

        {/* PROGRESS MODAL */}
        {generating && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[9999] flex items-center justify-center p-4">
            <Card className="max-w-2xl w-full bg-slate-900/95 border-slate-700 shadow-2xl">
              <CardContent className="p-8 md:p-12">
                <div className="text-center mb-8">
                  <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
                    <Brain className="w-10 h-10 text-white animate-bounce" />
                  </div>
                  <h2 className="text-3xl font-bold text-white mb-3">
                    {subject} Examen wordt gegenereerd...
                  </h2>
                  <p className="text-xl text-slate-300 mb-8">{generationStep}</p>
                </div>

                <div className="space-y-4">
                  <div className="relative w-full h-4 bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className="absolute top-0 left-0 h-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 transition-all duration-500 ease-out"
                      style={{ width: `${generationProgress}%` }}
                    >
                      <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                    </div>
                  </div>
                  
                  <div className="flex justify-between text-sm text-slate-400">
                    <span>Voortgang</span>
                    <span className="font-bold text-white">{generationProgress}%</span>
                  </div>
                </div>

                <div className="mt-8 p-6 bg-blue-900/30 rounded-xl border border-blue-700">
                  <p className="text-blue-200 text-center text-sm">
                    💡 <strong>Geduld:</strong> Universitaire examens genereren duurt 15-45 seconden
                  </p>
                </div>

                <div className="mt-6 flex items-center justify-center gap-2 text-slate-500 text-sm">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Even geduld, de AI professor is aan het werk...</span>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    );
  }

  // Exam intro
  if (step === "exam" && !examStarted) {
    return (
      <div className="fixed inset-0 bg-black z-[9999] flex items-center justify-center p-8">
        <Card className="max-w-3xl w-full bg-slate-900 border-slate-700 shadow-2xl">
          <CardContent className="p-12 text-center">
            <Timer className="w-24 h-24 text-yellow-400 mx-auto mb-8" />
            <h1 className="text-5xl font-bold text-white mb-4">{exam.exam_title}</h1>
            {exam.subtitle && <p className="text-2xl text-slate-400 mb-6">{exam.subtitle}</p>}
            <Badge className="text-2xl px-8 py-3 bg-blue-600 text-white mb-8">
              {exam.subject}
            </Badge>

            <div className="grid grid-cols-3 gap-6 my-8">
              <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
                <p className="text-slate-400 mb-2">Aantal Vragen</p>
                <p className="text-4xl font-bold text-white">{exam.questions.length}</p>
              </div>
              <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
                <p className="text-slate-400 mb-2">Totaal Punten</p>
                <p className="text-4xl font-bold text-white">{exam.total_points}</p>
              </div>
              <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
                <p className="text-slate-400 mb-2">Tijd</p>
                <p className="text-4xl font-bold">{exam.total_time_minutes} min</p>
              </div>
            </div>

            <Alert className="bg-red-900/50 border-red-700 mb-8">
              <AlertCircle className="w-6 h-6 text-red-400" />
              <AlertDescription className="text-white text-lg">
                <strong>Belangrijk:</strong> Zodra je start, begint de timer. Druk ESC om te stoppen. Slagingspercentage: {exam.passing_score}%
              </AlertDescription>
            </Alert>

            <Button
              onClick={handleStartExam}
              className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-12 py-8 text-2xl font-bold shadow-2xl"
              size="lg"
            >
              <Zap className="w-8 h-8 mr-3" />
              Start Examen
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Active exam - FULLSCREEN
  if (step === "exam" && examStarted) {
    const currentQ = exam.questions[currentQuestion];
    const progress = ((currentQuestion + 1) / exam.questions.length) * 100;

    return (
      <div className="fixed inset-0 bg-white z-[9999] overflow-auto">
        {/* Top Bar - Academic Style */}
        <div className="bg-slate-100 border-b-2 border-slate-300 p-4 sticky top-0 z-10">
          <div className="max-w-5xl mx-auto flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-slate-900">{exam.exam_title}</h1>
              <p className="text-sm text-slate-600">{exam.subtitle}</p>
            </div>
            <div className={`px-6 py-3 rounded-lg ${
              timeRemaining < 300 ? 'bg-red-600 text-white animate-pulse' : 'bg-slate-800 text-white'
            }`}>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                <div>
                  <p className="text-xs opacity-80">Tijd Over</p>
                  <p className="text-2xl font-bold">{formatTime(timeRemaining)}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Progress */}
        <div className="max-w-5xl mx-auto p-6">
          <div className="mb-6">
            <div className="flex justify-between text-sm mb-2">
              <span className="font-semibold">Vraag {currentQuestion + 1} van {exam.questions.length}</span>
              <span className="font-bold text-blue-600">{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-3" />
          </div>

          {/* Question Card - Academic Style */}
          <Card className="border-2 border-slate-300 shadow-lg mb-6 bg-white">
            <CardContent className="p-8">
              {/* Exercise Number */}
              {currentQ.exercise_number && (
                <div className="mb-6 pb-4 border-b-2 border-slate-200">
                  <h2 className="text-2xl font-bold text-slate-900">{currentQ.exercise_number}</h2>
                  {currentQ.case_title && <p className="text-lg text-slate-700 mt-1">{currentQ.case_title}</p>}
                  <Badge className="mt-2 bg-blue-600 text-white">
                    {currentQ.total_points || currentQ.points} {(currentQ.total_points || currentQ.points) === 1 ? 'punt' : 'punten'}
                  </Badge>
                </div>
              )}

              {/* Context */}
              {currentQ.context && (
                <div className="mb-6 p-4 bg-slate-50 border-l-4 border-blue-500 rounded">
                  <p className="text-base text-slate-800 leading-relaxed whitespace-pre-wrap">{currentQ.context}</p>
                </div>
              )}

              {/* Data Table */}
              {currentQ.table_data && (
                <div className="mb-6">
                  {currentQ.table_title && <h3 className="font-bold text-lg mb-3">{currentQ.table_title}</h3>}
                  <div className="overflow-x-auto border-2 border-slate-300 rounded-lg">
                    <table className="w-full">
                      <thead className="bg-slate-200">
                        <tr>
                          {currentQ.table_data.headers?.map((header, idx) => (
                            <th key={idx} className="p-3 text-left font-bold text-sm border-r border-slate-300 last:border-r-0">
                              {header}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {currentQ.table_data.rows?.map((row, rowIdx) => (
                          <tr key={rowIdx} className="border-b border-slate-200 last:border-b-0">
                            {row.map((cell, cellIdx) => (
                              <td key={cellIdx} className="p-3 text-sm border-r border-slate-200 last:border-r-0">
                                {cell}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Graph Description */}
              {currentQ.graph_description && (
                <div className="mb-6 p-4 bg-blue-50 border-2 border-blue-300 rounded-lg">
                  <h3 className="font-bold mb-2 text-blue-900">📈 Grafiek:</h3>
                  <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-wrap">{currentQ.graph_description}</p>
                </div>
              )}

              {/* Sub-questions */}
              {currentQ.sub_questions && (
                <div className="space-y-6">
                  {currentQ.sub_questions.map((subQ, subIdx) => (
                    <div key={subIdx} className="p-4 bg-slate-50 rounded-lg border border-slate-300">
                      <div className="flex items-start gap-2 mb-3">
                        <Badge className="bg-slate-700 text-white">{subQ.number || subIdx + 1}</Badge>
                        <div className="flex-1">
                          <p className="font-semibold text-slate-900 mb-1">{subQ.question}</p>
                          <Badge variant="outline" className="text-xs">
                            {subQ.points} {subQ.points === 1 ? 'punt' : 'punten'}
                          </Badge>
                        </div>
                      </div>

                      {subQ.options ? (
                        <div className="space-y-2">
                          {subQ.options.map((option, optIdx) => (
                            <label
                              key={optIdx}
                              className={`flex items-center p-3 rounded-lg border-2 cursor-pointer transition-all ${
                                userAnswers[`${currentQuestion}_${subIdx}`] === optIdx
                                  ? 'border-blue-500 bg-blue-50'
                                  : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50'
                              }`}
                            >
                              <input
                                type="radio"
                                name={`q${currentQuestion}_${subIdx}`}
                                checked={userAnswers[`${currentQuestion}_${subIdx}`] === optIdx}
                                onChange={() => handleAnswerSelect(`${currentQuestion}_${subIdx}`, optIdx)}
                                className="mr-3 w-4 h-4"
                              />
                              <span className="text-sm">{option}</span>
                            </label>
                          ))}
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <Input
                            type={subQ.answer_type === "number" ? "number" : "text"}
                            step={subQ.answer_type === "number" ? "0.01" : undefined}
                            value={userAnswers[`${currentQuestion}_${subIdx}`] || ''}
                            onChange={(e) => handleAnswerSelect(`${currentQuestion}_${subIdx}`, e.target.value)}
                            placeholder={subQ.answer_type === "number" ? "0" : "Type antwoord..."}
                            className="flex-1 border-2 border-slate-300 text-lg p-3"
                          />
                          {subQ.unit && (
                            <span className="text-lg font-semibold text-slate-700 px-2">{subQ.unit}</span>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Single question (no sub-questions) */}
              {!currentQ.sub_questions && currentQ.question && (
                <div className="mb-6">
                  <p className="font-semibold text-lg text-slate-900 mb-4">{currentQ.question}</p>
                  {currentQ.options ? (
                    <div className="space-y-2">
                      {currentQ.options.map((option, idx) => (
                        <label
                          key={idx}
                          className={`flex items-center p-4 rounded-lg border-2 cursor-pointer transition-all ${
                            userAnswers[currentQuestion] === idx
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50'
                          }`}
                        >
                          <input
                            type="radio"
                            name={`q${currentQuestion}`}
                            checked={userAnswers[currentQuestion] === idx}
                            onChange={() => handleAnswerSelect(currentQuestion, idx)}
                            className="mr-3 w-4 h-4"
                          />
                          <span className="text-sm">{option}</span>
                        </label>
                      ))}
                    </div>
                  ) : (
                    <Input
                      value={userAnswers[currentQuestion] || ''}
                      onChange={(e) => handleAnswerSelect(currentQuestion, e.target.value)}
                      placeholder="Type antwoord..."
                      className="border-2 border-slate-300 text-lg p-4"
                    />
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex justify-between items-center">
            <Button
              onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
              disabled={currentQuestion === 0}
              variant="outline"
              className="border-2 px-8 py-6 text-lg"
              size="lg"
            >
              ← Vorige
            </Button>

            <div className="text-center">
              <p className="text-slate-600">
                Beantwoord: {Object.keys(userAnswers).length}
              </p>
            </div>

            {currentQuestion < exam.questions.length - 1 ? (
              <Button
                onClick={() => setCurrentQuestion(currentQuestion + 1)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg"
                size="lg"
              >
                Volgende →
              </Button>
            ) : (
              <Button
                onClick={handleSubmitExam}
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-8 py-6 text-lg font-bold"
                size="lg"
              >
                <CheckCircle2 className="w-6 h-6 mr-2" />
                Inleveren
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Results Screen
  if (step === "results") {
    return (
      <div className="fixed inset-0 bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 z-[9999] p-6 lg:p-8 overflow-auto">
        <div className="max-w-6xl mx-auto">
          <Card className={`bg-gradient-to-br ${
            results.passed ? 'from-green-600 to-emerald-600' : 'from-red-600 to-orange-600'
          } border-none shadow-2xl mb-8`}>
            <CardContent className="p-12 text-center">
              {results.passed ? (
                <CheckCircle2 className="w-24 h-24 text-white mx-auto mb-6" />
              ) : (
                <X className="w-24 h-24 text-white mx-auto mb-6" />
              )}
              <h1 className="text-6xl font-bold text-white mb-4">
                {results.passed ? '🎉 GESLAAGD!' : '📚 HELAAS...'}
              </h1>
              <p className="text-3xl text-white mb-8">
                Je hebt {results.passed ? 'het examen gehaald' : 'het examen niet gehaald'}
              </p>

              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <div className="bg-white/20 backdrop-blur-sm rounded-xl p-6">
                  <p className="text-white/80 mb-2">Jouw Score</p>
                  <p className="text-6xl font-bold text-white">{results.percentage}%</p>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-xl p-6">
                  <p className="text-white/80 mb-2">Slagingsgrens</p>
                  <p className="text-6xl font-bold text-white">{results.passingScore}%</p>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-xl p-6">
                  <p className="text-white/80 mb-2">Punten</p>
                  <p className="text-6xl font-bold text-white">{results.totalPointsEarned} / {results.totalPoints}</p>
                </div>
              </div>

              <Button
                onClick={resetExam}
                className="bg-white text-purple-900 hover:bg-white/90 px-12 py-6 text-xl font-bold"
                size="lg"
              >
                Nieuw Examen Maken
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/90 backdrop-blur-xl border-slate-700 shadow-2xl">
            <CardContent className="p-8">
              <h2 className="text-3xl font-bold text-white mb-8">📊 Gedetailleerde Uitslag</h2>

              <div className="space-y-6">
                {results.questionResults.map((result, idx) => (
                  <div key={idx} className={`rounded-xl p-6 border-2 ${
                    result.earnedPoints === result.maxPoints ? 'bg-green-900/30 border-green-500' : 'bg-red-900/30 border-red-500'
                  }`}>
                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-xl font-bold text-white">{result.exercise_number || `Vraag ${idx + 1}`}</h3>
                        <Badge className={result.earnedPoints === result.maxPoints ? 'bg-green-600' : 'bg-red-600'}>
                          {result.earnedPoints} / {result.maxPoints} punten
                        </Badge>
                      </div>
                      {result.context && (
                        <p className="text-sm text-white/80 mt-2 p-3 bg-slate-700/50 rounded">{result.context.substring(0, 200)}...</p>
                      )}
                    </div>

                    {result.subResults?.map((subRes, subIdx) => (
                      <div key={subIdx} className={`mb-4 p-4 rounded-lg ${subRes.isCorrect ? 'bg-green-800/20' : 'bg-red-800/20'}`}>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className="bg-slate-700 text-white">{subRes.number || subIdx + 1}</Badge>
                          <p className="text-white font-semibold">{subRes.question}</p>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="bg-slate-700/50 rounded p-3">
                            <p className="text-xs text-slate-300 mb-1">Jouw Antwoord:</p>
                            <p className={`font-semibold ${subRes.isCorrect ? 'text-green-300' : 'text-red-300'}`}>
                              {subRes.userAnswer} {subRes.unit && subRes.unit} {subRes.isCorrect ? '✓' : '✗'}
                            </p>
                          </div>
                          {!subRes.isCorrect && (
                            <div className="bg-slate-700/50 rounded p-3">
                              <p className="text-xs text-slate-300 mb-1">Correct Antwoord:</p>
                              <p className="font-semibold text-green-300">
                                {subRes.correctAnswer} {subRes.unit && subRes.unit} ✓
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}

                    {result.explanation && (
                      <div className="bg-blue-900/30 rounded p-4 border border-blue-500 mt-4">
                        <p className="text-sm text-blue-300 mb-1">💡 Uitleg:</p>
                        <p className="text-white text-sm">{result.explanation}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return null;
}
