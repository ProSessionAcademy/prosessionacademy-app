import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import { 
  ArrowLeft,
  ExternalLink, 
  AlertCircle,
  Loader2,
  Sparkles
} from 'lucide-react';

export default function ToolViewer() {
  const params = new URLSearchParams(window.location.search);
  const toolName = params.get('name') || 'Application';
  const toolUrl = params.get('url') || '';
  const toolColor = params.get('color') || 'from-blue-600 to-purple-600';
  const toolDescription = params.get('description') || 'Business application';
  
  const [loading, setLoading] = useState(true);
  const [showError, setShowError] = useState(false);

  useEffect(() => {
    // Give iframe 3 seconds to load, then assume it might be blocked
    const timer = setTimeout(() => {
      setLoading(false);
      setShowError(true);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="h-screen w-screen flex flex-col bg-slate-900">
      {/* Header */}
      <div className={`bg-gradient-to-r ${toolColor} text-white p-4 flex items-center justify-between shadow-xl z-50`}>
        <div className="flex items-center gap-3">
          <Link to={createPageUrl('ProfessionalSpace')}>
            <Button
              variant="ghost"
              size="icon"
              className="bg-white/20 hover:bg-white/30 text-white"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold">{toolName}</h1>
            <p className="text-sm text-white/90">{toolDescription}</p>
          </div>
        </div>
        <Button
          onClick={() => window.open(toolUrl, '_blank')}
          className="bg-white/20 hover:bg-white/30 text-white border border-white/30"
          size="sm"
        >
          <ExternalLink className="w-4 h-4 mr-2" />
          Open in New Tab
        </Button>
      </div>

      {/* Content Area */}
      <div className="flex-1 relative">
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-900 z-40">
            <div className="text-center text-white">
              <Loader2 className="w-16 h-16 animate-spin mx-auto mb-4" />
              <p className="text-xl">Loading {toolName}...</p>
            </div>
          </div>
        )}

        {showError && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-900 p-8">
            <Card className="max-w-2xl border-none shadow-2xl">
              <CardContent className="p-12 text-center">
                <div className={`w-24 h-24 bg-gradient-to-br ${toolColor} rounded-full flex items-center justify-center mx-auto mb-6`}>
                  <AlertCircle className="w-14 h-14 text-white" />
                </div>
                <h3 className="text-3xl font-bold mb-4 text-slate-900">Security Restriction</h3>
                <p className="text-slate-600 mb-6 leading-relaxed text-lg">
                  {toolName} cannot be embedded directly due to security policies (X-Frame-Options). 
                  This is a security feature by the application provider to protect your data.
                </p>
                <div className="space-y-3">
                  <Button
                    onClick={() => {
                      window.open(toolUrl, '_blank');
                    }}
                    className={`w-full bg-gradient-to-r ${toolColor} hover:opacity-90 text-white text-lg py-6`}
                    size="lg"
                  >
                    <ExternalLink className="w-6 h-6 mr-2" />
                    Open {toolName} in New Tab
                  </Button>
                  
                  <Link to={createPageUrl('ProfessionalSpace')}>
                    <Button
                      variant="outline"
                      className="w-full py-6"
                      size="lg"
                    >
                      <ArrowLeft className="w-5 h-5 mr-2" />
                      Back to Professional Space
                    </Button>
                  </Link>

                  <p className="text-sm text-slate-500 flex items-center justify-center gap-2 mt-4">
                    <Sparkles className="w-4 h-4" />
                    Tip: Keep this tab open and switch between tabs for seamless workflow
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Iframe - tries to load the tool */}
        <iframe
          src={toolUrl}
          className="w-full h-full border-0"
          title={toolName}
          onLoad={() => {
            setLoading(false);
            setShowError(false);
          }}
          onError={() => {
            setLoading(false);
            setShowError(true);
          }}
          sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads allow-modals allow-top-navigation allow-top-navigation-by-user-activation"
          allow="camera *; microphone *; clipboard-read *; clipboard-write *; geolocation *; fullscreen *; autoplay *; encrypted-media *; picture-in-picture *"
        />
      </div>
    </div>
  );
}