import React, { useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  ExternalLink, 
  Sparkles, 
  Zap,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';

export default function ToolLauncher() {
  const params = new URLSearchParams(window.location.search);
  const toolName = params.get('name') || 'Application';
  const toolUrl = params.get('url') || '';
  const toolColor = params.get('color') || 'from-blue-600 to-purple-600';
  const toolDescription = params.get('description') || 'Business application';

  // Auto-open the tool in a new window/tab
  useEffect(() => {
    if (toolUrl) {
      const newWindow = window.open(toolUrl, '_blank', 'noopener,noreferrer');
      
      // Focus the new window
      if (newWindow) {
        newWindow.focus();
      }
    }
  }, [toolUrl]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 flex items-center justify-center p-6">
      <Card className="max-w-2xl w-full border-none shadow-2xl bg-white/95 backdrop-blur-xl">
        <CardContent className="p-12">
          <div className="text-center space-y-6">
            <div className={`w-24 h-24 bg-gradient-to-br ${toolColor} rounded-3xl flex items-center justify-center mx-auto shadow-2xl`}>
              <Sparkles className="w-14 h-14 text-white" />
            </div>

            <div className="space-y-3">
              <h1 className="text-4xl font-black text-slate-900">
                Opening {toolName}
              </h1>
              <p className="text-lg text-slate-600">
                {toolDescription}
              </p>
            </div>

            <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-6 border-2 border-green-200">
              <div className="flex items-start gap-4">
                <CheckCircle2 className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />
                <div className="text-left">
                  <h3 className="font-bold text-green-900 text-lg mb-2">
                    {toolName} is opening in a new window
                  </h3>
                  <p className="text-sm text-green-700 leading-relaxed">
                    For the best experience, {toolName} opens in its own window. 
                    This ensures full functionality and security.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <Button
                onClick={() => window.open(toolUrl, '_blank')}
                className={`w-full bg-gradient-to-r ${toolColor} hover:opacity-90 text-white text-lg py-6 shadow-xl`}
              >
                <ExternalLink className="w-6 h-6 mr-2" />
                Open {toolName} Now
              </Button>

              <Button
                onClick={() => window.close()}
                variant="outline"
                className="w-full py-6"
              >
                Close This Window
              </Button>
            </div>

            <div className="bg-blue-50 rounded-xl p-4 border-2 border-blue-200">
              <div className="flex items-center gap-2 justify-center text-blue-900">
                <Zap className="w-5 h-5" />
                <p className="text-sm font-semibold">
                  Pro Tip: Keep both windows open for seamless multitasking
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}