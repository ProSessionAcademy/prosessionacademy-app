
import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  BookOpen,
  CheckCircle2,
  Award,
  ChevronRight,
  PlayCircle,
  ArrowLeft,
  CheckCircle,
  Volume2,
  VolumeX,
  Trophy,
  Star,
  Brain,
  Sparkles,
  Loader2 
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { AnimatePresence, motion } from "framer-motion";

// FlipCard Component
function FlipCard({ frontText, backText, frontImage, backImage }) {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div
      className="relative w-full h-64 cursor-pointer perspective"
      onClick={() => setIsFlipped(!isFlipped)}
    >
      <motion.div
        className="relative w-full h-full"
        initial={false}
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.6, ease: "easeInOut" }}
        style={{ transformStyle: "preserve-3d" }}
      >
        <div
          className="absolute inset-0 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl p-6 flex items-center justify-center text-white shadow-xl border-2 border-blue-300"
          style={{ backfaceVisibility: "hidden" }}
        >
          <div className="text-center">
            {frontImage && <img src={frontImage} alt="" className="w-24 h-24 mx-auto mb-4 rounded-lg" />}
            <h3 className="text-2xl font-bold">{frontText}</h3>
          </div>
        </div>

        <div
          className="absolute inset-0 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl p-6 flex items-center justify-center text-white shadow-xl border-2 border-green-300"
          style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
        >
          <div className="text-center">
            {backImage && <img src={backImage} alt="" className="w-24 h-24 mx-auto mb-4 rounded-lg" />}
            <p className="text-lg leading-relaxed">{backText}</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

// Celebration Component
function GlitterCelebration() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      className="fixed inset-0 flex items-center justify-center z-50 pointer-events-none"
    >
      {[...Array(30)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-3 h-3 rounded-full"
          style={{
            background: ['#667eea', '#764ba2', '#f093fb', '#4facfe', '#ffd700'][i % 5],
            left: `${Math.random() * 100}%`,
            top: '50%',
          }}
          initial={{ y: 0, opacity: 1, scale: 1 }}
          animate={{
            y: [0, -200, -400],
            x: [(Math.random() - 0.5) * 200, (Math.random() - 0.5) * 400],
            opacity: [1, 1, 0],
            scale: [1, 1.5, 0],
            rotate: [0, 360 * (Math.random() - 0.5)]
          }}
          transition={{
            duration: 2 + Math.random(),
            ease: "easeOut",
            delay: Math.random() * 0.3
          }}
        />
      ))}

      <Card className="bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-2xl p-8 text-center pointer-events-auto relative z-10">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: [0, 1.2, 1] }}
          transition={{ duration: 0.5 }}
        >
          <Trophy className="w-20 h-20 mx-auto mb-4 text-yellow-300" />
        </motion.div>
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-4xl font-bold mb-2"
        >
          Chapter Complete! 🎉
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-xl mb-4"
        >
          Amazing work! Keep going!
        </motion.p>
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.7 }}
          className="flex items-center justify-center gap-4 text-2xl font-bold"
        >
          <div className="flex items-center gap-2 bg-white/20 px-6 py-3 rounded-full">
            <Star className="w-8 h-8 text-yellow-300" />
            <span>+50 XP</span>
          </div>
        </motion.div>
      </Card>
    </motion.div>
  );
}

// SliderBlock Component
function SliderBlock({ block }) {
  const [sliderValue, setSliderValue] = useState(block.data?.minValue || 0);
  const [showAnswer, setShowAnswer] = useState(false);
  
  return (
    <div className="bg-white rounded-lg p-8 shadow-sm border-2 border-slate-200">
      <h3 className="text-2xl font-bold text-slate-900 mb-6">{block.data?.question}</h3>
      <input
        type="range"
        min={block.data?.minValue || 0}
        max={block.data?.maxValue || 100}
        value={sliderValue}
        onChange={(e) => setSliderValue(Number(e.target.value))}
        className="w-full h-4 bg-gradient-to-r from-blue-400 to-purple-400 rounded-lg appearance-none cursor-pointer"
      />
      <div className="flex justify-between mt-3 text-base text-slate-600 font-medium">
        <span>{block.data?.minValue || 0}{block.data?.unit}</span>
        <span className="text-2xl font-bold text-blue-600">{sliderValue}{block.data?.unit}</span>
        <span>{block.data?.maxValue || 100}{block.data?.unit}</span>
      </div>
      <Button
        onClick={() => setShowAnswer(!showAnswer)}
        variant="outline"
        className="mt-6 border-2"
        size="lg"
      >
        {showAnswer ? 'Hide Answer' : 'Show Answer'}
      </Button>
      {showAnswer && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 p-4 bg-green-50 border-2 border-green-300 rounded-lg"
        >
          <p className="text-base text-green-700 font-semibold">
            ✅ Correct Answer: {block.data?.correctAnswer}{block.data?.unit}
          </p>
        </motion.div>
      )}
    </div>
  );
}


export default function Learning() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const courseIdFromUrl = urlParams.get('courseId');
  
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [selectedChapter, setSelectedChapter] = useState(null);
  const [currentSection, setCurrentSection] = useState(0);
  const [showCelebration, setShowCelebration] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [quizAnswers, setQuizAnswers] = useState({});
  const audioRef = useRef(null);
  const speechRef = useRef(null);
  const [loadingVoice, setLoadingVoice] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false); 

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const user = await base44.auth.me();
        setCurrentUser(user);
      } catch (error) {
        console.error("Failed to fetch user:", error);
      }
    };
    fetchUser();
  }, []);

  const { data: courses = [] } = useQuery({
    queryKey: ['courses'],
    queryFn: () => base44.entities.Course.list(),
    initialData: []
  });

  const { data: chapters = [] } = useQuery({
    queryKey: ['chapters', selectedCourse?.id],
    queryFn: async () => {
      if (!selectedCourse?.id) return [];
      try {
        const result = await base44.entities.Chapter.filter({ course_id: selectedCourse.id }, 'order');
        return result || [];
      } catch (error) {
        console.error("Error fetching chapters:", error);
        return [];
      }
    },
    enabled: !!selectedCourse?.id,
    initialData: []
  });

  const { data: courseProgress } = useQuery({
    queryKey: ['courseProgress', selectedCourse?.id, currentUser?.email],
    queryFn: async () => {
      if (!selectedCourse?.id || !currentUser?.email) return null;
      try {
        const progress = await base44.entities.UserProgress.filter({
          course_id: selectedCourse.id,
          user_email: currentUser.email
        });
        return progress[0] || null;
      } catch (error) {
        console.error("Error fetching progress:", error);
        return null;
      }
    },
    enabled: !!selectedCourse?.id && !!currentUser?.email,
  });

  const createProgressMutation = useMutation({
    mutationFn: (data) => base44.entities.UserProgress.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['courseProgress']);
    }
  });

  const updateProgressMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.UserProgress.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['courseProgress']);
    }
  });

  useEffect(() => {
    if (courseIdFromUrl && courses.length > 0 && !selectedCourse) {
      const course = courses.find(c => c.id === courseIdFromUrl);
      if (course) {
        setSelectedCourse(course);
      }
    }
  }, [courseIdFromUrl, courses, selectedCourse]);

  // Generate natural explanation with AI
  const generateNaturalExplanation = async (text) => {
    if (!text || text.length < 50) return text;
    
    try {
      setLoadingVoice(true);
      
      const prompt = `You are a warm, friendly female educator explaining a lesson to a student. 
      
Take this lesson content and turn it into a natural, conversational explanation as if you're speaking directly to the student. 

Guidelines:
- Speak naturally like a teacher explaining in person
- Use "you" and "your" to address the student
- Keep it engaging and encouraging
- Simplify complex ideas
- Add smooth transitions between concepts
- Sound enthusiastic and supportive
- Keep the main points but make it conversational
- Around 200-300 words

Lesson content:
${text.substring(0, 2000)}

Your natural explanation:`;

      const explanation = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        add_context_from_internet: false
      });
      
      return explanation || text;
    } catch (error) {
      console.error('Failed to generate explanation:', error);
      return text;
    } finally {
      setLoadingVoice(false);
    }
  };

  // Clean text for natural speech
  const cleanTextForSpeech = (text) => {
    if (!text) return '';
    
    return text
      .replace(/\*\*/g, '')
      .replace(/\*/g, '')
      .replace(/#/g, '')
      .replace(/\n\n/g, '. ')
      .replace(/\n/g, ' ')
      .replace(/[→↓]/g, 'leads to')
      .replace(/=/g, ' equals ')
      .replace(/\+/g, ' plus ')
      .replace(/×/g, ' times ')
      .replace(/\//g, ' or ')
      .replace(/\|/g, ' ')
      .replace(/[🎯📊💡✅❌⚡🔄🎨🧠⏰📱📧📺🍳📝🔋🚫😴⚖️🔥🌅☀️🌙⚙️📋🗓️🚀]/g, '')
      .replace(/•/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  };

  useEffect(() => {
    const loadVoices = () => {
      window.speechSynthesis.getVoices();
    };
    
    loadVoices();
    
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, []);

  const markChapterComplete = async () => {
    if (!selectedChapter?.id || !currentUser?.email || !selectedCourse?.id) return;

    const completedChapters = courseProgress?.completed_chapters || [];
    
    // Check if already completed
    if (completedChapters.includes(selectedChapter.id)) {
      console.log('Chapter already completed');
      return;
    }

    const updatedCompletedChapters = [...completedChapters, selectedChapter.id];
    const progressPercentage = (updatedCompletedChapters.length / chapters.length) * 100;

    const progressData = {
      user_email: currentUser.email,
      course_id: selectedCourse.id,
      completed_chapters: updatedCompletedChapters,
      progress_percentage: progressPercentage,
      ...(progressPercentage === 100 && {
        completed_date: new Date().toISOString(),
        certificate_issued: false
      })
    };

    if (courseProgress) {
      await updateProgressMutation.mutateAsync({
        id: courseProgress.id,
        data: progressData
      });
    } else {
      await createProgressMutation.mutateAsync(progressData);
    }

    // Award XP
    const currentXP = currentUser.xp_points || 0;
    await base44.auth.updateMe({ xp_points: currentXP + 50 });
    
    const updatedUser = await base44.auth.me();
    setCurrentUser(updatedUser);

    setShowCelebration(true);
    setTimeout(() => {
      setShowCelebration(false);
      // Redirect back to course overview
      setSelectedChapter(null);
      setCurrentSection(0);
      setQuizAnswers({});
      stopAudio();
      setVoiceEnabled(false);
      setLoadingVoice(false);
    }, 3000);
  };

  const playAudio = (url) => {
    if (audioRef.current) {
      audioRef.current.pause();
    }

    if (!url) return;
    
    const audio = new Audio(url);
    audioRef.current = audio;
    audio.play();
    setIsPlayingAudio(true);

    audio.onended = () => setIsPlayingAudio(false);
    audio.onerror = () => setIsPlayingAudio(false);
  };

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
    }
    window.speechSynthesis.cancel();
    setIsPlayingAudio(false);
  };

  const handleGenerateVoice = async () => {
    if (isPlayingAudio) {
      stopAudio();
      setVoiceEnabled(false);
      setLoadingVoice(false);
      return;
    }

    setVoiceEnabled(true);
    setLoadingVoice(true);

    try {
      const allText = selectedChapter.content_blocks
        ?.filter(b => b.type === 'text')
        .map(b => b.data?.content || '')
        .join(' ');

      if (allText && allText.length > 50) {
        const naturalExplanation = await generateNaturalExplanation(allText);
        const cleanedText = cleanTextForSpeech(naturalExplanation);
        
        if (cleanedText && cleanedText.length > 20) {
          const utterance = new SpeechSynthesisUtterance(cleanedText);
          
          const voices = window.speechSynthesis.getVoices();
          const femaleVoice = voices.find(voice => 
            voice.name.includes('Female') || 
            voice.name.includes('female') ||
            voice.name.includes('Samantha') ||
            voice.name.includes('Victoria') ||
            voice.name.includes('Karen') ||
            voice.name.includes('Zira') ||
            (voice.name.includes('Google') && voice.name.includes('US') && voice.name.includes('2'))
          );
          
          if (femaleVoice) {
            utterance.voice = femaleVoice;
          }
          
          utterance.lang = 'en-US';
          utterance.rate = 0.95;
          utterance.pitch = 1.1;
          utterance.volume = 1;
          
          utterance.onstart = () => {
            setIsPlayingAudio(true);
            setLoadingVoice(false);
          };
          utterance.onend = () => {
            setIsPlayingAudio(false);
            setVoiceEnabled(false);
            setLoadingVoice(false);
          };
          utterance.onerror = () => {
            setIsPlayingAudio(false);
            setVoiceEnabled(false);
            setLoadingVoice(false);
          };
          
          speechRef.current = utterance;
          window.speechSynthesis.speak(utterance);
        } else {
            setLoadingVoice(false);
            setVoiceEnabled(false);
        }
      } else {
          setLoadingVoice(false);
          setVoiceEnabled(false);
      }
    } catch (error) {
      console.error('Voice generation error:', error);
      setLoadingVoice(false);
      setVoiceEnabled(false);
      setIsPlayingAudio(false);
    }
  };

  const renderContentBlock = (block, blockIdx) => {
    if (!block) {
      console.warn('Block is null or undefined at index:', blockIdx);
      return null;
    }
    
    if (!block.type) {
      console.warn('Block type is missing at index:', blockIdx);
      return null;
    }

    if (!block.data) {
      console.warn('Block data is missing at index:', blockIdx);
      return null;
    }

    try {
      switch (block.type) {
        case 'text':
          return (
            <div key={blockIdx} className="prose max-w-none bg-white rounded-lg p-8 shadow-sm border-2 border-slate-200">
              <div className="text-lg leading-relaxed text-slate-800 whitespace-pre-wrap">
                {block.data?.content || 'No content available'}
              </div>
            </div>
          );

        case 'flip_cards':
          if (!block.data?.cards || !Array.isArray(block.data.cards)) {
            return null;
          }
          return (
            <div key={blockIdx} className="grid md:grid-cols-2 gap-6">
              {block.data.cards.map((card, idx) => (
                <FlipCard
                  key={idx}
                  frontText={card.frontText || ''}
                  backText={card.backText || ''}
                  frontImage={card.frontImage || ''}
                  backImage={card.backImage || ''}
                />
              ))}
            </div>
          );

        case 'expandable':
          return (
            <div key={blockIdx} className="bg-white rounded-lg shadow-sm border-2 border-slate-200 overflow-hidden">
              <details className="group">
                <summary className="cursor-pointer p-6 bg-gradient-to-r from-blue-50 to-purple-50 hover:from-blue-100 hover:to-purple-100 transition-all">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-bold text-slate-900">{block.data?.title || 'More Info'}</h3>
                    <ChevronRight className="w-6 h-6 text-slate-600 group-open:rotate-90 transition-transform" />
                  </div>
                </summary>
                <div className="p-6 text-slate-700 whitespace-pre-wrap border-t-2 border-slate-100">
                  {block.data?.content || 'No content available'}
                </div>
              </details>
            </div>
          );

        case 'slider':
          return <SliderBlock key={blockIdx} block={block} />;

        case 'image':
          if (!block.data?.url) {
            return null;
          }
          return (
            <div key={blockIdx} className="bg-white rounded-lg p-6 shadow-sm border-2 border-slate-200">
              <img 
                src={block.data.url} 
                alt={block.data?.caption || ''} 
                className="w-full rounded-lg border-2 border-slate-200"
                onError={(e) => {
                  e.target.style.display = 'none';
                  console.warn('Image failed to load:', block.data.url);
                }}
              />
              {block.data?.caption && (
                <p className="text-base text-slate-600 mt-4 text-center italic font-medium">
                  {block.data.caption}
                </p>
              )}
            </div>
          );

        case 'quiz':
          if (!block.data?.question || !block.data?.options || !Array.isArray(block.data.options)) {
            return null;
          }
          
          const quizKey = `quiz-${blockIdx}`;
          const selectedAnswer = quizAnswers[quizKey];
          const hasAnswered = selectedAnswer !== undefined;
          const isCorrect = selectedAnswer === block.data?.correct_answer;

          return (
            <div key={blockIdx} className="bg-white rounded-lg p-8 shadow-sm border-2 border-slate-200">
              <div className="flex items-start gap-3 mb-6">
                <Brain className="w-8 h-8 text-purple-600 flex-shrink-0 mt-1" />
                <h3 className="text-2xl font-bold text-slate-900">{block.data.question}</h3>
              </div>
              <div className="space-y-3">
                {block.data.options.map((option, idx) => (
                  <label
                    key={idx}
                    className={`flex items-center p-5 rounded-lg border-2 cursor-pointer transition-all text-lg ${
                      hasAnswered
                        ? idx === block.data?.correct_answer
                          ? 'border-green-500 bg-green-50'
                          : selectedAnswer === idx
                          ? 'border-red-500 bg-red-50'
                          : 'border-slate-200 opacity-50'
                        : selectedAnswer === idx
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50'
                    }`}
                    onClick={() => !hasAnswered && setQuizAnswers({...quizAnswers, [quizKey]: idx})}
                  >
                    <input 
                      type="radio" 
                      name={quizKey} 
                      checked={selectedAnswer === idx}
                      onChange={() => {}}
                      className="mr-4 w-5 h-5"
                      disabled={hasAnswered}
                    />
                    <span className="flex-1 font-medium">{option}</span>
                    {hasAnswered && idx === block.data?.correct_answer && (
                      <CheckCircle2 className="w-6 h-6 text-green-600" />
                    )}
                  </label>
                ))}
              </div>
              {hasAnswered && block.data?.explanation && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`mt-6 p-6 rounded-lg border-2 ${isCorrect ? 'bg-green-50 border-green-300' : 'bg-orange-50 border-orange-300'}`}
                >
                  {isCorrect ? (
                    <div className="flex items-center gap-3 text-green-700 mb-3">
                      <CheckCircle2 className="w-7 h-7" />
                      <span className="font-bold text-lg">Correct! Well done! 🎉</span>
                    </div>
                  ) : (
                    <div className="text-orange-700 mb-3">
                      <p className="font-bold text-lg mb-2">Not quite right, but great try! 💪</p>
                    </div>
                  )}
                  <p className="text-slate-700">{block.data.explanation}</p>
                </motion.div>
              )}
            </div>
          );

        default:
          console.warn('Unknown block type:', block.type);
          return null;
      }
    } catch (error) {
      console.error('Error rendering block:', error, block);
      return (
        <div key={blockIdx} className="bg-red-50 border-2 border-red-300 rounded-lg p-6">
          <p className="text-red-700">Error rendering content block</p>
        </div>
      );
    }
  };

  if (selectedChapter) {
    const contentBlocks = selectedChapter.content_blocks || [];
    const currentBlock = contentBlocks[currentSection];
    const isLastSection = currentSection === contentBlocks.length - 1;
    const completedChapters = courseProgress?.completed_chapters || [];
    const isChapterCompleted = completedChapters.includes(selectedChapter.id);

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="max-w-6xl mx-auto p-6 lg:p-8">
          <div className="flex items-center justify-between mb-8">
            <Button
              variant="ghost"
              onClick={() => {
                setSelectedChapter(null);
                setCurrentSection(0);
                setQuizAnswers({});
                stopAudio();
                setVoiceEnabled(false);
                setLoadingVoice(false);
              }}
              className="text-lg"
              size="lg"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Chapters
            </Button>

            <Button
              onClick={handleGenerateVoice}
              disabled={loadingVoice || !selectedChapter?.content_blocks || selectedChapter.content_blocks.filter(b => b.type === 'text').length === 0}
              variant="outline"
              className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
              size="lg"
            >
              {loadingVoice ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Loading...
                </>
              ) : voiceEnabled ? (
                <>
                  <Volume2 className="w-5 h-5 mr-2" />
                  Voice Enabled
                </>
              ) : (
                <>
                  <Volume2 className="w-5 h-5 mr-2" />
                  Enable Voice
                </>
              )}
            </Button>
          </div>

          <Card className="border-2 border-slate-200 shadow-2xl bg-white">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-xl p-8">
              <CardTitle className="text-4xl font-bold">{selectedChapter.title}</CardTitle>
              <CardDescription className="text-white/90 text-xl mt-2">
                {selectedChapter.description}
              </CardDescription>
            </CardHeader>

            <CardContent className="p-10 space-y-10">
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="text-xl px-6 py-3 border-2">
                  Section {currentSection + 1} of {contentBlocks.length}
                </Badge>
                <div className="flex-1 mx-8">
                  <Progress value={((currentSection + 1) / contentBlocks.length) * 100} className="h-4" />
                </div>
                <span className="text-lg font-bold text-blue-600">
                  {Math.round(((currentSection + 1) / contentBlocks.length) * 100)}%
                </span>
              </div>

              <AnimatePresence mode="wait">
                <motion.div
                  key={currentSection}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="min-h-[400px]"
                >
                  {renderContentBlock(currentBlock, currentSection)}
                </motion.div>
              </AnimatePresence>

              <div className="flex justify-between pt-8 border-t-2 border-slate-200">
                <Button
                  variant="outline"
                  onClick={() => {
                    setCurrentSection(Math.max(0, currentSection - 1));
                    stopAudio();
                    setVoiceEnabled(false);
                    setLoadingVoice(false);
                  }}
                  disabled={currentSection === 0}
                  size="lg"
                  className="text-lg px-8 border-2"
                >
                  Previous
                </Button>

                {!isLastSection ? (
                  <Button
                    onClick={() => {
                        setCurrentSection(currentSection + 1);
                        stopAudio();
                        setVoiceEnabled(false);
                        setLoadingVoice(false);
                    }}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 text-lg px-8"
                    size="lg"
                  >
                    Next Section
                    <ChevronRight className="w-5 h-5 ml-2" />
                  </Button>
                ) : (
                  <Button
                    onClick={() => markChapterComplete()}
                    disabled={isChapterCompleted}
                    className="bg-gradient-to-r from-green-600 to-emerald-600 text-lg px-8 disabled:opacity-50 disabled:cursor-not-allowed"
                    size="lg"
                  >
                    {isChapterCompleted ? '✓ Completed' : 'Complete Chapter'}
                    <CheckCircle className="w-5 h-5 ml-2" />
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          <AnimatePresence>
            {showCelebration && <GlitterCelebration />}
          </AnimatePresence>
        </div>
      </div>
    );
  }

  if (selectedCourse) {
    const completedChapters = courseProgress?.completed_chapters || [];
    const progressPercent = chapters.length > 0 
      ? (completedChapters.length / chapters.length) * 100 
      : 0;

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="max-w-5xl mx-auto p-6 lg:p-8">
          <Button
            variant="ghost"
            onClick={() => {
              setSelectedCourse(null);
              setSelectedChapter(null);
              setCurrentSection(0);
              setQuizAnswers({});
              queryClient.invalidateQueries(['courses']);
              stopAudio();
              setVoiceEnabled(false);
              setLoadingVoice(false);
              // Clear URL params
              navigate(createPageUrl("Learning"));
            }}
            className="mb-6 text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Courses
          </Button>

          <Card className="border-none shadow-2xl mb-8 bg-white/90 backdrop-blur-sm">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-xl">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-4xl mb-2">{selectedCourse.title}</CardTitle>
                  <CardDescription className="text-white/90 text-lg">
                    {selectedCourse.description}
                  </CardDescription>
                </div>
                {selectedCourse.voice_intro_url && (
                  <Button
                    variant="outline"
                    onClick={() => {
                      if (isPlayingAudio) {
                        stopAudio();
                      } else {
                        playAudio(selectedCourse.voice_intro_url);
                      }
                    }}
                    className="bg-white/10 border-white/30 text-white hover:bg-white/20"
                  >
                    {isPlayingAudio ? (
                      <>
                        <VolumeX className="w-5 h-5 mr-2" />
                        Stop
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-5 h-5 mr-2" />
                        Hear Intro
                      </>
                    )}
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="flex-1">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="font-semibold">Course Progress</span>
                    <span>{completedChapters.length} / {chapters.length} chapters</span>
                  </div>
                  <Progress value={progressPercent} className="h-3" />
                </div>
                <Award className={`w-12 h-12 ${progressPercent === 100 ? 'text-yellow-500' : 'text-slate-300'}`} />
              </div>
            </CardContent>
          </Card>

          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-white mb-6">Course Chapters</h2>
            {chapters.length === 0 ? (
              <Card className="p-12 text-center">
                <BookOpen className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">No chapters available yet</p>
              </Card>
            ) : (
              chapters.map((chapter, idx) => {
                const isCompleted = completedChapters.includes(chapter.id);

                return (
                  <motion.div
                    key={chapter.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                  >
                    <Card
                      className={`border-2 cursor-pointer transition-all hover:shadow-xl ${
                        isCompleted
                          ? 'border-green-300 bg-gradient-to-r from-green-50 to-emerald-50'
                          : 'border-blue-300 bg-gradient-to-r from-blue-50 to-purple-50 shadow-lg'
                      }`}
                      onClick={() => setSelectedChapter(chapter)}
                    >
                      <CardContent className="p-6">
                        <div className="flex items-center gap-4">
                          <div
                            className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold ${
                              isCompleted
                                ? 'bg-green-600'
                                : 'bg-gradient-to-br from-blue-600 to-purple-600'
                            }`}
                          >
                            {isCompleted ? (
                              <CheckCircle2 className="w-5 h-5 text-white" />
                            ) : (
                              <PlayCircle className="w-5 h-5 text-white" />
                            )}
                          </div>
                          <div className="flex-1">
                            <h3 className="text-xl font-bold text-slate-900">{chapter.title}</h3>
                            <p className="text-slate-600 text-sm">{chapter.description}</p>
                          </div>
                          <ChevronRight className="w-6 h-6 text-blue-600" />
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-7xl mx-auto p-6 lg:p-8">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-slate-50 mb-4">
            Start Learning
          </h1>
          <p className="text-xl text-slate-300">
            Interactive courses designed for real-world skills
          </p>
        </div>

        {courses.length === 0 ? (
          <Card className="border-none shadow-xl p-12 text-center">
            <BookOpen className="w-16 h-16 text-slate-400 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-slate-900 mb-2">No courses available yet</h3>
            <p className="text-slate-600">Check back soon for new learning content!</p>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courses.map((course, idx) => (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
              >
                <Card
                  className="border-none shadow-xl hover:shadow-2xl transition-all cursor-pointer group overflow-hidden h-full"
                  onClick={() => setSelectedCourse(course)}
                >
                  <div className="h-48 bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 relative overflow-hidden">
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-all" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <Badge className="bg-white/90 text-slate-900 mb-2">
                        {course.category || 'Professional'}
                      </Badge>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-2xl font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
                      {course.title}
                    </h3>
                    <p className="text-slate-600 mb-4 line-clamp-2">{course.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
