import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Settings,
  Plus,
  Edit,
  Trash2,
  CreditCard,
  Crown,
  Shield,
  Infinity
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function SubscriptionPlanAdmin() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  
  const [showPlanDialog, setShowPlanDialog] = useState(false);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);
  const [editingPayment, setEditingPayment] = useState(null);

  const [planForm, setPlanForm] = useState({
    plan_name: '',
    price_monthly: 0,
    price_yearly: 0,
    display_order: 1,
    highlight: false,
    is_active: true,
    features: {
      max_courses: -1,
      max_practice_sessions: -1,
      max_ai_generations: -1,
      max_ppt_generations: -1,
      max_group_posts: -1,
      max_community_posts: -1,
      max_file_uploads: -1,
      max_groups_join: -1,
      can_create_groups: false,
      access_student_space: false,
      access_career_link: false,
      access_professional_space: false,
      access_practice_hub: false,
      access_meeting_rooms: false,
      access_pathways: false,
      access_companies: false,
      access_events: false,
      access_resources: false,
      access_ppt_generator: false,
      access_community: false,
      priority_support: false,
      certificates: false,
      group_access: false,
      ai_chat: false
    }
  });

  const [paymentForm, setPaymentForm] = useState({
    method_name: '',
    method_type: 'stripe',
    is_active: true,
    display_order: 1,
    supported_currencies: ['USD'],
    configuration: {}
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        setIsAdmin(currentUser.role === 'admin');
      } catch (error) {
        console.error('Error:', error);
      }
    };
    fetchUser();
  }, []);

  const { data: plans = [] } = useQuery({
    queryKey: ['subscriptionPlans'],
    queryFn: () => base44.entities.SubscriptionPlan.list('display_order'),
    initialData: []
  });

  const { data: paymentMethods = [] } = useQuery({
    queryKey: ['paymentMethods'],
    queryFn: () => base44.entities.PaymentMethod.list('display_order'),
    initialData: []
  });

  const createPlanMutation = useMutation({
    mutationFn: (data) => base44.entities.SubscriptionPlan.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subscriptionPlans'] });
      setShowPlanDialog(false);
      resetPlanForm();
    }
  });

  const updatePlanMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SubscriptionPlan.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subscriptionPlans'] });
      setShowPlanDialog(false);
      resetPlanForm();
      setEditingPlan(null);
    }
  });

  const deletePlanMutation = useMutation({
    mutationFn: (id) => base44.entities.SubscriptionPlan.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subscriptionPlans'] });
    }
  });

  const createPaymentMutation = useMutation({
    mutationFn: (data) => base44.entities.PaymentMethod.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['paymentMethods'] });
      setShowPaymentDialog(false);
      resetPaymentForm();
    }
  });

  const updatePaymentMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PaymentMethod.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['paymentMethods'] });
      setShowPaymentDialog(false);
      resetPaymentForm();
      setEditingPayment(null);
    }
  });

  const deletePaymentMutation = useMutation({
    mutationFn: (id) => base44.entities.PaymentMethod.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['paymentMethods'] });
    }
  });

  const resetPlanForm = () => {
    setPlanForm({
      plan_name: '',
      price_monthly: 0,
      price_yearly: 0,
      display_order: plans.length + 1,
      highlight: false,
      is_active: true,
      features: {
        max_courses: -1,
        max_practice_sessions: -1,
        max_ai_generations: -1,
        max_ppt_generations: -1,
        max_group_posts: -1,
        max_community_posts: -1,
        max_file_uploads: -1,
        max_groups_join: -1,
        can_create_groups: false,
        access_student_space: false,
        access_career_link: false,
        access_professional_space: false,
        access_practice_hub: false,
        access_meeting_rooms: false,
        access_pathways: false,
        access_companies: false,
        access_events: false,
        access_resources: false,
        access_ppt_generator: false,
        access_community: false,
        priority_support: false,
        certificates: false,
        group_access: false,
        ai_chat: false
      }
    });
  };

  const resetPaymentForm = () => {
    setPaymentForm({
      method_name: '',
      method_type: 'stripe',
      is_active: true,
      display_order: paymentMethods.length + 1,
      supported_currencies: ['USD'],
      configuration: {}
    });
  };

  const handleEditPlan = (plan) => {
    setEditingPlan(plan);
    setPlanForm(plan);
    setShowPlanDialog(true);
  };

  const handleEditPayment = (payment) => {
    setEditingPayment(payment);
    setPaymentForm(payment);
    setShowPaymentDialog(true);
  };

  const handleSavePlan = () => {
    if (!planForm.plan_name.trim()) {
      alert('Enter plan name');
      return;
    }

    if (editingPlan) {
      updatePlanMutation.mutate({ id: editingPlan.id, data: planForm });
    } else {
      createPlanMutation.mutate(planForm);
    }
  };

  const handleSavePayment = () => {
    if (!paymentForm.method_name.trim()) {
      alert('Enter method name');
      return;
    }

    if (editingPayment) {
      updatePaymentMutation.mutate({ id: editingPayment.id, data: paymentForm });
    } else {
      createPaymentMutation.mutate(paymentForm);
    }
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-pink-50 p-6 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-12 text-center">
            <Shield className="w-16 h-16 text-red-500 mx-auto mb-6" />
            <h3 className="text-2xl font-bold mb-2">Admin Only</h3>
            <p className="text-slate-600">This page is restricted to administrators.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <Card className="border-none shadow-xl bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <CardContent className="p-8">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center">
                <Settings className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-3xl font-black mb-1">💳 Subscription Plans Manager</h1>
                <p className="text-blue-100">Configure pricing, limits, features & payment methods</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Subscription Plans Section */}
        <Card className="border-none shadow-xl">
          <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50 border-b-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl flex items-center gap-2">
                <Crown className="w-6 h-6 text-purple-600" />
                Subscription Plans
              </CardTitle>
              <Button onClick={() => { resetPlanForm(); setEditingPlan(null); setShowPlanDialog(true); }} className="bg-purple-600">
                <Plus className="w-5 h-5 mr-2" />
                Add Plan
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {plans.map((plan) => (
                <Card key={plan.id} className={`border-2 ${plan.highlight ? 'border-yellow-400 bg-gradient-to-br from-yellow-50 to-orange-50 shadow-lg' : 'border-slate-200'}`}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-2xl font-bold text-slate-900 mb-1">{plan.plan_name}</h3>
                        <div className="flex gap-2">
                          {plan.highlight && <Badge className="bg-yellow-500 text-white">⭐ Popular</Badge>}
                          {!plan.is_active && <Badge variant="outline" className="text-red-600">Inactive</Badge>}
                        </div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="flex items-baseline gap-2 mb-1">
                        <span className="text-4xl font-black text-purple-600">${plan.price_monthly}</span>
                        <span className="text-slate-500">/mo</span>
                      </div>
                      {plan.price_yearly > 0 && (
                        <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-bold text-blue-600">${plan.price_yearly}</span>
                          <span className="text-slate-500 text-sm">/yr</span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-1 mb-4 text-xs max-h-48 overflow-y-auto">
                      <p className="font-bold text-slate-700 mb-2">Limits:</p>
                      <p className="text-slate-600">
                        📚 {plan.features?.max_courses === -1 ? '∞ Courses' : `${plan.features?.max_courses || 0} Courses`}
                      </p>
                      <p className="text-slate-600">
                        🎯 {plan.features?.max_practice_sessions === -1 ? '∞ Practice' : `${plan.features?.max_practice_sessions || 0} Sessions`}
                      </p>
                      <p className="text-slate-600">
                        🎨 {plan.features?.max_ai_generations === -1 ? '∞ AI Images' : `${plan.features?.max_ai_generations || 0} AI Images`}
                      </p>
                      <p className="text-slate-600">
                        📊 {plan.features?.max_ppt_generations === -1 ? '∞ PPTs' : `${plan.features?.max_ppt_generations || 0} PPTs`}
                      </p>
                      
                      <p className="font-bold text-slate-700 mb-2 mt-3">Access:</p>
                      {plan.features?.access_student_space && <p className="text-green-600">✓ Student Space</p>}
                      {plan.features?.access_pathways && <p className="text-green-600">✓ Pathways</p>}
                      {plan.features?.access_career_link && <p className="text-green-600">✓ Career Link</p>}
                      {plan.features?.access_professional_space && <p className="text-green-600">✓ Professional</p>}
                      {plan.features?.access_practice_hub && <p className="text-green-600">✓ Practice Hub</p>}
                      {plan.features?.access_ppt_generator && <p className="text-green-600">✓ PPT Generator</p>}
                      {plan.features?.access_community && <p className="text-green-600">✓ Community</p>}
                    </div>

                    <div className="flex gap-2">
                      <Button onClick={() => handleEditPlan(plan)} size="sm" variant="outline" className="flex-1">
                        <Edit className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                      <Button onClick={() => { if (confirm('Delete this plan?')) deletePlanMutation.mutate(plan.id); }} size="sm" variant="outline" className="text-red-600">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {plans.length === 0 && (
              <div className="text-center p-12">
                <Crown className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">No subscription plans yet. Create one!</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Payment Methods Section */}
        <Card className="border-none shadow-xl">
          <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 border-b-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl flex items-center gap-2">
                <CreditCard className="w-6 h-6 text-green-600" />
                Payment Methods
              </CardTitle>
              <Button onClick={() => { resetPaymentForm(); setEditingPayment(null); setShowPaymentDialog(true); }} className="bg-green-600">
                <Plus className="w-5 h-5 mr-2" />
                Add Method
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              {paymentMethods.map((method) => (
                <Card key={method.id} className="border-2">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 flex-1">
                        <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-emerald-600 rounded-xl flex items-center justify-center">
                          <CreditCard className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-xl font-bold">{method.method_name}</h3>
                          <p className="text-sm text-slate-500 capitalize">Type: {method.method_type}</p>
                          <div className="flex gap-2 mt-2">
                            {method.supported_currencies?.map(curr => (
                              <Badge key={curr} variant="outline">{curr}</Badge>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <Badge className={method.is_active ? 'bg-green-600 text-white' : 'bg-slate-400 text-white'}>
                          {method.is_active ? 'Active' : 'Inactive'}
                        </Badge>
                        <Button onClick={() => handleEditPayment(method)} size="sm" variant="outline">
                          <Edit className="w-4 h-4 mr-1" />
                          Edit
                        </Button>
                        <Button onClick={() => { if (confirm('Delete?')) deletePaymentMutation.mutate(method.id); }} size="sm" variant="outline" className="text-red-600">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {paymentMethods.length === 0 && (
              <div className="text-center p-12">
                <CreditCard className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">No payment methods configured yet.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Plan Dialog */}
        <Dialog open={showPlanDialog} onOpenChange={setShowPlanDialog}>
          <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl flex items-center gap-2">
                <Crown className="w-6 h-6 text-purple-600" />
                {editingPlan ? 'Edit Subscription Plan' : 'Create Subscription Plan'}
              </DialogTitle>
            </DialogHeader>

            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="basic">Basic Info</TabsTrigger>
                <TabsTrigger value="limits">Usage Limits</TabsTrigger>
                <TabsTrigger value="access">Feature Access</TabsTrigger>
              </TabsList>

              <TabsContent value="basic" className="space-y-4 mt-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>Plan Name *</Label>
                    <Input
                      value={planForm.plan_name}
                      onChange={(e) => setPlanForm({ ...planForm, plan_name: e.target.value })}
                      placeholder="e.g., Premium, Basic, Plus"
                    />
                  </div>
                  <div>
                    <Label>Display Order</Label>
                    <Input
                      type="number"
                      value={planForm.display_order}
                      onChange={(e) => setPlanForm({ ...planForm, display_order: parseInt(e.target.value) })}
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>Monthly Price (USD) *</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-3 text-slate-500">$</span>
                      <Input
                        type="number"
                        value={planForm.price_monthly}
                        onChange={(e) => setPlanForm({ ...planForm, price_monthly: parseFloat(e.target.value) })}
                        placeholder="29.99"
                        className="pl-7"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Yearly Price (USD)</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-3 text-slate-500">$</span>
                      <Input
                        type="number"
                        value={planForm.price_yearly}
                        onChange={(e) => setPlanForm({ ...planForm, price_yearly: parseFloat(e.target.value) })}
                        placeholder="299.99"
                        className="pl-7"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-6 p-4 bg-slate-50 rounded-xl">
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={planForm.is_active}
                      onCheckedChange={(checked) => setPlanForm({ ...planForm, is_active: checked })}
                    />
                    <Label>Active Plan</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={planForm.highlight}
                      onCheckedChange={(checked) => setPlanForm({ ...planForm, highlight: checked })}
                    />
                    <Label>⭐ Highlight (Most Popular)</Label>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="limits" className="space-y-4 mt-6">
                <div className="bg-blue-50 p-4 rounded-xl border-2 border-blue-200 mb-4">
                  <p className="text-sm text-blue-900 font-semibold flex items-center gap-2">
                    <Infinity className="w-4 h-4" />
                    Use <code className="bg-blue-200 px-2 py-1 rounded">-1</code> for unlimited access
                  </p>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <Card className="bg-purple-50 border-2 border-purple-200">
                    <CardContent className="p-4">
                      <Label className="mb-2 block font-bold">📚 Max Courses per Month</Label>
                      <Input
                        type="number"
                        value={planForm.features.max_courses}
                        onChange={(e) => setPlanForm({ 
                          ...planForm, 
                          features: { ...planForm.features, max_courses: parseInt(e.target.value) }
                        })}
                        placeholder="-1 for unlimited"
                      />
                    </CardContent>
                  </Card>

                  <Card className="bg-blue-50 border-2 border-blue-200">
                    <CardContent className="p-4">
                      <Label className="mb-2 block font-bold">🎯 Max Practice Sessions per Month</Label>
                      <Input
                        type="number"
                        value={planForm.features.max_practice_sessions}
                        onChange={(e) => setPlanForm({ 
                          ...planForm, 
                          features: { ...planForm.features, max_practice_sessions: parseInt(e.target.value) }
                        })}
                        placeholder="-1 for unlimited"
                      />
                    </CardContent>
                  </Card>

                  <Card className="bg-pink-50 border-2 border-pink-200">
                    <CardContent className="p-4">
                      <Label className="mb-2 block font-bold">🎨 Max AI Image Generations per Month</Label>
                      <Input
                        type="number"
                        value={planForm.features.max_ai_generations}
                        onChange={(e) => setPlanForm({ 
                          ...planForm, 
                          features: { ...planForm.features, max_ai_generations: parseInt(e.target.value) }
                        })}
                        placeholder="-1 for unlimited"
                      />
                    </CardContent>
                  </Card>

                  <Card className="bg-orange-50 border-2 border-orange-200">
                    <CardContent className="p-4">
                      <Label className="mb-2 block font-bold">📊 Max PPT Generations per Month</Label>
                      <Input
                        type="number"
                        value={planForm.features.max_ppt_generations}
                        onChange={(e) => setPlanForm({ 
                          ...planForm, 
                          features: { ...planForm.features, max_ppt_generations: parseInt(e.target.value) }
                        })}
                        placeholder="-1 for unlimited"
                      />
                    </CardContent>
                  </Card>

                  <Card className="bg-green-50 border-2 border-green-200">
                    <CardContent className="p-4">
                      <Label className="mb-2 block font-bold">💬 Max Group Posts per Month</Label>
                      <Input
                        type="number"
                        value={planForm.features.max_group_posts}
                        onChange={(e) => setPlanForm({ 
                          ...planForm, 
                          features: { ...planForm.features, max_group_posts: parseInt(e.target.value) }
                        })}
                        placeholder="-1 for unlimited"
                      />
                    </CardContent>
                  </Card>

                  <Card className="bg-indigo-50 border-2 border-indigo-200">
                    <CardContent className="p-4">
                      <Label className="mb-2 block font-bold">🌐 Max Community Posts per Month</Label>
                      <Input
                        type="number"
                        value={planForm.features.max_community_posts}
                        onChange={(e) => setPlanForm({ 
                          ...planForm, 
                          features: { ...planForm.features, max_community_posts: parseInt(e.target.value) }
                        })}
                        placeholder="-1 for unlimited"
                      />
                    </CardContent>
                  </Card>

                  <Card className="bg-cyan-50 border-2 border-cyan-200">
                    <CardContent className="p-4">
                      <Label className="mb-2 block font-bold">📁 Max File Uploads per Month</Label>
                      <Input
                        type="number"
                        value={planForm.features.max_file_uploads}
                        onChange={(e) => setPlanForm({ 
                          ...planForm, 
                          features: { ...planForm.features, max_file_uploads: parseInt(e.target.value) }
                        })}
                        placeholder="-1 for unlimited"
                      />
                    </CardContent>
                  </Card>

                  <Card className="bg-teal-50 border-2 border-teal-200">
                    <CardContent className="p-4">
                      <Label className="mb-2 block font-bold">👥 Max Groups Can Join</Label>
                      <Input
                        type="number"
                        value={planForm.features.max_groups_join}
                        onChange={(e) => setPlanForm({ 
                          ...planForm, 
                          features: { ...planForm.features, max_groups_join: parseInt(e.target.value) }
                        })}
                        placeholder="-1 for unlimited"
                      />
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="access" className="space-y-4 mt-6">
                <div className="grid md:grid-cols-2 gap-4">
                  {[
                    { key: 'access_student_space', label: '🎓 Student Space', icon: '🎓' },
                    { key: 'access_pathways', label: '🛤️ Learning Pathways', icon: '🛤️' },
                    { key: 'access_career_link', label: '💼 Career Link', icon: '💼' },
                    { key: 'access_professional_space', label: '👔 Professional Space', icon: '👔' },
                    { key: 'access_practice_hub', label: '🎯 Practice Hub', icon: '🎯' },
                    { key: 'access_meeting_rooms', label: '📹 Meeting Rooms', icon: '📹' },
                    { key: 'access_companies', label: '🏢 Companies Directory', icon: '🏢' },
                    { key: 'access_events', label: '📅 Events', icon: '📅' },
                    { key: 'access_resources', label: '📚 Resources Library', icon: '📚' },
                    { key: 'access_ppt_generator', label: '📊 PPT Generator', icon: '📊' },
                    { key: 'access_community', label: '💬 Community Forum', icon: '💬' },
                    { key: 'can_create_groups', label: '➕ Can Create Groups', icon: '➕' },
                    { key: 'group_access', label: '👥 Groups Access', icon: '👥' },
                    { key: 'priority_support', label: '🚀 Priority Support', icon: '🚀' },
                    { key: 'certificates', label: '🏆 Certificates', icon: '🏆' },
                    { key: 'ai_chat', label: '🤖 AI Chat', icon: '🤖' }
                  ].map(({ key, label, icon }) => (
                    <div key={key} className="flex items-center justify-between p-4 bg-gradient-to-r from-slate-50 to-blue-50 rounded-lg border-2 border-slate-200 hover:border-blue-400 transition-all">
                      <Label className="flex items-center gap-2 font-semibold">
                        <span>{icon}</span>
                        {label}
                      </Label>
                      <Switch
                        checked={planForm.features[key]}
                        onCheckedChange={(checked) => setPlanForm({
                          ...planForm,
                          features: { ...planForm.features, [key]: checked }
                        })}
                      />
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>

            <div className="flex gap-4 mt-6">
              <Button onClick={() => setShowPlanDialog(false)} variant="outline" className="flex-1">
                Cancel
              </Button>
              <Button onClick={handleSavePlan} className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 py-6 text-lg font-bold">
                {editingPlan ? '💾 Update Plan' : '✨ Create Plan'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Payment Dialog */}
        <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-2xl flex items-center gap-2">
                <CreditCard className="w-6 h-6 text-green-600" />
                {editingPayment ? 'Edit Payment Method' : 'Add Payment Method'}
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Method Name *</Label>
                  <Input
                    value={paymentForm.method_name}
                    onChange={(e) => setPaymentForm({ ...paymentForm, method_name: e.target.value })}
                    placeholder="e.g., Credit Card via Stripe"
                  />
                </div>
                <div>
                  <Label>Method Type *</Label>
                  <Select value={paymentForm.method_type} onValueChange={(val) => setPaymentForm({ ...paymentForm, method_type: val })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="stripe">💳 Stripe</SelectItem>
                      <SelectItem value="paypal">🅿️ PayPal</SelectItem>
                      <SelectItem value="bank_transfer">🏦 Bank Transfer</SelectItem>
                      <SelectItem value="crypto">₿ Cryptocurrency</SelectItem>
                      <SelectItem value="other">🔧 Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Display Order</Label>
                  <Input
                    type="number"
                    value={paymentForm.display_order}
                    onChange={(e) => setPaymentForm({ ...paymentForm, display_order: parseInt(e.target.value) })}
                  />
                </div>
                <div className="flex items-center gap-2 pt-6">
                  <Switch
                    checked={paymentForm.is_active}
                    onCheckedChange={(checked) => setPaymentForm({ ...paymentForm, is_active: checked })}
                  />
                  <Label>Active</Label>
                </div>
              </div>

              <div>
                <Label>API Key / Merchant ID (Optional)</Label>
                <Input
                  value={paymentForm.configuration?.api_key || ''}
                  onChange={(e) => setPaymentForm({ 
                    ...paymentForm, 
                    configuration: { ...paymentForm.configuration, api_key: e.target.value }
                  })}
                  placeholder="For Stripe/PayPal integration"
                  type="password"
                />
              </div>

              <div>
                <Label>Instructions for Users (Optional)</Label>
                <Input
                  value={paymentForm.configuration?.instructions || ''}
                  onChange={(e) => setPaymentForm({ 
                    ...paymentForm, 
                    configuration: { ...paymentForm.configuration, instructions: e.target.value }
                  })}
                  placeholder="e.g., Send payment to account #..."
                />
              </div>

              <div className="flex gap-4">
                <Button onClick={() => setShowPaymentDialog(false)} variant="outline" className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleSavePayment} className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 py-6 text-lg font-bold">
                  {editingPayment ? '💾 Update' : '✨ Add Method'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}