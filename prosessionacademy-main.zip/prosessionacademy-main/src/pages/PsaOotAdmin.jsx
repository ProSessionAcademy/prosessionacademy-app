
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Plus,
  Gamepad2,
  Trash2,
  Edit,
  Play,
  Users,
  Clock,
  Upload,
  Image as ImageIcon,
  X,
  Copy,
  CheckCircle,
  AlertCircle
} from "lucide-react";
import { format } from "date-fns";

export default function PsaOotAdmin() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  // Removed editingGame state as its corresponding dialog was removed from the outline.
  const [copiedCode, setCopiedCode] = useState(null);

  const [newGame, setNewGame] = useState({
    title: '',
    group_id: '',
    questions: []
  });

  const [currentQuestion, setCurrentQuestion] = useState({
    question: '',
    question_type: 'multiple_choice',
    options: ['', '', '', ''],
    picture_options: [],
    correct_answer: 0,
    correct_text: '', // For open_ended
    slider_min: 0,
    slider_max: 100,
    slider_correct: 50,
    slider_tolerance: 5,
    time_limit: 20,
    points: 1000
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching user:", error);
        setLoading(false);
        // Redirect to login if not authenticated
        base44.auth.redirectToLogin();
      }
    };
    fetchUser();
  }, []);

  const { data: games = [] } = useQuery({
    queryKey: ['psaOotGames'],
    queryFn: () => base44.entities.PsaOotGame.list('-created_date'),
    initialData: [],
    enabled: !!user, // Only fetch if user is loaded
  });

  const { data: groups = [] } = useQuery({
    queryKey: ['groups'],
    queryFn: () => base44.entities.Group.list(),
    initialData: [],
    enabled: !!user,
  });

  const createGameMutation = useMutation({
    mutationFn: async (gameData) => {
      // Generate a 6-digit number game code
      const gameCode = Math.floor(100000 + Math.random() * 900000).toString();
      return base44.entities.PsaOotGame.create({
        ...gameData,
        game_code: gameCode,
        status: 'draft' // Initial status is draft
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['psaOotGames'] });
      setShowCreateDialog(false);
      setNewGame({ title: '', group_id: '', questions: [] });
      setCurrentQuestion({ // Reset current question form
        question: '',
        question_type: 'multiple_choice',
        options: ['', '', '', ''],
        picture_options: [],
        correct_answer: 0,
        correct_text: '',
        slider_min: 0,
        slider_max: 100,
        slider_correct: 50,
        slider_tolerance: 5,
        time_limit: 20,
        points: 1000
      });
      alert('✅ Game created! You can now add questions.');
    },
    onError: (error) => {
      console.error('Error creating game:', error);
      alert('❌ Failed to create game: ' + (error.message || 'Unknown error'));
    }
  });

  // updateGameMutation is kept for handleHostGame and potential future edit functionality
  const updateGameMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PsaOotGame.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['psaOotGames'] });
      // alert('✅ Game updated!'); // Removed alert to prevent redundant popups on status change
    },
    onError: (error) => {
      console.error('Error updating game:', error);
      alert('❌ Failed to update game');
    }
  });

  const deleteGameMutation = useMutation({
    mutationFn: (id) => base44.entities.PsaOotGame.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['psaOotGames'] });
      alert('✅ Game deleted!');
    },
    onError: (error) => {
      console.error('Error deleting game:', error);
      alert('❌ Failed to delete game');
    }
  });

  const handleImageUpload = async (event, index) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('⚠️ Please select an image file!');
      return;
    }

    setUploadingImage(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      const updatedPictureOptions = [...currentQuestion.picture_options];
      updatedPictureOptions[index] = response.file_url;
      setCurrentQuestion({ ...currentQuestion, picture_options: updatedPictureOptions });
      alert('✅ Image uploaded!');
    } catch (error) {
      alert('❌ Upload failed: ' + error.message);
    } finally {
      setUploadingImage(false);
      event.target.value = ''; // Clear the input so same file can be selected again
    }
  };

  const addQuestion = () => {
    if (!currentQuestion.question.trim()) {
      alert('⚠️ Please enter a question!');
      return;
    }

    // Validate based on question type
    if (currentQuestion.question_type === 'multiple_choice' && currentQuestion.options.filter(o => o.trim()).length < 2) {
      alert('⚠️ Please add at least 2 options for multiple choice!');
      return;
    }
    if (currentQuestion.question_type === 'picture_choice' && currentQuestion.picture_options.filter(o => o).length < 2) {
      alert('⚠️ Please upload at least 2 images for picture choice!');
      return;
    }
    if (currentQuestion.question_type === 'slider' && (currentQuestion.slider_min >= currentQuestion.slider_max || currentQuestion.slider_correct < currentQuestion.slider_min || currentQuestion.slider_correct > currentQuestion.slider_max)) {
      alert('⚠️ Please ensure slider values (min, max, correct) are valid!');
      return;
    }
    if (currentQuestion.question_type === 'open_ended' && !currentQuestion.correct_text.trim()) {
      alert('⚠️ Please provide a sample correct answer for open-ended questions!');
      return;
    }

    setNewGame({
      ...newGame,
      questions: [...newGame.questions, { ...currentQuestion }]
    });

    // Reset form after adding
    setCurrentQuestion({
      question: '',
      question_type: 'multiple_choice',
      options: ['', '', '', ''],
      picture_options: [],
      correct_answer: 0,
      correct_text: '',
      slider_min: 0,
      slider_max: 100,
      slider_correct: 50,
      slider_tolerance: 5,
      time_limit: 20,
      points: 1000
    });
  };

  const removeQuestion = (index) => {
    setNewGame({
      ...newGame,
      questions: newGame.questions.filter((_, i) => i !== index)
    });
  };

  const handleCreateGame = async () => {
    if (!user) {
      alert('⚠️ You must be logged in to create a game!');
      base44.auth.redirectToLogin();
      return;
    }

    if (!newGame.title.trim()) {
      alert('⚠️ Please enter a game title!');
      return;
    }

    if (newGame.questions.length === 0) {
      alert('⚠️ Please add at least one question!');
      return;
    }

    try {
      await createGameMutation.mutateAsync({
        ...newGame,
        created_by: user.email,
        created_by_name: user.full_name || user.email
      });
    } catch (error) {
      console.error('Create game error:', error);
    }
  };

  const handleHostGame = async (game) => {
    if (!user) {
      alert('⚠️ You must be logged in to host a game!');
      base44.auth.redirectToLogin();
      return;
    }

    if (!game || !game.id) {
      alert('⚠️ Invalid game!');
      return;
    }

    try {
      // Update game status to waiting
      await updateGameMutation.mutateAsync({
        id: game.id,
        data: { status: 'waiting', current_question: 0, players: [] }
      });

      // Navigate to host page
      navigate(createPageUrl("PsaOotHost") + `?gameId=${game.id}`);
    } catch (error) {
      console.error('Host game error:', error);
      alert('❌ Failed to start hosting: ' + (error.message || 'Unknown error'));
    }
  };

  const copyGameCode = (code) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const handleDeleteGame = (gameId) => {
    if (confirm('Are you sure you want to delete this game?')) {
      deleteGameMutation.mutate(gameId);
    }
  };

  // Check if user is admin
  const isAdmin = user?.admin_level === 'top_tier_admin' ||
                  user?.admin_level === 'super_admin' ||
                  user?.admin_level === 'supervisor_admin';

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50">
        <Card className="max-w-md shadow-lg">
          <CardContent className="p-12 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
            <p className="text-slate-600">Only admins can access PSA-OOT game management.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Filter games created by the current user
  const myGames = games.filter(g => g.created_by === user?.email);

  return (
    <div className="p-6 lg:p-8 min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-2 flex items-center gap-2">
            <Gamepad2 className="w-8 h-8 text-blue-600" />
            PSA-OOT Game Management
          </h1>
          <p className="text-slate-600">
            Create and manage interactive quiz games for your groups
          </p>
        </div>

        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
              <Plus className="w-4 h-4 mr-2" />
              Create Game
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New PSA-OOT Game</DialogTitle>
            </DialogHeader>

            <div className="space-y-6 py-4">
              <div>
                <Label htmlFor="game-title">Game Title *</Label>
                <Input
                  id="game-title"
                  value={newGame.title}
                  onChange={(e) => setNewGame({ ...newGame, title: e.target.value })}
                  placeholder="Enter game title..."
                />
              </div>

              <div>
                <Label htmlFor="group-select">Assign to Group (Optional)</Label>
                <Select value={newGame.group_id || ''} onValueChange={(value) => setNewGame({ ...newGame, group_id: value || null })}>
                  <SelectTrigger id="group-select">
                    <SelectValue placeholder="Select a group..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>No Group</SelectItem>
                    {groups.map(group => (
                      <SelectItem key={group.id} value={group.id}>
                        {group.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-bold mb-4">Add Questions</h3>

                <div className="space-y-4 p-4 border rounded-lg bg-slate-50">
                  <div>
                    <Label htmlFor="question-type">Question Type</Label>
                    <Select
                      id="question-type"
                      value={currentQuestion.question_type}
                      onValueChange={(value) => setCurrentQuestion({
                        ...currentQuestion,
                        question_type: value,
                        // Reset options/picture_options if changing type
                        options: value === 'multiple_choice' ? ['', '', '', ''] : (value === 'true_false' ? [] : currentQuestion.options),
                        picture_options: value === 'picture_choice' ? [] : currentQuestion.picture_options,
                        correct_answer: 0, // Reset correct answer index
                        correct_text: '', // Reset correct text for open_ended
                        slider_correct: 50, // Reset slider correct
                      })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                        <SelectItem value="true_false">True/False</SelectItem>
                        <SelectItem value="picture_choice">Picture Choice</SelectItem>
                        <SelectItem value="slider">Slider</SelectItem>
                        <SelectItem value="open_ended">Open Ended</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="question-text">Question *</Label>
                    <Textarea
                      id="question-text"
                      value={currentQuestion.question}
                      onChange={(e) => setCurrentQuestion({ ...currentQuestion, question: e.target.value })}
                      placeholder="Enter your question..."
                      rows={2}
                    />
                  </div>

                  {/* Multiple Choice Options */}
                  {currentQuestion.question_type === 'multiple_choice' && (
                    <div>
                      <Label>Answer Options *</Label>
                      <div className="space-y-2">
                        {currentQuestion.options.map((option, idx) => (
                          <div key={idx} className="flex gap-2 items-center">
                            <Input
                              value={option}
                              onChange={(e) => {
                                const updated = [...currentQuestion.options];
                                updated[idx] = e.target.value;
                                setCurrentQuestion({ ...currentQuestion, options: updated });
                              }}
                              placeholder={`Option ${idx + 1}`}
                            />
                            <Button
                              variant={currentQuestion.correct_answer === idx ? 'default' : 'outline'}
                              onClick={() => setCurrentQuestion({ ...currentQuestion, correct_answer: idx })}
                              size="sm"
                            >
                              {currentQuestion.correct_answer === idx ? '✓ Correct' : 'Set Correct'}
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* True/False */}
                  {currentQuestion.question_type === 'true_false' && (
                    <div>
                      <Label>Correct Answer *</Label>
                      <div className="flex gap-2">
                        <Button
                          variant={currentQuestion.correct_answer === 0 ? 'default' : 'outline'}
                          onClick={() => setCurrentQuestion({ ...currentQuestion, correct_answer: 0 })}
                          className="flex-1"
                        >
                          True
                        </Button>
                        <Button
                          variant={currentQuestion.correct_answer === 1 ? 'default' : 'outline'}
                          onClick={() => setCurrentQuestion({ ...currentQuestion, correct_answer: 1 })}
                          className="flex-1"
                        >
                          False
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Picture Choice */}
                  {currentQuestion.question_type === 'picture_choice' && (
                    <div>
                      <Label>Upload Images (up to 4) *</Label>
                      <div className="grid grid-cols-2 gap-4">
                        {[0, 1, 2, 3].map(idx => (
                          <div key={idx} className="space-y-2 border p-2 rounded-md">
                            {currentQuestion.picture_options[idx] ? (
                              <div className="relative">
                                <img
                                  src={currentQuestion.picture_options[idx]}
                                  className="w-full h-24 object-cover rounded border-2 mb-2"
                                  alt={`Option ${idx + 1}`}
                                />
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  className="absolute top-1 right-1 bg-white rounded-full h-6 w-6 p-0"
                                  onClick={() => {
                                    const updated = [...currentQuestion.picture_options];
                                    updated[idx] = '';
                                    setCurrentQuestion({ ...currentQuestion, picture_options: updated });
                                  }}
                                >
                                  <X className="w-4 h-4 text-red-500" />
                                </Button>
                              </div>
                            ) : (
                              <label htmlFor={`image-upload-${idx}`} className="w-full flex flex-col items-center justify-center border-2 border-dashed rounded-md p-4 cursor-pointer hover:bg-slate-100 min-h-[100px]">
                                {uploadingImage ? (
                                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-500"></div>
                                ) : (
                                  <>
                                    <Upload className="w-6 h-6 text-slate-400 mb-1" />
                                    <span className="text-sm text-slate-500">Upload Image {idx + 1}</span>
                                  </>
                                )}
                              </label>
                            )}
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) => handleImageUpload(e, idx)}
                              className="hidden"
                              id={`image-upload-${idx}`}
                              disabled={uploadingImage}
                            />
                            <Button
                              size="sm"
                              variant={currentQuestion.correct_answer === idx ? 'default' : 'outline'}
                              onClick={() => setCurrentQuestion({ ...currentQuestion, correct_answer: idx })}
                              className="w-full"
                              disabled={!currentQuestion.picture_options[idx]} // Disable if no image
                            >
                              {currentQuestion.correct_answer === idx ? '✓ Correct' : 'Mark Correct'}
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Slider */}
                  {currentQuestion.question_type === 'slider' && (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="slider-min">Min Value</Label>
                          <Input
                            id="slider-min"
                            type="number"
                            value={currentQuestion.slider_min}
                            onChange={(e) => setCurrentQuestion({ ...currentQuestion, slider_min: Number(e.target.value) })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="slider-max">Max Value</Label>
                          <Input
                            id="slider-max"
                            type="number"
                            value={currentQuestion.slider_max}
                            onChange={(e) => setCurrentQuestion({ ...currentQuestion, slider_max: Number(e.target.value) })}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="slider-correct">Correct Answer</Label>
                          <Input
                            id="slider-correct"
                            type="number"
                            value={currentQuestion.slider_correct}
                            onChange={(e) => setCurrentQuestion({ ...currentQuestion, slider_correct: Number(e.target.value) })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="slider-tolerance">Tolerance (±)</Label>
                          <Input
                            id="slider-tolerance"
                            type="number"
                            value={currentQuestion.slider_tolerance}
                            onChange={(e) => setCurrentQuestion({ ...currentQuestion, slider_tolerance: Number(e.target.value) })}
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Open Ended */}
                  {currentQuestion.question_type === 'open_ended' && (
                    <div>
                      <Label htmlFor="correct-text">Sample Correct Answer *</Label>
                      <Textarea
                        id="correct-text"
                        value={currentQuestion.correct_text}
                        onChange={(e) => setCurrentQuestion({ ...currentQuestion, correct_text: e.target.value })}
                        placeholder="Example of a correct answer (players will be scored based on similarity)..."
                        rows={2}
                      />
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="time-limit">Time Limit (seconds)</Label>
                      <Input
                        id="time-limit"
                        type="number"
                        value={currentQuestion.time_limit}
                        onChange={(e) => setCurrentQuestion({ ...currentQuestion, time_limit: Number(e.target.value) })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="points">Points</Label>
                      <Input
                        id="points"
                        type="number"
                        value={currentQuestion.points}
                        onChange={(e) => setCurrentQuestion({ ...currentQuestion, points: Number(e.target.value) })}
                      />
                    </div>
                  </div>

                  <Button onClick={addQuestion} variant="outline" className="w-full" disabled={!currentQuestion.question.trim() || uploadingImage}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Question to Game
                  </Button>
                </div>
              </div>

              {/* Added Questions List */}
              {newGame.questions.length > 0 && (
                <div className="border-t pt-6">
                  <h3 className="text-lg font-bold mb-4">Questions ({newGame.questions.length})</h3>
                  <div className="space-y-3">
                    {newGame.questions.map((q, idx) => (
                      <Card key={idx} className="border-l-4 border-blue-500">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <Badge variant="secondary">{q.question_type.replace(/_/g, ' ')}</Badge>
                                <span className="text-sm text-slate-500">
                                  <Clock className="inline-block w-3 h-3 mr-1" />{q.time_limit}s • {q.points} pts
                                </span>
                              </div>
                              <p className="font-medium text-slate-900">{q.question}</p>
                            </div>
                            <Button
                              onClick={() => removeQuestion(idx)}
                              variant="ghost"
                              size="sm"
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-3 pt-4">
                <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                  Cancel
                </Button>
                <Button
                  onClick={handleCreateGame}
                  className="bg-gradient-to-r from-purple-600 to-pink-600"
                  disabled={!newGame.title || newGame.questions.length === 0 || createGameMutation.isPending}
                >
                  <Gamepad2 className="w-4 h-4 mr-2" />
                  {createGameMutation.isPending ? "Creating..." : "Create Game"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Games List */}
      <Tabs defaultValue="my_games" className="space-y-6">
        <TabsList>
          <TabsTrigger value="my_games">My Games ({myGames.length})</TabsTrigger>
          <TabsTrigger value="all_games">All Games ({games.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="my_games" className="space-y-4">
          {myGames.length === 0 ? (
            <Card className="shadow-lg">
              <CardContent className="p-12 text-center">
                <Gamepad2 className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No games yet</h3>
                <p className="text-slate-500 mb-4">Create your first PSA-OOT game!</p>
                <Button onClick={() => setShowCreateDialog(true)} className="bg-gradient-to-r from-purple-600 to-pink-600">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Game
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {myGames.map(game => (
                <Card key={game.id} className="border-none shadow-lg hover:shadow-xl transition-all">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between mb-2">
                      <Badge className={
                        game.status === 'active' ? 'bg-green-100 text-green-700' :
                        game.status === 'waiting' ? 'bg-blue-100 text-blue-700' :
                        game.status === 'completed' ? 'bg-slate-100 text-slate-700' :
                        'bg-orange-100 text-orange-700'
                      }>
                        {game.status.replace(/_/g, ' ')}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteGame(game.id)}
                        className="text-red-600"
                        disabled={deleteGameMutation.isPending}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                    <CardTitle className="text-xl">{game.title}</CardTitle>
                    {game.group_id && (
                      <p className="text-sm text-slate-500">Group: {groups.find(g => g.id === game.group_id)?.name || "Unknown"}</p>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="flex items-center gap-2 text-slate-600">
                        <Clock className="w-4 h-4" />
                        <span>{game.questions?.length || 0} questions</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-600">
                        <Users className="w-4 h-4" />
                        <span>{game.players?.length || 0} players</span>
                      </div>
                    </div>

                    <div className="bg-slate-100 rounded-lg p-3 flex items-center justify-between">
                      <div>
                        <p className="text-xs text-slate-500">Game Code</p>
                        <p className="text-2xl font-bold text-slate-900">{game.game_code}</p>
                      </div>
                      <Button
                        onClick={() => copyGameCode(game.game_code)}
                        variant="outline"
                        size="sm"
                      >
                        {copiedCode === game.game_code ? (
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleHostGame(game)}
                        className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                        disabled={game.status === 'active' || game.status === 'completed' || updateGameMutation.isPending}
                      >
                        <Play className="w-4 h-4 mr-2" />
                        {game.status === 'active' ? 'Game Active' : game.status === 'completed' ? 'Game Over' : 'Host Game'}
                      </Button>
                      {/* Edit button could be added here in the future if needed */}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="all_games" className="space-y-4">
          {games.length === 0 ? (
            <Card className="shadow-lg"> {/* Kept shadow-lg for consistency */}
              <CardContent className="p-12 text-center">
                <Gamepad2 className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No games created yet</h3> {/* Updated text */}
                <p className="text-slate-500">Be the first to create a game!</p> {/* Updated text and removed mb-4 */}
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {games.map(game => (
                <Card key={game.id} className="border-none shadow-lg">
                  <CardHeader> {/* Removed pb-3 */}
                    <Badge className={`w-fit mb-2 ${ // Re-added dynamic styling
                        game.status === 'active' ? 'bg-green-100 text-green-700' :
                        game.status === 'waiting' ? 'bg-blue-100 text-blue-700' :
                        game.status === 'completed' ? 'bg-slate-100 text-slate-700' :
                        'bg-orange-100 text-orange-700'
                      }`}>
                      {game.status.replace(/_/g, ' ')}
                    </Badge>
                    <CardTitle className="text-xl">{game.title}</CardTitle> {/* Removed mt-2 */}
                    <p className="text-sm text-slate-500">by {game.created_by_name || game.created_by}</p> {/* Kept fallback for created_by_name */}
                    {/* Removed game.group_id display block */}
                  </CardHeader>
                  <CardContent> {/* Removed space-y-4 */}
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="flex items-center gap-2 text-slate-600">
                        <Clock className="w-4 h-4" />
                        <span>{game.questions?.length || 0} questions</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-600">
                        <Users className="w-4 h-4" />
                        <span>{game.players?.length || 0} players</span>
                      </div>
                    </div>
                    {/* Removed Game Code display block */}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
