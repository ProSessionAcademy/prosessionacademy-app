import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Crown, 
  Check, 
  X,
  Sparkles,
  ArrowLeft,
  CreditCard,
  Shield,
  Clock,
  Calendar,
  AlertCircle,
  ExternalLink,
  Zap,
  Infinity
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Subscription() {
  const [user, setUser] = useState(null);
  const [daysLeft, setDaysLeft] = useState(0);
  const [paymentUrl, setPaymentUrl] = useState('');

  const { data: settings = [] } = useQuery({
    queryKey: ['appSettings'],
    queryFn: () => base44.entities.AppSettings.list(),
    initialData: [],
  });

  const { data: plans = [] } = useQuery({
    queryKey: ['subscriptionPlans'],
    queryFn: () => base44.entities.SubscriptionPlan.filter({ is_active: true }),
    initialData: [],
  });

  useEffect(() => {
    const fetchUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      if (currentUser.trial_end_date) {
        const now = new Date();
        const trialEnd = new Date(currentUser.trial_end_date);
        const diffTime = trialEnd - now;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        setDaysLeft(Math.max(0, diffDays));
      }
    };
    fetchUser();
  }, []);

  useEffect(() => {
    const paymentSetting = settings.find(s => s.setting_key === 'payment_url');
    if (paymentSetting) {
      setPaymentUrl(paymentSetting.setting_value);
    }
  }, [settings]);

  const handleUpgrade = (plan) => {
    if (!paymentUrl) {
      alert('⚠️ Payment system not configured yet. Contact admin.');
      return;
    }

    const urlWithData = paymentUrl.includes('?') 
      ? `${paymentUrl}&email=${encodeURIComponent(user.email)}&plan=${encodeURIComponent(plan.plan_name)}&amount=${plan.price_monthly}`
      : `${paymentUrl}?email=${encodeURIComponent(user.email)}&plan=${encodeURIComponent(plan.plan_name)}&amount=${plan.price_monthly}`;
    
    window.open(urlWithData, '_blank');
    
    alert('✅ Payment page opened!\n\nAfter successful payment, your account will be upgraded automatically.');
  };

  const isPremium = user?.subscription_status === 'premium';
  const isFreeTrial = user?.subscription_status === 'free_trial';
  const userPlanId = user?.subscription_plan_id;

  const sortedPlans = [...plans].sort((a, b) => a.display_order - b.display_order);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 p-6">
      <div className="max-w-7xl mx-auto">
        <Link to={createPageUrl("Dashboard")}>
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>

        {/* Payment URL Warning for Admin */}
        {user?.role === 'admin' && !paymentUrl && (
          <Alert className="mb-6 border-orange-300 bg-orange-50">
            <AlertCircle className="h-4 w-4 text-orange-600" />
            <AlertDescription className="text-orange-900">
              <strong>Admin Note:</strong> Payment URL not configured. 
              Go to <Link to={createPageUrl("AdminSettings")} className="underline font-semibold">App Settings</Link> to set it up.
            </AlertDescription>
          </Alert>
        )}

        {/* Current Status Card */}
        {user && (
          <Card className="border-none shadow-2xl mb-8 overflow-hidden">
            <div className={`p-6 bg-gradient-to-r ${
              isPremium ? 'from-yellow-400 to-yellow-600' : 
              isFreeTrial ? 'from-green-400 to-emerald-600' : 
              'from-slate-400 to-slate-600'
            } text-white`}>
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    {isPremium ? <Crown className="w-6 h-6" /> : 
                     isFreeTrial ? <Sparkles className="w-6 h-6" /> : 
                     <Shield className="w-6 h-6" />}
                    <h2 className="text-2xl font-bold">
                      {isPremium ? 'Premium Subscription' : 
                       isFreeTrial ? 'Free Trial Active' : 
                       'Current Plan'}
                    </h2>
                  </div>
                  {isFreeTrial && (
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="w-4 h-4" />
                      <span>{daysLeft} days left in your free trial</span>
                    </div>
                  )}
                  {isPremium && user.subscription_end_date && (
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="w-4 h-4" />
                      <span>Valid until {new Date(user.subscription_end_date).toLocaleDateString()}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </Card>
        )}

        <div className="text-center mb-12">
          <h1 className="text-5xl font-black text-slate-900 mb-3">Choose Your Plan</h1>
          <p className="text-slate-600 text-lg">Unlock your full learning potential</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {sortedPlans.map((plan) => {
            const isCurrentPlan = userPlanId === plan.id || (isPremium && plan.plan_name === 'Premium');
            const isHighlighted = plan.highlight;

            return (
              <Card 
                key={plan.id} 
                className={`border-2 relative ${
                  isHighlighted ? 'border-blue-500 shadow-2xl transform hover:scale-105 transition-all' : 'border-slate-200'
                } ${isCurrentPlan ? 'ring-4 ring-green-400' : ''}`}
              >
                {isHighlighted && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-2 text-sm">
                      <Sparkles className="w-4 h-4 mr-1" />
                      BEST VALUE
                    </Badge>
                  </div>
                )}

                <CardHeader>
                  <div className="flex items-center gap-2 mb-2">
                    <Crown className="w-6 h-6 text-purple-600" />
                    <CardTitle className="text-2xl">{plan.plan_name}</CardTitle>
                  </div>
                  <div className="space-y-2">
                    <p className="text-5xl font-black bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                      ${plan.price_monthly}
                      <span className="text-sm font-normal text-slate-500">/mo</span>
                    </p>
                    {plan.price_yearly > 0 && (
                      <p className="text-xl font-bold text-green-600">
                        ${plan.price_yearly}/yr
                        <span className="text-xs text-slate-500"> (save ${(plan.price_monthly * 12 - plan.price_yearly).toFixed(0)})</span>
                      </p>
                    )}
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div className="space-y-2 min-h-[400px]">
                    <p className="font-bold text-slate-700 mb-3">📊 Usage Limits:</p>
                    
                    {plan.features?.max_courses === -1 ? (
                      <div className="flex items-center gap-2 text-sm">
                        <Infinity className="w-5 h-5 text-purple-600" />
                        <span className="font-semibold">∞ Unlimited Courses</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-sm">
                        <Check className="w-5 h-5 text-green-600" />
                        <span>{plan.features?.max_courses} courses/month</span>
                      </div>
                    )}

                    {plan.features?.max_practice_sessions === -1 ? (
                      <div className="flex items-center gap-2 text-sm">
                        <Infinity className="w-5 h-5 text-purple-600" />
                        <span className="font-semibold">∞ Unlimited Practice Sessions</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-sm">
                        <Check className="w-5 h-5 text-green-600" />
                        <span>{plan.features?.max_practice_sessions} practice sessions/month</span>
                      </div>
                    )}

                    {plan.features?.max_ai_generations === -1 ? (
                      <div className="flex items-center gap-2 text-sm">
                        <Infinity className="w-5 h-5 text-purple-600" />
                        <span className="font-semibold">∞ Unlimited AI Images</span>
                      </div>
                    ) : plan.features?.max_ai_generations > 0 ? (
                      <div className="flex items-center gap-2 text-sm">
                        <Check className="w-5 h-5 text-green-600" />
                        <span>{plan.features?.max_ai_generations} AI images/month</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-sm text-slate-400">
                        <X className="w-5 h-5" />
                        <span>No AI image generation</span>
                      </div>
                    )}

                    {plan.features?.max_ppt_generations === -1 ? (
                      <div className="flex items-center gap-2 text-sm">
                        <Infinity className="w-5 h-5 text-purple-600" />
                        <span className="font-semibold">∞ Unlimited PPT Generation</span>
                      </div>
                    ) : plan.features?.max_ppt_generations > 0 ? (
                      <div className="flex items-center gap-2 text-sm">
                        <Check className="w-5 h-5 text-green-600" />
                        <span>{plan.features?.max_ppt_generations} PPTs/month</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-sm text-slate-400">
                        <X className="w-5 h-5" />
                        <span>No PPT generation</span>
                      </div>
                    )}

                    <div className="border-t pt-3 mt-3">
                      <p className="font-bold text-slate-700 mb-2">🔓 Feature Access:</p>
                      
                      {plan.features?.access_student_space && (
                        <div className="flex items-center gap-2 text-sm">
                          <Check className="w-5 h-5 text-green-600" />
                          <span>🎓 Student Space</span>
                        </div>
                      )}
                      {plan.features?.access_pathways && (
                        <div className="flex items-center gap-2 text-sm">
                          <Check className="w-5 h-5 text-green-600" />
                          <span>🛤️ Learning Pathways</span>
                        </div>
                      )}
                      {plan.features?.access_career_link && (
                        <div className="flex items-center gap-2 text-sm">
                          <Check className="w-5 h-5 text-green-600" />
                          <span>💼 Career Link</span>
                        </div>
                      )}
                      {plan.features?.access_professional_space && (
                        <div className="flex items-center gap-2 text-sm">
                          <Check className="w-5 h-5 text-green-600" />
                          <span>👔 Professional Space</span>
                        </div>
                      )}
                      {plan.features?.access_practice_hub && (
                        <div className="flex items-center gap-2 text-sm">
                          <Check className="w-5 h-5 text-green-600" />
                          <span>🎯 Practice Hub</span>
                        </div>
                      )}
                      {plan.features?.access_ppt_generator && (
                        <div className="flex items-center gap-2 text-sm">
                          <Check className="w-5 h-5 text-green-600" />
                          <span>📊 PowerPoint Generator</span>
                        </div>
                      )}
                      {plan.features?.access_community && (
                        <div className="flex items-center gap-2 text-sm">
                          <Check className="w-5 h-5 text-green-600" />
                          <span>💬 Community Forum</span>
                        </div>
                      )}
                      {plan.features?.access_meeting_rooms && (
                        <div className="flex items-center gap-2 text-sm">
                          <Check className="w-5 h-5 text-green-600" />
                          <span>📹 Meeting Rooms</span>
                        </div>
                      )}
                      {plan.features?.access_companies && (
                        <div className="flex items-center gap-2 text-sm">
                          <Check className="w-5 h-5 text-green-600" />
                          <span>🏢 Companies Directory</span>
                        </div>
                      )}
                      {plan.features?.access_events && (
                        <div className="flex items-center gap-2 text-sm">
                          <Check className="w-5 h-5 text-green-600" />
                          <span>📅 Events</span>
                        </div>
                      )}
                      {plan.features?.access_resources && (
                        <div className="flex items-center gap-2 text-sm">
                          <Check className="w-5 h-5 text-green-600" />
                          <span>📚 Resources</span>
                        </div>
                      )}
                      {plan.features?.can_create_groups && (
                        <div className="flex items-center gap-2 text-sm">
                          <Check className="w-5 h-5 text-green-600" />
                          <span>➕ Create Groups</span>
                        </div>
                      )}
                      {plan.features?.priority_support && (
                        <div className="flex items-center gap-2 text-sm">
                          <Zap className="w-5 h-5 text-yellow-600" />
                          <span className="font-semibold">🚀 Priority Support</span>
                        </div>
                      )}
                      {plan.features?.certificates && (
                        <div className="flex items-center gap-2 text-sm">
                          <Check className="w-5 h-5 text-green-600" />
                          <span>🏆 Certificates</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {isCurrentPlan ? (
                    <div className="bg-green-50 border-2 border-green-300 rounded-lg p-4 text-center">
                      <Check className="w-8 h-8 text-green-600 mx-auto mb-2" />
                      <p className="font-semibold text-green-900">✅ Current Plan</p>
                    </div>
                  ) : (
                    <Button 
                      onClick={() => handleUpgrade(plan)}
                      className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-lg"
                      size="lg"
                    >
                      <CreditCard className="w-5 h-5 mr-2" />
                      Upgrade for ${plan.price_monthly}/mo
                    </Button>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {plans.length === 0 && (
          <Card className="border-none shadow-xl">
            <CardContent className="p-16 text-center">
              <Crown className="w-20 h-20 text-slate-300 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-2">No Plans Available</h3>
              <p className="text-slate-600">Subscription plans are being configured by the admin.</p>
            </CardContent>
          </Card>
        )}

        {/* Trust Badges */}
        <div className="flex flex-wrap items-center justify-center gap-8 text-sm text-slate-600 mb-8">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-green-600" />
            <span>Secure Payment</span>
          </div>
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-green-600" />
            <span>Cancel Anytime</span>
          </div>
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-green-600" />
            <span>Money-back Guarantee</span>
          </div>
        </div>

        {/* How it works */}
        <Card className="border-none shadow-lg bg-blue-50">
          <CardContent className="p-6">
            <h3 className="font-bold text-lg mb-4 text-slate-900">💳 How does payment work?</h3>
            <ol className="space-y-2 text-sm text-slate-700">
              <li className="flex items-start gap-2">
                <span className="font-bold text-blue-600">1.</span>
                <span>Click "Upgrade" on your desired plan</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold text-blue-600">2.</span>
                <span>Complete payment via our secure payment page</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold text-blue-600">3.</span>
                <span>Your account is upgraded instantly</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold text-blue-600">4.</span>
                <span>Enjoy all premium features!</span>
              </li>
            </ol>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}