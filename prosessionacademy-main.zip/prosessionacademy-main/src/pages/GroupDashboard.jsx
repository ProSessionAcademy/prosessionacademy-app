
import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  MessageSquare,
  FileText,
  Upload,
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  CheckSquare,
  Plus,
  X,
  Send,
  Paperclip,
  Video,
  Trash2,
  Edit,
  Users as UsersIcon,
  Download,
  TrendingUp,
  Crown,
  Settings,
  User,
  AlertCircle,
  Briefcase,
  Gamepad2,
  Play,
  Image as ImageIcon,
  BookOpen,
  MessageCircle,
  DollarSign,
  Loader2,
  Save,
  Sparkles,
  Reply,
  Smile,
  Pin
} from "lucide-react";
import { format } from "date-fns";
import GlobalSearch from "@/components/GlobalSearch";
import PrivateMessaging from "@/components/PrivateMessaging";

export default function GroupDashboard() {
  const urlParams = new URLSearchParams(window.location.search);
  const groupId = urlParams.get("groupId");

  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("feed");
  const [newPost, setNewPost] = useState("");
  const [postAttachments, setPostAttachments] = useState([]);
  const [showDocDialog, setShowDocDialog] = useState(false);
  const [showEventDialog, setShowEventDialog] = useState(false);
  const [showNoticeDialog, setShowNoticeDialog] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [replyingTo, setReplyingTo] = useState(null);
  const [showReactionPicker, setShowReactionPicker] = useState(null);
  const [expandedThreads, setExpandedThreads] = useState({});

  const [showCegidDialog, setShowCegidDialog] = useState(false);
  const [cegidForm, setCegidForm] = useState({
    enabled: false,
    button_text: "Discover Cegid",
    topics: []
  });

  const [newDocument, setNewDocument] = useState({
    title: "",
    description: "",
    file_url: ""
  });

  const [newEvent, setNewEvent] = useState({
    title: "",
    description: "",
    date: "",
    time: "",
    location: "",
    event_type: "meeting"
  });

  const [newNotice, setNewNotice] = useState({
    title: "",
    content: "",
    expire_date: ""
  });

  const [chatMessage, setChatMessage] = useState("");
  const [chatAttachments, setChatAttachments] = useState([]);

  const [showEditGroupDialog, setShowEditGroupDialog] = useState(false);
  const [groupInfoForm, setGroupInfoForm] = useState({
    name: '',
    description: '',
    logo_url: ''
  });

  const [showBannerLayoutDialog, setShowBannerLayoutDialog] = useState(false);
  const [bannerLayoutForm, setBannerLayoutForm] = useState({
    height: '400px',
    logo_size: '120px',
    logo_position: 'left',
    title_size: '3xl',
    title_alignment: 'left',
    description_size: 'base',
    description_alignment: 'left',
    content_position: 'left',
    show_member_count: true,
    show_group_type: true,
    button_position: 'bottom-left',
    text_color: '#FFFFFF',
    overlay_opacity: 0.7,
    show_description: true,
    show_logo: true,
    title_font_weight: 'bold',
    padding_vertical: '8',
    padding_horizontal: '4'
  });

  const [showTaskDialog, setShowTaskDialog] = useState(false);
  const [showSalesDialog, setShowSalesDialog] = useState(false);
  const [showPrivateMessageDialog, setShowPrivateMessageDialog] = useState(false);
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    assigned_to: "",
    due_date: "",
    status: "todo"
  });
  const [newSalesEntry, setNewSalesEntry] = useState({
    date: new Date().toISOString().split('T')[0],
    sales_count: 0,
    custom_data: {}
  });

  const queryClient = useQueryClient();
  const reactions = ['👍', '❤️', '😂', '😮', '🎉', '🔥'];
  
  // NEW: State for feed post reactions and comments
  const [showFeedReactionPicker, setShowFeedReactionPicker] = useState(null);
  const [showCommentInput, setShowCommentInput] = useState(null);
  const [commentText, setCommentText] = useState('');

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error fetching user:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchUser();
  }, []);

  const { data: group } = useQuery({
    queryKey: ["group", groupId],
    queryFn: async () => {
      const groups = await base44.entities.Group.filter({ id: groupId });
      return groups[0];
    },
    enabled: !!groupId,
    refetchInterval: 3000,
  });

  useEffect(() => {
    if (group?.banner_layout) {
      setBannerLayoutForm(prevForm => ({
        ...prevForm,
        ...group.banner_layout
      }));
    }
  }, [group]);

  useEffect(() => {
    if (group) {
      setGroupInfoForm({
        name: group.name || '',
        description: group.description || '',
        logo_url: group.logo_url || ''
      });

      if (group.cegid_discovery) {
        setCegidForm(group.cegid_discovery);
      }
    }
  }, [group]);

  const groupData = group;

  const { data: members = [] } = useQuery({
    queryKey: ["groupMembers", groupId],
    queryFn: async () => {
      if (!groupData?.members) return [];
      return groupData.members;
    },
    enabled: !!groupId && !!groupData,
  });

  const { data: events = [] } = useQuery({
    queryKey: ["groupEvents", groupId],
    queryFn: async () => {
      const allEvents = await base44.entities.Event.list("date");
      return allEvents.filter(e => e.group_id === groupId);
    },
    initialData: [],
    enabled: !!groupId,
  });

  const { data: groupCourses = [] } = useQuery({
    queryKey: ['groupCourses', groupId],
    queryFn: async () => {
      const allCourses = await base44.entities.Course.list();
      return allCourses.filter(c => c.group_id === groupId);
    },
    initialData: [],
    enabled: !!groupId,
  });

  const { data: psaGames = [] } = useQuery({
    queryKey: ['psaGames', groupId],
    queryFn: async () => {
      const allGames = await base44.entities.PsaOotGame.list('-created_date');
      return allGames.filter(g => g.group_id === groupId);
    },
    initialData: [],
    enabled: !!groupId,
  });

  const updateGroupMutation = useMutation({
    mutationFn: (dataToUpdate) => base44.entities.Group.update(groupId, dataToUpdate),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["group", groupId] });
    },
  });

  const addReactionMutation = useMutation({
    mutationFn: async ({ messageId, reaction }) => {
      const messages = groupData.group_chat_messages || [];
      const updatedMessages = messages.map(msg => {
        if (msg.id === messageId) {
          const reactions = msg.reactions || [];
          const existingReactionIndex = reactions.findIndex(r => r.emoji === reaction && r.user_email === user.email);
          
          if (existingReactionIndex !== -1) {
            const newReactions = [...reactions];
            newReactions.splice(existingReactionIndex, 1);
            return { ...msg, reactions: newReactions };
          } else {
            return {
              ...msg,
              reactions: [...reactions, { emoji: reaction, user_email: user.email, user_name: user.full_name }]
            };
          }
        }
        return msg;
      });

      return await base44.entities.Group.update(groupId, {
        group_chat_messages: updatedMessages
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["group", groupId] });
      setShowReactionPicker(null);
    },
  });

  // NEW: Add reaction to feed post
  const addFeedReactionMutation = useMutation({
    mutationFn: async ({ postId, reactionType }) => {
      const posts = groupData.feed_posts || [];
      const updatedPosts = posts.map(post => {
        if (post.id === postId) {
          // Initialize reactions if null/undefined
          const currentReactions = post.reactions || {
            like: [], love: [], haha: [], wow: [], sad: [], celebrate: [], fire: [], thumbsup: []
          };
          
          const reactionKey = reactionType;
          const userReacted = currentReactions[reactionKey]?.includes(user.email);
          
          let newReactionArray;
          if (userReacted) {
            newReactionArray = currentReactions[reactionKey].filter(email => email !== user.email);
          } else {
            newReactionArray = [...(currentReactions[reactionKey] || []), user.email];
          }
          
          return {
            ...post,
            reactions: {
              ...currentReactions,
              [reactionKey]: newReactionArray
            }
          };
        }
        return post;
      });

      return await base44.entities.Group.update(groupId, {
        feed_posts: updatedPosts
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["group", groupId] });
      setShowFeedReactionPicker(null);
    },
  });

  // NEW: Add comment to feed post
  const addCommentMutation = useMutation({
    mutationFn: async ({ postId, comment }) => {
      const posts = groupData.feed_posts || [];
      const updatedPosts = posts.map(post => {
        if (post.id === postId) {
          const comments = post.comments || [];
          const newComment = {
            id: Date.now().toString(),
            user_email: user.email,
            user_name: user.full_name,
            user_picture: user.profile_picture || '',
            comment: comment,
            timestamp: new Date().toISOString(),
            edited: false
          };
          return { ...post, comments: [...comments, newComment] };
        }
        return post;
      });

      return await base44.entities.Group.update(groupId, {
        feed_posts: updatedPosts
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["group", groupId] });
      setShowCommentInput(null);
      setCommentText('');
    },
  });

  const deletePostMutation = useMutation({
    mutationFn: async (postId) => {
      const updatedPosts = (groupData.feed_posts || []).filter(
        (post) => post.id !== postId
      );
      return await base44.entities.Group.update(groupId, {
        feed_posts: updatedPosts,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["group", groupId] });
      alert("✅ Post deleted!");
    },
  });

  const deleteMessageMutation = useMutation({
    mutationFn: async (messageId) => {
      const messagesToDelete = [
        messageId,
        ...(groupData.group_chat_messages || [])
          .filter(msg => msg.parent_id === messageId)
          .map(msg => msg.id)
      ];

      const updatedMessages = (groupData.group_chat_messages || []).filter(
        (msg) => !messagesToDelete.includes(msg.id)
      );
      return await base44.entities.Group.update(groupId, {
        group_chat_messages: updatedMessages,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["group", groupId] });
      alert("✅ Message deleted!");
    },
  });

  const deleteNoticeMutation = useMutation({
    mutationFn: async (noticeId) => {
      const notices = groupData.notice_board || [];
      const updatedNotices = notices.filter(n => n.id !== noticeId);
      return await base44.entities.Group.update(groupId, {
        notice_board: updatedNotices
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['group', groupId] });
      alert('✅ Notice deleted!');
    },
  });

  const saveBannerLayoutMutation = useMutation({
    mutationFn: async (layoutData) => {
      return await base44.entities.Group.update(groupId, {
        banner_layout: layoutData
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['group'] });
      setShowBannerLayoutDialog(false);
      alert('✅ Layout saved!');
    },
  });

  const updateGroupInfoMutation = useMutation({
    mutationFn: async (groupData) => {
      return await base44.entities.Group.update(groupId, groupData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['group'] });
      setShowEditGroupDialog(false);
      alert('✅ Group updated!');
    },
  });

  const createTaskMutation = useMutation({
    mutationFn: async (taskData) => {
      const tasks = groupData.tasks || [];
      const newTaskObj = {
        ...taskData,
        id: Date.now().toString(),
        created_by: user.email,
        created_by_name: user.full_name,
        created_date: new Date().toISOString()
      };
      return await base44.entities.Group.update(groupId, {
        tasks: [newTaskObj, ...tasks]
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['group', groupId] });
      setShowTaskDialog(false);
      setNewTask({ title: "", description: "", assigned_to: "", due_date: "", status: "todo" });
      alert('✅ Task created!');
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ taskId, updates }) => {
      const tasks = groupData.tasks || [];
      const updatedTasks = tasks.map(t => 
        t.id === taskId ? { ...t, ...updates } : t
      );
      return await base44.entities.Group.update(groupId, {
        tasks: updatedTasks
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['group', groupId] });
    },
  });

  const addSalesEntryMutation = useMutation({
    mutationFn: async (entryData) => {
      const sales = groupData.sales_follow_up || [];
      const newEntry = {
        ...entryData,
        id: Date.now().toString(),
        user_email: user.email,
        user_name: user.full_name,
        created_date: new Date().toISOString()
      };
      return await base44.entities.Group.update(groupId, {
        sales_follow_up: [newEntry, ...sales]
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['group', groupId] });
      setShowSalesDialog(false);
      setNewSalesEntry({ date: new Date().toISOString().split('T')[0], sales_count: 0, custom_data: {} });
      alert('✅ Sales entry added!');
    },
  });

  const sendChatMessage = async () => {
    if ((!chatMessage.trim() && chatAttachments.length === 0) || !user || !groupData) return;

    if (replyingTo) {
      const messages = groupData.group_chat_messages || [];
      
      const newReply = {
        id: Date.now().toString(),
        sender_email: user.email,
        sender_name: user.full_name,
        sender_title: groupData.members?.find(m => m.user_email === user.email)?.role || "",
        message: chatMessage,
        timestamp: new Date().toISOString(),
        attachments: chatAttachments,
        parent_id: replyingTo.id,
        reactions: []
      };

      await updateGroupMutation.mutateAsync({
        group_chat_messages: [newReply, ...messages]
      });

      setChatMessage("");
      setChatAttachments([]);
      setReplyingTo(null);
    } else {
      const userMembership = groupData.members?.find(m => m.user_email === user.email);

      const newMessage = {
        id: Date.now().toString(),
        sender_email: user.email,
        sender_name: user.full_name,
        sender_title: userMembership?.role || "",
        message: chatMessage,
        timestamp: new Date().toISOString(),
        attachments: chatAttachments,
        reactions: []
      };

      const updatedMessages = [newMessage, ...(groupData.group_chat_messages || [])];

      await updateGroupMutation.mutateAsync({
        group_chat_messages: updatedMessages
      });

      setChatMessage("");
      setChatAttachments([]);
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploadingFile(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setNewDocument({ ...newDocument, file_url });
      alert("File uploaded!");
    } catch (error) {
      alert("Upload failed: " + error.message);
    } finally {
      setUploadingFile(false);
    }
  };

  const handleChatFileUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadingFile(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      setChatAttachments([...chatAttachments, response.file_url]);
      alert('✅ File uploaded!');
    } catch (error) {
      alert('❌ Upload failed');
    } finally {
      setUploadingFile(false);
      event.target.value = '';
    }
  };

  const handlePostFileUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadingFile(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      setPostAttachments([...postAttachments, response.file_url]);
      alert('✅ File uploaded!');
    } catch (error) {
      alert('❌ Upload failed');
    } finally {
      setUploadingFile(false);
      event.target.value = '';
    }
  };

  const handleCreatePost = async () => {
    if (!newPost.trim() && postAttachments.length === 0) return;

    const userMembership = groupData.members?.find(m => m.user_email === user.email);

    const postData = {
      id: Date.now().toString(),
      sender_email: user.email,
      sender_name: user.full_name,
      sender_title: userMembership?.role || "",
      message: newPost,
      timestamp: new Date().toISOString(),
      attachments: postAttachments,
      reactions: {}, // Initialize reactions as an empty object
      comments: [] // Initialize comments as an empty array
    };

    const updatedPosts = [postData, ...(groupData.feed_posts || [])];

    await updateGroupMutation.mutateAsync({
      feed_posts: updatedPosts
    });

    setNewPost('');
    setPostAttachments([]);
  };

  const handleUploadDocument = async () => {
    if (!newDocument.title || !newDocument.file_url) {
      alert("Please fill in all fields!");
      return;
    }

    const newDoc = {
      title: newDocument.title,
      description: newDocument.description,
      file_url: newDocument.file_url,
      uploaded_by: user.email,
      uploaded_by_name: user.full_name,
      uploaded_date: new Date().toISOString()
    };

    const updatedDocs = [...(groupData.shared_documents || []), newDoc];

    updateGroupMutation.mutate({
      shared_documents: updatedDocs
    });

    setShowDocDialog(false);
    setNewDocument({ title: "", description: "", file_url: "" });
    alert('✅ Document uploaded!');
  };

  const handleCreateNotice = async () => {
    if (!newNotice.title || !newNotice.content) {
      alert("Please fill in required fields!");
      return;
    }

    const notice = {
      id: Date.now().toString(),
      title: newNotice.title,
      content: newNotice.content,
      author_email: user.email,
      author_name: user.full_name,
      created_date: new Date().toISOString(),
      expire_date: newNotice.expire_date,
      pinned: false,
      read_by: [],
      attachments: []
    };

    const updatedNotices = [notice, ...(groupData.notice_board || [])];

    updateGroupMutation.mutate({
      notice_board: updatedNotices
    });

    setShowNoticeDialog(false);
    setNewNotice({ title: "", content: "", expire_date: "" });
    alert('✅ Notice posted!');
  };

  const handleCreateEvent = () => {
    if (!newEvent.title || !newEvent.date) {
      alert("Please fill in required fields!");
      return;
    }

    base44.entities.Event.create({
      ...newEvent,
      group_id: groupId,
      organizer_name: user.full_name,
      organizer_email: user.email,
      status: "approved"
    }).then(() => {
      queryClient.invalidateQueries({ queryKey: ["groupEvents"] });
      setShowEventDialog(false);
      setNewEvent({
        title: "",
        description: "",
        date: "",
        time: "",
        location: "",
        event_type: "meeting"
      });
      alert('✅ Event created!');
    });
  };

  const handleCreateTask = () => {
    if (!newTask.title || !newTask.assigned_to) {
      alert('Please fill in required fields!');
      return;
    }
    createTaskMutation.mutate(newTask);
  };

  const handleAddSalesEntry = () => {
    if (!newSalesEntry.sales_count || newSalesEntry.sales_count <= 0) {
      alert('Please enter a valid sales count!');
      return;
    }
    addSalesEntryMutation.mutate(newSalesEntry);
  };

  const getLeaderboard = () => {
    const salesData = groupData.sales_follow_up || [];
    const memberSales = {};
    
    salesData.forEach(entry => {
      if (!memberSales[entry.user_email]) {
        memberSales[entry.user_email] = {
          name: entry.user_name,
          email: entry.user_email,
          total: 0
        };
      }
      memberSales[entry.user_email].total += entry.sales_count;
    });

    return Object.values(memberSales).sort((a, b) => b.total - a.total);
  };

  const isImageFile = (url) => {
    if (!url) return false;
    return url.match(/\.(jpeg|jpg|gif|png|webp|bmp|svg)$/i);
  };

  const isVideoFile = (url) => {
    if (!url) return false;
    return url.match(/\.(mp4|webm|ogg|mov|avi)$/i);
  };

  const getReplies = (parentId) => {
    if (!groupData?.group_chat_messages) return [];
    return groupData.group_chat_messages.filter(msg => msg.parent_id === parentId)
      .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
  };

  const getTopLevelMessages = () => {
    if (!groupData?.group_chat_messages) return [];
    return groupData.group_chat_messages.filter(msg => !msg.parent_id)
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  };

  const isAdmin = groupData?.members?.find(m => m.user_email === user?.email)?.role === "admin";
  const isTopTierAdmin = user?.admin_level === 'top_tier_admin' || user?.admin_level === 'super_admin';
  const canManage = isAdmin || isTopTierAdmin;

  const kickMemberMutation = useMutation({
    mutationFn: async (memberEmail) => {
      const updatedMembers = (groupData.members || []).filter(m => m.user_email !== memberEmail);
      return await base44.entities.Group.update(groupId, {
        members: updatedMembers
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["group", groupId] });
      alert('✅ Member removed from group');
    }
  });

  const bannerLayout = groupData?.banner_layout || bannerLayoutForm;

  const getTitleSizeClass = (size) => {
    const sizeMap = {
      'xl': 'text-xl sm:text-2xl',
      '2xl': 'text-2xl sm:text-3xl',
      '3xl': 'text-3xl sm:text-4xl',
      '4xl': 'text-4xl sm:text-5xl',
      '5xl': 'text-5xl sm:text-6xl',
      '6xl': 'text-6xl sm:text-7xl'
    };
    return sizeMap[size] || 'text-3xl sm:text-4xl';
  };

  const getDescriptionSizeClass = (size) => {
    const sizeMap = {
      'xs': 'text-xs',
      'sm': 'text-sm',
      'base': 'text-base',
      'lg': 'text-lg',
      'xl': 'text-xl',
      '2xl': 'text-2xl'
    };
    return sizeMap[size] || 'text-base';
  };

  const getAlignmentClass = (alignment) => {
    const alignMap = {
      'left': 'text-left items-start',
      'center': 'text-center items-center',
      'right': 'text-right items-end'
    };
    return alignMap[alignment] || 'text-left items-start';
  };

  const getButtonPositionClass = (position) => {
    const posMap = {
      'top-left': 'absolute top-4 left-4',
      'top-center': 'absolute top-4 left-1/2 transform -translate-x-1/2',
      'top-right': 'absolute top-4 right-4',
      'bottom-left': 'mt-6',
      'bottom-center': 'mt-6 mx-auto',
      'bottom-right': 'mt-6 ml-auto'
    };
    return posMap[position] || 'mt-6';
  };

  const getFontWeightClass = (weight) => {
    const weightMap = {
      'normal': 'font-normal',
      'medium': 'font-medium',
      'semibold': 'font-semibold',
      'bold': 'font-bold',
      'extrabold': 'font-extrabold',
      'black': 'font-black'
    };
    return weightMap[weight] || 'font-bold';
  };

  // NEW: Add comment to feed post
  const handleAddComment = (postId) => {
    if (!commentText.trim()) return;
    addCommentMutation.mutate({ postId, comment: commentText });
  };

  // NEW: Get total reaction count for a post
  const getTotalReactions = (reactions) => {
    if (!reactions) return 0;
    return Object.values(reactions).reduce((sum, arr) => sum + (arr?.length || 0), 0);
  };

  // NEW: Get reaction emoji mapping
  const getReactionEmoji = (type) => {
    const emojiMap = {
      like: '👍',
      love: '❤️',
      haha: '😂',
      wow: '😮',
      sad: '😢',
      celebrate: '🎉',
      fire: '🔥',
      thumbsup: '👍'
    };
    return emojiMap[type] || '👍';
  };

  if (loading || !groupData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading group...</p>
        </div>
      </div>
    );
  }

  const headerGradient = group?.custom_branding
    ? `linear-gradient(135deg, ${group.custom_branding.primary_color}, ${group.custom_branding.secondary_color}, ${group.custom_branding.accent_color})`
    : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%, #f093fb 100%)';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50">
      {/* Banner */}
      <div
        className="relative overflow-hidden shadow-2xl"
        style={{
          height: bannerLayout.height,
          background: headerGradient
        }}
      >
        {group?.custom_branding?.banner_url && (
          <div className="absolute inset-0">
            <img
              src={group.custom_branding.banner_url}
              alt="Banner"
              className="w-full h-full object-cover"
            />
            <div
              className="absolute inset-0 bg-gradient-to-r from-black to-transparent"
              style={{ opacity: bannerLayout.overlay_opacity }}
            />
          </div>
        )}

        {canManage && (
          <div className="absolute top-4 right-4 z-20 flex gap-2">
            <Button
              onClick={() => setShowEditGroupDialog(true)}
              className="bg-green-600/90 backdrop-blur-md hover:bg-green-700 text-white border border-white/30 shadow-xl"
              size="sm"
            >
              <Edit className="w-4 h-4 mr-2" />
              Edit Group
            </Button>
            <Button
              onClick={() => setShowBannerLayoutDialog(true)}
              className="bg-white/20 backdrop-blur-md hover:bg-white/30 text-white border border-white/30 shadow-xl"
              size="sm"
            >
              <Settings className="w-4 h-4 mr-2" />
              Layout
            </Button>
          </div>
        )}

        <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`flex flex-col h-full py-8 sm:py-12 ${
            bannerLayout.content_position === 'center' ? 'justify-center items-center' :
            bannerLayout.content_position === 'right' ? 'justify-center items-end' :
            'justify-center items-start'
          }`}>
            {bannerLayout.show_logo && group?.logo_url && (
              <div className={`mb-6 ${
                bannerLayout.logo_position === 'center' ? 'mx-auto' :
                bannerLayout.logo_position === 'right' ? 'ml-auto' : ''
              }`}>
                <img
                  src={group.logo_url}
                  alt={group.name}
                  style={{
                    width: bannerLayout.logo_size,
                    height: bannerLayout.logo_size
                  }}
                  className="rounded-2xl shadow-2xl object-cover border-4 border-white/20"
                />
              </div>
            )}

            <div className={`max-w-2xl ${getAlignmentClass(bannerLayout.content_position)}`}>
              <h1
                className={`${getTitleSizeClass(bannerLayout.title_size)} ${getFontWeightClass(bannerLayout.title_font_weight)} mb-4 ${getAlignmentClass(bannerLayout.title_alignment)} drop-shadow-lg`}
                style={{ color: bannerLayout.text_color }}
              >
                {group?.name}
              </h1>

              {bannerLayout.show_description && group?.description && (
                <p
                  className={`${getDescriptionSizeClass(bannerLayout.description_size)} mb-6 ${getAlignmentClass(bannerLayout.description_alignment)} drop-shadow-md max-w-xl`}
                  style={{ color: bannerLayout.text_color, opacity: 0.95 }}
                >
                  {group.description}
                </p>
              )}

              <div className={`flex gap-3 mb-6 flex-wrap ${
                bannerLayout.title_alignment === 'center' ? 'justify-center' :
                bannerLayout.title_alignment === 'right' ? 'justify-end' :
                'justify-start'
              }`}>
                {bannerLayout.show_member_count && (
                  <div className="flex items-center gap-2 bg-white/20 backdrop-blur-md px-4 py-2 rounded-full border border-white/30">
                    <UsersIcon className="w-4 h-4" style={{ color: bannerLayout.text_color }} />
                    <span className="font-semibold" style={{ color: bannerLayout.text_color }}>
                      {members.length} Members
                    </span>
                  </div>
                )}

                {bannerLayout.show_group_type && (
                  <div className="bg-white/20 backdrop-blur-md px-4 py-2 rounded-full border border-white/30">
                    <span className="font-semibold" style={{ color: bannerLayout.text_color }}>
                      {group?.group_type}
                    </span>
                  </div>
                )}
              </div>

              <div className={`flex gap-3 flex-wrap ${getButtonPositionClass(bannerLayout.button_position)}`}>
                {group?.meeting_room_url && (
                  <a href={`https://meeting.base44.app/?room=${group.meeting_room_url}`} target="_blank" rel="noopener noreferrer">
                    <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white shadow-2xl px-8 py-6 font-bold">
                      <Video className="w-6 h-6 mr-3" />
                      JOIN MEETING
                    </Button>
                  </a>
                )}

                {group?.cegid_discovery?.enabled && (
                  <Link to={`${createPageUrl("CegidDiscovery")}?groupId=${groupId}`}>
                    <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-2xl px-8 py-6 font-bold">
                      <Sparkles className="w-6 h-6 mr-3" />
                      {group.cegid_discovery.button_text || 'DISCOVER CEGID'}
                    </Button>
                  </Link>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 lg:grid-cols-10">
            <TabsTrigger value="feed">Feed</TabsTrigger>
            <TabsTrigger value="chat">Chat</TabsTrigger>
            <TabsTrigger value="notice">Notices</TabsTrigger>
            <TabsTrigger value="docs">Documents</TabsTrigger>
            <TabsTrigger value="events">Events</TabsTrigger>
            <TabsTrigger value="tasks">Tasks</TabsTrigger>
            <TabsTrigger value="sales">Sales</TabsTrigger>
            <TabsTrigger value="courses">Courses</TabsTrigger>
            <TabsTrigger value="games">Games</TabsTrigger>
            <TabsTrigger value="members">Members</TabsTrigger>
          </TabsList>

          {/* FEED TAB - UPDATED WITH REACTIONS & COMMENTS */}
          <TabsContent value="feed" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Group Feed</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4">
                  <Textarea
                    placeholder="Share something with the group..."
                    value={newPost}
                    onChange={(e) => setNewPost(e.target.value)}
                    rows={3}
                  />
                </div>
                <div className="flex gap-2 items-center">
                  <input
                    type="file"
                    onChange={handlePostFileUpload}
                    className="hidden"
                    id="post-file-upload"
                  />
                  <Button
                    onClick={() => document.getElementById('post-file-upload').click()}
                    variant="outline"
                    size="sm"
                    disabled={uploadingFile}
                  >
                    <Paperclip className="w-4 h-4 mr-2" />
                    Attach
                  </Button>
                  <Button onClick={handleCreatePost} disabled={!newPost.trim() && postAttachments.length === 0}>
                    <Send className="w-4 h-4 mr-2" />
                    Post
                  </Button>
                </div>
                {postAttachments.length > 0 && (
                  <div className="flex gap-2 flex-wrap">
                    {postAttachments.map((url, idx) => (
                      <Badge key={idx} variant="secondary">
                        📎 File {idx + 1}
                        <X className="w-3 h-3 ml-1 cursor-pointer" onClick={() => setPostAttachments(postAttachments.filter((_, i) => i !== idx))} />
                      </Badge>
                    ))}
                  </div>
                )}

                {/* FEED POSTS WITH REACTIONS & COMMENTS */}
                <div className="space-y-4 mt-6">
                  {(groupData.feed_posts || []).map((post) => {
                    const totalReactions = getTotalReactions(post.reactions);
                    const userReactions = Object.entries(post.reactions || {}).filter(([type, users]) => 
                      users?.includes(user?.email)
                    ).map(([type]) => type);

                    return (
                      <Card key={post.id} className="border-2 hover:shadow-lg transition-all">
                        <CardContent className="p-6">
                          {/* Post Header */}
                          <div className="flex items-start gap-3 mb-4">
                            <Avatar>
                              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white">
                                {post.sender_name?.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <p className="font-semibold text-lg">{post.sender_name}</p>
                                {post.sender_title && <Badge variant="outline">{post.sender_title}</Badge>}
                              </div>
                              <p className="text-sm text-slate-600">{format(new Date(post.timestamp), 'MMM d, yyyy HH:mm')}</p>
                            </div>
                            {canManage && (
                              <Button
                                onClick={() => deletePostMutation.mutate(post.id)}
                                variant="ghost"
                                size="sm"
                                className="text-red-600 hover:bg-red-50"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            )}
                          </div>

                          {/* Post Content */}
                          <p className="text-slate-900 text-base mb-3 whitespace-pre-wrap">{post.message}</p>
                          
                          {/* Attachments */}
                          {post.attachments?.map((url, idx) => (
                            <div key={idx} className="mt-3">
                              {isImageFile(url) && <img src={url} alt="Attachment" className="rounded-lg max-w-full border-2 border-slate-200" />}
                              {isVideoFile(url) && <video src={url} controls className="rounded-lg max-w-full border-2 border-slate-200" />}
                              {!isImageFile(url) && !isVideoFile(url) && (
                                <a href={url} target="_blank" rel="noopener noreferrer">
                                  <Badge variant="outline" className="cursor-pointer hover:bg-slate-100">
                                    <Paperclip className="w-3 h-3 mr-1" />
                                    Attachment {idx + 1}
                                  </Badge>
                                </a>
                              )}
                            </div>
                          ))}

                          {/* Reaction Summary Bar */}
                          {totalReactions > 0 && (
                            <div className="flex items-center gap-2 mt-4 pt-3 border-t">
                              <div className="flex -space-x-1">
                                {Object.entries(post.reactions || {})
                                  .filter(([, users]) => users?.length > 0)
                                  .sort(([, usersA], [, usersB]) => usersB.length - usersA.length) // Sort by count
                                  .slice(0, 3)
                                  .map(([type]) => (
                                    <span key={type} className="text-lg bg-white rounded-full border-2 border-white shadow-sm">
                                      {getReactionEmoji(type)}
                                    </span>
                                  ))}
                              </div>
                              <span className="text-sm text-slate-600 font-medium">
                                {totalReactions} {totalReactions === 1 ? 'reaction' : 'reactions'}
                              </span>
                            </div>
                          )}

                          {/* Reaction & Comment Buttons */}
                          <div className="flex items-center gap-2 mt-4 pt-3 border-t">
                            <div className="relative flex-1">
                              <Button
                                onClick={() => setShowFeedReactionPicker(showFeedReactionPicker === post.id ? null : post.id)}
                                variant="ghost"
                                className="w-full justify-center hover:bg-blue-50"
                                size="sm"
                              >
                                <Smile className="w-4 h-4 mr-2" />
                                React {userReactions.length > 0 && `(${userReactions.length})`}
                              </Button>

                              {/* Reaction Picker Popup */}
                              {showFeedReactionPicker === post.id && (
                                <div className="absolute bottom-full left-0 mb-2 bg-white border-2 border-slate-200 rounded-xl shadow-2xl p-3 z-50 flex gap-2">
                                  {[
                                    { type: 'like', emoji: '👍', label: 'Like' },
                                    { type: 'love', emoji: '❤️', label: 'Love' },
                                    { type: 'haha', emoji: '😂', label: 'Haha' },
                                    { type: 'wow', emoji: '😮', label: 'Wow' },
                                    { type: 'sad', emoji: '😢', label: 'Sad' },
                                    { type: 'celebrate', emoji: '🎉', label: 'Celebrate' },
                                    { type: 'fire', emoji: '🔥', label: 'Fire' }
                                  ].map(({ type, emoji, label }) => {
                                    const count = post.reactions?.[type]?.length || 0;
                                    const userReacted = post.reactions?.[type]?.includes(user?.email);
                                    
                                    return (
                                      <button
                                        key={type}
                                        onClick={() => addFeedReactionMutation.mutate({ postId: post.id, reactionType: type })}
                                        className={`flex flex-col items-center p-2 rounded-lg hover:bg-slate-100 transition-all group ${
                                          userReacted ? 'bg-blue-50 ring-2 ring-blue-400' : ''
                                        }`}
                                        title={label}
                                      >
                                        <span className="text-2xl group-hover:scale-125 transition-transform">{emoji}</span>
                                        {count > 0 && (
                                          <span className="text-xs font-bold text-slate-600 mt-1">{count}</span>
                                        )}
                                      </button>
                                    );
                                  })}
                                </div>
                              )}
                            </div>

                            <Button
                              onClick={() => setShowCommentInput(showCommentInput === post.id ? null : post.id)}
                              variant="ghost"
                              className="flex-1 justify-center hover:bg-slate-50"
                              size="sm"
                            >
                              <MessageSquare className="w-4 h-4 mr-2" />
                              Comment {post.comments?.length > 0 && `(${post.comments.length})`}
                            </Button>
                          </div>

                          {/* Comments Section */}
                          {post.comments && post.comments.length > 0 && (
                            <div className="mt-4 pt-4 border-t space-y-3">
                              <p className="text-sm font-semibold text-slate-700 mb-3">
                                💬 {post.comments.length} {post.comments.length === 1 ? 'Comment' : 'Comments'}
                              </p>
                              {post.comments.map((comment) => (
                                <div key={comment.id} className="flex items-start gap-3 bg-slate-50 rounded-lg p-3">
                                  <Avatar className="w-8 h-8">
                                    <AvatarFallback className="bg-gradient-to-br from-green-500 to-emerald-500 text-white text-xs">
                                      {comment.user_name?.charAt(0)}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div className="flex-1">
                                    <div className="flex items-center gap-2 mb-1">
                                      <p className="font-semibold text-sm">{comment.user_name}</p>
                                      {comment.edited && <Badge variant="outline" className="text-xs">Edited</Badge>}
                                    </div>
                                    <p className="text-sm text-slate-800">{comment.comment}</p>
                                    <p className="text-xs text-slate-500 mt-1">
                                      {format(new Date(comment.timestamp), 'MMM d, HH:mm')}
                                    </p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}

                          {/* Comment Input */}
                          {showCommentInput === post.id && (
                            <div className="mt-4 pt-4 border-t">
                              <div className="flex gap-2">
                                <Avatar className="w-8 h-8">
                                  <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white text-xs">
                                    {user?.full_name?.charAt(0)}
                                  </AvatarFallback>
                                </Avatar>
                                <Input
                                  placeholder="Write a comment..."
                                  value={commentText}
                                  onChange={(e) => setCommentText(e.target.value)}
                                  onKeyPress={(e) => e.key === 'Enter' && handleAddComment(post.id)}
                                  className="flex-1"
                                />
                                <Button
                                  onClick={() => handleAddComment(post.id)}
                                  disabled={!commentText.trim() || addCommentMutation.isPending}
                                  size="sm"
                                >
                                  <Send className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>

                {(!groupData.feed_posts || groupData.feed_posts.length === 0) && (
                  <div className="text-center py-12">
                    <MessageSquare className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500">No posts yet. Be the first to share something!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* CHAT TAB */}
          <TabsContent value="chat" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Group Chat</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4 max-h-[500px] overflow-y-auto">
                  {getTopLevelMessages().map((msg) => {
                    const replies = getReplies(msg.id);
                    const isExpanded = expandedThreads[msg.id];

                    return (
                      <div key={msg.id} className="border rounded-lg p-4">
                        <div className="flex items-start gap-3">
                          <Avatar>
                            <AvatarFallback>{msg.sender_name?.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <p className="font-semibold">{msg.sender_name}</p>
                              {msg.sender_title && <Badge variant="outline">{msg.sender_title}</Badge>}
                            </div>
                            <p className="text-sm text-slate-600 mb-2">{format(new Date(msg.timestamp), 'MMM d, HH:mm')}</p>
                            <p className="text-slate-900">{msg.message}</p>
                            
                            {msg.attachments?.map((url, idx) => (
                              <div key={idx} className="mt-2">
                                {isImageFile(url) && <img src={url} alt="Attachment" className="rounded-lg max-w-sm" />}
                                {isVideoFile(url) && <video src={url} controls className="rounded-lg max-w-sm" />}
                              </div>
                            ))}

                            <div className="flex gap-2 mt-2">
                              {msg.reactions?.map((r, idx) => (
                                <Badge key={idx} variant="outline">
                                  {r.emoji} {msg.reactions.filter(x => x.emoji === r.emoji).length}
                                </Badge>
                              )).filter((badge, idx, self) => self.findIndex(b => b.key === badge.key) === idx)}
                              
                              <Button
                                onClick={() => setShowReactionPicker(showReactionPicker === msg.id ? null : msg.id)}
                                variant="ghost"
                                size="sm"
                              >
                                <Smile className="w-4 h-4" />
                              </Button>
                              
                              <Button
                                onClick={() => setReplyingTo(msg)}
                                variant="ghost"
                                size="sm"
                              >
                                <Reply className="w-4 h-4 mr-1" />
                                Reply
                              </Button>

                              {canManage && (
                                <Button
                                  onClick={() => deleteMessageMutation.mutate(msg.id)}
                                  variant="ghost"
                                  size="sm"
                                  className="text-red-600"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              )}
                            </div>

                            {showReactionPicker === msg.id && (
                              <div className="flex gap-2 mt-2 p-2 bg-slate-50 rounded-lg">
                                {reactions.map(emoji => (
                                  <button
                                    key={emoji}
                                    onClick={() => addReactionMutation.mutate({ messageId: msg.id, reaction: emoji })}
                                    className="text-2xl hover:scale-125 transition-transform"
                                  >
                                    {emoji}
                                  </button>
                                ))}
                              </div>
                            )}

                            {replies.length > 0 && (
                              <div className="mt-3">
                                <Button
                                  onClick={() => setExpandedThreads(prev => ({ ...prev, [msg.id]: !prev[msg.id] }))}
                                  variant="ghost"
                                  size="sm"
                                >
                                  {isExpanded ? 'Hide' : 'Show'} {replies.length} {replies.length === 1 ? 'reply' : 'replies'}
                                </Button>
                                {isExpanded && (
                                  <div className="mt-3 ml-6 space-y-3 border-l-2 pl-4">
                                    {replies.map(reply => (
                                      <div key={reply.id} className="flex items-start gap-2">
                                        <Avatar className="w-8 h-8">
                                          <AvatarFallback>{reply.sender_name?.charAt(0)}</AvatarFallback>
                                        </Avatar>
                                        <div className="flex-1">
                                          <p className="font-semibold text-sm">{reply.sender_name}</p>
                                          <p className="text-sm text-slate-900">{reply.message}</p>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="border-t pt-4">
                  {replyingTo && (
                    <div className="bg-blue-50 p-2 rounded mb-2 flex items-center justify-between">
                      <p className="text-sm">Replying to {replyingTo.sender_name}</p>
                      <Button onClick={() => setReplyingTo(null)} variant="ghost" size="sm">
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                  <div className="flex gap-2">
                    <Input
                      placeholder="Type a message..."
                      value={chatMessage}
                      onChange={(e) => setChatMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && sendChatMessage()}
                    />
                    <input
                      type="file"
                      onChange={handleChatFileUpload}
                      className="hidden"
                      id="chat-file-upload"
                    />
                    <Button
                      onClick={() => document.getElementById('chat-file-upload').click()}
                      variant="outline"
                      disabled={uploadingFile}
                    >
                      <Paperclip className="w-4 h-4" />
                    </Button>
                    <Button onClick={sendChatMessage}>
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* NOTICE BOARD TAB */}
          <TabsContent value="notice" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Notice Board</CardTitle>
                  {canManage && (
                    <Button onClick={() => setShowNoticeDialog(true)}>
                      <Plus className="w-4 h-4 mr-2" />
                      New Notice
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {(groupData.notice_board || []).map((notice) => (
                  <Card key={notice.id} className="border-2 border-orange-200 bg-orange-50">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Pin className="w-5 h-5 text-orange-600 flex-shrink-0 mt-1" />
                        <div className="flex-1">
                          <h3 className="font-bold text-lg mb-2">{notice.title}</h3>
                          <p className="text-slate-700 mb-2">{notice.content}</p>
                          <p className="text-xs text-slate-500">
                            Posted by {notice.author_name} • {format(new Date(notice.created_date), 'MMM d, yyyy')}
                          </p>
                        </div>
                        {isTopTierAdmin && (
                          <Button
                            onClick={() => deleteNoticeMutation.mutate(notice.id)}
                            variant="ghost"
                            size="sm"
                            className="text-red-600"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {(!groupData.notice_board || groupData.notice_board.length === 0) && (
                  <p className="text-center text-slate-500 py-8">No notices yet</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* DOCUMENTS TAB */}
          <TabsContent value="docs" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Shared Documents</CardTitle>
                  <Button onClick={() => setShowDocDialog(true)}>
                    <Upload className="w-4 h-4 mr-2" />
                    Upload
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {(groupData.shared_documents || []).map((doc) => (
                    <Card key={doc.file_url}>
                      <CardContent className="p-4">
                        <FileText className="w-8 h-8 text-blue-600 mb-2" />
                        <h3 className="font-semibold mb-1">{doc.title}</h3>
                        <p className="text-sm text-slate-600 mb-2">{doc.description}</p>
                        <p className="text-xs text-slate-500 mb-3">
                          By {doc.uploaded_by_name} • {format(new Date(doc.uploaded_date), 'MMM d, yyyy')}
                        </p>
                        <a href={doc.file_url} target="_blank" rel="noopener noreferrer">
                          <Button size="sm" className="w-full">
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </Button>
                        </a>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                {(!groupData.shared_documents || groupData.shared_documents.length === 0) && (
                  <p className="text-center text-slate-500 py-8">No documents yet</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* EVENTS TAB */}
          <TabsContent value="events" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Group Events</CardTitle>
                  <Button onClick={() => setShowEventDialog(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Event
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {events.map((event) => (
                    <Card key={event.id}>
                      <CardContent className="p-4">
                        <CalendarIcon className="w-8 h-8 text-purple-600 mb-2" />
                        <h3 className="font-semibold mb-1">{event.title}</h3>
                        <p className="text-sm text-slate-600 mb-2">{event.description}</p>
                        <div className="text-xs text-slate-500 space-y-1 mb-3">
                          <p>📅 {format(new Date(event.date), 'MMM d, yyyy')}</p>
                          {event.time && <p>⏰ {event.time}</p>}
                          {event.location && <p>📍 {event.location}</p>}
                        </div>
                        
                        {/* Calendar Sync Buttons */}
                        <div className="flex gap-2">
                          <a 
                            href={`https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(event.title)}&dates=${new Date(event.date).toISOString().replace(/[-:]/g, '').split('.')[0]}Z/${new Date(new Date(event.date).getTime() + 3600000).toISOString().replace(/[-:]/g, '').split('.')[0]}Z&details=${encodeURIComponent(event.description || '')}&location=${encodeURIComponent(event.location || '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1"
                          >
                            <Button size="sm" variant="outline" className="w-full">
                              <CalendarIcon className="w-3 h-3 mr-1" />
                              Google
                            </Button>
                          </a>
                          <a 
                            href={`https://outlook.live.com/calendar/0/deeplink/compose?subject=${encodeURIComponent(event.title)}&body=${encodeURIComponent(event.description || '')}&location=${encodeURIComponent(event.location || '')}&startdt=${new Date(event.date).toISOString()}&enddt=${new Date(new Date(event.date).getTime() + 3600000).toISOString()}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1"
                          >
                            <Button size="sm" variant="outline" className="w-full">
                              <CalendarIcon className="w-3 h-3 mr-1" />
                              Outlook
                            </Button>
                          </a>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                {events.length === 0 && (
                  <p className="text-center text-slate-500 py-8">No events yet</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* TASKS TAB (WITHOUT SALES) */}
          <TabsContent value="tasks" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Group Tasks</CardTitle>
                  {canManage && (
                    <Button onClick={() => setShowTaskDialog(true)}>
                      <Plus className="w-4 h-4 mr-2" />
                      New Task
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {(groupData.tasks || []).map((task) => (
                    <Card key={task.id} className={`border-2 ${
                      task.status === 'completed' ? 'border-green-200 bg-green-50' :
                      task.status === 'in_progress' ? 'border-blue-200 bg-blue-50' :
                      'border-slate-200'
                    }`}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="font-bold text-lg mb-2">{task.title}</h3>
                            <p className="text-sm text-slate-600 mb-2">{task.description}</p>
                            <div className="flex items-center gap-4 text-sm text-slate-500">
                              <span>👤 Assigned to: {members.find(m => m.user_email === task.assigned_to)?.full_name || task.assigned_to}</span>
                              {task.due_date && <span>📅 Due: {format(new Date(task.due_date), 'MMM d, yyyy')}</span>}
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Select 
                              value={task.status} 
                              onValueChange={(value) => updateTaskMutation.mutate({ taskId: task.id, updates: { status: value } })}
                              disabled={!canManage && task.assigned_to !== user?.email}
                            >
                              <SelectTrigger className="w-32">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="todo">To Do</SelectItem>
                                <SelectItem value="in_progress">In Progress</SelectItem>
                                <SelectItem value="completed">Completed</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {(!groupData.tasks || groupData.tasks.length === 0) && (
                    <p className="text-center text-slate-500 py-8">No tasks yet</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* SALES TRACKING TAB (SEPARATE) */}
          <TabsContent value="sales" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>📊 Sales Tracking & Leaderboard</CardTitle>
                  <Button onClick={() => setShowSalesDialog(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Sales
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-bold mb-3">🏆 Top Performers</h3>
                    <div className="space-y-2">
                      {getLeaderboard().slice(0, 10).map((member, idx) => (
                        <div key={member.email} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <span className={`text-2xl font-bold ${
                              idx === 0 ? 'text-yellow-500' :
                              idx === 1 ? 'text-slate-400' :
                              idx === 2 ? 'text-orange-600' :
                              'text-slate-400'
                            }`}>#{idx + 1}</span>
                            <div>
                              <p className="font-semibold">{member.name}</p>
                              <p className="text-xs text-slate-500">{member.email}</p>
                            </div>
                          </div>
                          <Badge className="text-lg">{member.total} sales</Badge>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="font-bold mb-3">📈 Recent Entries</h3>
                    <div className="space-y-2">
                      {(groupData.sales_follow_up || []).slice(0, 10).map((entry) => (
                        <div key={entry.id} className="p-3 bg-slate-50 rounded-lg">
                          <div className="flex items-center justify-between mb-1">
                            <p className="font-semibold text-sm">{entry.user_name}</p>
                            <Badge variant="outline">{entry.sales_count} sales</Badge>
                          </div>
                          <p className="text-xs text-slate-500">{format(new Date(entry.date), 'MMM d, yyyy')}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* COURSES TAB */}
          <TabsContent value="courses" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Group Courses</CardTitle>
              </CardHeader>
              <CardContent>
                {groupCourses.length > 0 ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {groupCourses.map((course) => (
                      <Card key={course.id} className="hover:shadow-lg transition-all">
                        <CardContent className="p-4">
                          <BookOpen className="w-8 h-8 text-blue-600 mb-2" />
                          <h3 className="font-bold mb-2">{course.title}</h3>
                          <p className="text-sm text-slate-600 mb-3 line-clamp-2">{course.description}</p>
                          <Link to={`${createPageUrl("Learning")}?courseId=${course.id}`}>
                            <Button className="w-full">
                              <Play className="w-4 h-4 mr-2" />
                              Start Learning
                            </Button>
                          </Link>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <BookOpen className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500">No courses assigned to this group yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* GAMES TAB (PSA-OOT) */}
          <TabsContent value="games" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>🎮 PSA-OOT Games</CardTitle>
                  {canManage && (
                    <Link to={createPageUrl("PsaOotAdmin")}>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        Create Game
                      </Button>
                    </Link>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {psaGames.length > 0 ? (
                  <div className="grid md:grid-cols-2 gap-4">
                    {psaGames.map((game) => (
                      <Card key={game.id} className="border-2 border-purple-200 hover:shadow-xl transition-all">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div>
                              <h3 className="font-bold text-xl mb-2">{game.title}</h3>
                              <Badge className={
                                game.status === 'completed' ? 'bg-green-600' :
                                game.status === 'active' ? 'bg-blue-600' :
                                game.status === 'waiting' ? 'bg-yellow-600' :
                                'bg-slate-600'
                              }>
                                {game.status}
                              </Badge>
                            </div>
                            <Gamepad2 className="w-10 h-10 text-purple-600" />
                          </div>
                          <div className="space-y-2 text-sm text-slate-600 mb-4">
                            <p>📝 Questions: {game.questions?.length || 0}</p>
                            <p>👥 Players: {game.players?.length || 0}</p>
                            <p>🎲 Code: <span className="font-mono font-bold text-lg">{game.game_code}</span></p>
                          </div>
                          <Link to={game.status === 'waiting' || game.status === 'active' ? 
                            `${createPageUrl("PsaOotPlay")}?gameId=${game.id}` :
                            `${createPageUrl("PsaOotHost")}?gameId=${game.id}`
                          }>
                            <Button className="w-full bg-purple-600 hover:bg-purple-700">
                              {game.status === 'completed' ? 'View Results' : 
                               game.status === 'active' ? 'Join Game' : 
                               'Start Game'}
                            </Button>
                          </Link>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Gamepad2 className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500 mb-4">No games created yet</p>
                    {canManage && (
                      <Link to={createPageUrl("PsaOotAdmin")}>
                        <Button>Create First Game</Button>
                      </Link>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* MEMBERS TAB - UPDATED WITH KICK FUNCTIONALITY */}
          <TabsContent value="members" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Group Members ({members.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {members.map((member) => (
                    <div key={member.user_email} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarFallback>{member.full_name?.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-semibold">{member.full_name}</p>
                          <p className="text-sm text-slate-500">{member.user_email}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {member.role === 'admin' && <Badge className="bg-orange-600">Admin</Badge>}
                        {member.points > 0 && <Badge variant="outline">{member.points} pts</Badge>}
                        {canManage && member.user_email !== user?.email && (
                          <Button
                            onClick={() => {
                              if (confirm(`Remove ${member.full_name} from the group?`)) {
                                kickMemberMutation.mutate(member.user_email);
                              }
                            }}
                            variant="ghost"
                            size="sm"
                            className="text-red-600 hover:bg-red-50"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Private Messaging Button */}
        {user && (
          <div className="fixed bottom-6 right-6 z-50">
            <Button 
              onClick={() => setShowPrivateMessageDialog(true)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-2xl"
              size="lg"
            >
              <MessageCircle className="w-5 h-5 mr-2" />
              Private Messages
            </Button>
          </div>
        )}
      </div>

      {/* DIALOGS */}
      <Dialog open={showDocDialog} onOpenChange={setShowDocDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Upload Document</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Title</Label>
              <Input
                value={newDocument.title}
                onChange={(e) => setNewDocument({ ...newDocument, title: e.target.value })}
                placeholder="Document title"
              />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea
                value={newDocument.description}
                onChange={(e) => setNewDocument({ ...newDocument, description: e.target.value })}
                placeholder="Brief description"
                rows={3}
              />
            </div>
            <div>
              <Label>File</Label>
              <input
                type="file"
                onChange={handleFileUpload}
                className="block w-full text-sm"
              />
            </div>
            <Button onClick={handleUploadDocument} className="w-full" disabled={uploadingFile}>
              {uploadingFile ? 'Uploading...' : 'Upload Document'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showEventDialog} onOpenChange={setShowEventDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Event</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Title</Label>
              <Input
                value={newEvent.title}
                onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                placeholder="Event title"
              />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea
                value={newEvent.description}
                onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                placeholder="Event description"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Date</Label>
                <Input
                  type="date"
                  value={newEvent.date}
                  onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                />
              </div>
              <div>
                <Label>Time</Label>
                <Input
                  type="time"
                  value={newEvent.time}
                  onChange={(e) => setNewEvent({ ...newEvent, time: e.target.value })}
                />
              </div>
            </div>
            <div>
              <Label>Location</Label>
              <Input
                value={newEvent.location}
                onChange={(e) => setNewEvent({ ...newEvent, location: e.target.value })}
                placeholder="Location or URL"
              />
            </div>
            <Button onClick={handleCreateEvent} className="w-full">
              Create Event
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showNoticeDialog} onOpenChange={setShowNoticeDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Post Notice</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Title</Label>
              <Input
                value={newNotice.title}
                onChange={(e) => setNewNotice({ ...newNotice, title: e.target.value })}
                placeholder="Notice title"
              />
            </div>
            <div>
              <Label>Content</Label>
              <Textarea
                value={newNotice.content}
                onChange={(e) => setNewNotice({ ...newNotice, content: e.target.value })}
                placeholder="Notice content"
                rows={5}
              />
            </div>
            <div>
              <Label>Expire Date (Optional)</Label>
              <Input
                type="date"
                value={newNotice.expire_date}
                onChange={(e) => setNewNotice({ ...newNotice, expire_date: e.target.value })}
              />
            </div>
            <Button onClick={handleCreateNotice} className="w-full">
              Post Notice
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showEditGroupDialog} onOpenChange={setShowEditGroupDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Group Info</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Group Name</Label>
              <Input
                value={groupInfoForm.name}
                onChange={(e) => setGroupInfoForm({ ...groupInfoForm, name: e.target.value })}
              />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea
                value={groupInfoForm.description}
                onChange={(e) => setGroupInfoForm({ ...groupInfoForm, description: e.target.value })}
                rows={3}
              />
            </div>
            <Button onClick={() => updateGroupInfoMutation.mutate(groupInfoForm)} className="w-full">
              Save Changes
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showBannerLayoutDialog} onOpenChange={setShowBannerLayoutDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Customize Banner Layout</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Banner Height</Label>
              <Input
                value={bannerLayoutForm.height}
                onChange={(e) => setBannerLayoutForm({ ...bannerLayoutForm, height: e.target.value })}
                placeholder="e.g., 400px"
              />
            </div>
            <div>
              <Label>Content Position</Label>
              <Select
                value={bannerLayoutForm.content_position}
                onValueChange={(value) => setBannerLayoutForm({ ...bannerLayoutForm, content_position: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="left">Left</SelectItem>
                  <SelectItem value="center">Center</SelectItem>
                  <SelectItem value="right">Right</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={() => saveBannerLayoutMutation.mutate(bannerLayoutForm)} className="w-full">
              <Save className="w-4 h-4 mr-2" />
              Save Layout
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Task Dialog */}
      <Dialog open={showTaskDialog} onOpenChange={setShowTaskDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Task</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Task Title *</Label>
              <Input
                value={newTask.title}
                onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                placeholder="Task title"
              />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea
                value={newTask.description}
                onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                placeholder="Task description"
                rows={3}
              />
            </div>
            <div>
              <Label>Assign To *</Label>
              <Select value={newTask.assigned_to} onValueChange={(value) => setNewTask({ ...newTask, assigned_to: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select member" />
                </SelectTrigger>
                <SelectContent>
                  {members.map(member => (
                    <SelectItem key={member.user_email} value={member.user_email}>
                      {member.full_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Due Date</Label>
              <Input
                type="date"
                value={newTask.due_date}
                onChange={(e) => setNewTask({ ...newTask, due_date: e.target.value })}
              />
            </div>
            <Button onClick={handleCreateTask} className="w-full">
              Create Task
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Sales Entry Dialog */}
      <Dialog open={showSalesDialog} onOpenChange={setShowSalesDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Sales Entry</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Date *</Label>
              <Input
                type="date"
                value={newSalesEntry.date}
                onChange={(e) => setNewSalesEntry({ ...newSalesEntry, date: e.target.value })}
              />
            </div>
            <div>
              <Label>Number of Sales *</Label>
              <Input
                type="number"
                value={newSalesEntry.sales_count}
                onChange={(e) => setNewSalesEntry({ ...newSalesEntry, sales_count: parseInt(e.target.value) || 0 })}
                min="0"
                placeholder="Enter sales count"
              />
            </div>
            {groupData.sales_custom_columns?.map((column) => (
              <div key={column.id}>
                <Label>{column.name}</Label>
                <Input
                  type={column.type}
                  onChange={(e) => {
                    const customData = { ...newSalesEntry.custom_data };
                    customData[column.id] = column.type === 'number' ? parseFloat(e.target.value) : e.target.value;
                    setNewSalesEntry({ ...newSalesEntry, custom_data: customData });
                  }}
                />
              </div>
            ))}
            <Button onClick={handleAddSalesEntry} className="w-full">
              Add Entry
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Private Messaging Dialog */}
      <Dialog open={showPrivateMessageDialog} onOpenChange={setShowPrivateMessageDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Private Messages</DialogTitle>
          </DialogHeader>
          <PrivateMessaging user={user} groupId={groupId} groupName={groupData?.name} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
