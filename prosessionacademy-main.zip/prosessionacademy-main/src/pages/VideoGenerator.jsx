
import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Sparkles,
  Loader2,
  FileVideo,
  Download,
  PlayCircle,
  Video,
  AlertCircle,
  Film
} from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function VideoGenerator() {
  const [user, setUser] = useState(null);
  const [videoPrompt, setVideoPrompt] = useState('');
  const [videoDuration, setVideoDuration] = useState(5); // seconds
  const [generatingVideo, setGeneratingVideo] = useState(false);
  const [generatedImages, setGeneratedImages] = useState([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState(null);
  const [videoTitle, setVideoTitle] = useState('');
  
  const canvasRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error:", error);
        base44.auth.redirectToLogin();
      }
    };
    fetchUser();
  }, []);

  const calculateRequiredImages = () => {
    const fps = 24;
    return videoDuration * fps; // 24 images per second
  };

  const handleGenerateVideo = async () => {
    if (!videoPrompt.trim()) {
      alert('⚠️ Please enter a video description');
      return;
    }

    setGeneratingVideo(true);
    setGeneratedImages([]);
    setRecordedVideoUrl(null);
    
    const requiredImages = calculateRequiredImages();
    
    try {
      // Step 1: Generate frame-by-frame animation sequence
      const storyboardResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Create a FRAME-BY-FRAME ANIMATION sequence for: "${videoPrompt}"

CRITICAL: This is NOT separate scenes - it's SMOOTH ANIMATION like a cartoon!

Generate EXACTLY ${requiredImages} frames that show PROGRESSIVE MOVEMENT frame by frame.

Each frame should show a TINY incremental change from the previous frame to create smooth motion.

Example - "dog running":
Frame 1: Dog standing still, legs together
Frame 2: Dog's front right leg lifted 10 degrees
Frame 3: Dog's front right leg lifted 20 degrees
Frame 4: Dog's front right leg lifted 30 degrees, body leaning forward
Frame 5: Dog's front right leg extended forward, back left leg pushing off
...and so on with TINY incremental movements

For "${videoPrompt}", create ${requiredImages} frames with SMOOTH PROGRESSIVE MOTION.

Return ONLY valid JSON:
{
  "title": "Animation title",
  "frames": [
    {
      "frame_number": 1,
      "visual": "EXTREMELY detailed description of EXACT positions, angles, and state in this specific frame. Include: exact body positions, angles, distances, expressions, background. Be precise about what moves between frames."
    }
  ]
}

Remember: Each frame should be SLIGHTLY different from the previous one to create smooth animation!`,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            frames: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  frame_number: { type: "number" },
                  visual: { type: "string" }
                }
              }
            }
          },
          required: ["title", "frames"]
        }
      });

      setVideoTitle(storyboardResult.title);
      
      // Step 2: Generate images for each frame with consistency
      const images = [];
      const baseStyle = "consistent animation style, same character design, same lighting, same perspective, frame-by-frame animation";
      
      for (let i = 0; i < storyboardResult.frames.length; i++) {
        const frame = storyboardResult.frames[i];
        
        try {
          const imagePrompt = `${frame.visual}. ${baseStyle}. Animation frame ${i + 1} of ${storyboardResult.frames.length}. Professional 2D/3D animation quality, consistent character design, smooth motion`;
          
          const imageResult = await base44.integrations.Core.GenerateImage({
            prompt: imagePrompt
          });
          
          images.push({
            frame_number: frame.frame_number,
            image_url: imageResult.url,
            visual: frame.visual
          });
          
          setGeneratedImages([...images]);
        } catch (error) {
          console.error('Frame generation error:', error);
          images.push({
            frame_number: frame.frame_number,
            image_url: null,
            error: true,
            visual: frame.visual
          });
          setGeneratedImages([...images]);
        }
      }
      
      alert(`✅ Generated ${images.length} animation frames! Click "Create Video" to compile into downloadable video.`);

    } catch (error) {
      console.error('Video generation error:', error);
      alert('❌ Failed to generate: ' + error.message);
    } finally {
      setGeneratingVideo(false);
    }
  };

  const createVideoFromImages = async () => {
    if (generatedImages.length === 0) return;

    setIsRecording(true);
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    // Set canvas size (1920x1080 for Full HD)
    canvas.width = 1920;
    canvas.height = 1080;

    // Start recording
    const stream = canvas.captureStream(24); // 24 FPS
    const mediaRecorder = new MediaRecorder(stream, {
      mimeType: 'video/webm;codecs=vp9',
      videoBitsPerSecond: 8000000 // 8 Mbps for high quality
    });

    chunksRef.current = [];

    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        chunksRef.current.push(event.data);
      }
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: 'video/webm' });
      const url = URL.createObjectURL(blob);
      setRecordedVideoUrl(url);
      setIsRecording(false);
      alert('✅ Video created! You can now download it.');
    };

    mediaRecorder.start();
    mediaRecorderRef.current = mediaRecorder;

    // Play through images at 24 FPS
    let currentFrame = 0;
    const fps = 24;
    const frameDuration = 1000 / fps; // ~41.67ms per frame

    const renderFrame = () => {
      if (currentFrame >= generatedImages.length) {
        // Finished - stop recording
        mediaRecorder.stop();
        return;
      }

      const frame = generatedImages[currentFrame];
      
      if (frame.image_url) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
          // Clear canvas
          ctx.fillStyle = '#000000';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          
          // Calculate scaling to fit image
          const scale = Math.min(canvas.width / img.width, canvas.height / img.height);
          const x = (canvas.width - img.width * scale) / 2;
          const y = (canvas.height - img.height * scale) / 2;
          
          ctx.drawImage(img, x, y, img.width * scale, img.height * scale);
          
          currentFrame++;
          setTimeout(renderFrame, frameDuration);
        };
        img.onerror = () => {
          // Skip failed image
          currentFrame++;
          setTimeout(renderFrame, frameDuration);
        };
        img.src = frame.image_url;
      } else {
        // Skip failed frame
        currentFrame++;
        setTimeout(renderFrame, frameDuration);
      }
    };

    renderFrame();
  };

  const playPreview = () => {
    setIsPlaying(true);
    setCurrentImageIndex(0);
    
    const fps = 24;
    const frameDuration = 1000 / fps;
    
    const playNextFrame = (index) => {
      if (index >= generatedImages.length) {
        setIsPlaying(false);
        setCurrentImageIndex(0);
        return;
      }
      
      setCurrentImageIndex(index);
      setTimeout(() => playNextFrame(index + 1), frameDuration);
    };
    
    playNextFrame(0);
  };

  const downloadVideo = () => {
    if (!recordedVideoUrl) return;
    
    const a = document.createElement('a');
    a.href = recordedVideoUrl;
    a.download = `${videoTitle.replace(/[^a-z0-9]/gi, '_')}_${Date.now()}.webm`;
    a.click();
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-purple-600"></div>
      </div>
    );
  }

  const requiredImages = calculateRequiredImages();

  return (
    <div className="p-6 lg:p-8 min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Film className="w-12 h-12 text-purple-600 animate-pulse" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              AI Video Generator
            </h1>
          </div>
          <p className="text-slate-600 text-lg">
            Create REAL downloadable videos with AI - Completely FREE!
          </p>
        </div>

        <Card className="border-none shadow-2xl bg-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-purple-600" />
              Generate Your Video
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <Alert className="bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-300">
              <AlertCircle className="h-5 w-5 text-green-700" />
              <AlertDescription className="text-green-900">
                <p className="font-bold mb-2">✅ 100% FREE Real Video Creation</p>
                <p className="text-sm">
                  Generates {requiredImages} AI images at 24 FPS, compiles them into a downloadable video file!
                </p>
              </AlertDescription>
            </Alert>

            {!generatedImages.length ? (
              <>
                <div>
                  <Label className="text-lg font-bold mb-2 block">Video Description:</Label>
                  <Textarea
                    value={videoPrompt}
                    onChange={(e) => setVideoPrompt(e.target.value)}
                    rows={6}
                    placeholder="Example: A journey through space showing planets, stars, and galaxies. Start with Earth, zoom out through the solar system, past Jupiter, through the asteroid belt, and into deep space with colorful nebulas..."
                    className="text-base"
                  />
                </div>

                <div>
                  <Label className="text-lg font-bold mb-2 block">Video Duration (seconds):</Label>
                  <Input
                    type="number"
                    min="3"
                    max="20"
                    value={videoDuration}
                    onChange={(e) => setVideoDuration(parseInt(e.target.value) || 5)}
                    className="text-base"
                  />
                  <p className="text-sm text-slate-500 mt-2">
                    Will generate <strong>{requiredImages} images</strong> at 24 FPS for a {videoDuration}-second video
                  </p>
                </div>

                <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4">
                  <p className="font-bold text-blue-900 mb-2">💡 Tips for Better Videos:</p>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>• Describe a clear sequence of events</li>
                    <li>• Be specific about transitions and movements</li>
                    <li>• Shorter durations (5-10s) work best</li>
                    <li>• Describe visual style (cinematic, animated, realistic)</li>
                  </ul>
                </div>

                <Button
                  onClick={handleGenerateVideo}
                  disabled={!videoPrompt.trim() || generatingVideo}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-xl py-8 shadow-xl"
                >
                  {generatingVideo ? (
                    <>
                      <Loader2 className="w-6 h-6 mr-2 animate-spin" />
                      Generating {generatedImages.length}/{requiredImages} Frames...
                    </>
                  ) : (
                    <>
                      <FileVideo className="w-6 h-6 mr-2" />
                      Generate {requiredImages} Frames (FREE)
                    </>
                  )}
                </Button>
              </>
            ) : (
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-2xl p-8">
                  <h2 className="text-3xl font-bold mb-4">✅ {videoTitle}</h2>
                  <p className="text-lg mb-4">Generated {generatedImages.length} frames at 24 FPS</p>
                  
                  {/* Preview Canvas */}
                  <div className="bg-black rounded-xl overflow-hidden mb-6 shadow-2xl" style={{ aspectRatio: '16/9' }}>
                    {generatedImages[currentImageIndex]?.image_url ? (
                      <img 
                        src={generatedImages[currentImageIndex].image_url} 
                        alt={`Frame ${currentImageIndex + 1}`}
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-white">
                        <Loader2 className="w-16 h-16 animate-spin" />
                      </div>
                    )}
                    <div className="absolute top-6 right-6 bg-black/70 px-4 py-2 rounded-full text-white text-lg font-bold">
                      Frame {currentImageIndex + 1} / {generatedImages.length}
                    </div>
                  </div>

                  {/* Controls */}
                  <div className="flex gap-3 flex-wrap">
                    <Button
                      onClick={playPreview}
                      disabled={isPlaying || isRecording}
                      className="flex-1 bg-white text-purple-600 hover:bg-gray-100 text-lg py-6"
                    >
                      <PlayCircle className="w-6 h-6 mr-2" />
                      {isPlaying ? 'Playing Preview...' : 'Preview Animation'}
                    </Button>
                    
                    <Button
                      onClick={createVideoFromImages}
                      disabled={isRecording || recordedVideoUrl}
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white text-lg py-6"
                    >
                      {isRecording ? (
                        <>
                          <Loader2 className="w-6 h-6 mr-2 animate-spin" />
                          Creating Video...
                        </>
                      ) : recordedVideoUrl ? (
                        <>
                          <FileVideo className="w-6 h-6 mr-2" />
                          Video Ready!
                        </>
                      ) : (
                        <>
                          <Film className="w-6 h-6 mr-2" />
                          Create Video File
                        </>
                      )}
                    </Button>

                    {recordedVideoUrl && (
                      <Button
                        onClick={downloadVideo}
                        className="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-lg py-6"
                      >
                        <Download className="w-6 h-6 mr-2" />
                        Download Video
                      </Button>
                    )}
                  </div>
                </div>

                {/* Hidden canvas for video recording */}
                <canvas ref={canvasRef} style={{ display: 'none' }} />

                {/* Video Preview */}
                {recordedVideoUrl && (
                  <div className="bg-white rounded-xl p-6 shadow-lg">
                    <h3 className="text-xl font-bold mb-4">Your Video:</h3>
                    <video 
                      src={recordedVideoUrl} 
                      controls 
                      className="w-full rounded-lg"
                      style={{ maxHeight: '500px' }}
                    />
                  </div>
                )}

                {/* Frame Grid */}
                <div>
                  <h3 className="text-xl font-bold mb-4">All Frames ({generatedImages.length}):</h3>
                  <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-2">
                    {generatedImages.map((frame, idx) => (
                      <div
                        key={idx}
                        onClick={() => !isPlaying && !isRecording && setCurrentImageIndex(idx)}
                        className={`cursor-pointer rounded-lg overflow-hidden border-2 transition-all ${
                          currentImageIndex === idx ? 'border-pink-500 scale-105' : 'border-transparent hover:border-purple-300'
                        }`}
                      >
                        {frame.image_url ? (
                          <img src={frame.image_url} alt={`Frame ${idx + 1}`} className="w-full h-20 object-cover" />
                        ) : frame.error ? (
                          <div className="w-full h-20 bg-red-100 flex items-center justify-center text-red-600 text-xs">
                            Error
                          </div>
                        ) : (
                          <div className="w-full h-20 bg-gray-200 flex items-center justify-center">
                            <Loader2 className="w-4 h-4 animate-spin text-purple-600" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <Button
                  onClick={() => {
                    setGeneratedImages([]);
                    setVideoPrompt('');
                    setRecordedVideoUrl(null);
                    setCurrentImageIndex(0);
                  }}
                  variant="outline"
                  className="w-full text-lg py-6"
                >
                  Create Another Video
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* How It Works */}
        <Card className="border-none shadow-lg bg-gradient-to-r from-blue-50 to-purple-50">
          <CardContent className="p-6">
            <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-purple-600" />
              How It Works
            </h3>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="bg-white rounded-lg p-4 shadow-md">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-3">
                  <span className="text-2xl font-bold text-purple-600">1</span>
                </div>
                <h4 className="font-bold mb-2">Describe Video</h4>
                <p className="text-sm text-slate-600">Tell AI what video you want and how long</p>
              </div>
              <div className="bg-white rounded-lg p-4 shadow-md">
                <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center mb-3">
                  <span className="text-2xl font-bold text-pink-600">2</span>
                </div>
                <h4 className="font-bold mb-2">Generate Frames</h4>
                <p className="text-sm text-slate-600">AI creates {requiredImages}+ images at 24 FPS</p>
              </div>
              <div className="bg-white rounded-lg p-4 shadow-md">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-3">
                  <span className="text-2xl font-bold text-blue-600">3</span>
                </div>
                <h4 className="font-bold mb-2">Compile Video</h4>
                <p className="text-sm text-slate-600">Frames are compiled into real video file</p>
              </div>
              <div className="bg-white rounded-lg p-4 shadow-md">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-3">
                  <span className="text-2xl font-bold text-green-600">4</span>
                </div>
                <h4 className="font-bold mb-2">Download & Share</h4>
                <p className="text-sm text-slate-600">Download as .webm video file</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
