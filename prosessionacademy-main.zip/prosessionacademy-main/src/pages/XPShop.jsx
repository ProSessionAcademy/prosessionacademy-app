
import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import {
  Star, ShoppingBag, Sparkles, Crown, Building2, Factory, Store, TrendingUp,
  DollarSign, Users, Briefcase, AlertTriangle, Scale, Gift, Plane,
  Trophy, Lock, CheckCircle2, ArrowUp, ArrowDown, Loader2, Target,
  Zap, ShieldCheck, Heart, Coins, Hammer, Megaphone, Wrench, Droplet,
  Info, HelpCircle, LineChart, Wallet, Flame, UserPlus, Rocket, Package, Clock,
  Gavel, MessageCircle, Send, TrendingDown, Plus
} from 'lucide-react';
import { motion } from 'framer-motion';

export default function XPShop() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [selectedTab, setSelectedTab] = useState('shop');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showInvestDialog, setShowInvestDialog] = useState(false);
  const [showLoanDialog, setShowLoanDialog] = useState(false);
  const [showMarketingDialog, setShowMarketingDialog] = useState(false);
  const [showRulesDialog, setShowRulesDialog] = useState(false);
  const [showIPODialog, setShowIPODialog] = useState(false);
  const [showEmployeeDialog, setShowEmployeeDialog] = useState(false);
  const [showSummaryDialog, setShowSummaryDialog] = useState(false);
  const [showAuctionDialog, setShowAuctionDialog] = useState(false);
  const [showNegotiationDialog, setShowNegotiationDialog] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState(null);
  const [selectedCompanyForMarketing, setSelectedCompanyForMarketing] = useState('');
  const [selectedCompanyForIPO, setSelectedCompanyForIPO] = useState('');
  const [selectedCompanyForEmployee, setSelectedCompanyForEmployee] = useState('');
  const [employeeType, setEmployeeType] = useState('');
  const [investAmount, setInvestAmount] = useState('');
  const [loanAmount, setLoanAmount] = useState('');
  const [ipoSharesPercent, setIpoSharesPercent] = useState('');
  const [marketNews, setMarketNews] = useState([]);
  const [selectedAssetForAuction, setSelectedAssetForAuction] = useState(null);
  const [selectedAssetForNegotiation, setSelectedAssetForNegotiation] = useState(null);
  const [bidAmount, setBidAmount] = useState('');
  const [offerAmount, setOfferAmount] = useState('');
  const [persuasionText, setPersuasionText] = useState('');

  // Function to calculate changes while the user was away
  const calculateWhileAway = async (userData, hoursAway) => {
    let stats = userData.game_stats;
    const initialCash = Math.round(stats.cash);
    const summary = {
      investment_gains: 0,
      asset_income: 0,
      events: [],
      total_change: 0,
      initial_cash: initialCash,
      final_cash: initialCash,
      hours_away: hoursAway
    };

    // Calculate passive income from assets
    (stats.assets || []).forEach(asset => {
      const income = Math.round((asset.income_rate || 0) * hoursAway);
      summary.asset_income += income;
      stats.cash += income;
    });

    // Calculate investment returns
    const updatedInvestments = { ...stats.investments };
    Object.entries(updatedInvestments).forEach(([key, inv]) => {
      const growth = inv.asset.growth_rate || 0.05;
      const risk = inv.asset.risk_factor || 0.1;
      // Simple simulation for hourly growth/loss over the period
      let currentAmount = inv.amount;
      for (let i = 0; i < hoursAway; i++) {
        const profitLossPerHour = currentAmount * (Math.random() * (risk * 2) - risk + growth);
        currentAmount += profitLossPerHour;
      }
      const gain = Math.round(currentAmount - inv.amount);
      updatedInvestments[key].amount = currentAmount;
      summary.investment_gains += gain;
      stats.cash += gain; // Add/subtract investment changes to cash
    });
    stats.investments = updatedInvestments;


    // Simulate random events
    const eventRolls = Math.floor(hoursAway / 1); // Check for events every hour
    for (let i = 0; i < eventRolls; i++) {
      if (Math.random() < 0.05) { // Lower chance for fines
        const fineAmount = Math.floor(Math.random() * 500) + 100;
        summary.events.push({
          type: 'fine',
          description: `Regulatory fine`,
          impact: -fineAmount
        });
        stats.cash -= fineAmount;
      }
      if (Math.random() < 0.02 && !stats.lawyer) { // Lower chance for lawsuits, if no lawyer
        const lawsuitAmount = Math.floor(Math.random() * 1000) + 300;
        summary.events.push({
          type: 'lawsuit',
          description: `Lawsuit settlement`,
          impact: -lawsuitAmount
        });
        stats.cash -= lawsuitAmount;
      } else if (Math.random() < 0.02 && stats.lawyer) { // With lawyer, reduce penalty
        const lawsuitAmount = Math.floor(Math.random() * 1000) + 300;
        const reducedAmount = Math.round(lawsuitAmount * (1 - stats.lawyer.skill)); // Lawyer reduces by skill %
        summary.events.push({
          type: 'lawsuit',
          description: `Lawsuit settlement (reduced by lawyer)`,
          impact: -reducedAmount
        });
        stats.cash -= reducedAmount;
      }
    }

    stats.cash = Math.round(stats.cash);
    summary.final_cash = stats.cash;
    summary.total_change = summary.final_cash - initialCash;

    // Update the user's game stats with the new cash and investments
    await base44.auth.updateMe({
      game_stats: {
        ...stats,
        away_summary: summary // Store the summary for display
      }
    });
  };

  useEffect(() => {
    const fetchAndProcessUser = async () => {
      let currentUser = await base44.auth.me();

      if (!currentUser.game_stats) {
        await base44.auth.updateMe({
          game_stats: {
            cash: 5000,
            assets: [],
            investments: {},
            employees: {},
            loans: [],
            lawyer: null,
            marketing_team: null,
            marketing_target: null,
            reputation: 50,
            happiness: 50,
            last_investment_check: Date.now(),
            last_login: Date.now(), // Initialize last_login
            event_history: [],
            active_projects: [],
            player_rank: "Junior Tycoon",
            market_prices: {},
            owned_shares: {},
            company_departments: {},
            away_summary: null
          }
        });
        currentUser = await base44.auth.me(); // Refetch after init
      } else {
        if (currentUser.game_stats.last_login) {
          const timeDiff = Date.now() - currentUser.game_stats.last_login;
          const hoursAway = Math.floor(timeDiff / (1000 * 60 * 60));

          if (hoursAway > 0) {
            await calculateWhileAway(currentUser, hoursAway);
            currentUser = await base44.auth.me(); // Refetch after away calculations to get updated stats
            setShowSummaryDialog(true); // Show summary dialog after processing
          }
        }

        // Update last_login regardless, using the potentially updated currentUser
        await base44.auth.updateMe({
          game_stats: {
            ...currentUser.game_stats,
            last_login: Date.now()
          }
        });
        currentUser = await base44.auth.me(); // Refetch one last time to get final state
      }
      setUser(currentUser);
    };

    fetchAndProcessUser();

    const investmentInterval = setInterval(() => {
      processInvestments();
    }, 5 * 60 * 1000);

    const eventInterval = setInterval(() => {
      triggerRandomEvent();
    }, 10 * 60 * 1000);

    const marketInterval = setInterval(() => {
      fluctuateMarket();
    }, 15 * 60 * 1000);

    return () => {
      clearInterval(investmentInterval);
      clearInterval(eventInterval);
      clearInterval(marketInterval);
    };
  }, []);

  const { data: shopAssets = [] } = useQuery({
    queryKey: ['businessAssets'],
    queryFn: () => base44.entities.BusinessAsset.filter({ available: true }),
    initialData: []
  });

  const { data: buildProjects = [] } = useQuery({
    queryKey: ['buildProjects'],
    queryFn: () => base44.entities.BuildProject.filter({ available: true }),
    initialData: []
  });

  const { data: allUsers = [], isLoading: isLoadingUsers } = useQuery({
    queryKey: ['allUsers'],
    queryFn: async () => {
      const response = await base44.functions.invoke('getUserLeaderboard');
      // The serverless function should return data in the format:
      // { data: { leaderboard: [{ username, email, xp_points, net_worth, rank }, ...] } }
      return response.data.leaderboard || [];
    },
    initialData: [],
    refetchInterval: 10000
  });

  const { data: activeAuctions = [] } = useQuery({
    queryKey: ['activeAuctions'],
    queryFn: () => base44.entities.Auction.filter({ status: 'active' }),
    initialData: [],
    refetchInterval: 5000
  });

  const { data: myNegotiations = [] } = useQuery({
    queryKey: ['myNegotiations', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      return await base44.entities.Negotiation.filter({ buyer_email: user.email });
    },
    enabled: !!user?.email,
    initialData: []
  });

  const calculateNetWorth = (player) => {
    const xp = player.xp_points || 0;
    const cash = player.game_stats?.cash || 0;

    const assetsValue = (player.game_stats?.assets || []).reduce((sum, asset) => {
      return sum + (asset.cost || 0);
    }, 0);

    const investmentsValue = Object.values(player.game_stats?.investments || {}).reduce((sum, inv) => {
      return sum + inv.amount;
    }, 0);

    const projectsValue = (player.game_stats?.active_projects || []).reduce((sum, project) => {
      return sum + (project.total_cost || 0);
    }, 0);

    const sharesValue = Object.values(player.game_stats?.owned_shares || {}).reduce((sum, share) => {
      return sum + (share.value || 0);
    }, 0);

    const loansTotal = (player.game_stats?.loans || []).reduce((sum, loan) => {
      return sum + loan.amount * (1 + loan.interest);
    }, 0);

    return Math.round(xp + cash + assetsValue + investmentsValue + projectsValue + sharesValue - loansTotal);
  };

  const updateGameStats = async (updates) => {
    if (updates.cash !== undefined) {
      updates.cash = Math.round(updates.cash);
    }
    
    const newStats = { ...user.game_stats, ...updates };

    const tempUser = { ...user, game_stats: newStats };
    const netWorth = calculateNetWorth(tempUser);

    let newRank = "Junior Tycoon";
    if (netWorth >= 100000) newRank = "XP Legend";
    else if (netWorth >= 50000) newRank = "Mogul";
    else if (netWorth >= 20000) newRank = "Tycoon";

    newStats.player_rank = newRank;

    await base44.auth.updateMe({ game_stats: newStats });
    const updatedUser = await base44.auth.me();
    setUser(updatedUser);
    queryClient.invalidateQueries(['allUsers']);
  };

  const fluctuateMarket = async () => {
    if (!user?.game_stats) return;

    const priceChanges = {};
    shopAssets.forEach(asset => {
      const change = (Math.random() - 0.5) * 0.1;
      priceChanges[asset.id] = 1 + change;
    });

    const newsItem = {
      title: "Market Update",
      description: "Asset prices fluctuated based on market conditions",
      timestamp: new Date().toISOString()
    };

    setMarketNews(prev => [newsItem, ...prev.slice(0, 9)]);

    await updateGameStats({
      market_prices: priceChanges
    });
  };

  const buyAssetMutation = useMutation({
    mutationFn: async (asset) => {
      const stats = user.game_stats;
      const priceMultiplier = stats.market_prices?.[asset.id] || 1;
      const finalCost = Math.round(asset.cost * priceMultiplier);

      if (stats.cash < finalCost) throw new Error('Not enough cash!');

      const newAssets = [...stats.assets, { ...asset, purchased_date: new Date().toISOString(), purchase_price: finalCost }];
      const newCash = Math.round(stats.cash - finalCost);

      await updateGameStats({ assets: newAssets, cash: newCash });
    },
    onSuccess: () => {
      alert('✅ Asset purchased!');
    }
  });

  const sellAssetMutation = useMutation({
    mutationFn: async (assetId) => {
      const stats = user.game_stats;
      const asset = stats.assets.find(a => a.id === assetId);
      if (!asset) return;

      const priceMultiplier = stats.market_prices?.[asset.id] || 1;
      const finalSellPrice = Math.round((asset.sell_price || asset.cost * 0.7) * priceMultiplier);

      const newAssets = stats.assets.filter(a => a.id !== assetId);
      const newCash = Math.round(stats.cash + finalSellPrice);

      await updateGameStats({ assets: newAssets, cash: newCash });
    },
    onSuccess: () => {
      alert('✅ Asset sold!');
    }
  });

  const startProjectMutation = useMutation({
    mutationFn: async (project) => {
      const stats = user.game_stats;
      if (stats.cash < project.total_cost) throw new Error('Not enough cash!');

      const newProject = {
        ...project,
        start_date: new Date().toISOString(),
        completion_date: new Date(Date.now() + project.build_time_days * 24 * 60 * 60 * 1000).toISOString(),
        status: 'building'
      };

      const newProjects = [...(stats.active_projects || []), newProject];
      const newCash = Math.round(stats.cash - project.total_cost);

      await updateGameStats({ active_projects: newProjects, cash: newCash });
    },
    onSuccess: () => {
      alert('✅ Project started! Check back when completed.');
    }
  });

  const launchIPOMutation = useMutation({
    mutationFn: async () => {
      const sharesPercent = parseFloat(ipoSharesPercent);
      if (isNaN(sharesPercent) || sharesPercent <= 0 || sharesPercent > 100) throw new Error('Invalid percentage');

      const stats = user.game_stats;
      const company = stats.assets.find(a => a.id === selectedCompanyForIPO);
      if (!company) throw new Error('Company not found');

      const companyValue = company.cost * 2;
      const cashRaised = Math.round((companyValue * sharesPercent) / 100);

      const newShares = {
        ...stats.owned_shares,
        [selectedCompanyForIPO]: {
          company_name: company.name,
          ownership_percent: 100 - sharesPercent,
          value: Math.round(companyValue * (100 - sharesPercent) / 100)
        }
      };

      const newCash = Math.round(stats.cash + cashRaised);

      await updateGameStats({
        owned_shares: newShares,
        cash: newCash
      });
    },
    onSuccess: () => {
      setShowIPODialog(false);
      setIpoSharesPercent('');
      alert('✅ IPO successful! Cash raised from selling shares.');
    }
  });

  const hireEmployeeMutation = useMutation({
    mutationFn: async () => {
      const costs = {
        marketing: 1500,
        production: 1200,
        rd: 2000,
        hr: 1000
      };

      const cost = costs[employeeType];
      if (user.game_stats.cash < cost) throw new Error('Not enough cash!');

      const stats = user.game_stats;
      const companyEmployees = stats.employees[selectedCompanyForEmployee] || [];

      const newEmployee = {
        id: Date.now().toString(),
        type: employeeType,
        skill: Math.random() * 0.3 + 0.6,
        happiness: 80,
        hired_date: new Date().toISOString()
      };

      const newEmployees = {
        ...stats.employees,
        [selectedCompanyForEmployee]: [...companyEmployees, newEmployee]
      };

      const newCash = Math.round(stats.cash - cost);

      await updateGameStats({
        employees: newEmployees,
        cash: newCash
      });
    },
    onSuccess: () => {
      setShowEmployeeDialog(false);
      alert('✅ Employee hired!');
    }
  });

  const investMutation = useMutation({
    mutationFn: async () => {
      const amount = Math.round(parseFloat(investAmount));
      if (isNaN(amount) || amount <= 0) throw new Error('Invalid amount');
      if (user.game_stats.cash < amount) throw new Error('Not enough cash!');

      const stats = user.game_stats;
      const newInvestments = { ...stats.investments };
      const key = `${selectedAsset.id}_${Date.now()}`;
      newInvestments[key] = {
        asset: selectedAsset,
        amount: amount,
        start_date: new Date().toISOString(),
        last_check: Date.now()
      };

      const newCash = Math.round(stats.cash - amount);
      await updateGameStats({ investments: newInvestments, cash: newCash });
    },
    onSuccess: () => {
      setShowInvestDialog(false);
      setInvestAmount('');
      alert('✅ Investment made!');
    }
  });

  const takeLoanMutation = useMutation({
    mutationFn: async () => {
      const amount = Math.round(parseFloat(loanAmount));
      if (isNaN(amount) || amount <= 0) throw new Error('Invalid amount');

      const stats = user.game_stats;
      const newLoan = {
        id: Date.now().toString(),
        amount: amount,
        interest: 0.15,
        due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        taken_date: new Date().toISOString()
      };

      const newLoans = [...stats.loans, newLoan];
      const newCash = Math.round(stats.cash + amount);

      await updateGameStats({ loans: newLoans, cash: newCash });
    },
    onSuccess: () => {
      setShowLoanDialog(false);
      setLoanAmount('');
      alert('✅ Loan approved! Repay within 30 days.');
    }
  });

  const hireLawyerMutation = useMutation({
    mutationFn: async () => {
      if (user.game_stats.cash < 2000) throw new Error('Not enough cash!');

      const lawyer = {
        name: 'Elite Attorney',
        skill: 0.75, // Lawyer reduces penalty by 75%
        hired_date: new Date().toISOString()
      };

      const newCash = Math.round(user.game_stats.cash - 2000);
      await updateGameStats({ lawyer, cash: newCash });
    },
    onSuccess: () => {
      alert('✅ Lawyer hired! You are protected from lawsuits.');
    }
  });

  const hireMarketingMutation = useMutation({
    mutationFn: async () => {
      if (user.game_stats.cash < 5000) throw new Error('Not enough cash!');
      if (!selectedCompanyForMarketing) throw new Error('Select a company!');

      const marketing = {
        hired_date: new Date().toISOString(),
        monthly_cost: 500,
        revenue_boost: 0.2
      };

      const newCash = Math.round(user.game_stats.cash - 5000);
      await updateGameStats({
        marketing_team: marketing,
        marketing_target: selectedCompanyForMarketing,
        cash: newCash
      });
    },
    onSuccess: () => {
      setShowMarketingDialog(false);
      alert('✅ Marketing team hired! +20% revenue for selected company.');
    }
  });

  const placeBidMutation = useMutation({
    mutationFn: async ({ auctionId, amount }) => {
      const bidAmount = Math.round(amount);
      const auction = activeAuctions.find(a => a.id === auctionId);
      if (!auction) throw new Error('Auction not found');
      if (bidAmount <= auction.current_bid) throw new Error('Bid too low!');
      if (user.game_stats.cash < bidAmount) throw new Error('Not enough cash!');

      const newBid = {
        bidder_email: user.email,
        bidder_name: user.full_name,
        amount: bidAmount,
        timestamp: new Date().toISOString()
      };

      const updatedBidHistory = [...(auction.bid_history || []), newBid];

      await base44.entities.Auction.update(auctionId, {
        current_bid: bidAmount,
        current_bidder_email: user.email,
        current_bidder_name: user.full_name,
        bid_history: updatedBidHistory
      });
      await updateGameStats({ cash: Math.round(user.game_stats.cash - bidAmount) }); // Deduct bid amount for now, returned if outbid
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['activeAuctions']);
      setBidAmount('');
      alert('✅ Bid placed successfully!');
    },
    onError: (error) => {
      alert(`Error placing bid: ${error.message}`);
    }
  });

  const buyoutAuctionMutation = useMutation({
    mutationFn: async (auction) => {
      if (!auction.buyout_price) throw new Error('No buyout price set');
      const buyoutPrice = Math.round(auction.buyout_price);
      if (user.game_stats.cash < buyoutPrice) throw new Error('Not enough cash!');

      const newAssets = [...user.game_stats.assets, {
        ...auction.asset_data,
        purchased_date: new Date().toISOString(),
        purchase_price: buyoutPrice
      }];

      await updateGameStats({
        assets: newAssets,
        cash: Math.round(user.game_stats.cash - buyoutPrice)
      });

      // Update the auction status to completed
      await base44.entities.Auction.update(auction.id, {
        status: 'completed',
        winner_email: user.email,
        final_price: buyoutPrice
      });

      // Refund previous bidder if any
      if (auction.current_bidder_email && auction.current_bidder_email !== user.email) {
        // This would require a server-side function to update other users' cash
        // For client-side simulation, we'll assume the cash was held and is now released.
        // In a real app, this would be a server-side transaction.
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['activeAuctions']);
      alert('✅ Buyout successful! Asset added to portfolio.');
    },
    onError: (error) => {
      alert(`Error with buyout: ${error.message}`);
    }
  });

  const startNegotiationMutation = useMutation({
    mutationFn: async () => {
      const offer = parseFloat(offerAmount);
      if (isNaN(offer) || offer <= 0) throw new Error('Invalid amount');
      if (user.game_stats.cash < offer) throw new Error('Not enough cash!');
      if (!selectedAssetForNegotiation) throw new Error('No asset selected for negotiation.');

      const negotiation = {
        asset_id: selectedAssetForNegotiation.id,
        asset_name: selectedAssetForNegotiation.name,
        asset_data: selectedAssetForNegotiation,
        buyer_email: user.email,
        buyer_name: user.full_name,
        seller_type: 'ai', // Assuming AI seller for shop assets
        initial_price: selectedAssetForNegotiation.cost,
        offered_price: offer,
        persuasion_text: persuasionText,
        buyer_reputation: user.game_stats.reputation,
        status: 'pending',
        negotiation_history: [{
          offer: offer,
          text: persuasionText,
          timestamp: new Date().toISOString(),
          type: 'offer'
        }]
      };

      const created = await base44.entities.Negotiation.create(negotiation);

      // Use AI to analyze the negotiation
      const analysisResponse = await base44.functions.invoke('analyzeNegotiation', {
        assetName: selectedAssetForNegotiation.name,
        assetCost: selectedAssetForNegotiation.cost,
        offerAmount: offer,
        persuasionText: persuasionText,
        reputation: user.game_stats.reputation
      });

      const analysis = analysisResponse.data;

      if (analysis.accepted) {
        const newAssets = [...user.game_stats.assets, {
          ...selectedAssetForNegotiation,
          purchased_date: new Date().toISOString(),
          purchase_price: offer
        }];

        await updateGameStats({
          assets: newAssets,
          cash: Math.round(user.game_stats.cash - offer)
        });

        await base44.entities.Negotiation.update(created.id, {
          status: 'accepted',
          final_price: offer,
          acceptance_chance: analysis.acceptance_probability
        });

        return { success: true, reason: analysis.reason };
      } else {
        await base44.entities.Negotiation.update(created.id, {
          status: 'rejected',
          acceptance_chance: analysis.acceptance_probability
        });

        return { success: false, reason: analysis.reason };
      }
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries(['myNegotiations']);
      setShowNegotiationDialog(false);
      setOfferAmount('');
      setPersuasionText('');

      if (result.success) {
        alert(`🎉 Deal accepted! ${result.reason}`);
      } else {
        alert(`❌ Offer rejected. ${result.reason}`);
      }
    },
    onError: (error) => {
      alert(`Error negotiating: ${error.message}`);
    }
  });

  const createPlayerAuctionMutation = useMutation({
    mutationFn: async ({ asset, startingPrice, buyoutPrice }) => {
      const auctionAsset = user.game_stats.assets.find(a => a.id === asset.id);
      if (!auctionAsset) throw new Error('Asset not found in your portfolio!');
      if (startingPrice <= 0) throw new Error('Starting price must be greater than 0.');
      if (buyoutPrice && buyoutPrice <= startingPrice) throw new Error('Buyout price must be higher than starting price.');

      const endTime = new Date();
      endTime.setHours(endTime.getHours() + 24); // 24-hour auction

      await base44.entities.Auction.create({
        asset_id: asset.id,
        asset_name: asset.name,
        asset_type: asset.category,
        asset_data: asset,
        auction_type: 'player_driven',
        seller_email: user.email,
        seller_name: user.full_name,
        starting_price: startingPrice,
        current_bid: startingPrice,
        buyout_price: buyoutPrice || null,
        min_increment: Math.max(1, Math.round(startingPrice * 0.05)), // Minimum 5% or 1 cash
        end_time: endTime.toISOString(),
        status: 'active',
        bid_history: []
      });

      const newAssets = user.game_stats.assets.filter(a => a.id !== asset.id);
      await updateGameStats({ assets: newAssets });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['activeAuctions']);
      setShowAuctionDialog(false);
      setSelectedAssetForAuction(null);
      alert('✅ Auction created! Other players can now bid.');
    },
    onError: (error) => {
      alert(`Error creating auction: ${error.message}`);
    }
  });

  const processInvestments = async () => {
    if (!user?.game_stats?.investments) return;

    const stats = user.game_stats;
    const updatedInvestments = { ...stats.investments };
    let totalProfit = 0;

    Object.entries(updatedInvestments).forEach(([key, inv]) => {
      const hoursPassed = (Date.now() - inv.last_check) / (1000 * 60 * 60);

      if (hoursPassed >= 5) {
        const risk = inv.asset.risk_factor || 0.1;
        const growth = inv.asset.growth_rate || 0.05;
        const profitLoss = Math.round(inv.amount * (Math.random() * (risk * 2) - risk + growth));

        updatedInvestments[key].amount += profitLoss;
        updatedInvestments[key].last_check = Date.now();
        totalProfit += profitLoss;
      }
    });

    if (totalProfit !== 0) {
      // Apply investment changes to cash as well for current session
      const newCash = Math.round(stats.cash + totalProfit);
      await updateGameStats({ investments: updatedInvestments, cash: newCash });
    }
  };

  const triggerRandomEvent = async () => {
    if (!user?.game_stats) return;

    const eventRoll = Math.random();
    const stats = user.game_stats;

    if (eventRoll < 0.1) {
      const fineAmount = Math.floor(Math.random() * 500) + 100;
      const newCash = Math.round(stats.cash - fineAmount);
      const eventLog = [...(stats.event_history || []), {
        type: 'fine',
        description: `Regulatory fine of ${fineAmount} cash`,
        xp_impact: -fineAmount,
        date: new Date().toISOString()
      }];
      await updateGameStats({ cash: newCash, event_history: eventLog });
      alert(`⚠️ Regulatory Fine! Lost ${fineAmount} cash`);
    } else if (eventRoll < 0.15 && !stats.lawyer) {
      const lawsuitAmount = Math.floor(Math.random() * 1000) + 300;
      const newCash = Math.round(stats.cash - lawsuitAmount);
      const eventLog = [...(stats.event_history || []), {
        type: 'lawsuit',
        description: `Lawsuit: ${lawsuitAmount} cash settlement`,
        xp_impact: -lawsuitAmount,
        date: new Date().toISOString()
      }];
      await updateGameStats({ cash: newCash, event_history: eventLog });
      alert(`🚨 Lawsuit! Lost ${lawsuitAmount} cash`);
    } else if (eventRoll < 0.15 && stats.lawyer) {
      const lawsuitAmount = Math.floor(Math.random() * 1000) + 300;
      const reducedAmount = Math.round(lawsuitAmount * (1 - stats.lawyer.skill));
      const newCash = Math.round(stats.cash - reducedAmount);
      const eventLog = [...(stats.event_history || []), {
        type: 'lawsuit_reduced',
        description: `Lawsuit: ${reducedAmount} cash settlement (Lawyer reduced from ${lawsuitAmount})`,
        xp_impact: -reducedAmount,
        date: new Date().toISOString()
      }];
      await updateGameStats({ cash: newCash, event_history: eventLog });
      alert(`🚨 Lawsuit! Lawyer reduced penalty to ${Math.round(reducedAmount)} cash`);
    }
  };

  const gameStats = user?.game_stats || {
    cash: 0,
    assets: [],
    investments: {},
    loans: [],
    reputation: 50,
    happiness: 50,
    active_projects: [],
    player_rank: "Junior Tycoon",
    employees: {},
    owned_shares: {},
    away_summary: null,
    last_login: Date.now()
  };

  const myNetWorth = user ? calculateNetWorth(user) : 0;
  const myRank = allUsers.findIndex(p => p.email === user?.email) + 1;

  const filteredAssets = selectedCategory === 'all'
    ? shopAssets
    : shopAssets.filter(asset => asset.category === selectedCategory);

  const rarityColors = {
    common: 'bg-slate-200 text-slate-900',
    rare: 'bg-blue-500 text-white',
    epic: 'bg-purple-600 text-white',
    legendary: 'bg-yellow-500 text-slate-900'
  };

  const categoryIcons = {
    company: Building2,
    building: Store,
    resource: Factory,
    service: Gift
  };

  const myCompanies = gameStats.assets?.filter(a => a.category === 'company') || [];

  const getRankBadge = (rank) => {
    const badges = {
      "Junior Tycoon": { color: "bg-slate-500", icon: "🌱" },
      "Tycoon": { color: "bg-blue-600", icon: "💼" },
      "Mogul": { color: "bg-purple-600", icon: "👑" },
      "XP Legend": { color: "bg-yellow-500", icon: "⭐" }
    };
    return badges[rank] || badges["Junior Tycoon"];
  };

  const rankBadge = getRankBadge(gameStats.player_rank);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 p-4 sm:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <h1 className="text-4xl font-black text-white">🎮 Business Tycoon</h1>
            <Badge className={`${rankBadge.color} text-white px-4 py-2 text-lg`}>
              {rankBadge.icon} {gameStats.player_rank}
            </Badge>
          </div>
          <div className="flex gap-3">
            {gameStats.away_summary && (
              <Button
                onClick={() => setShowSummaryDialog(true)}
                className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
                size="lg"
              >
                <Clock className="w-5 h-5 mr-2" />
                What Happened?
              </Button>
            )}
            <Button
              onClick={() => setShowRulesDialog(true)}
              className="bg-blue-600 hover:bg-blue-700"
              size="lg"
            >
              <HelpCircle className="w-5 h-5 mr-2" />
              How to Play
            </Button>
          </div>
        </div>

        <Card className="bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 text-white border-none shadow-2xl">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-4 gap-4">
              <div className="text-center">
                <p className="text-sm text-white/80 mb-1">XP Balance</p>
                <div className="flex items-center justify-center gap-2 text-3xl font-black">
                  <Star className="w-8 h-8" />
                  {user?.xp_points || 0}
                </div>
              </div>
              <div className="text-center">
                <p className="text-sm text-white/80 mb-1">Cash</p>
                <div className="flex items-center justify-center gap-2 text-3xl font-black">
                  <DollarSign className="w-8 h-8" />
                  {Math.round(gameStats.cash)}
                </div>
              </div>
              <div className="text-center">
                <p className="text-sm text-white/80 mb-1">Net Worth</p>
                <div className="flex items-center justify-center gap-2 text-3xl font-black">
                  <Trophy className="w-8 h-8" />
                  {myNetWorth}
                </div>
                <p className="text-xs text-white/70 mt-1">All Assets + Cash - Loans</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-white/80 mb-1">Global Rank</p>
                <div className="flex items-center justify-center gap-2 text-3xl font-black">
                  <Crown className="w-8 h-8" />
                  #{myRank || '—'}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <Card className="bg-white/95 border-none shadow-lg">
            <CardContent className="p-4 text-center">
              <Building2 className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <p className="text-2xl font-bold">{gameStats.assets?.length || 0}</p>
              <p className="text-xs text-slate-600">Assets</p>
            </CardContent>
          </Card>
          <Card className="bg-white/95 border-none shadow-lg">
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <p className="text-2xl font-bold">{Object.keys(gameStats.investments || {}).length}</p>
              <p className="text-xs text-slate-600">Investments</p>
            </CardContent>
          </Card>
          <Card className="bg-white/95 border-none shadow-lg">
            <CardContent className="p-4 text-center">
              <AlertTriangle className="w-8 h-8 text-red-600 mx-auto mb-2" />
              <p className="text-2xl font-bold">{gameStats.loans?.length || 0}</p>
              <p className="text-xs text-slate-600">Loans</p>
            </CardContent>
          </Card>
          <Card className="bg-white/95 border-none shadow-lg">
            <CardContent className="p-4 text-center">
              <Hammer className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <p className="text-2xl font-bold">{gameStats.active_projects?.length || 0}</p>
              <p className="text-xs text-slate-600">Projects</p>
            </CardContent>
          </Card>
          <Card className="bg-white/95 border-none shadow-lg">
            <CardContent className="p-4 text-center">
              <Users className="w-8 h-8 text-orange-600 mx-auto mb-2" />
              <p className="text-2xl font-bold">{Object.values(gameStats.employees || {}).flat().length}</p>
              <p className="text-xs text-slate-600">Employees</p>
            </CardContent>
          </Card>
        </div>

        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="grid grid-cols-7 w-full bg-white/90 border-2 text-xs sm:text-sm">
            <TabsTrigger value="shop">🏪 Shop</TabsTrigger>
            <TabsTrigger value="auctions">🔨 Auctions</TabsTrigger>
            <TabsTrigger value="negotiate">💬 Deals</TabsTrigger>
            <TabsTrigger value="projects">🏗️ Projects</TabsTrigger>
            <TabsTrigger value="portfolio">💼 Portfolio</TabsTrigger>
            <TabsTrigger value="leaderboard">🏆 Board</TabsTrigger>
            <TabsTrigger value="services">🔧 Services</TabsTrigger>
          </TabsList>

          <TabsContent value="shop" className="space-y-4">
            <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
              <TabsList className="grid grid-cols-5 w-full bg-white/90">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="company">Companies</TabsTrigger>
                <TabsTrigger value="building">Buildings</TabsTrigger>
                <TabsTrigger value="resource">Resources</TabsTrigger>
                <TabsTrigger value="service">Luxury</TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredAssets.map((asset, idx) => {
                const isOwned = gameStats.assets?.some(a => a.id === asset.id);
                const canAfford = gameStats.cash >= asset.cost;
                const Icon = categoryIcons[asset.category] || Building2;
                const priceMultiplier = gameStats.market_prices?.[asset.id] || 1;
                const finalCost = Math.round(asset.cost * priceMultiplier);
                const finalSellPrice = Math.round((asset.sell_price || asset.cost * 0.7) * priceMultiplier);

                return (
                  <motion.div
                    key={asset.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: idx * 0.03 }}
                  >
                    <Card className={`border-2 ${isOwned ? 'border-green-400 bg-green-50' : 'border-white/20 bg-white/95'} shadow-xl hover:shadow-2xl transition-all`}>
                      <CardContent className="p-5">
                        <div className="aspect-video bg-gradient-to-br from-slate-900 to-blue-900 rounded-lg mb-3 flex items-center justify-center relative overflow-hidden">
                          {asset.image_url ? (
                            <img src={asset.image_url} alt={asset.name} className="w-full h-full object-cover" />
                          ) : (
                            <Icon className="w-16 h-16 text-white/50" />
                          )}
                          <Badge className={`absolute top-2 right-2 ${rarityColors[asset.rarity]}`}>
                            {asset.rarity}
                          </Badge>
                          {priceMultiplier !== 1 && (
                            <Badge className={`absolute top-2 left-2 ${priceMultiplier > 1 ? 'bg-red-600' : 'bg-green-600'}`}>
                              {priceMultiplier > 1 ? '📈' : '📉'} {((priceMultiplier - 1) * 100).toFixed(0)}%
                            </Badge>
                          )}
                        </div>

                        <h3 className="font-bold text-lg mb-1">{asset.name}</h3>
                        <Badge variant="outline" className="mb-2">{asset.industry}</Badge>
                        <p className="text-sm text-slate-600 mb-3 line-clamp-2">{asset.description}</p>

                        <div className="space-y-1 text-xs text-slate-700 mb-4">
                          <div className="flex justify-between">
                            <span>💰 Cost:</span>
                            <span className="font-bold">{finalCost} Cash</span>
                          </div>
                          <div className="flex justify-between">
                            <span>📈 Income:</span>
                            <span className="font-bold text-green-600">+{asset.income_rate}/hr</span>
                          </div>
                          <div className="flex justify-between">
                            <span>⚠️ Risk:</span>
                            <Progress value={asset.risk_factor * 100} className="w-16 h-2" />
                          </div>
                          <div className="flex justify-between">
                            <span>💵 Sell:</span>
                            <span className="font-bold">{finalSellPrice} Cash</span>
                          </div>
                        </div>

                        {isOwned ? (
                          <div className="space-y-2">
                            <Badge className="w-full bg-green-600 justify-center py-2">
                              <CheckCircle2 className="w-4 h-4 mr-2" />
                              Owned
                            </Badge>
                            <Button
                              onClick={() => sellAssetMutation.mutate(asset.id)}
                              variant="outline"
                              size="sm"
                              className="w-full"
                            >
                              Sell for {finalSellPrice} Cash
                            </Button>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <Button
                              onClick={() => buyAssetMutation.mutate(asset)}
                              disabled={!canAfford}
                              className="w-full bg-gradient-to-r from-blue-600 to-purple-600"
                            >
                              {canAfford ? `Buy ${finalCost} Cash` : <><Lock className="w-4 h-4 mr-2" />Not Enough Cash</>}
                            </Button>
                            {asset.category === 'company' && (
                              <Button
                                onClick={() => {
                                  setSelectedAsset(asset);
                                  setShowInvestDialog(true);
                                }}
                                variant="outline"
                                size="sm"
                                className="w-full"
                              >
                                <TrendingUp className="w-4 h-4 mr-2" />
                                Invest
                              </Button>
                            )}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>

            {filteredAssets.length === 0 && (
              <Card className="p-12 text-center bg-white/90">
                <ShoppingBag className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                <p className="text-xl font-bold">No assets available</p>
              </Card>
            )}
          </TabsContent>

          {/* AUCTIONS TAB */}
          <TabsContent value="auctions" className="space-y-4">
            <Card className="bg-white/95 border-none shadow-xl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Gavel className="w-6 h-6 text-orange-600" />
                    Active Auctions ({activeAuctions.length})
                  </CardTitle>
                  <Button
                    onClick={() => setShowAuctionDialog(true)}
                    className="bg-orange-600 hover:bg-orange-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    List My Asset
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {activeAuctions.map((auction) => {
                    const timeLeft = new Date(auction.end_time) - new Date();
                    const hoursLeft = Math.floor(timeLeft / (1000 * 60 * 60));
                    const minutesLeft = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
                    const isMyAuction = auction.seller_email === user?.email;
                    const isWinning = auction.current_bidder_email === user?.email;
                    const isExpired = timeLeft <= 0;

                    return (
                      <Card key={auction.id} className={`border-2 ${
                        isExpired ? 'border-gray-400 bg-gray-50' :
                        isWinning ? 'border-green-400 bg-green-50' :
                        isMyAuction ? 'border-blue-400 bg-blue-50' :
                        'border-orange-200'
                      }`}>
                        <CardContent className="p-5">
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <h3 className="font-bold text-lg">{auction.asset_name}</h3>
                              <Badge variant="outline">{auction.asset_type}</Badge>
                            </div>
                            <Badge className={isExpired ? 'bg-gray-600' : timeLeft < 3600000 ? 'bg-red-600' : 'bg-orange-600'}>
                              {isExpired ? 'Ended' : `⏰ ${hoursLeft}h ${minutesLeft}m`}
                            </Badge>
                          </div>

                          <div className="space-y-2 text-sm mb-4">
                            <div className="flex justify-between">
                              <span>Current Bid:</span>
                              <span className="font-bold text-green-600">{auction.current_bid} Cash</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Leader:</span>
                              <span className="font-semibold">{auction.current_bidder_name || 'None'}</span>
                            </div>
                            {auction.buyout_price && (
                              <div className="flex justify-between">
                                <span>Buyout:</span>
                                <span className="font-bold text-purple-600">{auction.buyout_price} Cash</span>
                              </div>
                            )}
                            <p className="text-xs text-slate-500">
                              Bids: {auction.bid_history?.length || 0} • Min: +{auction.min_increment}
                            </p>
                          </div>

                          {isExpired ? (
                            <Badge className="w-full bg-gray-600 justify-center py-2">Auction Ended</Badge>
                          ) : isMyAuction ? (
                            <Badge className="w-full bg-blue-600 justify-center py-2">Your Auction</Badge>
                          ) : isWinning ? (
                            <Badge className="w-full bg-green-600 justify-center py-2">🏆 You're Winning!</Badge>
                          ) : (
                            <div className="space-y-2">
                              <Input
                                type="number"
                                placeholder={`Min: ${auction.current_bid + auction.min_increment}`}
                                value={bidAmount}
                                onChange={(e) => setBidAmount(e.target.value)}
                                className="text-center"
                              />
                              <div className="grid grid-cols-2 gap-2">
                                <Button
                                  onClick={() => placeBidMutation.mutate({
                                    auctionId: auction.id,
                                    amount: parseFloat(bidAmount)
                                  })}
                                  disabled={!bidAmount || parseFloat(bidAmount) < auction.current_bid + auction.min_increment || parseFloat(bidAmount) > gameStats.cash}
                                  variant="outline"
                                  size="sm"
                                >
                                  Place Bid
                                </Button>
                                {auction.buyout_price && (
                                  <Button
                                    onClick={() => buyoutAuctionMutation.mutate(auction)}
                                    disabled={gameStats.cash < auction.buyout_price}
                                    className="bg-purple-600 hover:bg-purple-700"
                                    size="sm"
                                  >
                                    Buyout
                                  </Button>
                                )}
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
                {activeAuctions.length === 0 && (
                  <div className="text-center py-12">
                    <Gavel className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500">No active auctions right now</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* NEGOTIATIONS TAB */}
          <TabsContent value="negotiate" className="space-y-4">
            <Card className="bg-white/95 border-none shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="w-6 h-6 text-blue-600" />
                  Interactive Deals & Negotiations
                </CardTitle>
                <p className="text-sm text-slate-600">Negotiate prices and persuade sellers for better deals</p>
              </CardHeader>
              <CardContent>
                <h3 className="font-bold mb-3">Available Assets to Negotiate</h3>
                <div className="grid md:grid-cols-3 gap-4 mb-6">
                  {shopAssets.slice(0, 6).map((asset) => {
                    const Icon = categoryIcons[asset.category] || Building2;
                    const isOwned = gameStats.assets?.some(a => a.id === asset.id);

                    return (
                      <Card key={asset.id} className="border-2 hover:shadow-lg transition-all">
                        <CardContent className="p-4">
                          <div className="aspect-video bg-gradient-to-br from-slate-900 to-blue-900 rounded-lg mb-3 flex items-center justify-center">
                            {asset.image_url ? (
                              <img src={asset.image_url} alt={asset.name} className="w-full h-full object-cover rounded-lg" />
                            ) : (
                              <Icon className="w-12 h-12 text-white/50" />
                            )}
                          </div>
                          <h4 className="font-bold mb-1">{asset.name}</h4>
                          <p className="text-xs text-slate-600 mb-3">List Price: {asset.cost} Cash</p>
                          <Button
                            onClick={() => {
                              setSelectedAssetForNegotiation(asset);
                              setShowNegotiationDialog(true);
                            }}
                            variant="outline"
                            size="sm"
                            className="w-full"
                            disabled={isOwned}
                          >
                            {isOwned ? (
                              <><CheckCircle2 className="w-3 h-3 mr-2" />Owned</>
                            ) : (
                              <><MessageCircle className="w-3 h-3 mr-2" />Negotiate Deal</>
                            )}
                          </Button>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>

                <h3 className="font-bold mb-3">📜 Your Recent Negotiations</h3>
                <div className="space-y-3">
                  {myNegotiations.slice(0, 5).map((neg) => (
                    <Card key={neg.id} className={`border-2 ${
                      neg.status === 'accepted' ? 'border-green-300 bg-green-50' :
                      neg.status === 'rejected' ? 'border-red-300 bg-red-50' :
                      'border-yellow-300 bg-yellow-50'
                    }`}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-bold">{neg.asset_name}</h4>
                            <p className="text-sm text-slate-600">
                              Offered: {neg.offered_price} / List: {neg.initial_price}
                            </p>
                            {neg.persuasion_text && (
                              <p className="text-xs text-slate-500 italic mt-1">"{neg.persuasion_text}"</p>
                            )}
                          </div>
                          <Badge className={
                            neg.status === 'accepted' ? 'bg-green-600' :
                            neg.status === 'rejected' ? 'bg-red-600' :
                            'bg-yellow-600'
                          }>
                            {neg.status}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {myNegotiations.length === 0 && (
                    <p className="text-center text-slate-500 py-8">No negotiations yet</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="projects" className="space-y-4">
            <Card className="bg-white/95 border-none shadow-xl">
              <CardHeader>
                <CardTitle>🏗️ Build Mega Projects</CardTitle>
                <p className="text-sm text-slate-600">Large-scale construction projects with huge returns</p>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {buildProjects.map((project) => {
                    const isBuilding = gameStats.active_projects?.some(p => p.id === project.id);
                    const canAfford = gameStats.cash >= project.total_cost;

                    return (
                      <Card key={project.id} className={`border-2 ${isBuilding ? 'border-yellow-400 bg-yellow-50' : 'border-slate-200'}`}>
                        <CardContent className="p-5">
                          <div className="flex items-start gap-3 mb-3">
                            <Hammer className="w-10 h-10 text-orange-600" />
                            <div className="flex-1">
                              <h4 className="font-bold text-lg">{project.name}</h4>
                              <p className="text-xs text-slate-600">{project.description}</p>
                            </div>
                          </div>

                          <div className="space-y-2 text-sm mb-4">
                            <div className="flex justify-between">
                              <span>Total Cost:</span>
                              <span className="font-bold">{project.total_cost} Cash</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Build Time:</span>
                              <span className="font-bold">{project.build_time_days} days</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Income:</span>
                              <span className="font-bold text-green-600">+{project.income_after_completion}/hr</span>
                            </div>
                          </div>

                          {isBuilding ? (
                            <Badge className="w-full bg-yellow-600 justify-center py-3">
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Building...
                            </Badge>
                          ) : (
                            <Button
                              onClick={() => startProjectMutation.mutate(project)}
                              disabled={!canAfford}
                              className="w-full bg-orange-600 hover:bg-orange-700"
                            >
                              {canAfford ? 'Start Building' : 'Not Enough Cash'}
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/95 border-none shadow-xl">
              <CardHeader>
                <CardTitle>🚧 Active Projects ({gameStats.active_projects?.length || 0})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {gameStats.active_projects?.map((project) => {
                    const daysLeft = Math.ceil((new Date(project.completion_date) - new Date()) / (1000 * 60 * 60 * 24));
                    const totalDays = project.build_time_days;
                    const progressPercentage = Math.max(0, Math.min(100, ((totalDays - daysLeft) / totalDays) * 100));

                    return (
                      <Card key={project.id} className="border-2 border-blue-200">
                        <CardContent className="p-4">
                          <h4 className="font-bold mb-2">{project.name}</h4>
                          <div className="space-y-2">
                            <Progress value={progressPercentage} className="h-3" />
                            <div className="flex justify-between text-xs">
                              <span>Days Left: {daysLeft}</span>
                              <span className="font-bold">{Math.round(progressPercentage)}%</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                  {(!gameStats.active_projects || gameStats.active_projects.length === 0) && (
                    <p className="text-center text-slate-500 py-8">No active projects</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="portfolio" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white/95 border-none shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="w-6 h-6" />
                    My Assets ({gameStats.assets?.length || 0})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-3">
                      {gameStats.assets?.map((asset) => {
                        const employeeCount = gameStats.employees?.[asset.id]?.length || 0;

                        return (
                          <Card key={asset.id} className="border-2">
                            <CardContent className="p-4">
                              <div className="flex items-start justify-between mb-3">
                                <div className="flex-1">
                                  <h4 className="font-bold">{asset.name}</h4>
                                  <Badge variant="outline" className="text-xs mt-1">{asset.category}</Badge>
                                  <p className="text-xs text-slate-600 mt-2">Value: {asset.cost} Cash</p>
                                  <p className="text-xs text-slate-600">Income: +{asset.income_rate}/hr</p>
                                  {employeeCount > 0 && (
                                    <p className="text-xs text-blue-600 mt-1">
                                      <Users className="w-3 h-3 inline mr-1" />
                                      {employeeCount} employees
                                    </p>
                                  )}
                                </div>
                                <Button
                                  onClick={() => sellAssetMutation.mutate(asset.id)}
                                  size="sm"
                                  variant="outline"
                                  className="text-red-600"
                                >
                                  Sell {asset.sell_price}
                                </Button>
                              </div>

                              {asset.category === 'company' && (
                                <div className="space-y-2 mt-3 pt-3 border-t">
                                  <Button
                                    onClick={() => {
                                      setSelectedCompanyForEmployee(asset.id);
                                      setShowEmployeeDialog(true);
                                    }}
                                    size="sm"
                                    variant="outline"
                                    className="w-full"
                                  >
                                    <UserPlus className="w-3 h-3 mr-2" />
                                    Hire Employee
                                  </Button>
                                  <Button
                                    onClick={() => {
                                      setSelectedCompanyForIPO(asset.id);
                                      setShowIPODialog(true);
                                    }}
                                    size="sm"
                                    variant="outline"
                                    className="w-full"
                                  >
                                    <Rocket className="w-3 h-3 mr-2" />
                                    Launch IPO
                                  </Button>
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        );
                      })}
                      {(!gameStats.assets || gameStats.assets.length === 0) && (
                        <p className="text-center text-slate-500 py-8">No assets yet</p>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card className="bg-white/95 border-none shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-6 h-6" />
                    Investments ({Object.keys(gameStats.investments || {}).length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-3">
                      {Object.entries(gameStats.investments || {}).map(([key, inv]) => (
                        <Card key={key} className="border-2">
                          <CardContent className="p-4">
                            <h4 className="font-bold mb-2">{inv.asset.name}</h4>
                            <div className="space-y-1 text-sm">
                              <div className="flex justify-between">
                                <span>Amount:</span>
                                <span className="font-bold">{Math.round(inv.amount)} XP</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Growth:</span>
                                <span className="text-green-600 font-bold">+{(inv.asset.growth_rate * 100).toFixed(1)}%</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                      {Object.keys(gameStats.investments || {}).length === 0 && (
                        <p className="text-center text-slate-500 py-8">No investments yet</p>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-white/95 border-none shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="w-6 h-6 text-purple-600" />
                  Stock Portfolio ({Object.keys(gameStats.owned_shares || {}).length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {Object.entries(gameStats.owned_shares || {}).map(([companyId, share]) => (
                    <Card key={companyId} className="border-2 border-purple-200 bg-purple-50">
                      <CardContent className="p-4">
                        <h4 className="font-bold mb-2">{share.company_name}</h4>
                        <div className="space-y-1 text-sm">
                          <div className="flex justify-between">
                            <span>Ownership:</span>
                            <span className="font-bold">{share.ownership_percent}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Value:</span>
                            <span className="font-bold text-purple-600">{share.value} Cash</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {Object.keys(gameStats.owned_shares || {}).length === 0 && (
                    <p className="text-center text-slate-500 py-4 col-span-2">No stocks owned</p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/95 border-none shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-6 h-6 text-red-600" />
                  Active Loans ({gameStats.loans?.length || 0})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {gameStats.loans?.map((loan) => (
                    <Card key={loan.id} className="border-2 border-red-200 bg-red-50">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-bold text-lg">{loan.amount} Cash</p>
                            <p className="text-xs text-slate-600">Interest: {(loan.interest * 100).toFixed(0)}%</p>
                          </div>
                          <Badge className="bg-red-600">Debt</Badge>
                        </div>
                        <p className="text-xs text-red-700">
                          Total Repay: {Math.round(loan.amount * (1 + loan.interest))} Cash
                        </p>
                        <p className="text-xs text-slate-500 mt-1">
                          Due: {new Date(loan.due_date).toLocaleDateString()}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                  {(!gameStats.loans || gameStats.loans.length === 0) && (
                    <p className="text-center text-slate-500 py-4 col-span-2">No loans</p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/95 border-none shadow-xl">
              <CardHeader>
                <CardTitle>📜 Event History</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-60">
                  <div className="space-y-2">
                    {gameStats.event_history?.slice(-10).reverse().map((event, idx) => (
                      <div key={idx} className={`p-3 rounded-lg ${event.xp_impact >= 0 ? 'bg-green-50' : 'bg-red-50'}`}>
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-semibold">{event.description}</p>
                          <Badge className={event.xp_impact >= 0 ? 'bg-green-600' : 'bg-red-600'}>
                            {event.xp_impact >= 0 ? '+' : ''}{Math.round(event.xp_impact)}
                          </Badge>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">{new Date(event.date).toLocaleString()}</p>
                      </div>
                    ))}
                    {(!gameStats.event_history || gameStats.event_history.length === 0) && (
                      <p className="text-center text-slate-500 py-8">No events yet</p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="leaderboard" className="space-y-4">
            <Card className="bg-white/95 border-none shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="w-6 h-6 text-yellow-600" />
                  Global Leaderboard - All Players ({allUsers.length})
                </CardTitle>
                <p className="text-sm text-slate-600">All Pro-Session Academy users ranked by net worth</p>
              </CardHeader>
              <CardContent>
                {isLoadingUsers || allUsers.length === 0 ? (
                  <div className="text-center py-12">
                    <Loader2 className="w-12 h-12 text-slate-400 mx-auto mb-4 animate-spin" />
                    <p className="text-slate-500">Loading players...</p>
                  </div>
                ) : (
                  <ScrollArea className="h-[600px]">
                    <div className="space-y-2">
                      {allUsers.map((player, idx) => {
                        const playerRankBadge = getRankBadge(player.rank);
                        const isMe = player.email === user?.email;

                        return (
                          <div key={`${player.email}-${idx}`} className={`flex items-center justify-between p-4 rounded-lg transition-all ${
                            isMe ? 'bg-blue-100 border-2 border-blue-400 shadow-md' : 'bg-slate-50 hover:bg-slate-100'
                          }`}>
                            <div className="flex items-center gap-4 flex-1">
                              <span className={`text-2xl font-black min-w-[60px] text-center ${
                                idx === 0 ? 'text-yellow-500' :
                                idx === 1 ? 'text-slate-400' :
                                idx === 2 ? 'text-orange-600' :
                                'text-slate-600'
                              }`}>
                                #{idx + 1}
                              </span>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1 flex-wrap">
                                  <p className="font-bold text-lg truncate">{player.username}</p>
                                  <Badge className={`${playerRankBadge.color} text-xs whitespace-nowrap`}>
                                    {playerRankBadge.icon} {player.rank}
                                  </Badge>
                                  {isMe && (
                                    <Badge className="bg-blue-600 text-xs">You</Badge>
                                  )}
                                </div>
                                <p className="text-xs text-slate-500 truncate">{player.email}</p>
                              </div>
                            </div>
                            <div className="text-right flex-shrink-0 ml-4">
                              <p className="text-2xl font-black text-green-600">{player.net_worth.toLocaleString()}</p>
                              <p className="text-xs text-slate-500">Net Worth</p>
                              <p className="text-sm text-blue-600 font-semibold">{player.xp_points.toLocaleString()} XP</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </ScrollArea>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="services" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-gradient-to-br from-purple-600 to-blue-600 text-white border-none shadow-xl">
                <CardContent className="p-6">
                  <Scale className="w-12 h-12 mb-4" />
                  <h3 className="text-2xl font-bold mb-2">Hire a Lawyer</h3>
                  <p className="text-white/90 mb-4">Protect yourself from lawsuits and reduce penalties by 75%</p>
                  <p className="text-3xl font-black mb-4">2,000 Cash</p>
                  {gameStats.lawyer ? (
                    <Badge className="bg-green-500 text-white text-lg px-4 py-2">
                      <CheckCircle2 className="w-5 h-5 mr-2" />
                      Lawyer Hired ({(gameStats.lawyer.skill * 100).toFixed(0)}% penalty reduction)
                    </Badge>
                  ) : (
                    <Button
                      onClick={() => hireLawyerMutation.mutate()}
                      disabled={gameStats.cash < 2000}
                      className="w-full bg-white text-purple-600 hover:bg-white/90"
                      size="lg"
                    >
                      {gameStats.cash >= 2000 ? 'Hire Lawyer' : 'Not Enough Cash'}
                    </Button>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-pink-600 to-rose-600 text-white border-none shadow-xl">
                <CardContent className="p-6">
                  <Megaphone className="w-12 h-12 mb-4" />
                  <h3 className="text-2xl font-bold mb-2">Marketing Team</h3>
                  <p className="text-white/90 mb-4">Boost one company's revenue by 20%</p>
                  <p className="text-3xl font-black mb-4">5,000 Cash</p>
                  {gameStats.marketing_team ? (
                    <div className="space-y-2">
                      <Badge className="bg-green-500 text-white text-lg px-4 py-2 w-full justify-center">
                        <CheckCircle2 className="w-5 h-5 mr-2" />
                        Team Hired
                      </Badge>
                      <p className="text-sm text-white/90">
                        Marketing: {myCompanies.find(c => c.id === gameStats.marketing_target)?.name || 'N/A'}
                      </p>
                    </div>
                  ) : (
                    <Button
                      onClick={() => setShowMarketingDialog(true)}
                      disabled={gameStats.cash < 5000 || myCompanies.length === 0}
                      className="w-full bg-white text-pink-600 hover:bg-white/90"
                      size="lg"
                    >
                      {myCompanies.length === 0 ? 'Buy a Company First' :
                       gameStats.cash >= 5000 ? 'Hire Team' : 'Not Enough Cash'}
                    </Button>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-red-600 to-orange-600 text-white border-none shadow-xl">
                <CardContent className="p-6">
                  <DollarSign className="w-12 h-12 mb-4" />
                  <h3 className="text-2xl font-bold mb-2">Take a Loan</h3>
                  <p className="text-white/90 mb-4">Borrow cash to expand faster. 15% interest, 30 days repayment</p>
                  <Button
                    onClick={() => setShowLoanDialog(true)}
                    className="w-full bg-white text-red-600 hover:bg-white/90"
                    size="lg"
                  >
                    Apply for Loan
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-600 to-emerald-600 text-white border-none shadow-xl">
                <CardContent className="p-6">
                  <Heart className="w-12 h-12 mb-4" />
                  <h3 className="text-2xl font-bold mb-2">Donate to Charity</h3>
                  <p className="text-white/90 mb-4">Increase reputation and happiness</p>
                  <p className="text-sm text-white/80 mb-4">Current Reputation: {gameStats.reputation}/100</p>
                  <Button
                    className="w-full bg-white text-green-600 hover:bg-white/90"
                    size="lg"
                    disabled={gameStats.cash < 500}
                  >
                    Donate 500 Cash
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Dialogs */}
      <Dialog open={showInvestDialog} onOpenChange={setShowInvestDialog}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle>Invest in {selectedAsset?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Investment Amount (Cash)</Label>
              <Input
                type="number"
                value={investAmount}
                onChange={(e) => setInvestAmount(e.target.value)}
                placeholder="Enter amount..."
              />
              <p className="text-xs text-slate-500 mt-1">Available Cash: {gameStats.cash}</p>
            </div>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm font-semibold mb-2">Investment Details:</p>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <span>Growth Rate:</span>
                  <span className="text-green-600 font-bold">+{((selectedAsset?.growth_rate || 0) * 100).toFixed(1)}%</span>
                </div>
                <div className="flex justify-between">
                  <span>Risk Factor:</span>
                  <span className="text-red-600 font-bold">{((selectedAsset?.risk_factor || 0) * 100).toFixed(0)}%</span>
                </div>
                <p className="text-xs text-slate-600 mt-2">Updates every 5 hours</p>
              </div>
            </div>
            <Button
              onClick={() => investMutation.mutate()}
              disabled={!investAmount || parseFloat(investAmount) > gameStats.cash}
              className="w-full bg-gradient-to-r from-green-600 to-emerald-600"
            >
              Confirm Investment
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showLoanDialog} onOpenChange={setShowLoanDialog}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle>Apply for Loan</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-yellow-50 p-4 rounded-lg border-2 border-yellow-300">
              <p className="text-sm font-semibold text-yellow-900 mb-2">⚠️ Loan Terms:</p>
              <ul className="text-xs text-yellow-800 space-y-1">
                <li>• 15% interest rate</li>
                <li>• 30 days repayment period</li>
                <li>• Penalty if not repaid on time</li>
              </ul>
            </div>
            <div>
              <Label>Loan Amount</Label>
              <Input
                type="number"
                value={loanAmount}
                onChange={(e) => setLoanAmount(e.target.value)}
                placeholder="Enter amount..."
              />
            </div>
            {loanAmount && (
              <div className="bg-red-50 p-3 rounded-lg">
                <p className="text-sm">
                  Total Repayment: <span className="font-bold text-red-600">
                    {Math.round(parseFloat(loanAmount) * 1.15)} Cash
                  </span>
                </p>
              </div>
            )}
            <Button
              onClick={() => takeLoanMutation.mutate()}
              disabled={!loanAmount}
              className="w-full bg-red-600 hover:bg-red-700"
            >
              Take Loan
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showMarketingDialog} onOpenChange={setShowMarketingDialog}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle>Hire Marketing Team</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-pink-50 p-4 rounded-lg">
              <p className="text-sm font-semibold mb-2">Marketing Benefits:</p>
              <ul className="text-xs space-y-1">
                <li>✅ +20% revenue for selected company</li>
                <li>✅ Permanent boost until team is replaced</li>
                <li>💰 5,000 Cash one-time fee</li>
              </ul>
            </div>
            <div>
              <Label>Select Company to Market</Label>
              <Select value={selectedCompanyForMarketing} onValueChange={setSelectedCompanyForMarketing}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a company..." />
                </SelectTrigger>
                <SelectContent>
                  {myCompanies.map((company) => (
                    <SelectItem key={company.id} value={company.id}>
                      {company.name} (+{company.income_rate}/hr)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button
              onClick={() => hireMarketingMutation.mutate()}
              disabled={!selectedCompanyForMarketing || gameStats.cash < 5000}
              className="w-full bg-gradient-to-r from-pink-600 to-rose-600"
            >
              Hire Marketing Team (5,000 Cash)
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showIPODialog} onOpenChange={setShowIPODialog}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle>Launch IPO - Go Public</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-purple-50 p-4 rounded-lg">
              <p className="text-sm font-semibold mb-2">📊 IPO Benefits:</p>
              <ul className="text-xs space-y-1">
                <li>✅ Sell shares to raise instant cash</li>
                <li>✅ Keep ownership and continue earning</li>
                <li>✅ Company value = 2x original cost</li>
                <li>⚠️ You'll own less of the company</li>
              </ul>
            </div>
            <div>
              <Label>Company</Label>
              <Select value={selectedCompanyForIPO} onValueChange={setSelectedCompanyForIPO}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose company..." />
                </SelectTrigger>
                <SelectContent>
                  {myCompanies.filter(c => !gameStats.owned_shares?.[c.id]).map((company) => (
                    <SelectItem key={company.id} value={company.id}>
                      {company.name} (Value: {company.cost * 2})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Shares to Sell (%)</Label>
              <Input
                type="number"
                value={ipoSharesPercent}
                onChange={(e) => setIpoSharesPercent(e.target.value)}
                placeholder="e.g., 30"
                max="100"
              />
            </div>
            {ipoSharesPercent && selectedCompanyForIPO && (
              <div className="bg-green-50 p-3 rounded-lg">
                <p className="text-sm">
                  Cash Raised: <span className="font-bold text-green-600">
                    {Math.round((myCompanies.find(c => c.id === selectedCompanyForIPO)?.cost * 2 * parseFloat(ipoSharesPercent)) / 100)} Cash
                  </span>
                </p>
                <p className="text-xs text-slate-600 mt-1">
                  You'll own {100 - parseFloat(ipoSharesPercent)}% of the company
                </p>
              </div>
            )}
            <Button
              onClick={() => launchIPOMutation.mutate()}
              disabled={!selectedCompanyForIPO || !ipoSharesPercent}
              className="w-full bg-gradient-to-r from-purple-600 to-indigo-600"
            >
              Launch IPO
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showEmployeeDialog} onOpenChange={setShowEmployeeDialog}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle>Hire Employee</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm font-semibold mb-2">Employee Types:</p>
              <ul className="text-xs space-y-1">
                <li>• Marketing: +10% revenue (1,500 cash)</li>
                <li>• Production: +15% efficiency (1,200 cash)</li>
                <li>• R&D: Innovation bonus (2,000 cash)</li>
                <li>• HR: Employee happiness (1,000 cash)</li>
              </ul>
            </div>
            <div>
              <Label>Employee Type</Label>
              <Select value={employeeType} onValueChange={setEmployeeType}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose type..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="marketing">Marketing (1,500 cash)</SelectItem>
                  <SelectItem value="production">Production (1,200 cash)</SelectItem>
                  <SelectItem value="rd">R&D (2,000 cash)</SelectItem>
                  <SelectItem value="hr">HR Manager (1,000 cash)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button
              onClick={() => hireEmployeeMutation.mutate()}
              disabled={!employeeType}
              className="w-full bg-gradient-to-r from-blue-600 to-cyan-600"
            >
              Hire Employee
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Auction Creation Dialog */}
      <Dialog open={showAuctionDialog} onOpenChange={setShowAuctionDialog}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle>Create Player Auction</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Select Asset to Auction</Label>
              <Select
                value={selectedAssetForAuction?.id || ''}
                onValueChange={(value) => {
                  const asset = gameStats.assets.find(a => a.id === value);
                  setSelectedAssetForAuction(asset);
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Choose asset..." />
                </SelectTrigger>
                <SelectContent>
                  {gameStats.assets.map((asset) => (
                    <SelectItem key={asset.id} value={asset.id}>
                      {asset.name} (Value: {asset.cost})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {selectedAssetForAuction && (
              <>
                <div>
                  <Label>Starting Price</Label>
                  <Input
                    type="number"
                    value={selectedAssetForAuction.startingPrice || ''}
                    onChange={(e) => setSelectedAssetForAuction({
                      ...selectedAssetForAuction,
                      startingPrice: parseFloat(e.target.value)
                    })}
                    placeholder="Minimum starting bid"
                  />
                </div>
                <div>
                  <Label>Buyout Price (Optional)</Label>
                  <Input
                    type="number"
                    value={selectedAssetForAuction.buyoutPrice || ''}
                    onChange={(e) => setSelectedAssetForAuction({
                      ...selectedAssetForAuction,
                      buyoutPrice: parseFloat(e.target.value)
                    })}
                    placeholder="Instant purchase price"
                  />
                </div>
                <div className="bg-orange-50 p-4 rounded-lg">
                  <p className="text-sm font-semibold mb-2">Auction Details:</p>
                  <ul className="text-xs space-y-1">
                    <li>• Duration: 24 hours</li>
                    <li>• You'll receive 95% of final bid (5% fee)</li>
                    <li>• Bidders can buyout instantly at buyout price</li>
                  </ul>
                </div>
                <Button
                  onClick={() => createPlayerAuctionMutation.mutate({
                    asset: selectedAssetForAuction,
                    startingPrice: selectedAssetForAuction.startingPrice,
                    buyoutPrice: selectedAssetForAuction.buyoutPrice
                  })}
                  disabled={!selectedAssetForAuction.startingPrice || isNaN(selectedAssetForAuction.startingPrice) || (selectedAssetForAuction.buyoutPrice && selectedAssetForAuction.buyoutPrice <= selectedAssetForAuction.startingPrice)}
                  className="w-full bg-orange-600 hover:bg-orange-700"
                >
                  Create Auction
                </Button>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Negotiation Dialog */}
      <Dialog open={showNegotiationDialog} onOpenChange={setShowNegotiationDialog}>
        <DialogContent className="bg-white max-w-xl">
          <DialogHeader>
            <DialogTitle>Negotiate Deal - {selectedAssetForNegotiation?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm font-semibold mb-2">Asset Details:</p>
              <div className="space-y-1 text-sm">
                <p>List Price: <span className="font-bold">{selectedAssetForNegotiation?.cost} Cash</span></p>
                <p>Income: <span className="font-bold text-green-600">+{selectedAssetForNegotiation?.income_rate}/hr</span></p>
                <p>Your Reputation: <span className="font-bold">{gameStats.reputation}/100</span></p>
              </div>
            </div>

            <div>
              <Label>Your Offer (Cash)</Label>
              <Input
                type="number"
                value={offerAmount}
                onChange={(e) => setOfferAmount(e.target.value)}
                placeholder="Enter your bid..."
                max={gameStats.cash}
              />
              <p className="text-xs text-slate-500 mt-1">
                Available: {gameStats.cash} Cash • Discount: {selectedAssetForNegotiation && offerAmount && parseFloat(offerAmount) < selectedAssetForNegotiation.cost ?
                  Math.round(((selectedAssetForNegotiation.cost - parseFloat(offerAmount)) / selectedAssetForNegotiation.cost) * 100) : 0}%
              </p>
            </div>

            <div>
              <Label>Persuasion Message (Optional but Helpful)</Label>
              <Textarea
                value={persuasionText}
                onChange={(e) => setPersuasionText(e.target.value)}
                placeholder="e.g., 'I'm a loyal buyer looking for long-term partnership'"
                rows={3}
              />
              <p className="text-xs text-slate-500 mt-1">
                💡 Good arguments increase acceptance chance!
              </p>
            </div>

            {/* Removed client-side estimated success chance as it's now handled by AI */}
            {/* {offerAmount && selectedAssetForNegotiation && (
              <div className="bg-purple-50 p-3 rounded-lg">
                <p className="text-sm font-semibold mb-1">Estimated Success Chance:</p>
                <Progress
                  value={Math.min(
                    ((parseFloat(offerAmount) / selectedAssetForNegotiation?.cost) * 60) +
                    (gameStats.reputation / 100) * 10 +
                    (persuasionText.length > 10 ? 5 : 0), // Simple persuasion bonus
                    95 // Max chance
                  )}
                  className="h-3"
                />
                <p className="text-xs text-slate-600 mt-2">
                  Higher offers and reputation increase success probability
                </p>
              </div>
            )} */}

            <Button
              onClick={() => startNegotiationMutation.mutate()}
              disabled={!offerAmount || parseFloat(offerAmount) > gameStats.cash || parseFloat(offerAmount) <= 0}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600"
            >
              <Send className="w-4 h-4 mr-2" />
              Submit Deal Proposal
            </Button>
          </div>
        </DialogContent>
      </Dialog>


      {/* Business Summary Dialog */}
      <Dialog open={showSummaryDialog} onOpenChange={setShowSummaryDialog}>
        <DialogContent className="bg-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black flex items-center gap-2">
              <Clock className="w-6 h-6 text-orange-600" />
              What Happened While You Were Away
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[500px] pr-4">
            {gameStats.away_summary && (
              <div className="space-y-4">
                <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-300">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                      <TrendingUp className="w-6 h-6 text-green-600" />
                      Investment Returns
                    </h3>
                    <p className="text-3xl font-black text-green-600">
                      +{Math.round(gameStats.away_summary.investment_gains).toLocaleString()} Cash
                    </p>
                    <p className="text-sm text-slate-600 mt-2">
                      Your investments grew over {gameStats.away_summary.hours_away} hours.
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-2 border-blue-300">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                      <Building2 className="w-6 h-6 text-blue-600" />
                      Asset Income
                    </h3>
                    <p className="text-3xl font-black text-blue-600">
                      +{Math.round(gameStats.away_summary.asset_income).toLocaleString()} Cash
                    </p>
                    <p className="text-sm text-slate-600 mt-2">
                      Passive income generated from your assets over {gameStats.away_summary.hours_away} hours.
                    </p>
                  </CardContent>
                </Card>

                {gameStats.away_summary.events && gameStats.away_summary.events.length > 0 && (
                  <Card className="bg-gradient-to-r from-red-50 to-orange-50 border-2 border-red-300">
                    <CardContent className="p-6">
                      <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                        <AlertTriangle className="w-6 h-6 text-red-600" />
                        Events That Occurred
                      </h3>
                      <div className="space-y-3">
                        {gameStats.away_summary.events.map((event, idx) => (
                          <div key={idx} className="flex items-center justify-between p-3 bg-white rounded-lg">
                            <div>
                              <p className="font-bold text-slate-900">{event.description}</p>
                              <p className="text-xs text-slate-500">{event.type}</p>
                            </div>
                            <Badge className={`${event.impact >= 0 ? 'bg-green-600' : 'bg-red-600'} text-white text-lg px-4 py-2`}>
                              {event.impact >= 0 ? '+' : ''}{Math.round(event.impact).toLocaleString()}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                <Card className="bg-gradient-to-r from-purple-900 to-blue-900 text-white border-none">
                  <CardContent className="p-8 text-center">
                    <h3 className="text-2xl font-bold mb-2">Total Cash Change</h3>
                    <p className={`text-5xl font-black ${gameStats.away_summary.total_change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {gameStats.away_summary.total_change >= 0 ? '+' : ''}{Math.round(gameStats.away_summary.total_change).toLocaleString()} Cash
                    </p>
                    <p className="text-sm text-white/70 mt-4">
                      Initial Cash: {gameStats.away_summary.initial_cash.toLocaleString()} | Final Cash: {gameStats.away_summary.final_cash.toLocaleString()}
                    </p>
                    <p className="text-sm text-white/70 mt-2">
                      Your empire continued working for you over {gameStats.away_summary.hours_away} hours!
                    </p>
                  </CardContent>
                </Card>

                <Button
                  onClick={() => {
                    setShowSummaryDialog(false);
                    updateGameStats({ away_summary: null }); // Clear summary after user views it
                  }}
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 py-6 text-lg"
                >
                  Got it! Clear Summary
                </Button>
              </div>
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>

      <Dialog open={showRulesDialog} onOpenChange={setShowRulesDialog}>
        <DialogContent className="bg-white max-w-3xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black flex items-center gap-2">
              <Info className="w-6 h-6" />
              How to Play - Business Tycoon
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[500px] pr-4">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
                  <Target className="w-5 h-5 text-blue-600" />
                  Game Objective
                </h3>
                <p className="text-sm text-slate-700">
                  Build a business empire, climb the leaderboard, and become the ultimate tycoon! Buy assets, invest wisely, manage employees, and maximize your net worth.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-green-600" />
                  Currency & Net Worth
                </h3>
                <ul className="text-sm text-slate-700 space-y-1 ml-4">
                  <li>• <strong>XP:</strong> Earned from completing courses and activities</li>
                  <li>• <strong>Cash:</strong> Used to buy assets, hire employees, and invest</li>
                  <li>• <strong>Net Worth:</strong> XP + Cash + Assets + Investments + Stock Shares - Loans</li>
                  <li>• <strong>Rankings:</strong> Junior Tycoon (0) → Tycoon (20k) → Mogul (50k) → XP Legend (100k)</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-purple-600" />
                  Assets & Categories
                </h3>
                <ul className="text-sm text-slate-700 space-y-1 ml-4">
                  <li>• <strong>Companies:</strong> Can hire employees, launch IPO, highest income potential</li>
                  <li>• <strong>Buildings:</strong> Stable passive income, low risk investments</li>
                  <li>• <strong>Resources:</strong> High income but higher risk (gold mines, oil fields)</li>
                  <li>• <strong>Luxury Items:</strong> Cars, planes, yachts - status symbols that add to net worth</li>
                  <li>• <strong>Rarity:</strong> Common, Rare, Epic, Legendary - affects price and income</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
                  <Users className="w-5 h-5 text-orange-600" />
                  Employee System
                </h3>
                <ul className="text-sm text-slate-700 space-y-1 ml-4">
                  <li>• <strong>Marketing Team (1,500):</strong> +10% company revenue boost</li>
                  <li>• <strong>Production Staff (1,200):</strong> +15% efficiency increase</li>
                  <li>• <strong>R&D Department (2,000):</strong> Innovation and product development</li>
                  <li>• <strong>HR Manager (1,000):</strong> Boost employee happiness and productivity</li>
                  <li>• Each employee has skill and happiness levels that affect performance</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
                  <Rocket className="w-5 h-5 text-purple-600" />
                  IPO & Stock Market
                </h3>
                <ul className="text-sm text-slate-700 space-y-1 ml-4">
                  <li>• Take your company public by launching an IPO</li>
                  <li>• Sell shares (%) to raise instant cash without losing the company</li>
                  <li>• Company value = 2x original purchase cost for IPO calculation</li>
                  <li>• You keep earning from remaining ownership percentage</li>
                  <li>• Example: Sell 30% shares, keep 70% ownership and income</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
                  <LineChart className="w-5 h-5 text-blue-600" />
                  Dynamic Economy
                </h3>
                <ul className="text-sm text-slate-700 space-y-1 ml-4">
                  <li>• <strong>Market Fluctuation:</strong> Asset prices change every 15 minutes (±10%)</li>
                  <li>• <strong>Investment Updates:</strong> Your investments grow/shrink every 5 hours</li>
                  <li>• <strong>Passive Income:</strong> Assets generate hourly income automatically</li>
                  <li>• <strong>Away Progress:</strong> Your business keeps running when you're offline!</li>
                  <li>• Click "What Happened?" button to see what occurred while you're away</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  Investments
                </h3>
                <ul className="text-sm text-slate-700 space-y-1 ml-4">
                  <li>• Invest cash in companies for potential growth</li>
                  <li>• Returns calculated every 5 hours automatically</li>
                  <li>• Higher growth rate = higher potential but also higher risk</li>
                  <li>• Can gain significant returns or lose value based on market conditions</li>
                  <li>• Diversify investments across multiple companies</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
                  <Gavel className="w-5 h-5 text-orange-600" />
                  Auctions
                </h3>
                <ul className="text-sm text-slate-700 space-y-1 ml-4">
                  <li>• Bid on assets put up for auction by other players or the game</li>
                  <li>• Place a bid to become the current highest bidder</li>
                  <li>• Use the "Buyout" option for instant purchase if available</li>
                  <li>• You can list your own assets for auction to sell them to other players</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-blue-600" />
                  Negotiations
                </h3>
                <ul className="text-sm text-slate-700 space-y-1 ml-4">
                  <li>• Try to buy assets from the shop at a discount</li>
                  <li>• Make an offer and add a persuasion message to influence the seller (AI)</li>
                  <li>• Higher offers and better reputation increase your chance of success</li>
                  <li>• If accepted, you buy the asset at your negotiated price</li>
                  <li>• If rejected, try again with a better offer or more convincing message</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
                  <Hammer className="w-5 h-5 text-orange-600" />
                  Mega Projects
                </h3>
                <ul className="text-sm text-slate-700 space-y-1 ml-4">
                  <li>• Build massive infrastructure: Walls, Airports, Gold Mines, Solar Farms</li>
                  <li>• Takes real-world days or weeks to complete</li>
                  <li>• Generates huge passive income once finished</li>
                  <li>• Project value adds to net worth immediately upon starting</li>
                  <li>• Progress tracked with completion percentage</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
                  <Scale className="w-5 h-5 text-purple-600" />
                  Services & Protection
                </h3>
                <ul className="text-sm text-slate-700 space-y-1 ml-4">
                  <li>• <strong>Lawyer (2,000):</strong> Reduces lawsuit penalties by 75%</li>
                  <li>• <strong>Marketing Team (5,000):</strong> +20% revenue for one company</li>
                  <li>• <strong>Loans:</strong> Borrow cash at 15% interest, 30-day repayment</li>
                  <li>• <strong>Charity:</strong> Donate to boost reputation and happiness</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-red-600" />
                  Risks & Random Events
                </h3>
                <ul className="text-sm text-slate-700 space-y-1 ml-4">
                  <li>• <strong>Regulatory Fines:</strong> 100-600 cash penalties (10% chance)</li>
                  <li>• <strong>Lawsuits:</strong> 300-1,300 cash if no lawyer protection</li>
                  <li>• <strong>Market Crashes:</strong> Sudden drop in asset values</li>
                  <li>• <strong>Events:</strong> Trigger randomly every 10 minutes</li>
                  <li>• Events continue while you're away - check "What Happened?" summary</li>
                  </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-yellow-600" />
                  Pro Strategies
                </h3>
                <ul className="text-sm text-slate-700 space-y-1 ml-4">
                  <li>✅ Start with affordable buildings and services for stable income</li>
                  <li>✅ Hire a lawyer early to protect against lawsuit losses</li>
                  <li>✅ Diversify: Mix companies, buildings, resources, and investments</li>
                  <li>✅ Use marketing teams on your highest-earning companies</li>
                  <li>✅ Launch IPO to raise cash without selling entire company</li>
                  <li>✅ Hire employees strategically based on company needs</li>
                  <li>✅ Monitor market prices - buy during dips, sell at peaks</li>
                  <li>✅ Check "What Happened?" after being away to see your progress</li>
                  <li>✅ Reinvest profits into high-growth opportunities</li>
                </ul>
              </div>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
