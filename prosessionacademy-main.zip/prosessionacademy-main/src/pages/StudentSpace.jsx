
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from
"@/components/ui/dialog";
import {
  BookOpen,
  Calendar as CalendarIcon,
  Plus,
  Edit,
  Trash,
  Target,
  CheckCircle,
  TrendingUp,
  Award,
  FileText,
  Brain,
  Users,
  MessageSquare,
  Download,
  CheckSquare,
  Sparkles,
  GraduationCap,
  Lightbulb,
  Crown,
  Shield,
  CreditCard,
  LogIn,
  Search,
  CalendarDays,
  Gamepad2,
  Menu,
  X,
  Briefcase,
  Presentation,
  ExternalLink,
  Check,
  Settings,
  Lock,
  Loader2,
  Waves,
  Volume2 // Added Volume2 import
} from "lucide-react";
import { format, differenceInDays } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { CertificateGenerator } from "@/components/CertificateGenerator";
import { motion } from "framer-motion";
import MindRest from "@/components/MindRest";
import VoiceSummarizer from '@/components/VoiceSummarizer';

export default function StudentSpace() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('pathways');
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const [userPlan, setUserPlan] = useState(null);
  const [showNoteDialog, setShowNoteDialog] = useState(false);
  const [showAssignmentDialog, setShowAssignmentDialog] = useState(false);
  const [showUniversityDialog, setShowUniversityDialog] = useState(false);
  const [showChangeUniversityDialog, setShowChangeUniversityDialog] = useState(false);
  const [showMindRest, setShowMindRest] = useState(false);
  const [showVoiceSummarizer, setShowVoiceSummarizer] = useState(false);
  const [newNote, setNewNote] = useState({ title: "", content: "", subject: "" });
  const [newAssignment, setNewAssignment] = useState({
    title: "",
    description: "",
    subject: "",
    due_date: "",
    status: "pending"
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);

        // CHECK SUBSCRIPTION ACCESS - WAIT FOR THIS TO COMPLETE
        if (currentUser.subscription_plan_id) {
          const plans = await base44.entities.SubscriptionPlan.filter({ id: currentUser.subscription_plan_id });
          const plan = plans[0];
          setUserPlan(plan);
          setHasAccess(plan?.features?.access_student_space === true);
        } else {
          setHasAccess(false);
        }

        // Only set loading to false AFTER access check completes
        setLoading(false);

        if (!currentUser.university) {
          setShowUniversityDialog(true);
        }

        if (!currentUser.exam_checklist) {
          await base44.auth.updateMe({
            exam_checklist: { weeks_before: {}, days_before: {}, day_of: {} }
          });
        }
      } catch (error) {
        console.error("Error fetching user:", error);
        setHasAccess(false);
        setLoading(false);
      }
    };
    fetchUser();
  }, []);

  const updateProfileMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: (updatedUser) => {
      setUser(updatedUser);
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    }
  });

  const { data: studentCourses = [] } = useQuery({
    queryKey: ['studentCourses'],
    queryFn: async () => {
      const allCourses = await base44.entities.Course.list('-created_date');
      return allCourses.filter((c) => c.is_student_course === true);
    },
    initialData: []
  });

  const { data: pathways = [] } = useQuery({
    queryKey: ['studentPathways'],
    queryFn: async () => {
      const allPathways = await base44.entities.Pathway.list('-created_date');
      // Only show pathways marked for students
      return allPathways.filter((p) => p.is_student_pathway === true);
    },
    initialData: []
  });

  const { data: userProgress = [] } = useQuery({
    queryKey: ['studentProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      return await base44.entities.UserProgress.filter({ user_email: user.email });
    },
    enabled: !!user?.email,
    initialData: []
  });

  const completedCourses = userProgress.filter((p) => p.progress_percentage === 100).length;
  const inProgressCourses = userProgress.filter((p) => p.progress_percentage > 0 && p.progress_percentage < 100).length;
  const totalCoursesStarted = userProgress.length;
  const averageProgress = totalCoursesStarted > 0 ?
    Math.round(userProgress.reduce((sum, p) => sum + (p.progress_percentage || 0), 0) / totalCoursesStarted) :
    0;

  const studyStreak = user?.student_study_streak || 0;

  const updateNoteMutation = useMutation({
    mutationFn: (notes) => base44.auth.updateMe({ student_notes: notes }),
    onSuccess: (updatedUser) => {
      setUser(updatedUser);
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
      setShowNoteDialog(false);
      setNewNote({ title: "", content: "", subject: "" });
    }
  });

  const updateAssignmentMutation = useMutation({
    mutationFn: (assignments) => base44.auth.updateMe({ student_assignments: assignments }),
    onSuccess: (updatedUser) => {
      setUser(updatedUser);
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
      setShowAssignmentDialog(false);
      setNewAssignment({ title: "", description: "", subject: "", due_date: "", status: "pending" });
    }
  });

  const handleUniversitySelect = async (university) => {
    await updateProfileMutation.mutateAsync({
      university: university,
      is_thomas_more_student: university === 'thomas_more'
    });
    setShowUniversityDialog(false);
    setShowChangeUniversityDialog(false);
  };

  const handleAddNote = () => {
    const notes = user?.student_notes || [];
    const noteWithId = {
      ...newNote,
      id: Date.now().toString(),
      created_date: new Date().toISOString()
    };
    updateNoteMutation.mutate([...notes, noteWithId]);
  };

  const handleDeleteNote = (noteId) => {
    const notes = user?.student_notes || [];
    updateNoteMutation.mutate(notes.filter((n) => n.id !== noteId));
  };

  const handleAddAssignment = () => {
    const assignments = user?.student_assignments || [];
    const assignmentWithId = {
      ...newAssignment,
      id: Date.now().toString(),
      created_date: new Date().toISOString()
    };
    updateAssignmentMutation.mutate([...assignments, assignmentWithId]);
  };

  const handleToggleAssignment = (assignmentId) => {
    const assignments = user?.student_assignments || [];
    const updated = assignments.map((a) =>
      a.id === assignmentId ?
        { ...a, status: a.status === 'completed' ? 'pending' : 'completed' } :
        a
    );
    updateAssignmentMutation.mutate(updated);
  };

  const handleDeleteAssignment = (assignmentId) => {
    const assignments = user?.student_assignments || [];
    updateAssignmentMutation.mutate(assignments.filter((a) => a.id !== assignmentId));
  };

  const examChecklistItems = {
    weeks_before: [
      "Create comprehensive study schedule",
      "Review all course materials and syllabi",
      "Identify weak topics that need extra focus",
      "Form or join study groups",
      "Gather all textbooks and resources",
      "Create summary notes for each topic"],

    days_before: [
      "Review summary notes and flashcards",
      "Complete practice problems and past exams",
      "Attend review sessions or office hours",
      "Get adequate sleep (7-9 hours)",
      "Prepare exam materials (ID, pens, calculator)",
      "Eat nutritious meals and stay hydrated"],

    day_of: [
      "Arrive 15-20 minutes early",
      "Quick review of main concepts only",
      "Deep breathing exercises for calm",
      "Read all instructions carefully",
      "Budget time per section",
      "Review answers before submitting"]

  };

  const toggleChecklistItem = (category, index) => {
    const currentChecklist = user?.exam_checklist || { weeks_before: {}, days_before: {}, day_of: {} };
    const updatedChecklist = {
      ...currentChecklist,
      [category]: {
        ...currentChecklist[category],
        [index]: !currentChecklist[category]?.[index]
      }
    };
    updateProfileMutation.mutate({ exam_checklist: updatedChecklist });
  };

  const getChecklistProgress = (category) => {
    const total = examChecklistItems[category].length;
    const completed = Object.values(user?.exam_checklist?.[category] || {}).filter(Boolean).length;
    return { completed, total, percentage: total > 0 ? Math.round(completed / total * 100) : 0 };
  };

  const assignments = user?.student_assignments || [];
  const pendingAssignments = assignments.filter((a) => a.status === 'pending');
  const overdueAssignments = pendingAssignments.filter((a) =>
    a.due_date && new Date(a.due_date) < new Date()
  );

  const certificates = userProgress.filter((p) => p.progress_percentage === 100 && p.certificate_issued);

  const totalAllChecklistItems = Object.values(examChecklistItems).flat().length;
  const totalCompletedChecklistItems =
    getChecklistProgress('weeks_before').completed +
    getChecklistProgress('days_before').completed +
    getChecklistProgress('day_of').completed;
  const overallChecklistProgressPercentage = totalAllChecklistItems > 0 ?
    Math.round(totalCompletedChecklistItems / totalAllChecklistItems * 100) :
    0;

  const UNIVERSITY_PORTALS = {
    thomas_more: {
      name: 'Thomas More',
      portal: 'Canvas',
      url: 'https://thomasmore.instructure.com',
      iframe: true,
      icon: '📚'
    },
    ku_leuven: {
      name: 'KU Leuven',
      portal: 'Toledo',
      url: 'https://toledo.kuleuven.be',
      iframe: false,
      icon: '🎓'
    },
    ap_hogeschool: {
      name: 'AP Hogeschool',
      portal: 'Digitap',
      url: 'https://digitap.ap.be',
      iframe: false,
      icon: '📖'
    },
    kdg: {
      name: 'Karel de Grote Hogeschool',
      portal: 'Smartschool',
      url: 'https://kdg.smartschool.be',
      iframe: false,
      icon: '🏫'
    },
    universiteit_antwerpen: {
      name: 'Universiteit Antwerpen',
      portal: 'Blackboard',
      url: 'https://blackboard.uantwerpen.be',
      iframe: false,
      icon: '🎯'
    },
    ugent: {
      name: 'UGent',
      portal: 'Ufora',
      url: 'https://ufora.ugent.be',
      iframe: false,
      icon: '🔬'
    },
    other: {
      name: 'Other',
      portal: 'N/A',
      url: '',
      iframe: false,
      icon: '🏛️'
    }
  };

  const userUniversity = UNIVERSITY_PORTALS[user?.university];

  // Check pathway completion
  const getPathwayProgress = (pathway) => {
    const pathwayCourses = pathway.courses?.map((c) =>
      studentCourses.find((sc) => sc.id === c.course_id)
    ).filter(Boolean) || [];

    if (pathwayCourses.length === 0) return { percentage: 0, completed: false };

    const completedCourses = pathwayCourses.filter((course) => {
      const prog = userProgress.find((p) => p.course_id === course.id);
      return prog?.progress_percentage === 100;
    });

    const percentage = Math.round(completedCourses.length / pathwayCourses.length * 100);
    const completed = percentage === 100;

    return { percentage, completed };
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-blue-600 animate-spin" />
      </div>);

  }

  // ACCESS CONTROL - Check BEFORE university selection
  if (!hasAccess && user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 flex items-center justify-center p-6">
        <Card className="max-w-2xl border-none shadow-2xl">
          <CardContent className="p-12 text-center">
            <div className="w-24 h-24 bg-blue-600/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Lock className="w-12 h-12 text-blue-500" />
            </div>
            <h2 className="text-3xl font-bold text-slate-900 mb-4">🔒 Student Space Locked</h2>
            <p className="text-slate-600 mb-8">Upgrade to access Student Space and all academic tools!</p>

            <Link to={createPageUrl("Subscription")}>
              <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 py-6 px-8 text-xl font-bold shadow-xl">
                <Crown className="w-6 h-6 mr-2" />
                View Plans & Upgrade
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-4 sm:p-6 lg:p-8">
      <MindRest isOpen={showMindRest} onClose={() => setShowMindRest(false)} />
      <VoiceSummarizer isOpen={showVoiceSummarizer} onClose={() => setShowVoiceSummarizer(false)} />

      <div className="max-w-7xl mx-auto space-y-6 sm:space-y-8">
        {/* Professional Header */}
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          <Card className="border-none shadow-xl overflow-hidden bg-white">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 opacity-10"></div>
              <CardContent className="relative p-6 sm:p-8 lg:p-10">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 sm:gap-6">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-xl">
                      <GraduationCap className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
                    </div>
                    <div>
                      <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-slate-900 mb-1">
                        {user?.full_name?.split(' ')[0] || 'Student'}'s Space
                      </h1>
                      <p className="text-sm sm:text-base lg:text-lg text-slate-600">Your personal learning dashboard</p>
                      <div className="flex gap-2 mt-2 flex-wrap">
                        {user?.student_academic_year &&
                          <Badge className="bg-blue-100 text-blue-700 border-blue-300 px-2 py-0.5 text-xs">
                            Year {user.student_academic_year}
                          </Badge>
                        }
                        {user?.student_major &&
                          <Badge className="bg-indigo-100 text-indigo-700 border-indigo-300 px-2 py-0.5 text-xs">
                            {user.student_major}
                          </Badge>
                        }
                        {userUniversity &&
                          <Badge className="bg-purple-100 text-purple-700 border-purple-300 px-2 py-0.5 text-xs">
                            {userUniversity.icon} {userUniversity.name}
                          </Badge>
                        }
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2 w-full sm:w-auto items-center">
                    <div className="flex gap-2 flex-1 sm:flex-initial">
                      <div className="flex-1 sm:flex-initial">
                        <Label className="text-xs text-slate-500 font-semibold">Academic Year</Label>
                        <Select
                          value={user?.student_academic_year || ""}
                          onValueChange={(value) => updateProfileMutation.mutate({ student_academic_year: value })}>
                          <SelectTrigger className="w-full sm:w-24 border-2 mt-1 text-xs">
                            <SelectValue placeholder="Year" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">Year 1</SelectItem>
                            <SelectItem value="2">Year 2</SelectItem>
                            <SelectItem value="3">Year 3</SelectItem>
                            <SelectItem value="4">Year 4</SelectItem>
                            <SelectItem value="5">Year 5</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex-1 sm:flex-initial">
                        <Label className="text-xs text-slate-500 font-semibold">Major</Label>
                        <Input
                          value={user?.student_major || ""}
                          onChange={(e) => updateProfileMutation.mutate({ student_major: e.target.value })}
                          placeholder="Major..."
                          className="w-full sm:w-32 border-2 mt-1 text-xs"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </div>
          </Card>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <Card className="border-none shadow-lg bg-white hover:shadow-xl transition-all">
              <CardContent className="p-4 sm:p-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <CheckCircle className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-2xl sm:text-3xl font-bold text-slate-900">{completedCourses}</div>
                    <p className="text-xs sm:text-sm text-slate-600 font-medium">Completed</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
            <Card className="border-none shadow-lg bg-white hover:shadow-xl transition-all">
              <CardContent className="p-4 sm:p-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <BookOpen className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-2xl sm:text-3xl font-bold text-slate-900">{inProgressCourses}</div>
                    <p className="text-xs sm:text-sm text-slate-600 font-medium">In Progress</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <Card className="border-none shadow-lg bg-white hover:shadow-xl transition-all">
              <CardContent className="p-4 sm:p-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-2xl sm:text-3xl font-bold text-slate-900">{averageProgress}%</div>
                    <p className="text-xs sm:text-sm text-slate-600 font-medium">Average</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
            <Card className="border-none shadow-lg bg-white hover:shadow-xl transition-all">
              <CardContent className="p-4 sm:p-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-orange-500 to-red-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Award className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-2xl sm:text-3xl font-bold text-slate-900">{studyStreak} 🔥</div>
                    <p className="text-xs sm:text-sm text-slate-600 font-medium">Day Streak</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* CV Generator */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.28 }}>
          <Link to={createPageUrl("CVGenerator")}>
            <Card className="border-none shadow-xl bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white hover:shadow-purple-500/50 transition-all cursor-pointer transform hover:scale-[1.01]">
              <CardContent className="p-5 sm:p-6">
                <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
                  <div className="w-14 h-14 sm:w-16 sm:h-16 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center shadow-xl flex-shrink-0">
                    <FileText className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
                  </div>
                  <div className="flex-1 text-center sm:text-left">
                    <h3 className="text-xl sm:text-2xl font-black mb-1">📄 Generate Your CV</h3>
                    <p className="text-white/90 text-sm sm:text-base">Professional CV templates • Photo upload • PDF download</p>
                  </div>
                  <Badge className="bg-white text-blue-600 px-4 py-1.5 text-sm font-bold shadow-lg">
                    ✨ NEW
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </Link>
        </motion.div>

        {/* Quick Action Tools - ALL same size and style */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.32 }}>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Voice Summarizer */}
            <div onClick={() => setShowVoiceSummarizer(true)} className="block cursor-pointer">
              <div className="relative group h-full">
                <div className="absolute -inset-1 bg-gradient-to-r from-rose-500 to-pink-600 rounded-2xl blur opacity-75 group-hover:opacity-100 transition animate-pulse"></div>
                <Card className="relative border-none shadow-2xl bg-gradient-to-r from-rose-500 to-pink-600 text-white cursor-pointer transform hover:scale-[1.02] transition-all h-full">
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center gap-3">
                      <div className="w-16 h-16 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center shadow-xl">
                        <Volume2 className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-black mb-1">🎤 Voice Notes</h3>
                        <p className="text-white/90 text-sm">Record • AI summaries • Mind maps</p>
                      </div>
                      <Badge className="bg-yellow-400 text-yellow-900 px-3 py-1 font-bold text-xs">
                        ⭐ NEW
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Interview Prep */}
            <Link to={createPageUrl("Practice") + "?module=interview_preparation"} className="block">
              <div className="relative group h-full">
                <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl blur opacity-75 group-hover:opacity-100 transition"></div>
                <Card className="relative border-none shadow-2xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white cursor-pointer transform hover:scale-[1.02] transition-all h-full">
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center gap-3">
                      <div className="w-16 h-16 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center shadow-xl">
                        <Briefcase className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-black mb-1">💼 Interview Prep</h3>
                        <p className="text-white/90 text-sm">Upload CV • Tailored questions</p>
                      </div>
                      <Badge className="bg-yellow-400 text-yellow-900 px-3 py-1 font-bold text-xs">
                        ⭐ NEW
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </Link>

            {/* Mind Rest */}
            <div onClick={() => setShowMindRest(true)} className="block cursor-pointer">
              <div className="relative group h-full">
                <div className="absolute -inset-1 bg-gradient-to-r from-teal-500 to-emerald-600 rounded-2xl blur opacity-75 group-hover:opacity-100 transition animate-pulse"></div>
                <Card className="relative border-none shadow-2xl bg-gradient-to-r from-teal-500 to-emerald-600 text-white cursor-pointer transform hover:scale-[1.02] transition-all h-full">
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center gap-3">
                      <div className="w-16 h-16 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center shadow-xl">
                        <Waves className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-black mb-1">🧘 Mind Rest</h3>
                        <p className="text-white/90 text-sm">5-min guided • Study break</p>
                      </div>
                      <Badge className="bg-white/30 text-white px-3 py-1 font-bold text-xs">
                        CALM
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* AI Teacher */}
            <Link to={createPageUrl("StudentAITeacher")} className="block">
              <div className="relative group h-full">
                <div className="absolute -inset-1 bg-gradient-to-r from-violet-600 to-fuchsia-600 rounded-2xl blur opacity-75 group-hover:opacity-100 transition"></div>
                <Card className="relative border-none shadow-2xl bg-gradient-to-br from-violet-600 to-fuchsia-600 text-white cursor-pointer transform hover:scale-[1.02] transition-all h-full">
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center gap-3">
                      <div className="w-16 h-16 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center shadow-xl">
                        <Brain className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-black mb-1">🤖 AI Teacher</h3>
                        <p className="text-white/90 text-sm">24/7 study assistant</p>
                      </div>
                      <Badge className="bg-yellow-400 text-yellow-900 px-3 py-1 font-bold text-xs">
                        PERSONALIZED
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </Link>
          </div>
        </motion.div>

        {/* Secondary Tools Grid */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
          <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {/* Exam Focus */}
            <Link to={createPageUrl("ExamFocusSpace")} className="block">
              <Card className="border-none shadow-xl hover:shadow-2xl transition-all cursor-pointer bg-gradient-to-br from-orange-500 to-pink-500 overflow-hidden h-full">
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center text-white space-y-3">
                    <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                      <Target className="w-10 h-10" />
                    </div>
                    <h3 className="text-xl font-bold">🎯 Exam Focus</h3>
                    <p className="text-white/95 text-sm">AI-Generated Exams</p>
                    <Badge className="bg-white/30 text-white border-white/50">Popular</Badge>
                  </div>
                </CardContent>
              </Card>
            </Link>

            {/* PowerPoint Generator */}
            <Link to={createPageUrl("PowerPointGenerator")} className="block">
              <Card className="border-none shadow-xl hover:shadow-2xl transition-all cursor-pointer bg-gradient-to-br from-indigo-500 to-cyan-500 overflow-hidden h-full">
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center text-white space-y-3">
                    <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                      <Presentation className="w-10 h-10" />
                    </div>
                    <h3 className="text-xl font-bold">🎨 PPT Generator</h3>
                    <p className="text-white/95 text-sm">Beautiful Presentations</p>
                    <Badge className="bg-white/30 text-white border-white/50">NEW!</Badge>
                  </div>
                </CardContent>
              </Card>
            </Link>

            {/* Practice Hub */}
            <Link to={createPageUrl("Practice")} className="block">
              <Card className="border-none shadow-xl hover:shadow-2xl transition-all cursor-pointer bg-gradient-to-br from-blue-500 to-cyan-500 overflow-hidden h-full">
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center text-white space-y-3">
                    <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                      <Target className="w-10 h-10" />
                    </div>
                    <h3 className="text-xl font-bold">🎯 Practice Hub</h3>
                    <p className="text-white/95 text-sm">Skill simulations</p>
                    <Badge className="bg-white/30 text-white border-white/50">PRO</Badge>
                  </div>
                </CardContent>
              </Card>
            </Link>
          </div>
        </motion.div>

        {/* University Portal Quick Access */}
        {userUniversity && userUniversity.name !== 'Other' &&
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
            {userUniversity.iframe ?
              <Link to={createPageUrl("UniversityPortal")}>
                <Card className="border-none shadow-xl hover:shadow-2xl transition-all cursor-pointer bg-gradient-to-r from-green-500 to-emerald-600">
                  <CardContent className="p-5 sm:p-6">
                    <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 text-white">
                      <div className="w-14 h-14 sm:w-16 sm:h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center text-3xl sm:text-4xl flex-shrink-0">
                        {userUniversity.icon}
                      </div>
                      <div className="flex-1 text-center sm:text-left">
                        <h3 className="text-xl sm:text-2xl font-bold mb-1">Open {userUniversity.portal}</h3>
                        <p className="text-white/90 text-sm sm:text-base">Quick access to your {userUniversity.name} portal</p>
                      </div>
                      <Badge className="bg-white/30 text-white border-white/50 px-3 py-1.5 text-sm">
                        📱 Opens in App
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </Link> :
              <a href={userUniversity.url} target="_blank" rel="noopener noreferrer">
                <Card className="border-none shadow-xl hover:shadow-2xl transition-all cursor-pointer bg-gradient-to-r from-blue-600 to-indigo-700">
                  <CardContent className="p-5 sm:p-6">
                    <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 text-white">
                      <div className="w-14 h-14 sm:w-16 sm:h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center text-3xl sm:text-4xl flex-shrink-0">
                        {userUniversity.icon}
                      </div>
                      <div className="flex-1 text-center sm:text-left">
                        <h3 className="text-xl sm:text-2xl font-bold mb-1">Open {userUniversity.portal}</h3>
                        <p className="text-white/90 text-sm sm:text-base">Quick access to your {userUniversity.name} portal</p>
                      </div>
                      <Badge className="bg-white/30 text-white border-white/50 px-3 py-1.5 text-sm flex items-center gap-1">
                        <ExternalLink className="w-3 h-3" />
                        External
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </a>
            }
          </motion.div>
        }

        {/* Tabs */}
        <Card className="border-none shadow-xl bg-white">
          <CardContent className="p-4 sm:p-6">
            <Tabs defaultValue="pathways" value={activeTab} onValueChange={setActiveTab}>
              <div className="overflow-x-auto -mx-4 px-4 sm:mx-0 sm:px-0">
                <TabsList className="inline-flex w-auto min-w-full sm:grid sm:w-full sm:grid-cols-4 lg:grid-cols-8 gap-1 sm:gap-2 bg-slate-100 p-1.5 sm:p-2 rounded-xl mb-4 sm:mb-6">
                  <TabsTrigger value="pathways" className="data-[state=active]:bg-white data-[state=active]:shadow-md rounded-lg text-xs whitespace-nowrap px-3 py-2">
                    <BookOpen className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5" />
                    Pathways
                  </TabsTrigger>
                  <TabsTrigger value="assignments" className="data-[state=active]:bg-white data-[state=active]:shadow-md rounded-lg text-xs whitespace-nowrap px-3 py-2">
                    <FileText className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5" />
                    Tasks
                    {pendingAssignments.length > 0 &&
                      <Badge className="ml-1.5 bg-red-500 text-white text-[10px] px-1.5 py-0">{pendingAssignments.length}</Badge>
                    }
                  </TabsTrigger>
                  <TabsTrigger value="notes" className="data-[state=active]:bg-white data-[state=active]:shadow-md rounded-lg text-xs whitespace-nowrap px-3 py-2">
                    <Edit className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5" />
                    Notes
                  </TabsTrigger>
                  <TabsTrigger value="exam-prep" className="data-[state=active]:bg-white data-[state=active]:shadow-md rounded-lg text-xs whitespace-nowrap px-3 py-2">
                    <CheckSquare className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5" />
                    Exam
                  </TabsTrigger>
                  <TabsTrigger value="progress" className="data-[state=active]:bg-white data-[state=active]:shadow-md rounded-lg text-xs whitespace-nowrap px-3 py-2">
                    <TrendingUp className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5" />
                    Progress
                  </TabsTrigger>
                  <TabsTrigger value="certificates" className="data-[state=active]:bg-white data-[state=active]:shadow-md rounded-lg text-xs whitespace-nowrap px-3 py-2">
                    <Award className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5" />
                    Certs
                    {certificates.length > 0 &&
                      <Badge className="ml-1.5 bg-yellow-600 text-white text-[10px] px-1.5 py-0">{certificates.length}</Badge>
                    }
                  </TabsTrigger>
                  <TabsTrigger value="tools" className="data-[state=active]:bg-white data-[state=active]:shadow-md rounded-lg text-xs whitespace-nowrap px-3 py-2">
                    <Brain className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5" />
                    Tools
                  </TabsTrigger>
                  <TabsTrigger value="settings" className="data-[state=active]:bg-white data-[state=active]:shadow-md rounded-lg text-xs whitespace-nowrap px-3 py-2">
                    <Settings className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5" />
                    Settings
                  </TabsTrigger>
                </TabsList>
              </div>

              {/* Pathways Tab (NEW DEFAULT) */}
              <TabsContent value="pathways" className="mt-6 space-y-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-3xl font-bold text-slate-900">🗺️ Learning Pathways</h2>
                    <p className="text-slate-600">Structured learning journeys for academic success</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  {pathways.map((pathway) => {
                    const pathwayCourses = pathway.courses?.map((c) =>
                      studentCourses.find((sc) => sc.id === c.course_id)
                    ).filter(Boolean) || [];

                    const { percentage: totalProgress, completed: isCompleted } = getPathwayProgress(pathway);

                    // Check if pathway certificate exists
                    const pathwayProgress = userProgress.find((p) =>
                      p.pathway_id === pathway.id && p.pathway_completed === true
                    );

                    return (
                      <Card key={pathway.id} className="border-none shadow-xl hover:shadow-2xl transition-all overflow-hidden">
                        <div className="h-3 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500"></div>
                        {pathway.thumbnail_url &&
                          <img src={pathway.thumbnail_url} alt={pathway.title} className="w-full h-48 object-cover" />
                        }
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-3">
                            <Badge className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                              {pathway.category?.replace(/_/g, ' ')}
                            </Badge>
                            {isCompleted &&
                              <Badge className="bg-green-600 text-white">
                                <Award className="w-3 h-3 mr-1" />
                                Completed
                              </Badge>
                            }
                          </div>
                          <h3 className="font-bold text-2xl mb-2 text-slate-900">{pathway.title}</h3>
                          <p className="text-slate-600 mb-4">{pathway.description}</p>

                          <div className="space-y-3 mb-4">
                            <div className="flex justify-between text-sm">
                              <span className="text-slate-600">Overall Progress</span>
                              <span className="font-bold text-purple-600">{totalProgress}%</span>
                            </div>
                            <Progress value={totalProgress} className="h-3 bg-slate-200 [&>*]:bg-gradient-to-r [&>*]:from-blue-500 [&>*]:to-purple-500" />
                          </div>

                          <div className="space-y-2 mb-4">
                            <p className="text-sm font-semibold text-slate-700">Courses ({pathwayCourses.length}):</p>
                            {pathwayCourses.slice(0, 3).map((course) => {
                              const prog = userProgress.find((p) => p.course_id === course.id);
                              return (
                                <div key={course.id} className="flex items-center gap-2 text-sm">
                                  <div className={`w-2 h-2 rounded-full ${prog?.progress_percentage === 100 ? 'bg-green-500' : prog?.progress_percentage > 0 ? 'bg-blue-500' : 'bg-slate-300'}`}></div>
                                  <span className="text-slate-600 truncate">{course.title}</span>
                                </div>);

                            })}
                            {pathwayCourses.length > 3 &&
                              <p className="text-xs text-slate-500">+ {pathwayCourses.length - 3} more courses</p>
                            }
                          </div>

                          {isCompleted && pathwayProgress?.pathway_certificate_id ?
                            <Link to={createPageUrl(`PathwayCertificate?pathwayId=${pathway.id}`)}>
                              <Button className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 shadow-md py-6 text-lg font-bold mb-3">
                                <Award className="w-5 h-5 mr-2" />
                                View Certificate
                              </Button>
                            </Link> :

                            <Link to={createPageUrl(`PathwayDetail?pathwayId=${pathway.id}`)}>
                              <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-md py-6 text-lg font-bold">
                                {totalProgress === 0 ? 'Start Pathway' : totalProgress === 100 ? 'Review Pathway' : 'Continue Learning'}
                              </Button>
                            </Link>
                          }
                        </CardContent>
                      </Card>);

                  })}
                </div>

                {pathways.length === 0 &&
                  <Card className="shadow-lg bg-white">
                    <CardContent className="p-12 text-center">
                      <BookOpen className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-slate-900 mb-2">No Student Pathways Yet</h3>
                      <p className="text-slate-500 mb-6">Learning pathways will appear here once admins create them!</p>
                    </CardContent>
                  </Card>
                }
              </TabsContent>

              {/* Assignments Tab */}
              <TabsContent value="assignments" className="mt-6 space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-slate-900">📝 My Assignments</h2>
                  <Button onClick={() => setShowAssignmentDialog(true)} className="bg-gradient-to-r from-green-600 to-emerald-600 shadow-md">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Assignment
                  </Button>
                </div>

                {overdueAssignments.length > 0 &&
                  <Card className="border-l-4 border-red-500 bg-red-50 shadow-md">
                    <CardContent className="p-4">
                      <p className="text-red-700 font-semibold">
                        ⚠️ {overdueAssignments.length} overdue assignment(s)
                      </p>
                    </CardContent>
                  </Card>
                }

                <div className="space-y-3">
                  {assignments.length > 0 ?
                    assignments.map((assignment) => {
                      const isOverdue = assignment.due_date && new Date(assignment.due_date) < new Date() && assignment.status === 'pending';
                      const daysUntilDue = assignment.due_date ? differenceInDays(new Date(assignment.due_date), new Date()) : null;

                      return (
                        <Card key={assignment.id} className={`shadow-md hover:shadow-lg transition-all bg-white ${assignment.status === 'completed' ? 'opacity-70' : ''} ${isOverdue ? 'border-l-4 border-red-500' : ''}`}>
                          <CardContent className="p-5">
                            <div className="flex items-start gap-3">
                              <Button
                                size="sm"
                                variant="outline"
                                className={assignment.status === 'completed' ? 'bg-green-100 border-green-400' : 'border-slate-300'}
                                onClick={() => handleToggleAssignment(assignment.id)}>

                                {assignment.status === 'completed' ?
                                  <CheckCircle className="w-5 h-5 text-green-600" /> :

                                  <div className="w-5 h-5 border-2 border-slate-400 rounded"></div>
                                }
                              </Button>

                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1 flex-wrap">
                                  <h3 className={`font-bold text-lg ${assignment.status === 'completed' ? 'line-through text-slate-500' : 'text-slate-900'}`}>
                                    {assignment.title}
                                  </h3>
                                  {assignment.subject && <Badge variant="outline" className="bg-blue-50">{assignment.subject}</Badge>}
                                  {isOverdue && <Badge className="bg-red-500 text-white">Overdue!</Badge>}
                                </div>

                                {assignment.description &&
                                  <p className="text-slate-600 text-sm mb-2">{assignment.description}</p>
                                }

                                {assignment.due_date &&
                                  <div className="flex items-center gap-2 text-sm">
                                    <CalendarIcon className="w-4 h-4 text-slate-400" />
                                    <span className={isOverdue ? 'text-red-600 font-semibold' : 'text-slate-600'}>
                                      Due: {format(new Date(assignment.due_date), 'MMM d, yyyy')}
                                      {daysUntilDue !== null && daysUntilDue >= 0 && ` (${daysUntilDue} days)`}
                                    </span>
                                  </div>
                                }
                              </div>

                              <Button size="sm" variant="ghost" onClick={() => handleDeleteAssignment(assignment.id)} className="hover:bg-red-50">
                                <Trash className="w-4 h-4 text-red-500" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>);

                    }) :

                    <Card className="shadow-md bg-white">
                      <CardContent className="p-12 text-center">
                        <FileText className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                        <p className="text-slate-500">No assignments yet. Add your first one!</p>
                      </CardContent>
                    </Card>
                  }
                </div>
              </TabsContent>

              {/* Notes Tab */}
              <TabsContent value="notes" className="mt-6 space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-slate-900">📓 Study Notes</h2>
                  <Button onClick={() => setShowNoteDialog(true)} className="bg-gradient-to-r from-blue-600 to-purple-600 shadow-md">
                    <Plus className="w-4 h-4 mr-2" />
                    New Note
                  </Button>
                </div>

                <div className="grid md::grid-cols-2 lg:grid-cols-3 gap-4">
                  {(user?.student_notes || []).map((note) =>
                    <Card key={note.id} className="shadow-md hover:shadow-lg transition-all bg-white border-t-4 border-purple-500">
                      <CardContent className="p-5">
                        <div className="flex justify-between items-start mb-3">
                          {note.subject &&
                            <Badge className="bg-purple-100 text-purple-700 border-purple-300">{note.subject}</Badge>
                          }
                          <Button size="sm" variant="ghost" onClick={() => handleDeleteNote(note.id)} className="hover:bg-red-50">
                            <Trash className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                        <h3 className="font-bold text-lg mb-2 text-slate-900">{note.title}</h3>
                        <p className="text-slate-600 text-sm whitespace-pre-wrap mb-3">{note.content}</p>
                        <p className="text-xs text-slate-400">
                          {format(new Date(note.created_date), 'MMM d, yyyy')}
                        </p>
                      </CardContent>
                    </Card>
                  )}

                  {(user?.student_notes || []).length === 0 &&
                    <Card className="shadow-md col-span-full bg-white">
                      <CardContent className="p-12 text-center">
                        <Edit className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                        <p className="text-slate-500">No notes yet. Create your first study note!</p>
                      </CardContent>
                    </Card>
                  }
                </div>
              </TabsContent>

              {/* Exam Prep Tab */}
              <TabsContent value="exam-prep" className="mt-6 space-y-4">
                <h2 className="text-2xl font-bold text-slate-900">📝 Exam Preparation Checklist</h2>

                <div className="grid md:grid-cols-3 gap-5">
                  {/* Weeks Before */}
                  <Card className="shadow-lg bg-gradient-to-br from-blue-50 to-cyan-50 border-t-4 border-blue-500">
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between text-lg">
                        <span>📅 Weeks Before</span>
                        <Badge className="bg-blue-600 text-white">
                          {getChecklistProgress('weeks_before').completed}/{getChecklistProgress('weeks_before').total}
                        </Badge>
                      </CardTitle>
                      <Progress value={getChecklistProgress('weeks_before').percentage} className="h-2.5 bg-blue-200 [&>*]:bg-blue-600" />
                    </CardHeader>
                    <CardContent className="space-y-2.5">
                      {examChecklistItems.weeks_before.map((item, idx) =>
                        <label key={idx} className="flex items-start gap-2 cursor-pointer hover:bg-blue-50 p-2 rounded-lg transition-colors">
                          <input
                            type="checkbox"
                            checked={user?.exam_checklist?.weeks_before?.[idx] || false}
                            onChange={() => toggleChecklistItem('weeks_before', idx)}
                            className="mt-1 w-4 h-4 text-blue-600" />

                          <span className={`text-sm ${user?.exam_checklist?.weeks_before?.[idx] ? 'line-through text-slate-400' : 'text-slate-700'}`}>
                            {item}
                          </span>
                        </label>
                      )}
                    </CardContent>
                  </Card>

                  {/* Days Before */}
                  <Card className="shadow-lg bg-gradient-to-br from-purple-50 to-pink-50 border-t-4 border-purple-500">
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between text-lg">
                        <span>⏰ Days Before</span>
                        <Badge className="bg-purple-600 text-white">
                          {getChecklistProgress('days_before').completed}/{getChecklistProgress('days_before').total}
                        </Badge>
                      </CardTitle>
                      <Progress value={getChecklistProgress('days_before').percentage} className="h-2.5 bg-purple-200 [&>*]:bg-purple-600" />
                    </CardHeader>
                    <CardContent className="space-y-2.5">
                      {examChecklistItems.days_before.map((item, idx) =>
                        <label key={idx} className="flex items-start gap-2 cursor-pointer hover:bg-purple-50 p-2 rounded-lg transition-colors">
                          <input
                            type="checkbox"
                            checked={user?.exam_checklist?.days_before?.[idx] || false}
                            onChange={() => toggleChecklistItem('days_before', idx)}
                            className="mt-1 w-4 h-4 text-purple-600" />

                          <span className={`text-sm ${user?.exam_checklist?.days_before?.[idx] ? 'line-through text-slate-400' : 'text-slate-700'}`}>
                            {item}
                          </span>
                        </label>
                      )}
                    </CardContent>
                  </Card>

                  {/* Day Of */}
                  <Card className="shadow-lg bg-gradient-to-br from-green-50 to-emerald-50 border-t-4 border-green-500">
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between text-lg">
                        <span>🎯 Day Of Exam</span>
                        <Badge className="bg-green-600 text-white">
                          {getChecklistProgress('day_of').completed}/{getChecklistProgress('day_of').total}
                        </Badge>
                      </CardTitle>
                      <Progress value={getChecklistProgress('day_of').percentage} className="h-2.5 bg-green-200 [&>*]:bg-green-600" />
                    </CardHeader>
                    <CardContent className="space-y-2.5">
                      {examChecklistItems.day_of.map((item, idx) =>
                        <label key={idx} className="flex items-start gap-2 cursor-pointer hover:bg-green-50 p-2 rounded-lg transition-colors">
                          <input
                            type="checkbox"
                            checked={user?.exam_checklist?.day_of?.[idx] || false}
                            onChange={() => toggleChecklistItem('day_of', idx)}
                            className="mt-1 w-4 h-4 text-green-600" />

                          <span className={`text-sm ${user?.exam_checklist?.day_of?.[idx] ? 'line-through text-slate-400' : 'text-slate-700'}`}>
                            {item}
                          </span>
                        </label>
                      )}
                    </CardContent>
                  </Card>
                </div>

                {/* Overall Progress */}
                <Card className="shadow-lg bg-gradient-to-r from-purple-500 to-pink-500">
                  <CardContent className="p-6 text-white">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xl font-bold">Overall Exam Readiness</h3>
                      <div className="text-4xl font-bold">{overallChecklistProgressPercentage}%</div>
                    </div>
                    <Progress value={overallChecklistProgressPercentage} className="h-4 bg-white/30 [&>*]:bg-white" />
                    <p className="text-sm text-white/90 mt-3">
                      Complete all items to maximize your exam success! 🎓
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Progress Tab */}
              <TabsContent value="progress" className="mt-6 space-y-4">
                <h2 className="text-2xl font-bold text-slate-900">📈 Learning Progress</h2>

                <div className="grid md:grid-cols-2 gap-5">
                  {userProgress.map((progress) => {
                    const course = studentCourses.find((c) => c.id === progress.course_id);
                    if (!course) return null;

                    return (
                      <Card key={progress.id} className="shadow-lg bg-white hover:shadow-xl transition-all border-l-4 border-blue-500">
                        <CardContent className="p-5">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex-1">
                              <h3 className="font-bold text-lg mb-1 text-slate-900">{course.title}</h3>
                              <Badge className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                                {course.category?.replace(/_/g, ' ')}
                              </Badge>
                            </div>
                            {progress.progress_percentage === 100 &&
                              <CheckCircle className="w-8 h-8 text-green-600" />
                            }
                          </div>

                          <div className="space-y-3">
                            <div>
                              <div className="flex justify-between text-sm mb-1.5">
                                <span className="text-slate-600">Progress</span>
                                <span className="font-bold text-blue-600">{progress.progress_percentage}%</span>
                              </div>
                              <Progress value={progress.progress_percentage} className="h-3 bg-slate-200 [&>*]:bg-gradient-to-r [&>*]:from-blue-500 [&>*]:to-purple-500" />
                            </div>

                            <Link to={createPageUrl(`Learning?courseId=${course.id}`)}>
                              <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700" variant={progress.progress_percentage === 100 ? 'outline' : 'default'}>
                                {progress.progress_percentage === 100 ? 'Review Course' : 'Continue Learning'}
                              </Button>
                            </Link>
                          </div>
                        </CardContent>
                      </Card>);

                  })}
                </div>
              </TabsContent>

              {/* Certificates Tab */}
              <TabsContent value="certificates" className="mt-6 space-y-4">
                <h2 className="text-2xl font-bold text-slate-900">🏆 My Certificates</h2>

                {certificates.length > 0 ?
                  <div className="grid md:grid-cols-2 gap-5">
                    {certificates.map((cert) => {
                      const course = studentCourses.find((c) => c.id === cert.course_id);
                      if (!course) return null;

                      return (
                        <CertificateGenerator
                          key={cert.id}
                          userName={user.full_name || user.email}
                          courseName={course.title}
                          completedDate={cert.completed_date}
                          certificateId={cert.certificate_id}
                          score={cert.final_score} />);


                    })}
                  </div> :

                  <Card className="shadow-lg bg-white">
                    <CardContent className="p-12 text-center">
                      <Award className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-slate-900 mb-2">No Certificates Yet</h3>
                      <p className="text-slate-500 mb-6">Complete courses to earn certificates!</p>
                      <Link to={createPageUrl("Courses")}>
                        <Button className="bg-gradient-to-r from-blue-600 to-purple-600">
                          Browse Courses
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                }
              </TabsContent>

              {/* Tools Tab */}
              <TabsContent value="tools" className="mt-6 space-y-4">
                <h2 className="text-2xl font-bold text-slate-900">🛠️ Student Tools</h2>

                {/* AI Summarizer - Featured with gradient */}
                <Link to={createPageUrl("Summarizer")}>
                  <Card className="shadow-xl hover:shadow-2xl transition-all cursor-pointer bg-gradient-to-r from-violet-500 to-purple-600 border-none">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between text-white">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <FileText className="w-10 h-10" />
                            <div>
                              <h3 className="text-2xl font-bold">AI Summarizer ⭐</h3>
                              <Badge className="bg-white/30 text-white border-white/50 mt-1">Most Popular</Badge>
                            </div>
                          </div>
                          <p className="text-white/95 mb-3">
                            Upload lectures, PDFs, Word docs - Get smart summaries!
                          </p>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div className="bg-white/20 rounded-lg p-3 backdrop-blur-sm">
                              <p className="font-semibold">✨ 4 Formats</p>
                            </div>
                            <div className="bg-white/20 rounded-lg p-3 backdrop-blur-sm">
                              <p className="font-semibold">📄 All Files</p>
                            </div>
                          </div>
                        </div>
                        <Sparkles className="w-12 h-12 opacity-50" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <Link to={createPageUrl("PersonalityTest")}>
                    <Card className="shadow-lg hover:shadow-xl transition-all cursor-pointer bg-white border-t-4 border-blue-500">
                      <CardContent className="p-6 text-center">
                        <Brain className="w-14 h-14 text-blue-600 mx-auto mb-3" />
                        <h3 className="font-bold text-xl mb-1 text-slate-900">Personality Test</h3>
                        <p className="text-slate-600 text-sm">Discover your learning style</p>
                      </CardContent>
                    </Card>
                  </Link>

                  <Link to={createPageUrl("IQTest")}>
                    <Card className="shadow-lg hover:shadow-xl transition-all cursor-pointer bg-white border-t-4 border-purple-500">
                      <CardContent className="p-6 text-center">
                        <Target className="w-14 h-14 text-purple-600 mx-auto mb-3" />
                        <h3 className="font-bold text-xl mb-1 text-slate-900">IQ Assessment</h3>
                        <p className="text-slate-600 text-sm">Test cognitive abilities</p>
                      </CardContent>
                    </Card>
                  </Link>

                  <Link to={createPageUrl("AssessmentTest")}>
                    <Card className="shadow-lg hover:shadow-xl transition-all cursor-pointer bg-white border-t-4 border-green-500">
                      <CardContent className="p-6 text-center">
                        <CheckCircle className="w-14 h-14 text-green-600 mx-auto mb-3" />
                        <h3 className="font-bold text-xl mb-1 text-slate-900">Skill Assessment</h3>
                        <p className="text-slate-600 text-sm">Evaluate your knowledge</p>
                      </CardContent>
                    </Card>
                  </Link>

                  <Link to={createPageUrl("Groups")}>
                    <Card className="shadow-lg hover:shadow-xl transition-all cursor-pointer bg-white border-t-4 border-orange-500">
                      <CardContent className="p-6 text-center">
                        <Users className="w-14 h-14 text-orange-600 mx-auto mb-3" />
                        <h3 className="font-bold text-xl mb-1 text-slate-900">Study Groups</h3>
                        <p className="text-slate-600 text-sm">Join university groups</p>
                      </CardContent>
                    </Card>
                  </Link>

                  <Link to={createPageUrl("AIChat")}>
                    <Card className="shadow-lg hover:shadow-xl transition-all cursor-pointer bg-white border-t-4 border-cyan-500">
                      <CardContent className="p-6 text-center">
                        <MessageSquare className="w-14 h-14 text-cyan-600 mx-auto mb-3" />
                        <h3 className="font-bold text-xl mb-1 text-slate-900">AI Tutor</h3>
                        <p className="text-slate-600 text-sm">Get instant help</p>
                      </CardContent>
                    </Card>
                  </Link>

                  <Link to={createPageUrl("Resources")}>
                    <Card className="shadow-lg hover:shadow-xl transition-all cursor-pointer bg-white border-t-4 border-yellow-500">
                      <CardContent className="p-6 text-center">
                        <Download className="w-14 h-14 text-yellow-600 mx-auto mb-3" />
                        <h3 className="font-bold text-xl mb-1 text-slate-900">Study Resources</h3>
                        <p className="text-slate-600 text-sm">Download materials</p>
                      </CardContent>
                    </Card>
                  </Link>
                </div>
              </TabsContent>

              {/* NEW: Settings Tab */}
              <TabsContent value="settings" className="mt-6 space-y-6">
                <h2 className="text-2xl font-bold text-slate-900">⚙️ Student Settings</h2>

                {/* University Portal Settings */}
                <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-blue-50 border-l-4 border-l-purple-600">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <GraduationCap className="w-6 h-6 text-purple-600" />
                      University Portal Access
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label className="text-sm font-semibold mb-3 block">Current University</Label>
                      {userUniversity && userUniversity.name !== 'Other' ?
                        <Card className="bg-white border-2 border-purple-300">
                          <CardContent className="p-6">
                            <div className="flex items-center gap-4 mb-4">
                              <div className="text-5xl">{userUniversity.icon}</div>
                              <div className="flex-1">
                                <h3 className="text-2xl font-bold text-slate-900">{userUniversity.name}</h3>
                                <p className="text-slate-600">Portal: {userUniversity.portal}</p>
                                <Badge className={userUniversity.iframe ? 'bg-green-600' : 'bg-blue-600'}>
                                  {userUniversity.iframe ? '📱 Opens in App' : '🔗 Opens Externally'}
                                </Badge>
                              </div>
                            </div>

                            {userUniversity.iframe ?
                              <Link to={createPageUrl("UniversityPortal")}>
                                <Button className="w-full mb-3 bg-gradient-to-r from-green-600 to-emerald-600">
                                  <BookOpen className="w-4 h-4 mr-2" />
                                  Open {userUniversity.portal}
                                </Button>
                              </Link> :

                              <a href={userUniversity.url} target="_blank" rel="noopener noreferrer">
                                <Button className="w-full mb-3 bg-gradient-to-r from-blue-600 to-indigo-600">
                                  <ExternalLink className="w-4 h-4 mr-2" />
                                  Open {userUniversity.portal}
                                </Button>
                              </a>
                            }
                          </CardContent>
                        </Card> :

                        <Card className="bg-slate-50 border-2 border-slate-200">
                          <CardContent className="p-6 text-center">
                            <p className="text-slate-500">No university selected, or 'Other' selected.</p>
                          </CardContent>
                        </Card>
                      }
                    </div>

                    <Button
                      onClick={() => setShowChangeUniversityDialog(true)}
                      variant="outline"
                      className="w-full border-2 border-purple-400 hover:bg-purple-50"
                      size="lg">

                      <GraduationCap className="w-5 h-5 mr-2" />
                      Change University
                    </Button>
                  </CardContent>
                </Card>

                {/* Profile Settings */}
                <Card className="border-none shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="w-6 h-6 text-blue-600" />
                      Profile Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Full Name</Label>
                      <Input
                        value={user?.full_name || ''}
                        disabled
                        className="bg-slate-50" />

                      <p className="text-xs text-slate-500 mt-1">Contact admin to change name</p>
                    </div>

                    <div>
                      <Label>Email</Label>
                      <Input
                        value={user?.email || ''}
                        disabled
                        className="bg-slate-50" />

                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Academic Year</Label>
                        <Select
                          value={user?.student_academic_year || ""}
                          onValueChange={(value) => updateProfileMutation.mutate({ student_academic_year: value })}>

                          <SelectTrigger className="border-2">
                            <SelectValue placeholder="Select year..." />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">Year 1</SelectItem>
                            <SelectItem value="2">Year 2</SelectItem>
                            <SelectItem value="3">Year 3</SelectItem>
                            <SelectItem value="4">Year 4</SelectItem>
                            <SelectItem value="5">Year 5</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label>Major / Field of Study</Label>
                        <Input
                          value={user?.student_major || ""}
                          onChange={(e) => updateProfileMutation.mutate({ student_major: e.target.value })}
                          placeholder="e.g., Computer Science"
                          className="border-2" />

                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Study Stats */}
                <Card className="border-none shadow-lg bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="w-6 h-6" />
                      Your Stats
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>Study Streak</span>
                      <Badge className="bg-white/20 text-white text-lg px-4 py-2">
                        {studyStreak} 🔥
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Completed Courses</span>
                      <Badge className="bg-white/20 text-white text-lg px-4 py-2">
                        {completedCourses} ✅
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Average Progress</span>
                      <Badge className="bg-white/20 text-white text-lg px-4 py-2">
                        {averageProgress}% 📊
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* University Selection Dialog (First Time) */}
      <Dialog open={showUniversityDialog} onOpenChange={() => { }}>
        <DialogContent className="sm:max-w-2xl" onInteractOutside={(e) => e.preventDefault()}>
          <DialogHeader>
            <DialogTitle className="text-2xl text-center">🎓 Select Your University</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <p className="text-center text-slate-600 mb-4">
              Get quick access to your student portal
            </p>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {Object.entries(UNIVERSITY_PORTALS).map(([key, uni]) =>
                <Button
                  key={key}
                  onClick={() => handleUniversitySelect(key)}
                  variant="outline"
                  className="h-28 flex flex-col gap-2 hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 hover:border-blue-400">

                  <span className="text-3xl">{uni.icon}</span>
                  <span className="text-sm font-bold text-center">{uni.name}</span>
                  <span className="text-xs text-slate-500">{uni.portal}</span>
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Change University Dialog */}
      <Dialog open={showChangeUniversityDialog} onOpenChange={setShowChangeUniversityDialog}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl text-center">🔄 Change University</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <p className="text-center text-slate-600 mb-4">
              Select your university to update portal access
            </p>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {Object.entries(UNIVERSITY_PORTALS).map(([key, uni]) =>
                <Button
                  key={key}
                  onClick={() => handleUniversitySelect(key)}
                  variant={user?.university === key ? "default" : "outline"}
                  className={`h-28 flex flex-col gap-2 ${user?.university === key ?
                      'bg-gradient-to-r from-blue-600 to-purple-600 text-white' :
                      'hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 hover:border-blue-400'}`
                  }>

                  <span className="text-3xl">{uni.icon}</span>
                  <span className="text-sm font-bold text-center">{uni.name}</span>
                  <span className={`text-xs ${user?.university === key ? 'text-white/80' : 'text-slate-500'}`}>{uni.portal}</span>
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Note Dialog */}
      <Dialog open={showNoteDialog} onOpenChange={setShowNoteDialog}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle>Create Study Note</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Title</Label>
              <Input
                value={newNote.title}
                onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
                placeholder="Note title..." />

            </div>
            <div>
              <Label>Subject (Optional)</Label>
              <Input
                value={newNote.subject}
                onChange={(e) => setNewNote({ ...newNote, subject: e.target.value })}
                placeholder="e.g., Mathematics" />

            </div>
            <div>
              <Label>Content</Label>
              <Textarea
                value={newNote.content}
                onChange={(e) => setNewNote({ ...newNote, content: e.target.value })}
                placeholder="Your notes..."
                rows={6} />

            </div>
            <Button onClick={handleAddNote} className="w-full bg-gradient-to-r from-blue-600 to-purple-600" disabled={!newNote.title || !newNote.content}>
              <Plus className="w-4 h-4 mr-2" />
              Save Note
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Assignment Dialog */}
      <Dialog open={showAssignmentDialog} onOpenChange={setShowAssignmentDialog}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle>Add Assignment</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Title</Label>
              <Input
                value={newAssignment.title}
                onChange={(e) => setNewAssignment({ ...newAssignment, title: e.target.value })}
                placeholder="Assignment title..." />

            </div>
            <div>
              <Label>Subject (Optional)</Label>
              <Input
                value={newAssignment.subject}
                onChange={(e) => setNewAssignment({ ...newAssignment, subject: e.target.value })}
                placeholder="e.g., Physics" />

            </div>
            <div>
              <Label>Description</Label>
              <Textarea
                value={newAssignment.description}
                onChange={(e) => setNewAssignment({ ...newAssignment, description: e.target.value })}
                placeholder="Details..."
                rows={4} />

            </div>
            <div>
              <Label>Due Date</Label>
              <Input
                type="date"
                value={newAssignment.due_date}
                onChange={(e) => setNewAssignment({ ...newAssignment, due_date: e.target.value })} />

            </div>
            <Button onClick={handleAddAssignment} className="w-full bg-gradient-to-r from-green-600 to-emerald-600" disabled={!newAssignment.title}>
              <Plus className="w-4 h-4 mr-2" />
              Add Assignment
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
