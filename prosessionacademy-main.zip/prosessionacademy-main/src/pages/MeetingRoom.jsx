import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  Monitor, 
  PhoneOff,
  Users,
  MessageSquare,
  X,
  Send,
  ArrowLeft
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function MeetingRoom() {
  const urlParams = new URLSearchParams(window.location.search);
  const roomId = urlParams.get('roomId');
  const meetingId = urlParams.get('meetingId');
  const groupId = urlParams.get('groupId');
  
  const [user, setUser] = useState(null);
  const [displayName, setDisplayName] = useState("");
  const [showChat, setShowChat] = useState(false);
  const [chatMessage, setChatMessage] = useState("");
  const [chatMessages, setChatMessages] = useState([]);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        setDisplayName(currentUser.full_name || currentUser.email);
      } catch (error) {
        console.error("Error fetching user:", error);
        setDisplayName("Guest User");
      }
    };
    fetchUser();
  }, []);

  const { data: meeting } = useQuery({
    queryKey: ['meeting', meetingId],
    queryFn: async () => {
      if (!meetingId) return null;
      const meetings = await base44.entities.MeetingRoom.filter({ id: meetingId });
      return meetings[0];
    },
    enabled: !!meetingId,
  });

  const { data: group } = useQuery({
    queryKey: ['group', groupId],
    queryFn: async () => {
      if (!groupId) return null;
      const groups = await base44.entities.Group.filter({ id: groupId });
      return groups[0];
    },
    enabled: !!groupId,
  });

  const handleSendMessage = () => {
    if (!chatMessage.trim()) return;
    
    setChatMessages([
      ...chatMessages,
      {
        sender: displayName,
        message: chatMessage,
        timestamp: new Date().toISOString()
      }
    ]);
    setChatMessage("");
  };

  const handleLeave = () => {
    if (groupId) {
      window.location.href = `${createPageUrl("GroupDashboard")}?groupId=${groupId}`;
    } else {
      window.location.href = createPageUrl("MeetingRooms");
    }
  };

  if (!roomId) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <Video className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Invalid Meeting Room</h2>
            <p className="text-slate-600 mb-4">No room ID provided</p>
            <Link to={groupId ? `${createPageUrl("GroupDashboard")}?groupId=${groupId}` : createPageUrl("MeetingRooms")}>
              <Button>Go Back</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const meetingTitle = group?.name ? `${group.name} - Group Meeting` : (meeting?.title || "Meeting Room");

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col">
      {/* Header */}
      <div className="bg-slate-800 border-b border-slate-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-white hover:bg-slate-700"
              onClick={handleLeave}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-white font-semibold">{meetingTitle}</h1>
              <div className="flex items-center gap-2 mt-1">
                {group && (
                  <Badge className="bg-purple-600 text-white text-xs">
                    Group Meeting
                  </Badge>
                )}
                <Badge variant="outline" className="text-xs text-slate-300 border-slate-600">
                  <Users className="w-3 h-3 mr-1" />
                  {meeting?.participants?.length || group?.members?.length || 0} members
                </Badge>
              </div>
            </div>
          </div>

          <Button 
            onClick={handleLeave}
            variant="destructive"
            className="bg-red-600 hover:bg-red-700"
          >
            <PhoneOff className="w-4 h-4 mr-2" />
            Leave Meeting
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex">
        {/* Video Area */}
        <div className="flex-1 flex items-center justify-center p-6 relative">
          {/* Jitsi Meet Embed */}
          <div className="w-full h-full rounded-xl overflow-hidden shadow-2xl">
            <iframe
              src={`https://meet.jit.si/${roomId}#config.prejoinPageEnabled=false&userInfo.displayName="${displayName}"`}
              allow="camera; microphone; fullscreen; display-capture"
              className="w-full h-full"
              frameBorder="0"
            />
          </div>

          {/* Chat Sidebar */}
          {showChat && (
            <div className="absolute right-6 top-6 bottom-6 w-80 bg-slate-800 rounded-xl shadow-2xl flex flex-col">
              <div className="flex items-center justify-between p-4 border-b border-slate-700">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-white" />
                  <h3 className="text-white font-semibold">Chat</h3>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowChat(false)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {chatMessages.length === 0 ? (
                  <p className="text-slate-400 text-sm text-center mt-8">
                    No messages yet. Start the conversation!
                  </p>
                ) : (
                  chatMessages.map((msg, idx) => (
                    <div key={idx} className="bg-slate-700 rounded-lg p-3">
                      <p className="text-blue-400 text-xs font-semibold mb-1">{msg.sender}</p>
                      <p className="text-white text-sm">{msg.message}</p>
                    </div>
                  ))
                )}
              </div>

              <div className="p-4 border-t border-slate-700">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={chatMessage}
                    onChange={(e) => setChatMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Type a message..."
                    className="flex-1 bg-slate-700 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <Button
                    onClick={handleSendMessage}
                    size="sm"
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="bg-slate-800 border-t border-slate-700 px-6 py-4">
        <div className="flex items-center justify-center gap-4">
          <Button
            onClick={() => setShowChat(!showChat)}
            variant={showChat ? "default" : "outline"}
            className={showChat ? "bg-blue-600 hover:bg-blue-700" : "text-white border-slate-600 hover:bg-slate-700"}
          >
            <MessageSquare className="w-5 h-5 mr-2" />
            Chat
          </Button>

          <div className="text-xs text-slate-400">
            💡 Use the video controls in the meeting window above
          </div>
        </div>
      </div>
    </div>
  );
}