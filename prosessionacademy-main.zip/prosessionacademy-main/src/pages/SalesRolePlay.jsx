import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Camera,
  Mic,
  MicOff,
  Video,
  VideoOff,
  StopCircle,
  Play,
  Volume2,
  Target,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Loader2,
  ArrowRight,
  Sparkles,
  User,
  Users,
  BarChart3,
  MessageSquare,
  Download,
  RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function SalesRolePlay() {
  const [user, setUser] = useState(null);
  const [sessionActive, setSessionActive] = useState(false);
  const [recording, setRecording] = useState(false);
  
  // Setup
  const [productName, setProductName] = useState('');
  const [customerType, setCustomerType] = useState('business');
  const [difficulty, setDifficulty] = useState('medium');
  const [scenario, setScenario] = useState('');
  
  // Stream states
  const [localStream, setLocalStream] = useState(null);
  const [cameraEnabled, setCameraEnabled] = useState(true);
  const [micEnabled, setMicEnabled] = useState(true);
  
  // AI Feedback
  const [transcript, setTranscript] = useState([]);
  const [liveFeedback, setLiveFeedback] = useState([]);
  const [analyzing, setAnalyzing] = useState(false);
  
  // Final Report
  const [sessionComplete, setSessionComplete] = useState(false);
  const [finalReport, setFinalReport] = useState(null);
  const [generatingReport, setGeneratingReport] = useState(false);
  
  const localVideoRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const recordedChunksRef = useRef([]);
  const recognitionRef = useRef(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error('Error:', error);
      }
    };
    fetchUser();
  }, []);

  useEffect(() => {
    if (localStream && localVideoRef.current) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 1280, height: 720 },
        audio: true
      });
      setLocalStream(stream);
      
      // Start recording
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };
      
      mediaRecorder.start(1000); // Collect data every second
      setRecording(true);
      
      // Start speech recognition
      startSpeechRecognition();
      
    } catch (error) {
      alert('❌ Camera/Mic access denied: ' + error.message);
    }
  };

  const startSpeechRecognition = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      console.warn('Speech recognition not supported');
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event) => {
      const results = event.results;
      const lastResult = results[results.length - 1];
      
      if (lastResult.isFinal) {
        const text = lastResult[0].transcript;
        const timestamp = new Date().toISOString();
        
        setTranscript(prev => [...prev, {
          speaker: 'Sales Person',
          text: text,
          timestamp: timestamp
        }]);

        // Trigger AI feedback every 3-4 messages
        if (transcript.length % 3 === 0) {
          analyzeSpeech(text);
        }
      }
    };

    recognition.start();
    recognitionRef.current = recognition;
  };

  const analyzeSpeech = async (latestText) => {
    setAnalyzing(true);
    try {
      const recentTranscript = transcript.slice(-5).map(t => `${t.speaker}: ${t.text}`).join('\n') + `\nSales Person: ${latestText}`;
      
      const feedback = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this sales conversation snippet:

${recentTranscript}

Product: ${productName}
Customer Type: ${customerType}

Give 1-2 QUICK tips (30 words max):
- What they're doing well
- One improvement

Keep it SHORT and ACTIONABLE.`
      });

      setLiveFeedback(prev => [...prev, {
        text: feedback,
        timestamp: new Date().toISOString(),
        type: 'tip'
      }]);
    } catch (error) {
      console.error('Analysis error:', error);
    } finally {
      setAnalyzing(false);
    }
  };

  const startSession = () => {
    if (!productName.trim()) {
      alert('Please enter a product name');
      return;
    }
    setSessionActive(true);
    startCamera();
  };

  const endSession = async () => {
    // Stop recording
    if (mediaRecorderRef.current && recording) {
      mediaRecorderRef.current.stop();
      setRecording(false);
    }

    // Stop recognition
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }

    // Stop camera
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
      setLocalStream(null);
    }

    setSessionActive(false);
    setSessionComplete(true);
    
    // Generate final report
    generateFinalReport();
  };

  const generateFinalReport = async () => {
    setGeneratingReport(true);
    try {
      const fullTranscript = transcript.map(t => `${t.speaker}: ${t.text}`).join('\n');
      
      const report = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this complete sales role play session:

PRODUCT: ${productName}
CUSTOMER TYPE: ${customerType}
DIFFICULTY: ${difficulty}
${scenario ? `SCENARIO: ${scenario}` : ''}

FULL TRANSCRIPT:
${fullTranscript}

Create a comprehensive performance report with:

1. OVERALL SCORE (0-100)
2. STRENGTHS (3-4 specific things they did well)
3. AREAS FOR IMPROVEMENT (3-4 specific weaknesses)
4. COMMUNICATION SCORE (0-100) - clarity, confidence, tone
5. PERSUASION SCORE (0-100) - value proposition, handling objections
6. CLOSING SCORE (0-100) - asking for sale, urgency creation
7. KEY MOMENTS (2-3 best moments with quotes)
8. RED FLAGS (2-3 mistakes with quotes)
9. ACTIONABLE RECOMMENDATIONS (5 specific next steps)

Be specific and quote actual phrases from the transcript.`,
        response_json_schema: {
          type: "object",
          properties: {
            overall_score: { type: "number" },
            strengths: { type: "array", items: { type: "string" } },
            improvements: { type: "array", items: { type: "string" } },
            communication_score: { type: "number" },
            persuasion_score: { type: "number" },
            closing_score: { type: "number" },
            key_moments: { type: "array", items: { type: "string" } },
            red_flags: { type: "array", items: { type: "string" } },
            recommendations: { type: "array", items: { type: "string" } }
          }
        }
      });

      setFinalReport(report);
    } catch (error) {
      alert('❌ Report generation failed: ' + error.message);
    } finally {
      setGeneratingReport(false);
    }
  };

  const toggleCamera = () => {
    if (localStream) {
      const videoTrack = localStream.getVideoTracks()[0];
      videoTrack.enabled = !videoTrack.enabled;
      setCameraEnabled(videoTrack.enabled);
    }
  };

  const toggleMic = () => {
    if (localStream) {
      const audioTrack = localStream.getAudioTracks()[0];
      audioTrack.enabled = !audioTrack.enabled;
      setMicEnabled(audioTrack.enabled);
    }
  };

  const resetSession = () => {
    setSessionComplete(false);
    setFinalReport(null);
    setTranscript([]);
    setLiveFeedback([]);
    recordedChunksRef.current = [];
  };

  // Setup Screen
  if (!sessionActive && !sessionComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-pink-900 p-6 flex items-center justify-center">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="max-w-3xl w-full">
          <Card className="border-none shadow-2xl">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8 text-center">
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-10 h-10" />
              </div>
              <CardTitle className="text-4xl mb-2">🎬 Sales Live Role Play</CardTitle>
              <p className="text-white/90 text-lg">Practice with AI feedback in real-time</p>
            </CardHeader>
            
            <CardContent className="p-8 space-y-6">
              <Card className="bg-blue-50 border-2 border-blue-300">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Sparkles className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
                    <div>
                      <p className="font-bold text-blue-900 mb-2">How it works:</p>
                      <ul className="text-sm text-blue-800 space-y-1">
                        <li>📹 Your camera turns on - you're the salesperson</li>
                        <li>🎤 Talk naturally as if you're selling to a customer</li>
                        <li>🤖 AI listens and gives LIVE tips every few seconds</li>
                        <li>📊 Get full performance report when done</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div>
                <Label className="text-lg font-bold mb-3 block">What are you selling? *</Label>
                <Input
                  value={productName}
                  onChange={(e) => setProductName(e.target.value)}
                  placeholder="e.g., CRM Software, Marketing Services, Insurance"
                  className="h-12 text-lg border-2"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="font-bold mb-2 block">Customer Type</Label>
                  <select
                    value={customerType}
                    onChange={(e) => setCustomerType(e.target.value)}
                    className="w-full px-4 py-3 border-2 border-slate-300 rounded-lg focus:border-blue-500 focus:outline-none"
                  >
                    <option value="business">🏢 Business (B2B)</option>
                    <option value="consumer">👤 Consumer (B2C)</option>
                    <option value="enterprise">🏛️ Enterprise</option>
                    <option value="retail">🛍️ Retail Customer</option>
                  </select>
                </div>

                <div>
                  <Label className="font-bold mb-2 block">Difficulty</Label>
                  <select
                    value={difficulty}
                    onChange={(e) => setDifficulty(e.target.value)}
                    className="w-full px-4 py-3 border-2 border-slate-300 rounded-lg focus:border-blue-500 focus:outline-none"
                  >
                    <option value="easy">🟢 Easy - Interested buyer</option>
                    <option value="medium">🟡 Medium - Needs convincing</option>
                    <option value="hard">🔴 Hard - Skeptical customer</option>
                  </select>
                </div>
              </div>

              <div>
                <Label className="font-bold mb-2 block">Scenario (Optional)</Label>
                <Textarea
                  value={scenario}
                  onChange={(e) => setScenario(e.target.value)}
                  placeholder="e.g., Customer is comparing you to competitors, Budget concerns, First-time buyer..."
                  rows={3}
                  className="border-2"
                />
              </div>

              <Card className="bg-yellow-50 border-2 border-yellow-300">
                <CardContent className="p-4">
                  <div className="flex items-start gap-2">
                    <Camera className="w-5 h-5 text-yellow-700 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-yellow-900">
                      <strong>Camera & Mic Required:</strong> Make sure you're in a quiet space. Your camera will turn on when you start.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Button
                onClick={startSession}
                disabled={!productName.trim()}
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 py-8 text-2xl font-bold shadow-2xl"
                size="lg"
              >
                <Play className="w-8 h-8 mr-3" />
                Start Role Play 🎬
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  // Active Session
  if (sessionActive && !sessionComplete) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col">
        {/* Top Bar */}
        <div className="bg-slate-800 border-b border-slate-700 p-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Badge className="bg-red-600 text-white px-4 py-2 text-base animate-pulse">
                <div className="w-3 h-3 bg-white rounded-full mr-2 animate-pulse" />
                LIVE
              </Badge>
              <div className="text-white">
                <p className="font-bold text-lg">{productName}</p>
                <p className="text-sm text-slate-400">{customerType} • {difficulty} difficulty</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Button
                onClick={toggleCamera}
                variant="outline"
                className={`${cameraEnabled ? 'bg-slate-700 border-slate-600' : 'bg-red-600 border-red-500'}`}
                size="icon"
              >
                {cameraEnabled ? <Video className="w-5 h-5 text-white" /> : <VideoOff className="w-5 h-5 text-white" />}
              </Button>
              
              <Button
                onClick={toggleMic}
                variant="outline"
                className={`${micEnabled ? 'bg-slate-700 border-slate-600' : 'bg-red-600 border-red-500'}`}
                size="icon"
              >
                {micEnabled ? <Mic className="w-5 h-5 text-white" /> : <MicOff className="w-5 h-5 text-white" />}
              </Button>

              <Button
                onClick={endSession}
                className="bg-red-600 hover:bg-red-700 px-6"
                size="lg"
              >
                <StopCircle className="w-5 h-5 mr-2" />
                End Session
              </Button>
            </div>
          </div>
        </div>

        <div className="flex-1 p-6">
          <div className="max-w-7xl mx-auto grid lg:grid-cols-3 gap-6 h-full">
            {/* Left: Video Feed */}
            <div className="lg:col-span-2 space-y-4">
              <Card className="border-none shadow-2xl bg-slate-800 overflow-hidden">
                <CardContent className="p-0">
                  <div className="relative bg-black aspect-video">
                    <video
                      ref={localVideoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-4 left-4 bg-blue-600 text-white px-4 py-2 rounded-lg font-bold shadow-lg">
                      <User className="w-4 h-4 inline mr-2" />
                      YOU (Sales Person)
                    </div>
                    {!cameraEnabled && (
                      <div className="absolute inset-0 bg-slate-900 flex items-center justify-center">
                        <div className="text-center text-white">
                          <VideoOff className="w-16 h-16 mx-auto mb-3 opacity-50" />
                          <p className="text-lg">Camera Off</p>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Customer Avatar (AI) */}
              <Card className="border-none shadow-xl bg-gradient-to-br from-purple-600 to-pink-600">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 text-white">
                    <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center text-3xl">
                      👤
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-lg mb-1">AI Customer</p>
                      <p className="text-sm text-white/80">Imagine a {customerType} customer in front of you</p>
                    </div>
                    <Volume2 className="w-8 h-8 opacity-50" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right: Live Feedback */}
            <div className="space-y-4">
              <Card className="border-none shadow-2xl bg-slate-800">
                <CardHeader className="border-b border-slate-700">
                  <CardTitle className="text-white flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-blue-400" />
                    Live AI Feedback
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 max-h-[500px] overflow-y-auto space-y-3">
                  <AnimatePresence>
                    {liveFeedback.map((feedback, idx) => (
                      <motion.div
                        key={idx}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                      >
                        <Card className="bg-gradient-to-r from-blue-600 to-purple-600 border-none">
                          <CardContent className="p-4 text-white">
                            <div className="flex items-start gap-2">
                              <Sparkles className="w-5 h-5 flex-shrink-0 mt-1" />
                              <p className="text-sm leading-relaxed">{feedback.text}</p>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </AnimatePresence>

                  {analyzing && (
                    <Card className="bg-slate-700 border-slate-600">
                      <CardContent className="p-4 flex items-center gap-2 text-slate-300">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span className="text-sm">AI is analyzing...</span>
                      </CardContent>
                    </Card>
                  )}

                  {liveFeedback.length === 0 && !analyzing && (
                    <div className="text-center py-12 text-slate-400">
                      <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p className="text-sm">Start talking to receive AI tips</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Transcript Preview */}
              <Card className="border-none shadow-xl bg-slate-800">
                <CardHeader className="border-b border-slate-700">
                  <CardTitle className="text-white flex items-center gap-2 text-sm">
                    <Target className="w-4 h-4 text-green-400" />
                    Transcript
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 max-h-[200px] overflow-y-auto">
                  <div className="space-y-2 text-xs">
                    {transcript.slice(-5).map((t, idx) => (
                      <div key={idx} className="text-slate-300">
                        <span className="font-bold text-blue-400">{t.speaker}:</span> {t.text}
                      </div>
                    ))}
                    {transcript.length === 0 && (
                      <p className="text-slate-500 text-center py-4">Speech will appear here...</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Final Report
  if (sessionComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 p-6">
        <div className="max-w-5xl mx-auto space-y-6">
          {generatingReport ? (
            <Card className="border-none shadow-2xl">
              <CardContent className="p-16 text-center">
                <Loader2 className="w-16 h-16 text-blue-600 animate-spin mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-slate-900 mb-2">Analyzing Your Performance...</h2>
                <p className="text-slate-600">Reviewing transcript and generating detailed feedback</p>
              </CardContent>
            </Card>
          ) : finalReport ? (
            <>
              {/* Header */}
              <Card className="border-none shadow-2xl bg-gradient-to-r from-green-600 to-emerald-600 text-white">
                <CardContent className="p-8">
                  <div className="flex items-center justify-between">
                    <div>
                      <h1 className="text-4xl font-bold mb-2">📊 Performance Report</h1>
                      <p className="text-white/90 text-lg">{productName} - {customerType} sale</p>
                    </div>
                    <div className="text-center">
                      <div className="text-6xl font-black">{finalReport.overall_score}</div>
                      <p className="text-white/80">Overall Score</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Score Breakdown */}
              <div className="grid md:grid-cols-3 gap-6">
                <Card className="border-none shadow-xl">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                        <MessageSquare className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">Communication</p>
                        <p className="text-3xl font-bold text-blue-600">{finalReport.communication_score}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-none shadow-xl">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                        <Target className="w-6 h-6 text-purple-600" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">Persuasion</p>
                        <p className="text-3xl font-bold text-purple-600">{finalReport.persuasion_score}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-none shadow-xl">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                        <CheckCircle className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">Closing</p>
                        <p className="text-3xl font-bold text-green-600">{finalReport.closing_score}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Strengths & Improvements */}
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="border-none shadow-xl bg-gradient-to-br from-green-50 to-emerald-50 border-l-4 border-green-600">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-green-900">
                      <CheckCircle className="w-6 h-6" />
                      💪 What You Did Well
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {finalReport.strengths?.map((strength, idx) => (
                      <div key={idx} className="flex items-start gap-2">
                        <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                          <CheckCircle className="w-4 h-4 text-white" />
                        </div>
                        <p className="text-sm text-slate-700 leading-relaxed">{strength}</p>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card className="border-none shadow-xl bg-gradient-to-br from-orange-50 to-red-50 border-l-4 border-orange-600">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-orange-900">
                      <TrendingUp className="w-6 h-6" />
                      📈 Areas to Improve
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {finalReport.improvements?.map((improvement, idx) => (
                      <div key={idx} className="flex items-start gap-2">
                        <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                          <ArrowRight className="w-4 h-4 text-white" />
                        </div>
                        <p className="text-sm text-slate-700 leading-relaxed">{improvement}</p>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>

              {/* Key Moments */}
              <Card className="border-none shadow-xl bg-gradient-to-br from-blue-50 to-indigo-50 border-t-4 border-blue-600">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="w-6 h-6 text-blue-600" />
                    ⭐ Best Moments
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {finalReport.key_moments?.map((moment, idx) => (
                    <Card key={idx} className="bg-white">
                      <CardContent className="p-4">
                        <p className="text-sm text-slate-700 italic">"{moment}"</p>
                      </CardContent>
                    </Card>
                  ))}
                </CardContent>
              </Card>

              {/* Red Flags */}
              {finalReport.red_flags && finalReport.red_flags.length > 0 && (
                <Card className="border-none shadow-xl bg-gradient-to-br from-red-50 to-pink-50 border-t-4 border-red-600">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <AlertCircle className="w-6 h-6 text-red-600" />
                      🚩 Watch Out For
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {finalReport.red_flags.map((flag, idx) => (
                      <Card key={idx} className="bg-white">
                        <CardContent className="p-4">
                          <p className="text-sm text-slate-700">{flag}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </CardContent>
                </Card>
              )}

              {/* Action Plan */}
              <Card className="border-none shadow-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-6 h-6" />
                    🎯 Next Steps to Improve
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {finalReport.recommendations?.map((rec, idx) => (
                    <div key={idx} className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="font-bold">{idx + 1}</span>
                      </div>
                      <p className="text-sm text-white/95 leading-relaxed">{rec}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Actions */}
              <div className="flex gap-4">
                <Button
                  onClick={resetSession}
                  variant="outline"
                  className="flex-1"
                  size="lg"
                >
                  <RefreshCw className="w-5 h-5 mr-2" />
                  New Session
                </Button>
                <Button
                  onClick={() => window.print()}
                  className="flex-1 bg-blue-600"
                  size="lg"
                >
                  <Download className="w-5 h-5 mr-2" />
                  Save Report
                </Button>
              </div>
            </>
          ) : null}
        </div>
      </div>
    );
  }

  return null;
}