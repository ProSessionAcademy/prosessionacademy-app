import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import {
  TrendingUp,
  Users,
  BookOpen,
  Award,
  Clock,
  Target,
  Download,
  Calendar,
  Activity
} from "lucide-react";
import { format } from "date-fns";

export default function GroupAnalytics() {
  const [user, setUser] = useState(null);
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [timeRange, setTimeRange] = useState("30"); // days

  useEffect(() => {
    const fetchUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    fetchUser();
  }, []);

  const { data: groups = [] } = useQuery({
    queryKey: ['userGroups', user?.email],
    queryFn: async () => {
      if (!user) return [];
      const allGroups = await base44.entities.Group.list();
      return allGroups.filter(g => 
        g.admin_emails?.includes(user.email) || 
        g.members?.some(m => m.user_email === user.email && m.role === 'admin')
      );
    },
    enabled: !!user
  });

  const { data: groupProgress = [] } = useQuery({
    queryKey: ['groupProgress', selectedGroup?.id],
    queryFn: async () => {
      if (!selectedGroup) return [];
      const allProgress = await base44.entities.UserProgress.list();
      const memberEmails = selectedGroup.members?.map(m => m.user_email) || [];
      return allProgress.filter(p => memberEmails.includes(p.user_email));
    },
    enabled: !!selectedGroup
  });

  const { data: courses = [] } = useQuery({
    queryKey: ['courses'],
    queryFn: () => base44.entities.Course.list(),
    initialData: []
  });

  useEffect(() => {
    if (groups.length > 0 && !selectedGroup) {
      setSelectedGroup(groups[0]);
    }
  }, [groups]);

  if (!selectedGroup) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 flex items-center justify-center p-6">
        <Card className="max-w-md">
          <CardContent className="p-12 text-center">
            <Users className="w-16 h-16 text-slate-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-slate-900 mb-2">No Groups Found</h2>
            <p className="text-slate-600">You need to be a group admin to access analytics</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Calculate metrics
  const totalMembers = selectedGroup.members?.length || 0;
  const activeLearners = new Set(groupProgress.map(p => p.user_email)).size;
  const totalEnrollments = groupProgress.length;
  const completedCourses = groupProgress.filter(p => p.progress_percentage === 100).length;
  const averageProgress = groupProgress.length > 0 
    ? Math.round(groupProgress.reduce((sum, p) => sum + p.progress_percentage, 0) / groupProgress.length)
    : 0;
  
  // Engagement rate
  const engagementRate = totalMembers > 0 ? Math.round((activeLearners / totalMembers) * 100) : 0;

  // Course completion rate
  const completionRate = totalEnrollments > 0 ? Math.round((completedCourses / totalEnrollments) * 100) : 0;

  // Popular courses
  const courseEnrollments = {};
  groupProgress.forEach(p => {
    courseEnrollments[p.course_id] = (courseEnrollments[p.course_id] || 0) + 1;
  });
  
  const popularCoursesData = Object.entries(courseEnrollments)
    .map(([courseId, count]) => {
      const course = courses.find(c => c.id === courseId);
      return {
        name: course?.title?.substring(0, 20) || 'Unknown',
        enrollments: count,
        completions: groupProgress.filter(p => p.course_id === courseId && p.progress_percentage === 100).length
      };
    })
    .sort((a, b) => b.enrollments - a.enrollments)
    .slice(0, 5);

  // Progress distribution
  const progressDistribution = [
    { name: '0-25%', count: groupProgress.filter(p => p.progress_percentage >= 0 && p.progress_percentage < 25).length },
    { name: '25-50%', count: groupProgress.filter(p => p.progress_percentage >= 25 && p.progress_percentage < 50).length },
    { name: '50-75%', count: groupProgress.filter(p => p.progress_percentage >= 50 && p.progress_percentage < 75).length },
    { name: '75-99%', count: groupProgress.filter(p => p.progress_percentage >= 75 && p.progress_percentage < 100).length },
    { name: '100%', count: groupProgress.filter(p => p.progress_percentage === 100).length }
  ];

  // Individual performance (top performers)
  const memberPerformance = selectedGroup.members?.map(member => {
    const memberProgress = groupProgress.filter(p => p.user_email === member.user_email);
    const avgProgress = memberProgress.length > 0
      ? Math.round(memberProgress.reduce((sum, p) => sum + p.progress_percentage, 0) / memberProgress.length)
      : 0;
    const completedCount = memberProgress.filter(p => p.progress_percentage === 100).length;
    
    return {
      name: member.full_name,
      email: member.user_email,
      enrollments: memberProgress.length,
      avgProgress,
      completed: completedCount,
      points: member.points || 0
    };
  }).sort((a, b) => b.avgProgress - a.avgProgress) || [];

  const COLORS = ['#3B82F6', '#8B5CF6', '#EC4899', '#F59E0B', '#10B981'];

  const exportReport = () => {
    const report = {
      group_name: selectedGroup.name,
      generated_date: new Date().toISOString(),
      summary: {
        total_members: totalMembers,
        active_learners: activeLearners,
        engagement_rate: engagementRate,
        total_enrollments: totalEnrollments,
        completed_courses: completedCourses,
        completion_rate: completionRate,
        average_progress: averageProgress
      },
      popular_courses: popularCoursesData,
      progress_distribution: progressDistribution,
      member_performance: memberPerformance
    };

    const dataStr = JSON.stringify(report, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${selectedGroup.name}-analytics-${Date.now()}.json`;
    link.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-3xl blur opacity-75"></div>
          <Card className="relative border-none shadow-2xl">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-3xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center">
                    <TrendingUp className="w-9 h-9" />
                  </div>
                  <div>
                    <CardTitle className="text-3xl font-bold">Group Analytics</CardTitle>
                    <p className="text-blue-100 mt-1">Track learning progress & ROI</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Select value={selectedGroup?.id} onValueChange={(id) => setSelectedGroup(groups.find(g => g.id === id))}>
                    <SelectTrigger className="w-64 bg-white/20 border-white/30 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {groups.map(group => (
                        <SelectItem key={group.id} value={group.id}>
                          {group.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button onClick={exportReport} variant="secondary">
                    <Download className="w-4 h-4 mr-2" />
                    Export Report
                  </Button>
                </div>
              </div>
            </CardHeader>
          </Card>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="border-none shadow-lg bg-gradient-to-br from-blue-600 to-blue-700 text-white">
            <CardContent className="p-6">
              <Users className="w-10 h-10 mb-3 opacity-80" />
              <h3 className="text-3xl font-bold">{activeLearners}/{totalMembers}</h3>
              <p className="text-sm opacity-90">Active Learners</p>
              <Badge className="mt-2 bg-white/20">{engagementRate}% engagement</Badge>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-purple-600 to-purple-700 text-white">
            <CardContent className="p-6">
              <BookOpen className="w-10 h-10 mb-3 opacity-80" />
              <h3 className="text-3xl font-bold">{totalEnrollments}</h3>
              <p className="text-sm opacity-90">Total Enrollments</p>
              <Badge className="mt-2 bg-white/20">{completedCourses} completed</Badge>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-green-600 to-green-700 text-white">
            <CardContent className="p-6">
              <Award className="w-10 h-10 mb-3 opacity-80" />
              <h3 className="text-3xl font-bold">{completionRate}%</h3>
              <p className="text-sm opacity-90">Completion Rate</p>
              <Badge className="mt-2 bg-white/20">Industry avg: 15%</Badge>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-orange-600 to-orange-700 text-white">
            <CardContent className="p-6">
              <Target className="w-10 h-10 mb-3 opacity-80" />
              <h3 className="text-3xl font-bold">{averageProgress}%</h3>
              <p className="text-sm opacity-90">Avg. Progress</p>
              <Badge className="mt-2 bg-white/20">Across all courses</Badge>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-white shadow-lg">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="courses">Course Performance</TabsTrigger>
            <TabsTrigger value="members">Member Performance</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Popular Courses */}
              <Card className="border-none shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-blue-600" />
                    Most Popular Courses
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={popularCoursesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="enrollments" fill="#3B82F6" name="Enrollments" />
                      <Bar dataKey="completions" fill="#10B981" name="Completions" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Progress Distribution */}
              <Card className="border-none shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-purple-600" />
                    Progress Distribution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={progressDistribution}
                        dataKey="count"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        label
                      >
                        {progressDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="courses">
            <Card className="border-none shadow-xl">
              <CardHeader>
                <CardTitle>Detailed Course Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {popularCoursesData.map((course, idx) => {
                    const courseCompletionRate = course.enrollments > 0 
                      ? Math.round((course.completions / course.enrollments) * 100)
                      : 0;
                    
                    return (
                      <div key={idx} className="border-2 border-slate-200 rounded-xl p-4">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-bold text-slate-900">{course.name}</h4>
                          <Badge className={
                            courseCompletionRate >= 70 ? 'bg-green-600' :
                            courseCompletionRate >= 40 ? 'bg-yellow-600' :
                            'bg-red-600'
                          }>
                            {courseCompletionRate}% completion
                          </Badge>
                        </div>
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <p className="text-slate-500">Enrollments</p>
                            <p className="text-2xl font-bold text-blue-600">{course.enrollments}</p>
                          </div>
                          <div>
                            <p className="text-slate-500">Completions</p>
                            <p className="text-2xl font-bold text-green-600">{course.completions}</p>
                          </div>
                          <div>
                            <p className="text-slate-500">In Progress</p>
                            <p className="text-2xl font-bold text-orange-600">{course.enrollments - course.completions}</p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="members">
            <Card className="border-none shadow-xl">
              <CardHeader>
                <CardTitle>Member Performance Leaderboard</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {memberPerformance.map((member, idx) => (
                    <div key={idx} className="border-2 border-slate-200 rounded-xl p-4 hover:border-blue-400 transition-all">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white ${
                            idx === 0 ? 'bg-yellow-500' :
                            idx === 1 ? 'bg-slate-400' :
                            idx === 2 ? 'bg-orange-600' :
                            'bg-slate-300'
                          }`}>
                            #{idx + 1}
                          </div>
                          <div>
                            <h4 className="font-bold text-slate-900">{member.name}</h4>
                            <p className="text-sm text-slate-500">{member.email}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-6 text-center">
                          <div>
                            <p className="text-2xl font-bold text-blue-600">{member.enrollments}</p>
                            <p className="text-xs text-slate-500">Enrolled</p>
                          </div>
                          <div>
                            <p className="text-2xl font-bold text-green-600">{member.completed}</p>
                            <p className="text-xs text-slate-500">Completed</p>
                          </div>
                          <div>
                            <p className="text-2xl font-bold text-purple-600">{member.avgProgress}%</p>
                            <p className="text-xs text-slate-500">Avg Progress</p>
                          </div>
                          <div>
                            <p className="text-2xl font-bold text-orange-600">{member.points}</p>
                            <p className="text-xs text-slate-500">Points</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* ROI Insights */}
        <Card className="border-none shadow-xl bg-gradient-to-r from-green-50 to-emerald-50">
          <CardContent className="p-8">
            <div className="flex items-start gap-4">
              <div className="w-16 h-16 bg-green-600 rounded-2xl flex items-center justify-center">
                <TrendingUp className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Training ROI Insights</h3>
                <div className="grid md:grid-cols-3 gap-6 mt-4">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Engagement Score</p>
                    <p className="text-3xl font-bold text-green-600">{engagementRate}/100</p>
                    <p className="text-xs text-slate-500 mt-1">
                      {engagementRate >= 70 ? '🎉 Excellent!' : engagementRate >= 40 ? '👍 Good' : '⚠️ Needs improvement'}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Completion Quality</p>
                    <p className="text-3xl font-bold text-blue-600">{completionRate}%</p>
                    <p className="text-xs text-slate-500 mt-1">
                      {completionRate >= 50 ? 'Above industry average' : 'Room for growth'}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Estimated Training Hours</p>
                    <p className="text-3xl font-bold text-purple-600">{Math.round(totalEnrollments * 3.5)}h</p>
                    <p className="text-xs text-slate-500 mt-1">Total learning time invested</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}