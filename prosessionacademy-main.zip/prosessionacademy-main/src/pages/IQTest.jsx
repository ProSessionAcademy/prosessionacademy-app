import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Brain, 
  Zap, 
  Trophy,
  AlertCircle,
  CheckCircle,
  ArrowRight,
  RefreshCw,
  Clock
} from "lucide-react";

export default function IQTest() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [showStart, setShowStart] = useState(true);
  const [selectedAnswer, setSelectedAnswer] = useState(null);

  const { data: questions = [], isLoading } = useQuery({
    queryKey: ['iqQuestions'],
    queryFn: async () => {
      const allQuestions = await base44.entities.IQTestQuestion.filter({ active: true }, 'order');
      return allQuestions;
    },
    initialData: [],
  });

  const handleAnswer = (answerIdx) => {
    setSelectedAnswer(answerIdx);
    
    setTimeout(() => {
      const newAnswers = { ...answers, [currentQuestion]: answerIdx };
      setAnswers(newAnswers);
      setSelectedAnswer(null);

      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
      } else {
        calculateResult(newAnswers);
      }
    }, 500);
  };

  const calculateResult = (finalAnswers) => {
    let correct = 0;
    questions.forEach((q, idx) => {
      if (finalAnswers[idx] === q.correct_answer) {
        correct++;
      }
    });

    const percentage = (correct / questions.length) * 100;
    const estimatedIQ = 85 + (percentage * 0.3); // Scale to IQ range

    let range;
    if (correct <= Math.floor(questions.length * 0.4)) {
      range = { label: "Below Average", desc: "Keep practicing!", color: "from-red-500 to-orange-500" };
    } else if (correct <= Math.floor(questions.length * 0.6)) {
      range = { label: "Average", desc: "Good baseline!", color: "from-yellow-500 to-amber-500" };
    } else if (correct <= Math.floor(questions.length * 0.8)) {
      range = { label: "Above Average", desc: "Impressive!", color: "from-green-500 to-emerald-500" };
    } else {
      range = { label: "Superior", desc: "Exceptional!", color: "from-blue-500 to-purple-500" };
    }

    setResult({ correct, total: questions.length, range, estimatedIQ: Math.round(estimatedIQ) });
  };

  const restart = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setResult(null);
    setShowStart(true);
    setSelectedAnswer(null);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading test...</p>
        </div>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-indigo-50 p-6 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <Brain className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-slate-900 mb-2">No Questions Available</h2>
            <p className="text-slate-600">The admin needs to add IQ test questions first.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const progress = ((currentQuestion + 1) / questions.length) * 100;

  if (showStart) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-indigo-50 p-6 flex items-center justify-center">
        <Card className="max-w-2xl w-full border-none shadow-2xl">
          <CardContent className="p-12">
            <div className="text-center mb-8">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Brain className="w-12 h-12 text-white" />
              </div>
              <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                IQ Challenge
              </h1>
              <p className="text-slate-600 text-lg mb-6">
                Test your cognitive abilities with {questions.length} engaging questions
              </p>
            </div>

            <Alert className="mb-8 border-2 border-amber-200 bg-amber-50">
              <AlertCircle className="h-5 w-5 text-amber-600" />
              <AlertDescription className="text-amber-900">
                <strong>Disclaimer:</strong> This is a fun, unofficial IQ test for entertainment purposes only.
              </AlertDescription>
            </Alert>

            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="p-4 bg-blue-50 rounded-xl text-center">
                <Zap className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <p className="font-semibold text-slate-900">Quick Test</p>
                <p className="text-xs text-slate-600">{questions.length} questions</p>
              </div>
              <div className="p-4 bg-purple-50 rounded-xl text-center">
                <Brain className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                <p className="font-semibold text-slate-900">Multiple Areas</p>
                <p className="text-xs text-slate-600">Logic, Math, Patterns</p>
              </div>
              <div className="p-4 bg-indigo-50 rounded-xl text-center">
                <Clock className="w-8 h-8 text-indigo-600 mx-auto mb-2" />
                <p className="font-semibold text-slate-900">No Time Limit</p>
                <p className="text-xs text-slate-600">Take your time</p>
              </div>
              <div className="p-4 bg-pink-50 rounded-xl text-center">
                <Trophy className="w-8 h-8 text-pink-600 mx-auto mb-2" />
                <p className="font-semibold text-slate-900">Get Results</p>
                <p className="text-xs text-slate-600">Instant feedback</p>
              </div>
            </div>

            <Button 
              onClick={() => setShowStart(false)}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-6 text-lg shadow-lg"
            >
              Start Challenge
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (result) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-indigo-50 p-6 flex items-center justify-center">
        <Card className="max-w-2xl w-full border-none shadow-2xl">
          <CardContent className="p-12">
            <div className="text-center mb-8">
              <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
              <h2 className="text-3xl font-bold mb-4">Test Complete!</h2>
              
              <div className={`inline-block px-8 py-4 bg-gradient-to-r ${result.range.color} text-white rounded-2xl shadow-lg mb-4`}>
                <p className="text-5xl font-bold mb-2">{result.correct}/{result.total}</p>
                <p className="text-lg">Correct Answers</p>
              </div>

              <div className="my-6 p-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl">
                <p className="text-sm text-slate-600 mb-2">Estimated IQ Range</p>
                <p className="text-4xl font-bold text-slate-900 mb-2">{result.estimatedIQ}</p>
                <p className="text-xl font-semibold text-slate-700">{result.range.label}</p>
                <p className="text-slate-600 mt-2">{result.range.desc}</p>
              </div>

              <Alert className="mb-6 border-2 border-blue-200 bg-blue-50 text-left">
                <AlertCircle className="h-5 w-5 text-blue-600" />
                <AlertDescription className="text-blue-900">
                  Remember: This is an unofficial, fun test. Official IQ tests are administered by professionals.
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-2 gap-4 mb-6">
                {questions.map((q, idx) => (
                  <div 
                    key={idx}
                    className={`p-3 rounded-xl ${
                      answers[idx] === q.correct_answer 
                        ? 'bg-green-100 border-2 border-green-500' 
                        : 'bg-red-100 border-2 border-red-500'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      {answers[idx] === q.correct_answer ? (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-red-600" />
                      )}
                      <p className="text-sm font-semibold">Q{idx + 1}: {q.question_type}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <Button 
              onClick={restart}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Take Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const question = questions[currentQuestion];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-indigo-50 p-6 flex items-center justify-center">
      <Card className="max-w-2xl w-full border-none shadow-2xl">
        <CardHeader>
          <div className="flex items-center justify-between mb-4">
            <Badge className="bg-blue-100 text-blue-700">
              Question {currentQuestion + 1} of {questions.length}
            </Badge>
            <Badge variant="outline" className="text-sm">
              {question.question_type}
            </Badge>
          </div>
          <Progress value={progress} className="h-2 mb-6" />
          <CardTitle className="text-2xl leading-relaxed">{question.question}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {question.options.map((option, idx) => (
            <button
              key={idx}
              onClick={() => handleAnswer(idx)}
              disabled={selectedAnswer !== null}
              className={`w-full p-5 bg-white border-2 rounded-2xl transition-all text-left ${
                selectedAnswer === idx
                  ? 'border-blue-500 bg-blue-50 shadow-lg scale-105'
                  : 'border-slate-200 hover:border-blue-400 hover:shadow-md'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full flex items-center justify-center font-bold text-blue-700">
                  {String.fromCharCode(65 + idx)}
                </div>
                <p className="text-lg font-medium text-slate-900">{option}</p>
              </div>
            </button>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}