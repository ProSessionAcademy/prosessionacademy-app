import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Briefcase,
  Target,
  Zap,
  Users,
  Palette,
  Bell,
  Bot,
  ChevronRight,
  Sparkles,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const STEPS = [
  { id: 1, title: 'Your Role', icon: Briefcase },
  { id: 2, title: 'Work Goals', icon: Target },
  { id: 3, title: 'Working Style', icon: Zap },
  { id: 4, title: 'Collaboration', icon: Users },
  { id: 5, title: 'Workspace Theme', icon: Palette },
  { id: 6, title: 'Notifications', icon: Bell },
  { id: 7, title: 'AI Assistant', icon: Bot }
];

const WORK_GOALS = [
  'Productivity', 'Organization', 'Team Management',
  'Sales Growth', 'Client Relations', 'Creativity', 'Data Insights'
];

const TOOLS = [
  'Google Suite', 'Microsoft Office', 'Notion', 'Slack',
  'Trello', 'Asana', 'Drive', 'CRM'
];

const THEMES = [
  { value: 'minimal_zen', label: 'Minimal Zen', color: 'from-slate-400 to-slate-600', desc: 'Clean & focused' },
  { value: 'dynamic_visual', label: 'Dynamic & Visual', color: 'from-blue-500 to-purple-600', desc: 'Colorful & engaging' },
  { value: 'dark_executive', label: 'Dark Executive', color: 'from-slate-800 to-slate-900', desc: 'Professional & sleek' },
  { value: 'vibrant_energetic', label: 'Vibrant Energetic', color: 'from-orange-500 to-pink-600', desc: 'Bold & inspiring' }
];

const AI_PERSONALITIES = [
  { value: 'calm_professional', label: 'Calm Professional', emoji: '🧘', desc: 'Measured and thoughtful' },
  { value: 'energetic_motivator', label: 'Energetic Motivator', emoji: '⚡', desc: 'Enthusiastic and inspiring' },
  { value: 'data_analyst', label: 'Data-Driven Analyst', emoji: '📊', desc: 'Analytical and precise' },
  { value: 'friendly_coworker', label: 'Friendly Co-worker', emoji: '😊', desc: 'Warm and supportive' }
];

export default function ProfessionalOnboarding() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [config, setConfig] = useState({
    profession: '',
    industry: '',
    work_goals: [],
    working_style: 50,
    tool_familiarity: [],
    collaboration_level: 'solo',
    information_type: 'documents',
    theme: 'dynamic_visual',
    notification_mode: 'realtime',
    ai_personality: 'calm_professional',
    enabled_modules: ['home', 'tasks', 'documents', 'analytics', 'ai_studio']
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error('Error:', error);
        navigate(createPageUrl('Dashboard'));
      }
    };
    fetchUser();
  }, [navigate]);

  const saveConfigMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.WorkspaceConfig.create({
        ...data,
        user_email: user.email,
        onboarding_completed: true
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workspaceConfig'] });
      navigate(createPageUrl('ProfessionalSpace'));
    }
  });

  const handleNext = () => {
    if (currentStep < STEPS.length) {
      setCurrentStep(currentStep + 1);
    } else {
      saveConfigMutation.mutate(config);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const toggleGoal = (goal) => {
    const current = config.work_goals;
    if (current.includes(goal)) {
      setConfig({ ...config, work_goals: current.filter(g => g !== goal) });
    } else if (current.length < 3) {
      setConfig({ ...config, work_goals: [...current, goal] });
    }
  };

  const toggleTool = (tool) => {
    const current = config.tool_familiarity;
    if (current.includes(tool)) {
      setConfig({ ...config, tool_familiarity: current.filter(t => t !== tool) });
    } else {
      setConfig({ ...config, tool_familiarity: [...current, tool] });
    }
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return config.profession.trim().length > 0;
      case 2:
        return config.work_goals.length === 3;
      default:
        return true;
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-white animate-spin" />
      </div>
    );
  }

  const progress = (currentStep / STEPS.length) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center shadow-2xl">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-black text-white mb-2">
            Welcome to Your Professional Space
          </h1>
          <p className="text-xl text-blue-200">
            Let's build your work universe together
          </p>
        </motion.div>

        {/* Progress */}
        <div className="mb-8">
          <Progress value={progress} className="h-2 mb-4" />
          <div className="flex justify-between">
            {STEPS.map((step, idx) => {
              const Icon = step.icon;
              const isActive = currentStep === step.id;
              const isCompleted = currentStep > step.id;
              
              return (
                <div key={step.id} className="flex flex-col items-center">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                    isCompleted ? 'bg-green-600' :
                    isActive ? 'bg-blue-600 scale-110' :
                    'bg-white/20'
                  }`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <p className="text-xs text-white/80 mt-2 hidden md:block">{step.title}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Steps Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="border-none shadow-2xl bg-white/95 backdrop-blur-xl">
              <CardContent className="p-8 md:p-12">
                {/* Step 1: Role */}
                {currentStep === 1 && (
                  <div className="space-y-6">
                    <div className="text-center mb-8">
                      <Briefcase className="w-16 h-16 text-blue-600 mx-auto mb-4" />
                      <h2 className="text-3xl font-bold text-slate-900 mb-2">
                        What's your profession?
                      </h2>
                      <p className="text-slate-600">This helps us customize your workspace</p>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        Job Title / Role
                      </label>
                      <Input
                        value={config.profession}
                        onChange={(e) => setConfig({ ...config, profession: e.target.value })}
                        placeholder="e.g., Product Manager, Sales Director, CEO..."
                        className="text-lg h-14"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        Industry / Sector
                      </label>
                      <Input
                        value={config.industry}
                        onChange={(e) => setConfig({ ...config, industry: e.target.value })}
                        placeholder="e.g., Technology, Finance, Healthcare..."
                        className="text-lg h-14"
                      />
                    </div>
                  </div>
                )}

                {/* Step 2: Goals */}
                {currentStep === 2 && (
                  <div className="space-y-6">
                    <div className="text-center mb-8">
                      <Target className="w-16 h-16 text-purple-600 mx-auto mb-4" />
                      <h2 className="text-3xl font-bold text-slate-900 mb-2">
                        Pick your top 3 work goals
                      </h2>
                      <p className="text-slate-600">
                        Selected: {config.work_goals.length}/3
                      </p>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      {WORK_GOALS.map(goal => (
                        <motion.button
                          key={goal}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => toggleGoal(goal)}
                          className={`p-6 rounded-xl border-2 transition-all text-left ${
                            config.work_goals.includes(goal)
                              ? 'border-purple-600 bg-purple-50 shadow-lg'
                              : 'border-slate-200 hover:border-purple-300'
                          }`}
                        >
                          <h4 className="font-bold text-slate-900 text-lg">{goal}</h4>
                        </motion.button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Step 3: Working Style */}
                {currentStep === 3 && (
                  <div className="space-y-6">
                    <div className="text-center mb-8">
                      <Zap className="w-16 h-16 text-yellow-600 mx-auto mb-4" />
                      <h2 className="text-3xl font-bold text-slate-900 mb-2">
                        What's your working style?
                      </h2>
                    </div>
                    
                    <div className="space-y-8">
                      <div>
                        <div className="flex justify-between mb-4">
                          <span className="text-sm font-semibold text-slate-700">
                            Structured Planner
                          </span>
                          <span className="text-2xl font-bold text-blue-600">
                            {config.working_style}
                          </span>
                          <span className="text-sm font-semibold text-slate-700">
                            Adaptive Thinker
                          </span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={config.working_style}
                          onChange={(e) => setConfig({ ...config, working_style: Number(e.target.value) })}
                          className="w-full h-4 bg-gradient-to-r from-blue-400 to-purple-400 rounded-lg appearance-none cursor-pointer"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-3">
                          Tools you're familiar with
                        </label>
                        <div className="flex gap-2 flex-wrap">
                          {TOOLS.map(tool => (
                            <Button
                              key={tool}
                              onClick={() => toggleTool(tool)}
                              variant={config.tool_familiarity.includes(tool) ? "default" : "outline"}
                              size="sm"
                            >
                              {tool}
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Step 4: Collaboration */}
                {currentStep === 4 && (
                  <div className="space-y-6">
                    <div className="text-center mb-8">
                      <Users className="w-16 h-16 text-green-600 mx-auto mb-4" />
                      <h2 className="text-3xl font-bold text-slate-900 mb-2">
                        Collaboration level
                      </h2>
                    </div>
                    
                    <div className="grid gap-4">
                      {[
                        { value: 'solo', label: 'Solo', desc: 'I work independently' },
                        { value: 'small_team', label: 'Small Team', desc: '2-10 people' },
                        { value: 'department', label: 'Department', desc: '10+ people' }
                      ].map(option => (
                        <button
                          key={option.value}
                          onClick={() => setConfig({ ...config, collaboration_level: option.value })}
                          className={`p-6 rounded-xl border-2 transition-all text-left ${
                            config.collaboration_level === option.value
                              ? 'border-green-600 bg-green-50 shadow-lg'
                              : 'border-slate-200 hover:border-green-300'
                          }`}
                        >
                          <h4 className="font-bold text-slate-900 text-lg mb-1">{option.label}</h4>
                          <p className="text-sm text-slate-600">{option.desc}</p>
                        </button>
                      ))}
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-3">
                        Primary information type
                      </label>
                      <div className="grid grid-cols-2 gap-3">
                        {[
                          { value: 'documents', label: 'Documents' },
                          { value: 'numbers', label: 'Numbers' },
                          { value: 'people', label: 'People' },
                          { value: 'projects', label: 'Projects' }
                        ].map(type => (
                          <Button
                            key={type.value}
                            onClick={() => setConfig({ ...config, information_type: type.value })}
                            variant={config.information_type === type.value ? "default" : "outline"}
                          >
                            {type.label}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Step 5: Theme */}
                {currentStep === 5 && (
                  <div className="space-y-6">
                    <div className="text-center mb-8">
                      <Palette className="w-16 h-16 text-pink-600 mx-auto mb-4" />
                      <h2 className="text-3xl font-bold text-slate-900 mb-2">
                        Choose your workspace aesthetic
                      </h2>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      {THEMES.map(theme => (
                        <motion.button
                          key={theme.value}
                          whileHover={{ scale: 1.02 }}
                          onClick={() => setConfig({ ...config, theme: theme.value })}
                          className={`p-6 rounded-xl border-2 transition-all overflow-hidden ${
                            config.theme === theme.value
                              ? 'border-blue-600 shadow-xl'
                              : 'border-slate-200'
                          }`}
                        >
                          <div className={`h-24 rounded-lg bg-gradient-to-br ${theme.color} mb-4`} />
                          <h4 className="font-bold text-slate-900 text-lg mb-1">{theme.label}</h4>
                          <p className="text-sm text-slate-600">{theme.desc}</p>
                        </motion.button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Step 6: Notifications */}
                {currentStep === 6 && (
                  <div className="space-y-6">
                    <div className="text-center mb-8">
                      <Bell className="w-16 h-16 text-orange-600 mx-auto mb-4" />
                      <h2 className="text-3xl font-bold text-slate-900 mb-2">
                        Notification preferences
                      </h2>
                    </div>
                    
                    <div className="grid gap-4">
                      {[
                        { value: 'silent', label: 'Silent Mode', desc: 'AI summarizes everything later', icon: '🔇' },
                        { value: 'realtime', label: 'Real-time Alerts', desc: 'Get notified immediately', icon: '🔔' }
                      ].map(option => (
                        <button
                          key={option.value}
                          onClick={() => setConfig({ ...config, notification_mode: option.value })}
                          className={`p-6 rounded-xl border-2 transition-all text-left ${
                            config.notification_mode === option.value
                              ? 'border-orange-600 bg-orange-50 shadow-lg'
                              : 'border-slate-200 hover:border-orange-300'
                          }`}
                        >
                          <div className="text-3xl mb-2">{option.icon}</div>
                          <h4 className="font-bold text-slate-900 text-lg mb-1">{option.label}</h4>
                          <p className="text-sm text-slate-600">{option.desc}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Step 7: AI Personality */}
                {currentStep === 7 && (
                  <div className="space-y-6">
                    <div className="text-center mb-8">
                      <Bot className="w-16 h-16 text-blue-600 mx-auto mb-4" />
                      <h2 className="text-3xl font-bold text-slate-900 mb-2">
                        Choose your AI assistant personality
                      </h2>
                      <p className="text-slate-600">How should your AI companion interact with you?</p>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      {AI_PERSONALITIES.map(personality => (
                        <motion.button
                          key={personality.value}
                          whileHover={{ scale: 1.02 }}
                          onClick={() => setConfig({ ...config, ai_personality: personality.value })}
                          className={`p-6 rounded-xl border-2 transition-all text-left ${
                            config.ai_personality === personality.value
                              ? 'border-blue-600 bg-blue-50 shadow-lg'
                              : 'border-slate-200 hover:border-blue-300'
                          }`}
                        >
                          <div className="text-4xl mb-3">{personality.emoji}</div>
                          <h4 className="font-bold text-slate-900 text-lg mb-1">{personality.label}</h4>
                          <p className="text-sm text-slate-600">{personality.desc}</p>
                        </motion.button>
                      ))}
                    </div>

                    <div className="mt-8 p-6 bg-green-50 border-2 border-green-200 rounded-xl">
                      <Sparkles className="w-8 h-8 text-green-600 mb-3" />
                      <h3 className="font-bold text-green-900 text-xl mb-2">
                        You're all set! 🎉
                      </h3>
                      <p className="text-green-800">
                        Your personalized Professional Space is ready. Click Complete to enter your workspace.
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex justify-between mt-6">
          <Button
            onClick={handleBack}
            variant="outline"
            disabled={currentStep === 1}
            className="bg-white"
            size="lg"
          >
            Back
          </Button>
          <Button
            onClick={handleNext}
            disabled={!canProceed() || saveConfigMutation.isPending}
            className="bg-gradient-to-r from-blue-600 to-purple-600"
            size="lg"
          >
            {saveConfigMutation.isPending ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : currentStep === STEPS.length ? (
              <>
                Complete Setup
                <Sparkles className="w-5 h-5 ml-2" />
              </>
            ) : (
              <>
                Next
                <ChevronRight className="w-5 h-5 ml-2" />
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}