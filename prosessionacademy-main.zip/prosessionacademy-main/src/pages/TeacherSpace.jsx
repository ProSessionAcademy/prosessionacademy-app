
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  GraduationCap,
  BookOpen,
  FileText,
  Upload,
  Users,
  Award,
  Sparkles,
  Brain,
  FileUp,
  CheckCircle,
  Clock,
  Loader2,
  Edit,
  Save,
  Building2,
  FileCheck,
  Trash2
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function TeacherSpace() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [teacherProfile, setTeacherProfile] = useState(null);
  const [showProfileDialog, setShowProfileDialog] = useState(false);
  const [showDocumentDialog, setShowDocumentDialog] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);

  const [profileForm, setProfileForm] = useState({
    title: "",
    specialization: "",
    bio: "",
    subjects: "",
    profile_picture: "",
    office_hours: ""
  });

  const [documentForm, setDocumentForm] = useState({
    title: "",
    description: "",
    file_url: "",
    type: "course_material",
    target_groups: [],
    target_student_space: false
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);

        // Fetch teacher profile
        const teachers = await base44.entities.Teacher.filter({ user_email: currentUser.email });
        if (teachers.length > 0) {
          setTeacherProfile(teachers[0]);
          setProfileForm({
            title: teachers[0].title || "",
            specialization: teachers[0].specialization || "",
            bio: teachers[0].bio || "",
            subjects: teachers[0].subjects?.join(", ") || "",
            profile_picture: teachers[0].profile_picture || "",
            office_hours: teachers[0].office_hours || ""
          });
        }

        setLoading(false);
      } catch (error) {
        console.error("Error:", error);
        setLoading(false);
      }
    };
    fetchUser();
  }, []);

  const { data: groups = [] } = useQuery({
    queryKey: ['groups'],
    queryFn: async () => {
      const allGroups = await base44.entities.Group.list();
      // Filter to groups where user is a member
      return allGroups.filter(g =>
        g.members?.some(m => m.user_email === user?.email)
      );
    },
    enabled: !!user,
    initialData: []
  });

  const { data: myCourses = [] } = useQuery({
    queryKey: ['myCourses', user?.email],
    queryFn: async () => {
      const allCourses = await base44.entities.Course.list();
      return allCourses.filter(c => c.instructor === user?.full_name || c.created_by === user?.email);
    },
    enabled: !!user,
    initialData: []
  });

  const { data: myDocuments = [] } = useQuery({
    queryKey: ['myDocuments', user?.email],
    queryFn: async () => {
      const allResources = await base44.entities.Resource.list();
      return allResources.filter(r => r.created_by === user?.email);
    },
    enabled: !!user,
    initialData: []
  });

  const updateTeacherMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Teacher.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['teachers'] });
      setShowProfileDialog(false);
      alert("✅ Profile updated!");
    },
  });

  const createTeacherMutation = useMutation({
    mutationFn: (data) => base44.entities.Teacher.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['teachers'] });
      setShowProfileDialog(false);
      alert("✅ Profile created! Waiting for admin approval.");
    },
  });

  const createResourceMutation = useMutation({
    mutationFn: (data) => base44.entities.Resource.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myDocuments'] });
      setShowDocumentDialog(false);
      setDocumentForm({
        title: "",
        description: "",
        file_url: "",
        type: "course_material",
        target_groups: [],
        target_student_space: false
      });
      alert("✅ Document uploaded successfully!");
    },
  });

  const handleSaveProfile = () => {
    if (!profileForm.title || !profileForm.specialization) {
      alert("⚠️ Please fill in at least Title and Specialization");
      return;
    }

    const data = {
      title: profileForm.title,
      specialization: profileForm.specialization,
      bio: profileForm.bio,
      subjects: profileForm.subjects.split(',').map(s => s.trim()).filter(Boolean),
      profile_picture: profileForm.profile_picture,
      office_hours: profileForm.office_hours,
      user_email: user.email,
      full_name: user.full_name
    };

    if (teacherProfile) {
      updateTeacherMutation.mutate({ id: teacherProfile.id, data });
    } else {
      // Add group_id if user is part of any group
      if (groups.length > 0) {
        data.group_id = groups[0].id;
      }

      createTeacherMutation.mutate({
        ...data,
        status: "pending"
      });
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      setDocumentForm({ ...documentForm, file_url: response.file_url });
      alert("✅ File uploaded!");
    } catch (error) {
      alert("❌ Upload failed: " + error.message);
    } finally {
      setUploading(false);
      event.target.value = '';
    }
  };

  const handleProfilePictureUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      setProfileForm({ ...profileForm, profile_picture: response.file_url });
      alert("✅ Profile picture uploaded!");
    } catch (error) {
      alert("❌ Upload failed: " + error.message);
    } finally {
      setUploading(false);
      event.target.value = '';
    }
  };

  const handleGenerateQuiz = async () => {
    if (!documentForm.file_url) {
      alert("Please upload a document first!");
      return;
    }

    setAiGenerating(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Based on this document, generate 10 multiple choice quiz questions in Dutch.

Format EXACTLY as JSON:
{
  "questions": [
    {
      "question": "Question text in Dutch",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correct_answer": 0
    }
  ]
}

Make questions test understanding, not just memorization. Include explanations.`,
        file_urls: [documentForm.file_url],
        response_json_schema: {
          type: "object",
          properties: {
            questions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  question: { type: "string" },
                  options: { type: "array", items: { type: "string" } },
                  correct_answer: { type: "number" }
                }
              }
            }
          }
        }
      });

      console.log("Generated quiz:", result);
      alert("✅ Quiz generated! Check console for questions (will be integrated into course creation soon)");
    } catch (error) {
      alert("❌ AI generation failed: " + error.message);
    } finally {
      setAiGenerating(false);
    }
  };

  const handleSummarizeDocument = async () => {
    if (!documentForm.file_url) {
      alert("Please upload a document first!");
      return;
    }

    setAiGenerating(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Create a comprehensive summary of this educational document in Dutch.

Format:
## Samenvatting

[2-3 paragraph overview]

## Kernpunten
• [Key point 1]
• [Key point 2]
• [Key point 3]

## Belangrijkste Concepten
[List and explain main concepts]

## Voor Studenten
[Study tips and what to focus on]`,
        file_urls: [documentForm.file_url]
      });

      console.log("Generated summary:", result);
      alert("✅ Summary generated! You can copy it from the console.");
    } catch (error) {
      alert("❌ AI generation failed: " + error.message);
    } finally {
      setAiGenerating(false);
    }
  };

  const handleUploadDocument = () => {
    if (!documentForm.title || !documentForm.file_url) {
      alert("Please fill in title and upload a file!");
      return;
    }

    createResourceMutation.mutate({
      title: documentForm.title,
      description: documentForm.description,
      file_url: documentForm.file_url,
      type: documentForm.type,
      category: "general",
      thumbnail_url: "",
      downloads: 0
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <>
      {/* Profile Dialog - MUST be outside conditional rendering */}
      <Dialog open={showProfileDialog} onOpenChange={setShowProfileDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Teacher Profile</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div>
              <Label>Profile Picture</Label>
              <div className="flex items-center gap-4 mt-2">
                {profileForm.profile_picture && (
                  <img src={profileForm.profile_picture} alt="Profile" className="w-24 h-24 rounded-full object-cover" />
                )}
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleProfilePictureUpload}
                  className="hidden"
                  id="profile-pic-upload"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => document.getElementById('profile-pic-upload').click()}
                  disabled={uploading}
                >
                  {uploading ? "Uploading..." : "Upload Picture"}
                </Button>
              </div>
            </div>

            <div>
              <Label>Title (Dr./Prof./Mr./Ms.) *</Label>
              <Input
                value={profileForm.title}
                onChange={(e) => setProfileForm({ ...profileForm, title: e.target.value })}
                placeholder="e.g., Dr., Professor"
              />
            </div>

            <div>
              <Label>Specialization *</Label>
              <Input
                value={profileForm.specialization}
                onChange={(e) => setProfileForm({ ...profileForm, specialization: e.target.value })}
                placeholder="e.g., Mathematics, Computer Science"
              />
            </div>

            <div>
              <Label>Subjects (comma separated)</Label>
              <Input
                value={profileForm.subjects}
                onChange={(e) => setProfileForm({ ...profileForm, subjects: e.target.value })}
                placeholder="e.g., Calculus, Linear Algebra, Statistics"
              />
            </div>

            <div>
              <Label>Bio</Label>
              <Textarea
                value={profileForm.bio}
                onChange={(e) => setProfileForm({ ...profileForm, bio: e.target.value })}
                placeholder="Tell students about yourself..."
                rows={4}
              />
            </div>

            <div>
              <Label>Office Hours</Label>
              <Input
                value={profileForm.office_hours}
                onChange={(e) => setProfileForm({ ...profileForm, office_hours: e.target.value })}
                placeholder="e.g., Monday & Wednesday 2-4 PM"
              />
            </div>

            <Button
              onClick={handleSaveProfile}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600"
              size="lg"
            >
              <Save className="w-5 h-5 mr-2" />
              Save Profile
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Document Upload Dialog */}
      <Dialog open={showDocumentDialog} onOpenChange={setShowDocumentDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Upload Document</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div>
              <Label>Title</Label>
              <Input
                value={documentForm.title}
                onChange={(e) => setDocumentForm({ ...documentForm, title: e.target.value })}
                placeholder="Document title"
              />
            </div>

            <div>
              <Label>Description</Label>
              <Textarea
                value={documentForm.description}
                onChange={(e) => setDocumentForm({ ...documentForm, description: e.target.value })}
                placeholder="What is this document about?"
                rows={3}
              />
            </div>

            <div>
              <Label>Document Type</Label>
              <Select
                value={documentForm.type}
                onValueChange={(value) => setDocumentForm({ ...documentForm, type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="course_material">Course Material</SelectItem>
                  <SelectItem value="assignment">Assignment</SelectItem>
                  <SelectItem value="study_guide">Study Guide</SelectItem>
                  <SelectItem value="reference">Reference Material</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Upload File</Label>
              <input
                type="file"
                onChange={handleFileUpload}
                className="hidden"
                id="doc-upload"
              />
              <Button
                type="button"
                variant="outline"
                className="w-full"
                onClick={() => document.getElementById('doc-upload').click()}
                disabled={uploading}
              >
                {uploading ? "Uploading..." : documentForm.file_url ? "✅ File Uploaded" : "Upload File"}
              </Button>
            </div>

            {documentForm.file_url && (
              <Card className="bg-blue-50 border-blue-200">
                <CardContent className="p-4">
                  <h4 className="font-bold mb-3">AI Tools</h4>
                  <div className="flex gap-2">
                    <Button
                      onClick={handleGenerateQuiz}
                      disabled={aiGenerating}
                      variant="outline"
                      size="sm"
                    >
                      {aiGenerating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Brain className="w-4 h-4 mr-2" />}
                      Generate Quiz
                    </Button>
                    <Button
                      onClick={handleSummarizeDocument}
                      disabled={aiGenerating}
                      variant="outline"
                      size="sm"
                    >
                      {aiGenerating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <FileText className="w-4 h-4 mr-2" />}
                      Summarize
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            <Button
              onClick={handleUploadDocument}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600"
              size="lg"
              disabled={!documentForm.title || !documentForm.file_url}
            >
              <Upload className="w-5 h-5 mr-2" />
              Upload Document
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Main Content */}
      {!teacherProfile || teacherProfile.status === "pending" ? (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 p-6 lg:p-8">
          <div className="max-w-4xl mx-auto">
            <Card className="border-none shadow-2xl">
              <CardContent className="p-12 text-center">
                <div className="w-24 h-24 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                  <GraduationCap className="w-12 h-12 text-white" />
                </div>

                {!teacherProfile ? (
                  <>
                    <h1 className="text-3xl font-bold mb-4">Welcome to Teacher Space</h1>
                    <p className="text-slate-600 mb-8">
                      Create your professional teacher profile to access all teaching tools and features.
                    </p>
                    <Button
                      onClick={() => setShowProfileDialog(true)}
                      className="bg-gradient-to-r from-blue-600 to-purple-600"
                      size="lg"
                    >
                      Create Teacher Profile
                    </Button>
                  </>
                ) : (
                  <>
                    <Clock className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
                    <h1 className="text-3xl font-bold mb-4">Profile Pending Approval</h1>
                    <p className="text-slate-600 mb-4">
                      Your teacher profile is waiting for admin approval. You'll be notified once approved!
                    </p>
                    <Badge className="bg-yellow-500 text-white">Status: Pending</Badge>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      ) : (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 p-6 lg:p-8">
          <div className="max-w-7xl mx-auto space-y-8">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold text-slate-900">Teacher Space</h1>
                <p className="text-slate-600 mt-2">Professional tools for educators</p>
              </div>
              <Button
                onClick={() => setShowProfileDialog(true)}
                variant="outline"
                size="lg"
              >
                <Edit className="w-5 h-5 mr-2" />
                Edit Profile
              </Button>
            </div>

            {/* Teacher Profile Card */}
            <Card className="border-none shadow-xl bg-gradient-to-r from-blue-50 to-purple-50">
              <CardContent className="p-8">
                <div className="flex items-start gap-6">
                  {profileForm.profile_picture ? (
                    <img
                      src={profileForm.profile_picture}
                      alt="Profile"
                      className="w-32 h-32 rounded-full object-cover border-4 border-white shadow-xl"
                    />
                  ) : (
                    <div className="w-32 h-32 rounded-full bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center text-white text-4xl font-bold shadow-xl">
                      {user?.full_name?.charAt(0)}
                    </div>
                  )}
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div>
                        <h2 className="text-3xl font-bold text-slate-900">
                          {teacherProfile.title} {user?.full_name}
                        </h2>
                        <p className="text-xl text-slate-600 mt-1">{teacherProfile.specialization}</p>
                      </div>
                      <Badge className="bg-green-500 text-white">
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Approved
                      </Badge>
                    </div>

                    {teacherProfile.bio && (
                      <p className="text-slate-700 mt-4 leading-relaxed">{teacherProfile.bio}</p>
                    )}

                    <div className="flex gap-4 mt-6 flex-wrap">
                      {teacherProfile.subjects?.map((subject, idx) => (
                        <Badge key={idx} variant="outline" className="text-base px-4 py-2">
                          {subject}
                        </Badge>
                      ))}
                    </div>

                    {teacherProfile.office_hours && (
                      <div className="mt-4 flex items-center gap-2 text-slate-600">
                        <Clock className="w-5 h-5" />
                        <span>Office Hours: {teacherProfile.office_hours}</span>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Main Content Tabs */}
            <Tabs defaultValue="courses" className="w-full">
              <TabsList className="grid w-full grid-cols-4 h-auto p-2">
                <TabsTrigger value="courses" className="text-base py-3">
                  <BookOpen className="w-5 h-5 mr-2" />
                  My Courses
                </TabsTrigger>
                <TabsTrigger value="documents" className="text-base py-3">
                  <FileText className="w-5 h-5 mr-2" />
                  Documents
                </TabsTrigger>
                <TabsTrigger value="ai-tools" className="text-base py-3">
                  <Brain className="w-5 h-5 mr-2" />
                  AI Tools
                </TabsTrigger>
                <TabsTrigger value="groups" className="text-base py-3">
                  <Users className="w-5 h-5 mr-2" />
                  My Groups
                </TabsTrigger>
              </TabsList>

              {/* Courses Tab */}
              <TabsContent value="courses" className="space-y-6 mt-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold">My Courses ({myCourses.length})</h3>
                  <Link to={createPageUrl("CourseAdmin")}>
                    <Button className="bg-gradient-to-r from-green-600 to-emerald-600">
                      <BookOpen className="w-5 h-5 mr-2" />
                      Create New Course
                    </Button>
                  </Link>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {myCourses.map((course) => (
                    <Card key={course.id} className="border-none shadow-lg hover:shadow-xl transition-all">
                      {course.thumbnail_url && (
                        <img src={course.thumbnail_url} alt={course.title} className="w-full h-40 object-cover" />
                      )}
                      <CardContent className="p-6">
                        <h4 className="font-bold text-lg mb-2">{course.title}</h4>
                        <p className="text-sm text-slate-600 mb-4 line-clamp-2">{course.description}</p>
                        <div className="flex gap-2 flex-wrap mb-4">
                          <Badge>{course.level}</Badge>
                          <Badge variant="outline">{course.category}</Badge>
                          {course.is_group_course && <Badge className="bg-blue-600">Group Course</Badge>}
                        </div>
                        <Link to={createPageUrl("CourseAdmin")}>
                          <Button className="w-full" variant="outline">
                            Manage Course
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>
                  ))}

                  {myCourses.length === 0 && (
                    <Card className="border-none shadow-lg col-span-full">
                      <CardContent className="p-12 text-center">
                        <BookOpen className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                        <p className="text-slate-500 mb-4">No courses yet. Create your first course!</p>
                        <Link to={createPageUrl("CourseAdmin")}>
                          <Button className="bg-gradient-to-r from-blue-600 to-purple-600">
                            Create First Course
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </TabsContent>

              {/* Documents Tab */}
              <TabsContent value="documents" className="space-y-6 mt-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold">My Documents ({myDocuments.length})</h3>
                  <Button
                    onClick={() => setShowDocumentDialog(true)}
                    className="bg-gradient-to-r from-blue-600 to-purple-600"
                  >
                    <Upload className="w-5 h-5 mr-2" />
                    Upload Document
                  </Button>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {myDocuments.map((doc) => (
                    <Card key={doc.id} className="border-none shadow-lg">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <FileCheck className="w-12 h-12 text-blue-600" />
                          <Badge>{doc.type}</Badge>
                        </div>
                        <h4 className="font-bold text-lg mb-2">{doc.title}</h4>
                        <p className="text-sm text-slate-600 mb-4">{doc.description}</p>
                        <Button className="w-full" variant="outline" asChild>
                          <a href={doc.file_url} target="_blank" rel="noopener noreferrer">
                            View Document
                          </a>
                        </Button>
                      </CardContent>
                    </Card>
                  ))}

                  {myDocuments.length === 0 && (
                    <Card className="border-none shadow-lg col-span-full">
                      <CardContent className="p-12 text-center">
                        <FileText className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                        <p className="text-slate-500">No documents uploaded yet.</p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </TabsContent>

              {/* AI Tools Tab */}
              <TabsContent value="ai-tools" className="space-y-6 mt-6">
                <h3 className="text-2xl font-bold">AI Teaching Assistant</h3>

                <div className="grid md:grid-cols-2 gap-6">
                  <Card className="border-none shadow-xl bg-gradient-to-br from-green-50 to-emerald-50">
                    <CardContent className="p-8">
                      <div className="w-16 h-16 bg-gradient-to-br from-green-600 to-emerald-600 rounded-2xl flex items-center justify-center mb-6">
                        <Sparkles className="w-8 h-8 text-white" />
                      </div>
                      <h4 className="text-2xl font-bold mb-3">Generate Quiz</h4>
                      <p className="text-slate-600 mb-6">
                        Upload a document and AI will automatically generate quiz questions for your students.
                      </p>
                      <Link to={createPageUrl("Summarizer")}>
                        <Button className="w-full bg-gradient-to-r from-green-600 to-emerald-600" size="lg">
                          Generate Quiz from Document
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>

                  <Card className="border-none shadow-xl bg-gradient-to-br from-blue-50 to-indigo-50">
                    <CardContent className="p-8">
                      <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center mb-6">
                        <FileText className="w-8 h-8 text-white" />
                      </div>
                      <h4 className="text-2xl font-bold mb-3">Summarize Documents</h4>
                      <p className="text-slate-600 mb-6">
                        AI-powered document summarization for creating study materials and course content.
                      </p>
                      <Link to={createPageUrl("Summarizer")}>
                        <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600" size="lg">
                          Open Document Summarizer
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>

                  <Card className="border-none shadow-xl bg-gradient-to-br from-purple-50 to-pink-50">
                    <CardContent className="p-8">
                      <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center mb-6">
                        <Brain className="w-8 h-8 text-white" />
                      </div>
                      <h4 className="text-2xl font-bold mb-3">AI Course Assistant</h4>
                      <p className="text-slate-600 mb-6">
                        Get help designing course structure, learning objectives, and assessment strategies.
                      </p>
                      <Link to={createPageUrl("AIChat")}>
                        <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600" size="lg">
                          Open AI Assistant
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>

                  <Card className="border-none shadow-xl bg-gradient-to-br from-orange-50 to-red-50">
                    <CardContent className="p-8">
                      <div className="w-16 h-16 bg-gradient-to-br from-orange-600 to-red-600 rounded-2xl flex items-center justify-center mb-6">
                        <Award className="w-8 h-8 text-white" />
                      </div>
                      <h4 className="text-2xl font-bold mb-3">Create Interactive Content</h4>
                      <p className="text-slate-600 mb-6">
                        Build engaging flip cards, quizzes, and interactive learning modules.
                      </p>
                      <Link to={createPageUrl("CourseAdmin")}>
                        <Button className="w-full bg-gradient-to-r from-orange-600 to-red-600" size="lg">
                          Course Builder
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Groups Tab */}
              <TabsContent value="groups" className="space-y-6 mt-6">
                <h3 className="text-2xl font-bold">My Groups ({groups.length})</h3>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {groups.map((group) => (
                    <Card key={group.id} className="border-none shadow-lg hover:shadow-xl transition-all">
                      <CardContent className="p-6">
                        <div className="flex items-center gap-4 mb-4">
                          {group.logo_url ? (
                            <img src={group.logo_url} alt={group.name} className="w-16 h-16 rounded-lg object-cover" />
                          ) : (
                            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                              <Building2 className="w-8 h-8 text-white" />
                            </div>
                          )}
                          <div className="flex-1">
                            <h4 className="font-bold text-lg">{group.name}</h4>
                            <Badge variant="outline">{group.group_type}</Badge>
                          </div>
                        </div>
                        <p className="text-sm text-slate-600 mb-4 line-clamp-2">{group.description}</p>
                        <Link to={`${createPageUrl("GroupDashboard")}?groupId=${group.id}`}>
                          <Button className="w-full" variant="outline">
                            Open Group
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>
                  ))}

                  {groups.length === 0 && (
                    <Card className="border-none shadow-lg col-span-full">
                      <CardContent className="p-12 text-center">
                        <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                        <p className="text-slate-500">You're not a member of any groups yet.</p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      )}
    </>
  );
}
