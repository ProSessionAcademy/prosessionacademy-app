
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea"; 
import {
  Gamepad2,
  Users,
  Trophy,
  CheckCircle,
  X as XIcon
} from "lucide-react";

export default function PsaOotPlay() {
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const gameCodeParam = urlParams.get('gameCode');

  const [gameCode, setGameCode] = useState(gameCodeParam || "");
  const [playerName, setPlayerName] = useState("");
  const [playerId, setPlayerId] = useState("");
  const [joined, setJoined] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState(null); // Can be index (number), text (string), or value (number)
  const [hasAnswered, setHasAnswered] = useState(false);

  const { data: game, refetch } = useQuery({
    queryKey: ['psaOotGamePlay', gameCode],
    queryFn: async () => {
      if (!gameCode) return null;
      const games = await base44.entities.PsaOotGame.filter({ game_code: gameCode });
      return games[0];
    },
    enabled: !!gameCode && joined,
    refetchInterval: 1000, // Poll every second for updates
  });

  const updateGameMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PsaOotGame.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['psaOotGamePlay'] });
    },
  });

  const joinGame = async () => {
    if (!playerName || !gameCode) {
      alert('⚠️ Please enter your name and game code!');
      return;
    }

    try {
      const games = await base44.entities.PsaOotGame.filter({ game_code: gameCode });
      const foundGame = games[0];

      if (!foundGame) {
        alert('❌ Game not found! Check the code.');
        return;
      }

      if (foundGame.status !== 'waiting') {
        alert('❌ This game has already started!');
        return;
      }

      const newPlayerId = Date.now().toString() + Math.random().toString(36).substr(2, 9);
      const updatedPlayers = [
        ...(foundGame.players || []),
        {
          player_id: newPlayerId,
          player_name: playerName,
          score: 0,
          answers: []
        }
      ];

      await base44.entities.PsaOotGame.update(foundGame.id, {
        players: updatedPlayers
      });

      setPlayerId(newPlayerId);
      setJoined(true);
    } catch (error) {
      alert('Error joining game: ' + error.message);
    }
  };

  const submitAnswer = async (answerIndex, answerText, answerValue) => {
    if (hasAnswered) return;

    // Set selected answer based on the type of input received
    setSelectedAnswer(answerIndex !== undefined ? answerIndex : (answerText !== undefined ? answerText : answerValue));
    setHasAnswered(true);

    const currentQuestion = game.questions[game.current_question];
    let isCorrect = false;
    
    // Check correctness based on question type
    if (currentQuestion.question_type === "multiple_choice" || 
        currentQuestion.question_type === "true_false" || 
        currentQuestion.question_type === "picture_choice") {
      isCorrect = answerIndex === currentQuestion.correct_answer;
    } else if (currentQuestion.question_type === "slider") {
      // Calculate diff for slider, handle potential null/undefined for answerValue
      const submittedValue = answerValue !== undefined ? answerValue : (currentQuestion.slider_min + currentQuestion.slider_max) / 2; // Default if not interacted
      const diff = Math.abs(submittedValue - currentQuestion.slider_correct);
      isCorrect = diff <= currentQuestion.slider_tolerance;
    } else if (currentQuestion.question_type === "open_ended") {
      const keywords = currentQuestion.correct_text.toLowerCase().split(',').map(k => k.trim()).filter(k => k); // Filter empty keywords
      const userAnswer = (answerText || "").toLowerCase();
      isCorrect = keywords.some(keyword => userAnswer.includes(keyword));
    }
    
    const pointsEarned = isCorrect ? currentQuestion.points : 0;

    const updatedPlayers = game.players.map(p => {
      if (p.player_id === playerId) {
        return {
          ...p,
          score: p.score + pointsEarned,
          answers: [
            ...(p.answers || []),
            {
              question_index: game.current_question,
              answer_index: answerIndex,
              answer_text: answerText,
              answer_value: answerValue,
              is_correct: isCorrect,
              time_taken: 0, // Placeholder, actual time_taken logic might be added later
              points_earned: pointsEarned
            }
          ]
        };
      }
      return p;
    });

    await updateGameMutation.mutateAsync({
      id: game.id,
      data: { players: updatedPlayers }
    });
  };

  useEffect(() => {
    if (game && game.current_question !== undefined) {
      // Reset answer state when question changes or on initial load for a new question
      const currentPlayer = game.players?.find(p => p.player_id === playerId);
      const answeredThisQuestion = currentPlayer?.answers?.some(
        a => a.question_index === game.current_question
      );
      setHasAnswered(answeredThisQuestion || false);
      setSelectedAnswer(null); // Reset the selected answer for the new question
    }
  }, [game?.current_question, playerId, game?.players]);

  // Join Screen
  if (!joined) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-pink-900 to-blue-900 text-white flex items-center justify-center p-6">
        <Card className="max-w-md w-full bg-white/10 backdrop-blur-xl border-none shadow-2xl">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <Gamepad2 className="w-20 h-20 mx-auto mb-4 text-yellow-400" />
              <h1 className="text-4xl font-bold mb-2">Join PSA-OOT</h1>
              <p className="text-white/80">Enter the game code to play!</p>
            </div>

            <div className="space-y-4">
              <div>
                <Input
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  placeholder="Your Name"
                  className="text-lg p-6 bg-white/20 border-white/30 text-white placeholder:text-white/50"
                />
              </div>
              <div>
                <Input
                  value={gameCode}
                  onChange={(e) => setGameCode(e.target.value.toUpperCase())}
                  placeholder="Game Code"
                  className="text-2xl p-6 bg-white/20 border-white/30 text-white placeholder:text-white/50 text-center font-mono"
                  maxLength={6}
                />
              </div>
              <Button
                onClick={joinGame}
                className="w-full bg-green-600 hover:bg-green-700 text-white py-6 text-xl"
              >
                Join Game
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!game) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-pink-900 to-blue-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-white"></div>
      </div>
    );
  }

  // Waiting Screen
  if (game.status === 'waiting') {
    const currentPlayer = game.players?.find(p => p.player_id === playerId);
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-pink-900 to-blue-900 text-white flex items-center justify-center p-6">
        <Card className="max-w-2xl w-full bg-white/10 backdrop-blur-xl border-none shadow-2xl">
          <CardContent className="p-12 text-center">
            <CheckCircle className="w-20 h-20 text-green-400 mx-auto mb-6" />
            <h1 className="text-5xl font-bold mb-4">You're In!</h1>
            <p className="text-3xl mb-2">{currentPlayer?.player_name}</p>
            <div className="flex items-center justify-center gap-3 text-xl text-white/80 mb-12">
              <Users className="w-6 h-6" />
              <span>{game.players?.length} players waiting</span>
            </div>
            <div className="animate-pulse">
              <p className="text-2xl">Waiting for host to start the game...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Game Active
  if (game.status === 'active') {
    const currentQuestion = game.questions[game.current_question];
    const currentPlayer = game.players?.find(p => p.player_id === playerId);

    // Initial default for slider if user hasn't touched it yet
    const initialSliderValue = Math.floor((currentQuestion?.slider_min + currentQuestion?.slider_max) / 2);


    if (hasAnswered) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-pink-900 text-white flex items-center justify-center p-6">
          <Card className="max-w-md w-full bg-white/10 backdrop-blur-xl border-none shadow-2xl">
            <CardContent className="p-12 text-center">
              <CheckCircle className="w-20 h-20 text-green-400 mx-auto mb-6" />
              <h2 className="text-4xl font-bold mb-4">Answer Submitted!</h2>
              <p className="text-2xl mb-8 text-white/80">Waiting for other players...</p>
              <div>
                <p className="text-lg text-white/60 mb-2">Your Score</p>
                <p className="text-6xl font-bold">{currentPlayer?.score || 0}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-pink-900 to-red-900 text-white p-6">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <Badge className="text-lg px-4 py-2 bg-white/20">
              Q{game.current_question + 1}/{game.questions.length}
            </Badge>
            <div className="text-center">
              <p className="text-sm text-white/80">Your Score</p>
              <p className="text-3xl font-bold">{currentPlayer?.score || 0}</p>
            </div>
          </div>

          <Card className="bg-white/10 backdrop-blur-xl border-none mb-8">
            <CardContent className="p-8 text-center">
              <p className="text-3xl font-bold">{currentQuestion?.question}</p>
            </CardContent>
          </Card>

          {/* Multiple Choice / True False */}
          {(currentQuestion?.question_type === "multiple_choice" || currentQuestion?.question_type === "true_false") && (
            <div className="grid grid-cols-1 gap-4">
              {currentQuestion?.options.map((option, idx) => (
                <button
                  key={idx}
                  onClick={() => submitAnswer(idx, undefined, undefined)}
                  className={`p-6 rounded-2xl text-2xl font-semibold transition-all ${
                    ['bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800',
                     'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800',
                     'bg-gradient-to-r from-yellow-600 to-yellow-700 hover:from-yellow-700 hover:to-yellow-800',
                     'bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800'][idx]
                  } shadow-xl hover:scale-105 active:scale-95`}
                >
                  <div className="flex items-center gap-4">
                    <span className="text-4xl">
                      {['🔴', '🔵', '🟡', '🟢'][idx]}
                    </span>
                    <span>{option}</span>
                  </div>
                </button>
              ))}
            </div>
          )}

          {/* Picture Choice */}
          {currentQuestion?.question_type === "picture_choice" && (
            <div className="grid grid-cols-2 gap-4">
              {currentQuestion?.picture_options?.map((picUrl, idx) => (
                <button
                  key={idx}
                  onClick={() => submitAnswer(idx, undefined, undefined)}
                  className="relative rounded-2xl overflow-hidden shadow-xl hover:scale-105 active:scale-95 transition-all"
                >
                  <img src={picUrl} alt={`Option ${idx}`} className="w-full h-48 object-cover" />
                  <div className="absolute top-3 left-3 w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-lg">
                    <span className="text-2xl font-bold text-purple-600">{String.fromCharCode(65 + idx)}</span>
                  </div>
                </button>
              ))}
            </div>
          )}

          {/* Slider */}
          {currentQuestion?.question_type === "slider" && (
            <Card className="bg-white/10 backdrop-blur-xl border-none">
              <CardContent className="p-8">
                <div className="space-y-6">
                  <div className="flex justify-between text-xl font-bold">
                    <span>{currentQuestion.slider_min}</span>
                    <span>{currentQuestion.slider_max}</span>
                  </div>
                  <input
                    type="range"
                    min={currentQuestion.slider_min}
                    max={currentQuestion.slider_max}
                    defaultValue={initialSliderValue}
                    onChange={(e) => setSelectedAnswer(parseInt(e.target.value))}
                    className="w-full h-4 bg-white/30 rounded-full appearance-none cursor-pointer"
                    style={{
                      background: `linear-gradient(to right, #8b5cf6 0%, #ec4899 100%)`
                    }}
                  />
                  <div className="text-center">
                    <p className="text-4xl font-bold mb-4">{selectedAnswer !== null ? selectedAnswer : initialSliderValue}</p>
                    <Button
                      onClick={() => submitAnswer(undefined, undefined, selectedAnswer !== null ? selectedAnswer : initialSliderValue)}
                      className="w-full bg-green-600 hover:bg-green-700 text-white py-6 text-xl"
                    >
                      Submit Answer
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Open Ended */}
          {currentQuestion?.question_type === "open_ended" && (
            <Card className="bg-white/10 backdrop-blur-xl border-none">
              <CardContent className="p-8">
                <Textarea
                  placeholder="Type your answer here..."
                  value={selectedAnswer || ""}
                  onChange={(e) => setSelectedAnswer(e.target.value)}
                  className="text-lg p-4 bg-white/20 border-white/30 text-white placeholder:text-white/50 min-h-32 mb-4"
                  rows={4}
                />
                <Button
                  onClick={() => submitAnswer(undefined, selectedAnswer || "", undefined)}
                  disabled={!selectedAnswer}
                  className="w-full bg-green-600 hover:bg-green-700 text-white py-6 text-xl"
                >
                  Submit Answer
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    );
  }

  // Game Completed
  if (game.status === 'completed') {
    const sortedPlayers = [...(game.players || [])].sort((a, b) => b.score - a.score);
    const currentPlayer = game.players?.find(p => p.player_id === playerId);
    const playerRank = sortedPlayers.findIndex(p => p.player_id === playerId) + 1;

    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-pink-900 to-blue-900 text-white p-6">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12">
            <Trophy className="w-24 h-24 text-yellow-400 mx-auto mb-6" />
            <h1 className="text-5xl font-bold mb-4">Game Over!</h1>
            <p className="text-3xl mb-2">You finished #{playerRank}</p>
            <p className="text-6xl font-bold text-yellow-400">{currentPlayer?.score} points</p>
          </div>

          <Card className="bg-white/10 backdrop-blur-xl border-none">
            <CardContent className="p-8">
              <h2 className="text-3xl font-bold mb-6 text-center">Final Rankings</h2>
              <div className="space-y-3">
                {sortedPlayers.slice(0, 10).map((player, idx) => (
                  <div
                    key={idx}
                    className={`p-4 rounded-xl flex items-center justify-between ${
                      player.player_id === playerId ? 'bg-blue-600' :
                      idx === 0 ? 'bg-gradient-to-r from-yellow-600 to-orange-600' :
                      'bg-white/20'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center font-bold text-xl">
                        {idx + 1}
                      </div>
                      <p className="text-xl font-semibold">{player.player_name}</p>
                    </div>
                    <p className="text-2xl font-bold">{player.score}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return null;
}
