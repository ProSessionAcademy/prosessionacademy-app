import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Video, Loader2 } from 'lucide-react';
import TwilioVideoRoom from '@/components/TwilioVideoRoom';

export default function TwilioVideoDemo() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [joined, setJoined] = useState(false);
  const [userName, setUserName] = useState('');

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const authenticated = await base44.auth.isAuthenticated();
        if (authenticated) {
          const currentUser = await base44.auth.me();
          setUser(currentUser);
          setUserName(currentUser.full_name || currentUser.email);
        }
      } catch (error) {
        console.error('Error:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchUser();
  }, []);

  const handleJoin = () => {
    if (!userName.trim()) {
      alert('Please enter your name');
      return;
    }
    setJoined(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-16 h-16 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-pink-900 flex items-center justify-center p-6">
        <Card className="max-w-md border-none shadow-2xl">
          <CardContent className="p-12 text-center">
            <Video className="w-24 h-24 text-white mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-white mb-4">Login Required</h2>
            <Button onClick={() => base44.auth.redirectToLogin()} size="lg" className="bg-blue-600">
              Sign In to Join
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (joined) {
    return <TwilioVideoRoom roomName="PSA" userName={userName} onLeave={() => setJoined(false)} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-pink-900 p-6 flex items-center justify-center">
      <Card className="max-w-xl w-full border-none shadow-2xl">
        <CardContent className="p-12">
          <div className="text-center mb-8">
            <Video className="w-24 h-24 text-blue-600 mx-auto mb-4" />
            <h1 className="text-4xl font-black mb-2">PSA Video Room</h1>
            <p className="text-slate-600">Group video call • Up to 25 participants</p>
          </div>

          <div className="space-y-6">
            <div>
              <Label className="text-lg font-bold mb-2 block">Your Display Name</Label>
              <Input
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="Enter your name"
                className="h-14 text-lg"
              />
            </div>

            <Card className="bg-blue-50 border-2 border-blue-300">
              <CardContent className="p-4">
                <h3 className="font-bold text-blue-900 mb-2">✅ Room Features:</h3>
                <ul className="space-y-1 text-blue-800 text-sm">
                  <li>• 720p HD video quality</li>
                  <li>• 15-20 fps smooth playback</li>
                  <li>• Up to 25 participants</li>
                  <li>• Optimized for group collaboration</li>
                  <li>• Works behind NAT/firewalls</li>
                </ul>
              </CardContent>
            </Card>

            <Button
              onClick={handleJoin}
              disabled={!userName.trim()}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 py-6 text-xl font-bold"
            >
              <Video className="w-6 h-6 mr-2" />
              Join PSA Room
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}