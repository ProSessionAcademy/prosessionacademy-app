import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Users,
  Edit,
  Search,
  Crown,
  Shield,
  Sparkles,
  Calendar,
  CheckCircle2
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";

export default function UserSubscriptionAdmin() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAssignDialog, setShowAssignDialog] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  
  const [assignForm, setAssignForm] = useState({
    subscription_plan_id: '',
    subscription_status: 'active',
    subscription_start_date: new Date().toISOString(),
    subscription_end_date: ''
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        setIsAdmin(currentUser.role === 'admin');
      } catch (error) {
        console.error('Error:', error);
      }
    };
    fetchUser();
  }, []);

  const { data: allUsers = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    enabled: isAdmin,
    initialData: []
  });

  const { data: plans = [] } = useQuery({
    queryKey: ['subscriptionPlans'],
    queryFn: () => base44.entities.SubscriptionPlan.list('display_order'),
    enabled: isAdmin,
    initialData: []
  });

  const updateUserMutation = useMutation({
    mutationFn: ({ userId, updates }) => base44.entities.User.update(userId, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allUsers'] });
      setShowAssignDialog(false);
      setSelectedUser(null);
    }
  });

  const handleAssignSubscription = () => {
    if (!assignForm.subscription_plan_id) {
      alert('Select a subscription plan');
      return;
    }

    const updates = {
      subscription_plan_id: assignForm.subscription_plan_id,
      subscription_status: assignForm.subscription_status,
      subscription_start_date: assignForm.subscription_start_date
    };

    if (assignForm.subscription_end_date) {
      updates.subscription_end_date = assignForm.subscription_end_date;
    }

    updateUserMutation.mutate({
      userId: selectedUser.id,
      updates
    });
  };

  const handleEditUser = (targetUser) => {
    setSelectedUser(targetUser);
    setAssignForm({
      subscription_plan_id: targetUser.subscription_plan_id || '',
      subscription_status: targetUser.subscription_status || 'free_trial',
      subscription_start_date: targetUser.subscription_start_date || new Date().toISOString(),
      subscription_end_date: targetUser.subscription_end_date || ''
    });
    setShowAssignDialog(true);
  };

  const filteredUsers = allUsers.filter(u => 
    u.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.full_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getPlanName = (planId) => {
    const plan = plans.find(p => p.id === planId);
    return plan?.plan_name || 'No Plan';
  };

  const getStatusBadge = (status) => {
    const styles = {
      free_trial: 'bg-green-500 text-white',
      active: 'bg-blue-600 text-white',
      premium: 'bg-gradient-to-r from-yellow-400 to-orange-500 text-white',
      cancelled: 'bg-red-500 text-white',
      expired: 'bg-slate-400 text-white'
    };
    return styles[status] || 'bg-slate-400 text-white';
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-pink-50 p-6 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-12 text-center">
            <Shield className="w-16 h-16 text-red-500 mx-auto mb-6" />
            <h3 className="text-2xl font-bold mb-2">Admin Only</h3>
            <p className="text-slate-600">This page is restricted to administrators.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <Card className="border-none shadow-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white">
          <CardContent className="p-8">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center">
                <Users className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-3xl font-black mb-1">👥 User Subscriptions Manager</h1>
                <p className="text-purple-100">Assign and manage user subscription plans</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <Users className="w-8 h-8 text-blue-600" />
                <div>
                  <p className="text-sm text-slate-600">Total Users</p>
                  <p className="text-3xl font-bold">{allUsers.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-8 h-8 text-green-600" />
                <div>
                  <p className="text-sm text-slate-600">Active Subs</p>
                  <p className="text-3xl font-bold">{allUsers.filter(u => u.subscription_status === 'active').length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <Sparkles className="w-8 h-8 text-yellow-600" />
                <div>
                  <p className="text-sm text-slate-600">Free Trials</p>
                  <p className="text-3xl font-bold">{allUsers.filter(u => u.subscription_status === 'free_trial').length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <Crown className="w-8 h-8 text-purple-600" />
                <div>
                  <p className="text-sm text-slate-600">Premium</p>
                  <p className="text-3xl font-bold">{allUsers.filter(u => u.subscription_status === 'premium').length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <Card className="border-none shadow-lg">
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search users by name or email..."
                className="pl-10 h-12"
              />
            </div>
          </CardContent>
        </Card>

        {/* Users Table */}
        <Card className="border-none shadow-xl">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 border-b-2">
            <CardTitle className="text-2xl">All Users ({filteredUsers.length})</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-100 border-b-2">
                  <tr>
                    <th className="text-left p-4 font-bold text-slate-700">User</th>
                    <th className="text-left p-4 font-bold text-slate-700">Email</th>
                    <th className="text-left p-4 font-bold text-slate-700">Current Plan</th>
                    <th className="text-left p-4 font-bold text-slate-700">Status</th>
                    <th className="text-left p-4 font-bold text-slate-700">Expires</th>
                    <th className="text-right p-4 font-bold text-slate-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map((targetUser) => (
                    <tr key={targetUser.id} className="border-b hover:bg-blue-50 transition-colors">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                            <span className="text-white font-bold">
                              {targetUser.full_name?.charAt(0) || targetUser.email?.charAt(0)}
                            </span>
                          </div>
                          <div>
                            <p className="font-semibold text-slate-900">{targetUser.full_name || 'N/A'}</p>
                            <p className="text-xs text-slate-500">ID: {targetUser.id?.slice(0, 8)}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-slate-700">{targetUser.email}</td>
                      <td className="p-4">
                        <Badge variant="outline" className="font-semibold">
                          {getPlanName(targetUser.subscription_plan_id)}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <Badge className={getStatusBadge(targetUser.subscription_status)}>
                          {targetUser.subscription_status || 'free_trial'}
                        </Badge>
                      </td>
                      <td className="p-4 text-slate-600 text-sm">
                        {targetUser.subscription_end_date 
                          ? format(new Date(targetUser.subscription_end_date), 'MMM dd, yyyy')
                          : targetUser.trial_end_date 
                            ? format(new Date(targetUser.trial_end_date), 'MMM dd, yyyy')
                            : 'N/A'
                        }
                      </td>
                      <td className="p-4 text-right">
                        <Button onClick={() => handleEditUser(targetUser)} size="sm" variant="outline">
                          <Edit className="w-4 h-4 mr-1" />
                          Assign Plan
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredUsers.length === 0 && (
              <div className="text-center p-12">
                <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">No users found.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Assign Subscription Dialog */}
        <Dialog open={showAssignDialog} onOpenChange={setShowAssignDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-2xl flex items-center gap-2">
                <Crown className="w-6 h-6 text-purple-600" />
                Assign Subscription Plan
              </DialogTitle>
            </DialogHeader>

            {selectedUser && (
              <div className="space-y-6">
                {/* User Info */}
                <Card className="bg-slate-50 border-2">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold text-lg">
                          {selectedUser.full_name?.charAt(0) || selectedUser.email?.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <p className="font-bold text-lg">{selectedUser.full_name || 'User'}</p>
                        <p className="text-sm text-slate-600">{selectedUser.email}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Plan Selection */}
                <div>
                  <Label className="text-base font-bold mb-2 block">Select Subscription Plan *</Label>
                  <Select 
                    value={assignForm.subscription_plan_id} 
                    onValueChange={(val) => setAssignForm({ ...assignForm, subscription_plan_id: val })}
                  >
                    <SelectTrigger className="h-12">
                      <SelectValue placeholder="Choose a plan..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>🚫 No Plan (Free Trial)</SelectItem>
                      {plans.map(plan => (
                        <SelectItem key={plan.id} value={plan.id}>
                          {plan.plan_name} - ${plan.price_monthly}/mo
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Status */}
                <div>
                  <Label className="text-base font-bold mb-2 block">Subscription Status *</Label>
                  <Select 
                    value={assignForm.subscription_status} 
                    onValueChange={(val) => setAssignForm({ ...assignForm, subscription_status: val })}
                  >
                    <SelectTrigger className="h-12">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="free_trial">🆓 Free Trial</SelectItem>
                      <SelectItem value="active">✅ Active</SelectItem>
                      <SelectItem value="premium">👑 Premium</SelectItem>
                      <SelectItem value="cancelled">❌ Cancelled</SelectItem>
                      <SelectItem value="expired">⏰ Expired</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Dates */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-base font-bold mb-2 block">Start Date</Label>
                    <Input
                      type="date"
                      value={assignForm.subscription_start_date?.split('T')[0] || ''}
                      onChange={(e) => setAssignForm({ 
                        ...assignForm, 
                        subscription_start_date: new Date(e.target.value).toISOString() 
                      })}
                      className="h-12"
                    />
                  </div>
                  <div>
                    <Label className="text-base font-bold mb-2 block">End Date (Optional)</Label>
                    <Input
                      type="date"
                      value={assignForm.subscription_end_date?.split('T')[0] || ''}
                      onChange={(e) => setAssignForm({ 
                        ...assignForm, 
                        subscription_end_date: e.target.value ? new Date(e.target.value).toISOString() : '' 
                      })}
                      className="h-12"
                    />
                  </div>
                </div>

                {/* Preview */}
                {assignForm.subscription_plan_id && (
                  <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-300">
                    <CardContent className="p-4">
                      <p className="font-bold text-purple-900 mb-2">📋 Assignment Preview:</p>
                      <p className="text-sm text-purple-800">
                        <strong>{selectedUser.full_name}</strong> will be assigned to <strong>{getPlanName(assignForm.subscription_plan_id)}</strong> plan
                      </p>
                      <p className="text-sm text-purple-800">
                        Status: <strong>{assignForm.subscription_status}</strong>
                      </p>
                      {assignForm.subscription_end_date && (
                        <p className="text-sm text-purple-800">
                          Valid until: <strong>{format(new Date(assignForm.subscription_end_date), 'MMM dd, yyyy')}</strong>
                        </p>
                      )}
                    </CardContent>
                  </Card>
                )}

                {/* Actions */}
                <div className="flex gap-4">
                  <Button onClick={() => setShowAssignDialog(false)} variant="outline" className="flex-1">
                    Cancel
                  </Button>
                  <Button onClick={handleAssignSubscription} className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 py-6 text-lg font-bold">
                    <Crown className="w-5 h-5 mr-2" />
                    Assign Plan
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}