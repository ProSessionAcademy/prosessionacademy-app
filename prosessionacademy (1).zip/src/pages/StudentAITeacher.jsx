
import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Brain,
  Send,
  Loader2,
  ArrowLeft,
  Sparkles,
  MessageSquare,
  BookOpen,
  Target,
  Lightbulb,
  CheckCircle2,
  AlertCircle,
  RotateCw
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import ReactMarkdown from "react-markdown";

const UNIVERSITY_AI_CONFIG = {
  thomas_more: {
    name: 'AI Study Teacher',
    shortName: 'AI Teacher',
    icon: '📚',
    color: 'from-green-500 to-emerald-600',
    universityName: 'Thomas More',
    greeting: 'Hi! I\'m your AI Study Teacher, here to help you succeed at Thomas More! 🎓',
    personality: 'friendly, supportive, encouraging, academic-focused'
  },
  ku_leuven: {
    name: 'AI Study Mentor',
    shortName: 'AI Mentor',
    icon: '🎓',
    color: 'from-blue-600 to-indigo-700',
    universityName: 'KU Leuven',
    greeting: 'Welcome! I\'m your AI Study Mentor for KU Leuven students, ready to support your academic journey! 📖',
    personality: 'scholarly, thorough, research-oriented, professional'
  },
  ap_hogeschool: {
    name: 'AI Study Coach',
    shortName: 'AI Coach',
    icon: '📖',
    color: 'from-purple-600 to-pink-600',
    universityName: 'AP Hogeschool',
    greeting: 'Hey there! I\'m your AI Study Coach for AP Hogeschool students, let\'s achieve your goals together! 💪',
    personality: 'motivational, practical, goal-oriented, energetic'
  },
  kdg: {
    name: 'AI Study Tutor',
    shortName: 'AI Tutor',
    icon: '🏫',
    color: 'from-orange-500 to-red-600',
    universityName: 'Karel de Grote',
    greeting: 'Hello! I\'m your AI Study Tutor for Karel de Grote students, here to guide your learning! 🌟',
    personality: 'patient, detailed, step-by-step focused, supportive'
  },
  universiteit_antwerpen: {
    name: 'AI Study Advisor',
    shortName: 'AI Advisor',
    icon: '🎯',
    color: 'from-cyan-500 to-blue-600',
    universityName: 'UAntwerpen',
    greeting: 'Greetings! I\'m your AI Study Advisor for UAntwerpen students, your partner in academic excellence! 🚀',
    personality: 'analytical, strategic, solution-focused, professional'
  },
  ugent: {
    name: 'AI Study Partner',
    shortName: 'AI Partner',
    icon: '🔬',
    color: 'from-teal-500 to-green-600',
    universityName: 'UGent',
    greeting: 'Hi! I\'m your AI Study Partner for UGent students, let\'s make learning effective and fun! 🎉',
    personality: 'scientific, methodical, evidence-based, collaborative'
  },
  other: {
    name: 'AI Study Assistant',
    shortName: 'AI Assistant',
    icon: '🤖',
    color: 'from-slate-600 to-slate-800',
    universityName: 'Your University',
    greeting: 'Hello! I\'m your personal AI Study Assistant, ready to help you excel! ⭐',
    personality: 'adaptive, helpful, encouraging, versatile'
  }
};

export default function StudentAITeacher() {
  const [user, setUser] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [assessmentComplete, setAssessmentComplete] = useState(false);
  const [showAssessment, setShowAssessment] = useState(false);
  const messagesEndRef = useRef(null);

  const [assessmentAnswers, setAssessmentAnswers] = useState({
    struggles: '',
    goals: '',
    study_hours: '',
    learning_style: '',
    biggest_challenge: ''
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);

        // Check if assessment was completed before
        if (currentUser.ai_assessment_completed) {
          setAssessmentComplete(true);
          // Load conversation history if exists
          if (currentUser.ai_conversation_history?.length > 0) {
            setMessages(currentUser.ai_conversation_history);
          } else {
            // Start with greeting
            const aiConfig = UNIVERSITY_AI_CONFIG[currentUser.university] || UNIVERSITY_AI_CONFIG.other;
            setMessages([
              {
                role: 'assistant',
                content: aiConfig.greeting + '\n\nHow can I help you today? Feel free to ask me anything about:\n\n• 📚 Study strategies and planning\n• 📝 Assignment help and organization\n• 🎯 Exam preparation tips\n• 🧠 Learning techniques\n• ⏰ Time management\n• 💡 Motivation and productivity'
              }
            ]);
          }
        } else {
          setShowAssessment(true);
        }
      } catch (error) {
        console.error("Error fetching user:", error);
      }
    };
    fetchUser();
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleCompleteAssessment = async () => {
    if (!assessmentAnswers.struggles || !assessmentAnswers.goals) {
      alert('⚠️ Please answer at least the first two questions!');
      return;
    }

    setIsLoading(true);
    setShowAssessment(false);

    try {
      const aiConfig = UNIVERSITY_AI_CONFIG[user.university] || UNIVERSITY_AI_CONFIG.other;

      const assessmentPrompt = `You are an ${aiConfig.name}, a ${aiConfig.personality} AI study assistant for ${user.full_name || 'the student'} at ${aiConfig.universityName}.

STUDENT PROFILE:
${user.student_academic_year ? `• Academic Year: ${user.student_academic_year}` : ''}
${user.student_major ? `• Major: ${user.student_major}` : ''}
• University: ${aiConfig.universityName}

ASSESSMENT RESULTS:
━━━━━━━━━━━━━━━━━━━━━━━
1. Current struggles: ${assessmentAnswers.struggles}
2. Academic goals: ${assessmentAnswers.goals}
${assessmentAnswers.study_hours ? `3. Weekly study hours: ${assessmentAnswers.study_hours}` : ''}
${assessmentAnswers.learning_style ? `4. Preferred learning style: ${assessmentAnswers.learning_style}` : ''}
${assessmentAnswers.biggest_challenge ? `5. Biggest challenge: ${assessmentAnswers.biggest_challenge}` : ''}

Based on this assessment, create a warm, personalized welcome message that:
1. Acknowledges their specific struggles and goals
2. Provides 3-4 immediate actionable tips tailored to their situation
3. Offers ongoing support
4. Encourages them to ask questions anytime

Be conversational, supportive, and specific to their needs. Keep it under 300 words.`;

      const welcomeMessage = await base44.integrations.Core.InvokeLLM({
        prompt: assessmentPrompt
      });

      const initialMessages = [
        {
          role: 'assistant',
          content: welcomeMessage
        }
      ];

      setMessages(initialMessages);

      // Save assessment completion and conversation
      await base44.auth.updateMe({
        ai_assessment_completed: true,
        ai_assessment_data: assessmentAnswers,
        ai_conversation_history: initialMessages
      });

      setAssessmentComplete(true);
    } catch (error) {
      console.error('Assessment error:', error);
      alert('❌ Failed to process assessment. Please try again.');
      setShowAssessment(true);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return;

    const userMessage = {
      role: 'user',
      content: inputMessage
    };

    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setInputMessage('');
    setIsLoading(true);

    try {
      const aiConfig = UNIVERSITY_AI_CONFIG[user.university] || UNIVERSITY_AI_CONFIG.other;

      const conversationContext = updatedMessages.map(m => 
        `${m.role === 'user' ? 'Student' : aiConfig.shortName}: ${m.content}`
      ).join('\n\n');

      const aiPrompt = `You are an ${aiConfig.name}, a ${aiConfig.personality} AI study assistant for students at ${aiConfig.universityName}.

STUDENT PROFILE:
• Name: ${user.full_name || 'Student'}
${user.student_academic_year ? `• Year: ${user.student_academic_year}` : ''}
${user.student_major ? `• Major: ${user.student_major}` : ''}
${user.ai_assessment_data ? `• Known struggles: ${user.ai_assessment_data.struggles}` : ''}
${user.ai_assessment_data ? `• Goals: ${user.ai_assessment_data.goals}` : ''}

CONVERSATION HISTORY:
${conversationContext}

Respond to the student's latest message in a helpful, encouraging way. Provide:
- Specific, actionable advice
- Study techniques when relevant
- Motivation and encouragement
- Resources or strategies they can use immediately

Keep responses concise (150-250 words) and conversational. Use their name occasionally.`;

      const aiResponse = await base44.integrations.Core.InvokeLLM({
        prompt: aiPrompt
      });

      const assistantMessage = {
        role: 'assistant',
        content: aiResponse
      };

      const finalMessages = [...updatedMessages, assistantMessage];
      setMessages(finalMessages);

      // Save conversation history
      await base44.auth.updateMe({
        ai_conversation_history: finalMessages
      });

    } catch (error) {
      console.error('Chat error:', error);
      setMessages([...updatedMessages, {
        role: 'assistant',
        content: '❌ Sorry, I encountered an error. Please try again!'
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetAssessment = async () => {
    if (confirm('🔄 Reset your AI assessment?\n\nThis will clear your conversation history and let you take the assessment again.')) {
      await base44.auth.updateMe({
        ai_assessment_completed: false,
        ai_assessment_data: null,
        ai_conversation_history: []
      });
      setMessages([]);
      setAssessmentComplete(false);
      setShowAssessment(true);
      setAssessmentAnswers({
        struggles: '',
        goals: '',
        study_hours: '',
        learning_style: '',
        biggest_challenge: ''
      });
    }
  };

  const aiConfig = user?.university ? (UNIVERSITY_AI_CONFIG[user.university] || UNIVERSITY_AI_CONFIG.other) : UNIVERSITY_AI_CONFIG.other;

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <Card>
          <CardContent className="p-12 text-center">
            <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-blue-600" />
            <p className="text-slate-600">Loading...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Assessment Screen
  if (showAssessment) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 p-6 lg:p-8">
        <div className="max-w-3xl mx-auto space-y-6">
          <Link to={createPageUrl("StudentSpace")}>
            <Button variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>

          <Card className="border-none shadow-2xl overflow-hidden">
            <div className={`h-3 bg-gradient-to-r ${aiConfig.color}`}></div>
            <CardHeader className="text-center bg-white p-8">
              <div className="text-6xl mb-4">{aiConfig.icon}</div>
              <CardTitle className="text-3xl mb-2">Your {aiConfig.universityName} {aiConfig.name}</CardTitle>
              <p className="text-slate-600 text-lg">Quick Assessment - Help Me Understand You Better</p>
            </CardHeader>
            <CardContent className="p-8 space-y-6">
              <Card className="bg-blue-50 border-2 border-blue-300">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Lightbulb className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
                    <div>
                      <p className="font-bold text-blue-900 mb-2">Why this assessment?</p>
                      <p className="text-sm text-blue-800">
                        I'll use your answers to provide personalized study strategies, time management tips, 
                        and targeted help exactly where you need it most!
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div>
                <label className="flex items-center gap-2 mb-2 font-bold text-slate-900">
                  <AlertCircle className="w-5 h-5 text-red-500" />
                  1. What are you struggling with most right now? *
                </label>
                <Textarea
                  value={assessmentAnswers.struggles}
                  onChange={(e) => setAssessmentAnswers({ ...assessmentAnswers, struggles: e.target.value })}
                  placeholder="e.g., Time management, specific subjects, motivation, exam stress..."
                  rows={3}
                  className="border-2"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 mb-2 font-bold text-slate-900">
                  <Target className="w-5 h-5 text-green-500" />
                  2. What are your main academic goals this semester? *
                </label>
                <Textarea
                  value={assessmentAnswers.goals}
                  onChange={(e) => setAssessmentAnswers({ ...assessmentAnswers, goals: e.target.value })}
                  placeholder="e.g., Improve grades, pass specific exam, better study habits..."
                  rows={3}
                  className="border-2"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 mb-2 font-semibold text-slate-700">
                  📊 3. How many hours per week do you study? (optional)
                </label>
                <Input
                  value={assessmentAnswers.study_hours}
                  onChange={(e) => setAssessmentAnswers({ ...assessmentAnswers, study_hours: e.target.value })}
                  placeholder="e.g., 10-15 hours"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 mb-2 font-semibold text-slate-700">
                  🎨 4. What's your preferred learning style? (optional)
                </label>
                <Input
                  value={assessmentAnswers.learning_style}
                  onChange={(e) => setAssessmentAnswers({ ...assessmentAnswers, learning_style: e.target.value })}
                  placeholder="e.g., Visual, hands-on, reading, videos..."
                />
              </div>

              <div>
                <label className="flex items-center gap-2 mb-2 font-semibold text-slate-700">
                  💪 5. What's your biggest challenge as a student? (optional)
                </label>
                <Textarea
                  value={assessmentAnswers.biggest_challenge}
                  onChange={(e) => setAssessmentAnswers({ ...assessmentAnswers, biggest_challenge: e.target.value })}
                  placeholder="e.g., Procrastination, concentration, balancing work/study..."
                  rows={2}
                />
              </div>

              <Button
                onClick={handleCompleteAssessment}
                disabled={!assessmentAnswers.struggles || !assessmentAnswers.goals || isLoading}
                className={`w-full bg-gradient-to-r ${aiConfig.color} hover:opacity-90 py-6 text-xl font-bold shadow-xl`}
                size="lg"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-6 h-6 mr-3 animate-spin" />
                    Analyzing your needs...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-6 h-6 mr-3" />
                    Start My AI Teacher
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Chat Interface
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 flex flex-col">
      {/* Header */}
      <div className={`bg-gradient-to-r ${aiConfig.color} p-4 shadow-xl`}>
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("StudentSpace")}>
              <Button variant="outline" className="bg-white/20 border-white/30 text-white hover:bg-white/30">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center text-4xl backdrop-blur-sm">
                {aiConfig.icon}
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Your {aiConfig.universityName} {aiConfig.name}</h1>
                <p className="text-sm text-white/90">Personal study assistant</p>
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <Badge className="bg-white/30 text-white border-white/50 px-4 py-2">
              <Brain className="w-4 h-4 mr-2" />
              AI-Powered
            </Badge>
            <Button
              onClick={handleResetAssessment}
              variant="outline"
              size="sm"
              className="bg-white/20 border-white/30 text-white hover:bg-white/30"
            >
              <RotateCw className="w-4 h-4 mr-2" />
              Reset
            </Button>
          </div>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {messages.map((message, idx) => (
            <div
              key={idx}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {message.role === 'assistant' && (
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${aiConfig.color} flex items-center justify-center text-2xl mr-3 shadow-lg flex-shrink-0`}>
                  {aiConfig.icon}
                </div>
              )}
              
              <Card
                className={`max-w-[80%] ${
                  message.role === 'user'
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white border-none shadow-lg'
                    : 'bg-white border-2 border-slate-200 shadow-md'
                }`}
              >
                <CardContent className="p-4">
                  {message.role === 'user' ? (
                    <p className="text-lg leading-relaxed">{message.content}</p>
                  ) : (
                    <ReactMarkdown className="prose prose-slate max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
                      {message.content}
                    </ReactMarkdown>
                  )}
                </CardContent>
              </Card>

              {message.role === 'user' && (
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-slate-600 to-slate-800 flex items-center justify-center ml-3 shadow-lg flex-shrink-0">
                  <span className="text-white font-bold text-xl">
                    {user?.full_name?.charAt(0) || 'S'}
                  </span>
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-start">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${aiConfig.color} flex items-center justify-center text-2xl mr-3 shadow-lg`}>
                {aiConfig.icon}
              </div>
              <Card className="bg-white border-2 border-slate-200 shadow-md">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
                    <span className="text-slate-600 italic">Thinking...</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="border-t bg-white shadow-xl p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex gap-3">
            <Input
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
              placeholder="Ask me anything about studying, assignments, exams..."
              className="flex-1 h-14 text-lg border-2 border-slate-300 focus:border-blue-500"
              disabled={isLoading}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!inputMessage.trim() || isLoading}
              className={`bg-gradient-to-r ${aiConfig.color} hover:opacity-90 px-8 h-14`}
              size="lg"
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>

          <div className="flex gap-3 mt-3 flex-wrap">
            <Button
              onClick={() => setInputMessage("Help me create a study schedule")}
              variant="outline"
              size="sm"
              className="text-xs"
              disabled={isLoading}
            >
              📅 Study Schedule
            </Button>
            <Button
              onClick={() => setInputMessage("How can I prepare for my upcoming exam?")}
              variant="outline"
              size="sm"
              className="text-xs"
              disabled={isLoading}
            >
              📝 Exam Prep
            </Button>
            <Button
              onClick={() => setInputMessage("I'm struggling with motivation, any tips?")}
              variant="outline"
              size="sm"
              className="text-xs"
              disabled={isLoading}
            >
              💪 Motivation
            </Button>
            <Button
              onClick={() => setInputMessage("What are effective note-taking methods?")}
              variant="outline"
              size="sm"
              className="text-xs"
              disabled={isLoading}
            >
              📓 Note-taking
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
