import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, Award, ArrowLeft, Share2 } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

export default function PathwayCertificate() {
  const [user, setUser] = useState(null);
  const [pathwayId, setPathwayId] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error fetching user:", error);
      }
    };
    fetchUser();

    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('pathwayId');
    setPathwayId(id);
  }, []);

  const { data: pathway } = useQuery({
    queryKey: ['pathway', pathwayId],
    queryFn: async () => {
      if (!pathwayId) return null;
      const pathways = await base44.entities.Pathway.filter({ id: pathwayId });
      return pathways[0] || null;
    },
    enabled: !!pathwayId
  });

  const { data: userProgress = [] } = useQuery({
    queryKey: ['pathwayProgress', user?.email, pathwayId],
    queryFn: async () => {
      if (!user?.email || !pathwayId) return [];
      return await base44.entities.UserProgress.filter({ 
        user_email: user.email, 
        pathway_id: pathwayId 
      });
    },
    enabled: !!user?.email && !!pathwayId
  });

  const pathwayProgress = userProgress.find(p => p.pathway_completed === true);

  const generateCertificate = () => {
    if (!pathway || !user || !pathwayProgress) return;

    const certificateHTML = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Pathway Certificate - ${pathway.title}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Georgia', serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .certificate {
            background: white;
            width: 1000px;
            padding: 80px;
            border: 20px solid #1a365d;
            box-shadow: 0 30px 80px rgba(0,0,0,0.4);
            position: relative;
        }
        .certificate::before {
            content: '';
            position: absolute;
            inset: 15px;
            border: 3px solid #d4af37;
            pointer-events: none;
        }
        .ornament {
            text-align: center;
            font-size: 80px;
            color: #d4af37;
            margin-bottom: 20px;
        }
        h1 {
            text-align: center;
            font-size: 52px;
            color: #1a365d;
            margin-bottom: 10px;
            letter-spacing: 3px;
            text-transform: uppercase;
        }
        .subtitle {
            text-align: center;
            font-size: 22px;
            color: #4a5568;
            margin-bottom: 40px;
            font-style: italic;
        }
        .recipient {
            text-align: center;
            font-size: 56px;
            color: #2d3748;
            margin: 40px 0;
            font-weight: bold;
            border-bottom: 3px solid #d4af37;
            padding-bottom: 20px;
        }
        .pathway-title {
            text-align: center;
            font-size: 32px;
            color: #667eea;
            margin: 30px 0;
            font-weight: bold;
        }
        .description {
            text-align: center;
            font-size: 18px;
            color: #4a5568;
            line-height: 1.8;
            margin: 30px 0;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }
        .footer {
            margin-top: 60px;
            display: flex;
            justify-content: space-around;
            align-items: flex-end;
        }
        .signature-block {
            text-align: center;
        }
        .signature-line {
            width: 250px;
            border-top: 2px solid #2d3748;
            margin-bottom: 10px;
        }
        .signature-label {
            font-size: 14px;
            color: #718096;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .date {
            text-align: center;
            font-size: 16px;
            color: #4a5568;
            margin-top: 40px;
        }
        .badge {
            position: absolute;
            top: 60px;
            right: 60px;
            width: 120px;
            height: 120px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 50px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
        }
        .certificate-id {
            text-align: center;
            font-size: 12px;
            color: #a0aec0;
            margin-top: 20px;
            font-family: 'Courier New', monospace;
        }
        @media print {
            body { padding: 0; background: white; }
            .certificate { border: 15px solid #1a365d; }
        }
    </style>
</head>
<body>
    <div class="certificate">
        <div class="badge">🏆</div>
        <div class="ornament">🎓</div>
        <h1>Certificate of Achievement</h1>
        <div class="subtitle">Learning Pathway Completion</div>
        
        <div class="recipient">${user.full_name || user.email}</div>
        
        <div class="pathway-title">${pathway.title}</div>
        
        <div class="description">
            ${pathway.certificate_template || `Has successfully completed this comprehensive learning pathway, demonstrating dedication, commitment, and excellence in professional development.`}
        </div>

        <div class="description">
            <strong>Pathway Completed:</strong> ${pathway.courses?.length || 0} courses<br/>
            <strong>Category:</strong> ${pathway.category?.replace(/_/g, ' ')}
        </div>

        <div class="date">
            ${format(new Date(pathwayProgress.completed_date || new Date()), 'MMMM dd, yyyy')}
        </div>

        <div class="footer">
            <div class="signature-block">
                <div class="signature-line"></div>
                <div class="signature-label">Platform Director</div>
            </div>
            <div class="signature-block">
                <div class="signature-line"></div>
                <div class="signature-label">Date of Issue</div>
            </div>
        </div>

        <div class="certificate-id">
            Certificate ID: ${pathwayProgress.pathway_certificate_id || 'PATHWAY-' + Date.now()}
        </div>
    </div>
</body>
</html>`;

    const blob = new Blob([certificateHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    
    window.open(url, '_blank');
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `pathway-certificate-${pathway.title.replace(/[^a-z0-9]/gi, '_')}.html`;
    document.body.appendChild(a);
    a.click();
    
    setTimeout(() => {
      URL.revokeObjectURL(url);
      document.body.removeChild(a);
    }, 100);

    alert('✅ Certificate opened & downloaded!\n\nTip: Open the HTML file in your browser and use "Print to PDF" to save as PDF.');
  };

  if (!pathway || !pathwayProgress) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6 flex items-center justify-center">
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-slate-500 mb-4">Certificate not available</p>
            <Link to={createPageUrl("StudentSpace")}>
              <Button>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Student Space
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <Link to={createPageUrl("StudentSpace")}>
          <Button variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Student Space
          </Button>
        </Link>

        <Card className="border-none shadow-2xl bg-gradient-to-r from-yellow-50 to-orange-50 overflow-hidden">
          <div className="h-3 bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500"></div>
          <CardContent className="p-12 text-center">
            <div className="w-32 h-32 bg-gradient-to-br from-yellow-400 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-2xl">
              <Award className="w-16 h-16 text-white" />
            </div>

            <h1 className="text-4xl font-bold text-slate-900 mb-3">
              🎉 Congratulations!
            </h1>

            <div className="text-2xl text-slate-700 mb-2">
              {user?.full_name || user?.email}
            </div>

            <div className="text-xl text-slate-600 mb-6">
              Successfully completed the pathway:
            </div>

            <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-6">
              {pathway.title}
            </div>

            <div className="flex justify-center gap-4 mb-6">
              <Badge className="bg-blue-600 text-white px-4 py-2 text-sm">
                {pathway.courses?.length || 0} Courses Completed
              </Badge>
              <Badge className="bg-purple-600 text-white px-4 py-2 text-sm">
                {pathway.category?.replace(/_/g, ' ')}
              </Badge>
            </div>

            <p className="text-slate-600 mb-8">
              Completion Date: {format(new Date(pathwayProgress.completed_date || new Date()), 'MMMM dd, yyyy')}
            </p>

            <div className="flex gap-4 justify-center">
              <Button
                onClick={generateCertificate}
                size="lg"
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 shadow-xl py-6 px-8 text-lg"
              >
                <Download className="w-5 h-5 mr-2" />
                Download Certificate
              </Button>

              <Button
                onClick={() => {
                  if (navigator.share) {
                    navigator.share({
                      title: 'I completed a pathway!',
                      text: `I just completed ${pathway.title} on Pro-Session! 🎉`,
                    });
                  } else {
                    alert('Share feature not supported on this device');
                  }
                }}
                size="lg"
                variant="outline"
                className="py-6 px-8 text-lg"
              >
                <Share2 className="w-5 h-5 mr-2" />
                Share Achievement
              </Button>
            </div>

            <p className="text-xs text-slate-500 mt-8">
              💡 Tip: Open the HTML file in your browser and use "Print to PDF" to save as PDF
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}