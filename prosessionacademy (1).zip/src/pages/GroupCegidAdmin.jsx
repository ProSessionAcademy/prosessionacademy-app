import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Sparkles, Save, Search, Building2, GraduationCap, Users, CheckCircle, XCircle, Loader2 } from 'lucide-react';

export default function GroupCegidAdmin() {
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const queryClient = useQueryClient();

  useEffect(() => {
    const fetchUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    fetchUser();
  }, []);

  const { data: groups = [], isLoading } = useQuery({
    queryKey: ['allGroups'],
    queryFn: () => base44.entities.Group.list('-created_date'),
    initialData: []
  });

  const updateGroupMutation = useMutation({
    mutationFn: ({ groupId, updates }) => base44.entities.Group.update(groupId, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allGroups'] });
    }
  });

  const toggleCegidForGroup = async (group) => {
    const currentCegidConfig = group.cegid_discovery || {
      enabled: false,
      button_text: 'Discover Cegid',
      topics: []
    };

    await updateGroupMutation.mutateAsync({
      groupId: group.id,
      updates: {
        cegid_discovery: {
          ...currentCegidConfig,
          enabled: !currentCegidConfig.enabled
        }
      }
    });
  };

  const filteredGroups = groups.filter(g => 
    g.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    g.company_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getGroupIcon = (type) => {
    switch(type) {
      case 'work': return Building2;
      case 'university': return GraduationCap;
      default: return Users;
    }
  };

  if (user?.admin_level !== 'top_tier_admin' && user?.admin_level !== 'super_admin') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md">
          <CardContent className="p-12 text-center">
            <XCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
            <p className="text-slate-600">Only top tier admins can manage Cegid Discovery</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-16 h-16 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-pink-50 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <Card className="border-none shadow-2xl">
          <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
            <CardTitle className="text-3xl flex items-center gap-3">
              <Sparkles className="w-8 h-8" />
              Manage Cegid Discovery for Groups
            </CardTitle>
            <p className="text-purple-100 mt-2">Enable or disable Cegid Discovery feature for specific groups</p>
          </CardHeader>
          <CardContent className="p-6">
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  placeholder="Search groups..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-12 border-2"
                />
              </div>
            </div>

            <div className="space-y-3">
              {filteredGroups.map((group) => {
                const Icon = getGroupIcon(group.group_type);
                const cegidEnabled = group.cegid_discovery?.enabled || false;

                return (
                  <Card key={group.id} className={`border-2 transition-all ${
                    cegidEnabled ? 'border-purple-400 bg-purple-50' : 'border-slate-200'
                  }`}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 flex-1">
                          <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                            <Icon className="w-6 h-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-bold text-lg text-slate-900">{group.name}</h3>
                            {group.company_name && (
                              <p className="text-sm text-slate-600">{group.company_name}</p>
                            )}
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="outline" className="text-xs">{group.group_type}</Badge>
                              <Badge variant="outline" className="text-xs">
                                {group.members?.length || 0} members
                              </Badge>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          {cegidEnabled ? (
                            <Badge className="bg-purple-600 text-white">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Cegid Enabled
                            </Badge>
                          ) : (
                            <Badge variant="outline">
                              <XCircle className="w-3 h-3 mr-1" />
                              Disabled
                            </Badge>
                          )}
                          <Switch
                            checked={cegidEnabled}
                            onCheckedChange={() => toggleCegidForGroup(group)}
                            disabled={updateGroupMutation.isPending}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {filteredGroups.length === 0 && (
              <div className="text-center py-12">
                <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">No groups found</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}