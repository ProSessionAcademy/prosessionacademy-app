import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Brain, 
  Heart, 
  Users, 
  Target, 
  Sparkles,
  CheckCircle,
  ArrowRight,
  RefreshCw
} from "lucide-react";

const personalityTypes = {
  "ESTJ": { name: "The Executive", desc: "Organized, practical leader", color: "from-red-500 to-orange-500" },
  "ISTJ": { name: "The Logistician", desc: "Reliable, detail-oriented", color: "from-blue-500 to-indigo-500" },
  "ESFJ": { name: "The Consul", desc: "Caring, social helper", color: "from-pink-500 to-rose-500" },
  "ISFJ": { name: "The Defender", desc: "Warm, dedicated protector", color: "from-purple-500 to-pink-500" },
  "ENTJ": { name: "The Commander", desc: "Bold, strategic leader", color: "from-red-600 to-purple-600" },
  "INTJ": { name: "The Architect", desc: "Strategic, independent thinker", color: "from-indigo-600 to-blue-600" },
  "ENFJ": { name: "The Protagonist", desc: "Charismatic, inspiring", color: "from-green-500 to-emerald-500" },
  "INFJ": { name: "The Advocate", desc: "Idealistic, insightful", color: "from-teal-500 to-cyan-500" },
  "ESTP": { name: "The Entrepreneur", desc: "Bold, action-oriented", color: "from-orange-500 to-amber-500" },
  "ISTP": { name: "The Virtuoso", desc: "Practical, hands-on", color: "from-slate-500 to-zinc-500" },
  "ESFP": { name: "The Entertainer", desc: "Spontaneous, energetic", color: "from-yellow-500 to-orange-500" },
  "ISFP": { name: "The Adventurer", desc: "Flexible, artistic", color: "from-cyan-500 to-blue-500" },
  "ENTP": { name: "The Debater", desc: "Curious, innovative", color: "from-violet-500 to-purple-500" },
  "INTP": { name: "The Logician", desc: "Analytical, creative", color: "from-blue-600 to-indigo-600" },
  "ENFP": { name: "The Campaigner", desc: "Enthusiastic, creative", color: "from-pink-500 to-purple-500" },
  "INFP": { name: "The Mediator", desc: "Idealistic, compassionate", color: "from-purple-500 to-indigo-500" }
};

export default function PersonalityTest() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [showStart, setShowStart] = useState(true);

  const { data: questions = [], isLoading } = useQuery({
    queryKey: ['personalityQuestions'],
    queryFn: async () => {
      const allQuestions = await base44.entities.PersonalityTestQuestion.filter({ active: true }, 'order');
      return allQuestions;
    },
    initialData: [],
  });

  const handleAnswer = (type) => {
    const newAnswers = { ...answers, [currentQuestion]: type };
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      calculateResult(newAnswers);
    }
  };

  const calculateResult = (finalAnswers) => {
    const counts = { E: 0, I: 0, S: 0, N: 0, T: 0, F: 0, J: 0, P: 0 };
    
    Object.values(finalAnswers).forEach(type => {
      counts[type]++;
    });

    const personality = 
      (counts.E >= counts.I ? 'E' : 'I') +
      (counts.S >= counts.N ? 'S' : 'N') +
      (counts.T >= counts.F ? 'T' : 'F') +
      (counts.J >= counts.P ? 'J' : 'P');

    setResult({ type: personality, counts });
  };

  const restart = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setResult(null);
    setShowStart(true);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-purple-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading test...</p>
        </div>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 p-6 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <Heart className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-slate-900 mb-2">No Questions Available</h2>
            <p className="text-slate-600">The admin needs to add personality test questions first.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const progress = ((currentQuestion + 1) / questions.length) * 100;

  if (showStart) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 p-6 flex items-center justify-center">
        <Card className="max-w-2xl w-full border-none shadow-2xl">
          <CardContent className="p-12 text-center">
            <div className="w-24 h-24 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
              <Brain className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Personality Test
            </h1>
            <p className="text-slate-600 text-lg mb-8">
              Discover your unique personality type through {questions.length} interactive questions
            </p>
            <div className="grid grid-cols-2 gap-4 mb-8 text-left">
              <div className="p-4 bg-purple-50 rounded-xl">
                <Heart className="w-6 h-6 text-purple-600 mb-2" />
                <p className="text-sm font-semibold text-slate-900">Self Discovery</p>
                <p className="text-xs text-slate-600">Learn about yourself</p>
              </div>
              <div className="p-4 bg-pink-50 rounded-xl">
                <Users className="w-6 h-6 text-pink-600 mb-2" />
                <p className="text-sm font-semibold text-slate-900">Relationships</p>
                <p className="text-xs text-slate-600">Understand others better</p>
              </div>
              <div className="p-4 bg-blue-50 rounded-xl">
                <Target className="w-6 h-6 text-blue-600 mb-2" />
                <p className="text-sm font-semibold text-slate-900">Career Insights</p>
                <p className="text-xs text-slate-600">Find your path</p>
              </div>
              <div className="p-4 bg-indigo-50 rounded-xl">
                <Sparkles className="w-6 h-6 text-indigo-600 mb-2" />
                <p className="text-sm font-semibold text-slate-900">Fun & Quick</p>
                <p className="text-xs text-slate-600">{questions.length} questions</p>
              </div>
            </div>
            <Button 
              onClick={() => setShowStart(false)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-6 text-lg shadow-lg"
            >
              Start Test
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (result) {
    const typeInfo = personalityTypes[result.type];
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 p-6 flex items-center justify-center">
        <Card className="max-w-2xl w-full border-none shadow-2xl">
          <CardContent className="p-12">
            <div className="text-center mb-8">
              <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
              <h2 className="text-3xl font-bold mb-2">Your Personality Type</h2>
              <div className={`inline-block px-6 py-3 bg-gradient-to-r ${typeInfo.color} text-white rounded-2xl shadow-lg mb-4`}>
                <p className="text-4xl font-bold">{result.type}</p>
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-2">{typeInfo.name}</h3>
              <p className="text-slate-600 text-lg">{typeInfo.desc}</p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-center justify-between p-4 bg-blue-50 rounded-xl">
                <span className="font-semibold">Extroverted (E) vs Introverted (I)</span>
                <Badge>{result.counts.E >= result.counts.I ? 'E' : 'I'}</Badge>
              </div>
              <div className="flex items-center justify-between p-4 bg-green-50 rounded-xl">
                <span className="font-semibold">Sensing (S) vs Intuitive (N)</span>
                <Badge>{result.counts.S >= result.counts.N ? 'S' : 'N'}</Badge>
              </div>
              <div className="flex items-center justify-between p-4 bg-purple-50 rounded-xl">
                <span className="font-semibold">Thinking (T) vs Feeling (F)</span>
                <Badge>{result.counts.T >= result.counts.F ? 'T' : 'F'}</Badge>
              </div>
              <div className="flex items-center justify-between p-4 bg-pink-50 rounded-xl">
                <span className="font-semibold">Judging (J) vs Perceiving (P)</span>
                <Badge>{result.counts.J >= result.counts.P ? 'J' : 'P'}</Badge>
              </div>
            </div>

            <Button 
              onClick={restart}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Take Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const question = questions[currentQuestion];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 p-6 flex items-center justify-center">
      <Card className="max-w-2xl w-full border-none shadow-2xl">
        <CardHeader>
          <div className="flex items-center justify-between mb-4">
            <Badge className="bg-purple-100 text-purple-700">
              Question {currentQuestion + 1} of {questions.length}
            </Badge>
            <span className="text-sm text-slate-500">{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-2 mb-4" />
          <CardTitle className="text-2xl">{question.question}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {question.options.map((option, idx) => (
            <button
              key={idx}
              onClick={() => handleAnswer(option.type)}
              className="w-full p-6 bg-white border-2 border-slate-200 rounded-2xl hover:border-purple-500 hover:shadow-lg transition-all text-left group"
            >
              <div className="flex items-center gap-4">
                <div className="text-4xl">{option.emoji}</div>
                <p className="text-lg font-medium text-slate-900 group-hover:text-purple-600 transition-colors">
                  {option.text}
                </p>
              </div>
            </button>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}