import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import {
  DollarSign,
  TrendingUp,
  Users,
  Zap,
  AlertTriangle,
  CheckCircle,
  Activity,
  BarChart3,
  Shield,
  Crown,
  Lock
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const COST_PER_SESSION_LOW = 0.10;
const COST_PER_SESSION_HIGH = 0.80;
const MONTHLY_LIMIT = 25;

export default function UsageMonitor() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        const isAdmin = currentUser.admin_level === 'top_tier_admin' || 
                       currentUser.admin_level === 'super_admin' || 
                       currentUser.admin_level === 'supervisor_admin';
        
        if (!isAdmin) {
          alert('⛔ Access Denied! Admin only.');
          window.location.href = createPageUrl('Dashboard');
          return;
        }
        
        setLoading(false);
      } catch (error) {
        console.error('Error:', error);
        window.location.href = createPageUrl('Dashboard');
      }
    };
    fetchUser();
  }, []);

  const { data: allUsers = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    enabled: !!user && !loading,
    initialData: []
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-blue-900">
        <div className="text-center text-white">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-white mx-auto mb-4"></div>
          <p className="text-lg">Loading usage data...</p>
        </div>
      </div>
    );
  }

  // Calculate current month stats
  const now = new Date();
  const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

  const usersWithUsage = allUsers.filter(u => 
    u.ai_practice_usage?.month === currentMonth && u.ai_practice_usage?.sessions_used > 0
  );

  const totalSessionsUsed = usersWithUsage.reduce((sum, u) => 
    sum + (u.ai_practice_usage?.sessions_used || 0), 0
  );

  const averageSessionsPerUser = usersWithUsage.length > 0 
    ? Math.round(totalSessionsUsed / usersWithUsage.length) 
    : 0;

  const estimatedCostLow = totalSessionsUsed * COST_PER_SESSION_LOW;
  const estimatedCostHigh = totalSessionsUsed * COST_PER_SESSION_HIGH;
  const estimatedCostAvg = (estimatedCostLow + estimatedCostHigh) / 2;

  const premiumUsers = allUsers.filter(u => u.subscription_status === 'premium').length;
  const freeUsers = allUsers.length - premiumUsers;

  const usersOverLimit = usersWithUsage.filter(u => 
    u.ai_practice_usage?.sessions_used >= MONTHLY_LIMIT
  ).length;

  const totalPossibleSessions = freeUsers * MONTHLY_LIMIT;
  const usagePercentage = totalPossibleSessions > 0 
    ? Math.round((totalSessionsUsed / totalPossibleSessions) * 100) 
    : 0;

  // Projection for end of month
  const dayOfMonth = now.getDate();
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const projectedTotalSessions = totalSessionsUsed * (daysInMonth / dayOfMonth);
  const projectedCostAvg = projectedTotalSessions * ((COST_PER_SESSION_LOW + COST_PER_SESSION_HIGH) / 2);

  // Top users by usage
  const topUsers = [...usersWithUsage]
    .sort((a, b) => (b.ai_practice_usage?.sessions_used || 0) - (a.ai_practice_usage?.sessions_used || 0))
    .slice(0, 10);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">💰 AI Cost Monitor</h1>
            <p className="text-blue-200">Real-time Practice Hub usage & cost tracking</p>
          </div>
          <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white text-lg px-4 py-2">
            <Shield className="w-4 h-4 mr-2" />
            Admin Only
          </Badge>
        </div>

        {/* Current Month Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="border-none shadow-2xl bg-gradient-to-br from-green-600 to-emerald-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <DollarSign className="w-10 h-10 text-green-200" />
                <Badge className="bg-white/20 text-white">Current</Badge>
              </div>
              <div className="text-3xl font-black mb-1">
                ${estimatedCostAvg.toFixed(2)}
              </div>
              <p className="text-sm text-green-100">Estimated This Month</p>
              <p className="text-xs text-green-200 mt-1">
                Range: ${estimatedCostLow.toFixed(2)} - ${estimatedCostHigh.toFixed(2)}
              </p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-2xl bg-gradient-to-br from-blue-600 to-cyan-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <Zap className="w-10 h-10 text-blue-200" />
                <Badge className="bg-white/20 text-white">Sessions</Badge>
              </div>
              <div className="text-3xl font-black mb-1">{totalSessionsUsed}</div>
              <p className="text-sm text-blue-100">Total Sessions Used</p>
              <p className="text-xs text-blue-200 mt-1">
                Out of {totalPossibleSessions} possible
              </p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-2xl bg-gradient-to-br from-purple-600 to-fuchsia-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <Users className="w-10 h-10 text-purple-200" />
                <Badge className="bg-white/20 text-white">Active</Badge>
              </div>
              <div className="text-3xl font-black mb-1">{usersWithUsage.length}</div>
              <p className="text-sm text-purple-100">Users Practicing</p>
              <p className="text-xs text-purple-200 mt-1">
                {allUsers.length} total users
              </p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-2xl bg-gradient-to-br from-orange-600 to-red-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <Activity className="w-10 h-10 text-orange-200" />
                <Badge className="bg-white/20 text-white">Avg</Badge>
              </div>
              <div className="text-3xl font-black mb-1">{averageSessionsPerUser}</div>
              <p className="text-sm text-orange-100">Sessions/User</p>
              <p className="text-xs text-orange-200 mt-1">
                Limit: {MONTHLY_LIMIT}/user
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Projected End of Month */}
        <Card className="border-none shadow-2xl bg-gradient-to-br from-yellow-600 to-orange-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center gap-4 mb-4">
              <TrendingUp className="w-12 h-12 text-yellow-200" />
              <div>
                <h3 className="text-2xl font-bold">📊 Month-End Projection</h3>
                <p className="text-sm text-yellow-100">Based on current usage trend (Day {dayOfMonth} of {daysInMonth})</p>
              </div>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <p className="text-sm text-yellow-100 mb-1">Projected Sessions</p>
                <p className="text-3xl font-bold">{Math.round(projectedTotalSessions)}</p>
              </div>
              <div>
                <p className="text-sm text-yellow-100 mb-1">Projected Cost</p>
                <p className="text-3xl font-bold">${projectedCostAvg.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-sm text-yellow-100 mb-1">Cost/User</p>
                <p className="text-3xl font-bold">
                  ${usersWithUsage.length > 0 ? (projectedCostAvg / usersWithUsage.length).toFixed(2) : '0.00'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Usage Percentage */}
        <Card className="border-none shadow-2xl bg-slate-800/90 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold">🎯 Platform Usage Rate</h3>
              <Badge className={`text-lg px-4 py-2 ${
                usagePercentage < 30 ? 'bg-green-600' :
                usagePercentage < 60 ? 'bg-yellow-600' :
                usagePercentage < 85 ? 'bg-orange-600' : 'bg-red-600'
              }`}>
                {usagePercentage}%
              </Badge>
            </div>
            <Progress value={usagePercentage} className="h-4 bg-slate-700 [&>*]:bg-gradient-to-r [&>*]:from-blue-500 [&>*]:to-purple-500" />
            <p className="text-sm text-slate-300 mt-3">
              {totalSessionsUsed} sessions used out of {totalPossibleSessions} available ({freeUsers} free users × {MONTHLY_LIMIT} limit)
            </p>
          </CardContent>
        </Card>

        {/* Alerts */}
        {usersOverLimit > 0 && (
          <Card className="border-2 border-yellow-500 bg-yellow-900/50 text-white">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-6 h-6 text-yellow-300 mt-1" />
                <div>
                  <h3 className="font-bold text-xl mb-2">⚠️ Users at Limit</h3>
                  <p className="text-yellow-100">
                    {usersOverLimit} user(s) have reached the 25-session monthly limit. They're locked until next month or upgrade to Premium.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Top Users */}
        <Card className="border-none shadow-2xl bg-slate-800/90 text-white">
          <CardHeader>
            <CardTitle className="text-2xl text-white">👥 Top Users by AI Usage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topUsers.length > 0 ? (
                topUsers.map((u, idx) => {
                  const sessionsUsed = u.ai_practice_usage?.sessions_used || 0;
                  const usagePercent = (sessionsUsed / MONTHLY_LIMIT) * 100;
                  const estimatedUserCostLow = sessionsUsed * COST_PER_SESSION_LOW;
                  const estimatedUserCostHigh = sessionsUsed * COST_PER_SESSION_HIGH;
                  const isPremium = u.subscription_status === 'premium';
                  
                  return (
                    <div key={u.id} className="bg-slate-700/50 rounded-xl p-4 hover:bg-slate-700 transition-all">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 text-white font-bold text-lg">
                            {idx + 1}
                          </div>
                          <div>
                            <p className="font-semibold text-white">{u.full_name || u.email}</p>
                            <p className="text-xs text-slate-400">{u.email}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {isPremium && (
                            <Badge className="bg-yellow-600">
                              <Crown className="w-3 h-3 mr-1" />
                              Premium
                            </Badge>
                          )}
                          <Badge className={`text-lg px-3 py-1 ${
                            usagePercent >= 100 ? 'bg-red-600' :
                            usagePercent >= 80 ? 'bg-orange-600' :
                            usagePercent >= 50 ? 'bg-yellow-600' : 'bg-green-600'
                          }`}>
                            {sessionsUsed}/{MONTHLY_LIMIT}
                          </Badge>
                        </div>
                      </div>
                      <div className="mb-2">
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-slate-300">Usage</span>
                          <span className="text-slate-300">{usagePercent.toFixed(0)}%</span>
                        </div>
                        <Progress value={usagePercent} className="h-2 bg-slate-600" />
                      </div>
                      <div className="flex justify-between text-xs text-slate-400">
                        <span>Est. Cost:</span>
                        <span className="font-semibold text-green-300">
                          ${estimatedUserCostLow.toFixed(2)} - ${estimatedUserCostHigh.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-12">
                  <Activity className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                  <p className="text-slate-400">No AI usage this month yet</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Detailed Breakdown */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="border-none shadow-2xl bg-slate-800/90 text-white">
            <CardHeader>
              <CardTitle className="text-xl text-white">📊 Usage Distribution</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-slate-700/50 rounded-lg">
                <span className="text-slate-300">Active Users (used AI)</span>
                <span className="font-bold text-2xl text-blue-400">{usersWithUsage.length}</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-slate-700/50 rounded-lg">
                <span className="text-slate-300">Inactive Users</span>
                <span className="font-bold text-2xl text-slate-400">{allUsers.length - usersWithUsage.length}</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-slate-700/50 rounded-lg">
                <span className="text-slate-300">Users at Limit</span>
                <span className="font-bold text-2xl text-red-400">{usersOverLimit}</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-slate-700/50 rounded-lg">
                <span className="text-slate-300">Premium Users (Unlimited)</span>
                <span className="font-bold text-2xl text-yellow-400">{premiumUsers}</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-2xl bg-slate-800/90 text-white">
            <CardHeader>
              <CardTitle className="text-xl text-white">💡 Cost Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-green-900/30 border-2 border-green-500/50 rounded-xl">
                <p className="text-sm text-green-300 mb-1">Best Case Scenario</p>
                <p className="text-3xl font-bold text-green-400">${estimatedCostLow.toFixed(2)}</p>
                <p className="text-xs text-green-200 mt-1">If all sessions cost $0.10 each</p>
              </div>

              <div className="p-4 bg-blue-900/30 border-2 border-blue-500/50 rounded-xl">
                <p className="text-sm text-blue-300 mb-1">Most Likely</p>
                <p className="text-3xl font-bold text-blue-400">${estimatedCostAvg.toFixed(2)}</p>
                <p className="text-xs text-blue-200 mt-1">Average expected cost</p>
              </div>

              <div className="p-4 bg-orange-900/30 border-2 border-orange-500/50 rounded-xl">
                <p className="text-sm text-orange-300 mb-1">Worst Case Scenario</p>
                <p className="text-3xl font-bold text-orange-400">${estimatedCostHigh.toFixed(2)}</p>
                <p className="text-xs text-orange-200 mt-1">If all sessions cost $0.80 each</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Month-End Projection */}
        {dayOfMonth < daysInMonth && (
          <Card className="border-2 border-purple-500 bg-gradient-to-br from-purple-900/80 to-pink-900/80 text-white">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <BarChart3 className="w-12 h-12 text-purple-300" />
                <div className="flex-1">
                  <h3 className="text-2xl font-bold mb-2">🔮 End-of-Month Forecast</h3>
                  <p className="text-purple-200 mb-4">
                    Based on current pace (Day {dayOfMonth} of {daysInMonth})
                  </p>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-white/10 rounded-lg p-4">
                      <p className="text-sm text-purple-200 mb-1">Projected Sessions</p>
                      <p className="text-3xl font-bold">{Math.round(projectedTotalSessions)}</p>
                    </div>
                    <div className="bg-white/10 rounded-lg p-4">
                      <p className="text-sm text-purple-200 mb-1">Projected Total Cost</p>
                      <p className="text-3xl font-bold">${projectedCostAvg.toFixed(2)}</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Cost Optimization Tips */}
        <Card className="border-none shadow-2xl bg-gradient-to-br from-slate-800 to-blue-900 text-white">
          <CardHeader>
            <CardTitle className="text-2xl text-white">💡 Cost Optimization Tips</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-green-900/30 rounded-lg">
              <CheckCircle className="w-5 h-5 text-green-400 mt-0.5" />
              <div>
                <p className="font-semibold text-green-300">✅ Current Limit: 25 sessions/user</p>
                <p className="text-sm text-green-200">This caps your maximum monthly cost</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3 p-3 bg-blue-900/30 rounded-lg">
              <Zap className="w-5 h-5 text-blue-400 mt-0.5" />
              <div>
                <p className="font-semibold text-blue-300">Lower to 15-20 if costs too high</p>
                <p className="text-sm text-blue-200">Easy to adjust in code anytime</p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 bg-purple-900/30 rounded-lg">
              <Crown className="w-5 h-5 text-purple-400 mt-0.5" />
              <div>
                <p className="font-semibold text-purple-300">Promote Premium ($10-20/mo/user)</p>
                <p className="text-sm text-purple-200">Revenue covers AI costs + profit</p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 bg-orange-900/30 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-orange-400 mt-0.5" />
              <div>
                <p className="font-semibold text-orange-300">Monitor weekly</p>
                <p className="text-sm text-orange-200">Check this dashboard to catch spikes early</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="border-none shadow-xl bg-slate-800/90 text-white">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-slate-400 mb-2">Cost Per Session</p>
              <p className="text-2xl font-bold text-blue-400">
                ${COST_PER_SESSION_LOW} - ${COST_PER_SESSION_HIGH}
              </p>
              <p className="text-xs text-slate-500 mt-1">Depends on conversation length</p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-xl bg-slate-800/90 text-white">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-slate-400 mb-2">Free User Limit</p>
              <p className="text-2xl font-bold text-purple-400">{MONTHLY_LIMIT} sessions</p>
              <p className="text-xs text-slate-500 mt-1">Resets 1st of each month</p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-xl bg-slate-800/90 text-white">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-slate-400 mb-2">Premium Users</p>
              <p className="text-2xl font-bold text-yellow-400">Unlimited ∞</p>
              <p className="text-xs text-slate-500 mt-1">No session limits</p>
            </CardContent>
          </Card>
        </div>

        {/* Back Button */}
        <div className="flex justify-center">
          <Link to={createPageUrl('Dashboard')}>
            <Button variant="outline" size="lg" className="border-white/20 text-white hover:bg-white/10">
              Back to Dashboard
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}