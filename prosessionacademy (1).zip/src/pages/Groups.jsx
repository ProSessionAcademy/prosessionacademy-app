
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Users, 
  Building2, 
  GraduationCap, 
  Star, 
  Plus, 
  Check, 
  Clock,
  ArrowRight,
  UserPlus,
  RefreshCw,
  GraduationCapIcon,
  Upload,
  CheckCircle
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function Groups() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [showJoinDialog, setShowJoinDialog] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [joinType, setJoinType] = useState("student");
  const [joinForm, setJoinForm] = useState({
    full_name: "",
    employee_number: "",
    title: "",
    specialization: "",
    bio: "",
    subjects: ""
  });
  
  const [newGroup, setNewGroup] = useState({
    name: "",
    description: "",
    group_type: "work",
    company_name: "",
    logo_url: ""
  });
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    const fetchUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      setJoinForm({...joinForm, full_name: currentUser.full_name || ""});
    };
    fetchUser();
  }, []);

  const { data: groups = [], isLoading, refetch } = useQuery({
    queryKey: ['groups'],
    queryFn: async () => {
      const allGroups = await base44.entities.Group.list();
      return allGroups;
    },
    initialData: [],
    refetchInterval: 1500,
    refetchOnWindowFocus: true,
    refetchOnMount: true,
  });

  const requestJoinMutation = useMutation({
    mutationFn: ({ groupId, request }) => {
      const group = groups.find(g => g.id === groupId);
      const pendingRequests = group.pending_requests || [];
      return base44.entities.Group.update(groupId, {
        pending_requests: [...pendingRequests, request]
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      refetch();
      setShowJoinDialog(false);
      setJoinForm({ full_name: user?.full_name || "", employee_number: "", title: "", specialization: "", bio: "", subjects: "" });
      alert("✅ Join request submitted! Wait for admin approval.");
    },
  });

  const registerTeacherMutation = useMutation({
    mutationFn: (data) => base44.entities.Teacher.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['teachers'] });
      setShowJoinDialog(false);
      setJoinForm({ full_name: user?.full_name || "", employee_number: "", title: "", specialization: "", bio: "", subjects: "" });
      alert("✅ Teacher registration submitted! Wait for admin approval.");
    },
  });

  const createGroupMutation = useMutation({
    mutationFn: (data) => base44.entities.Group.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      setShowCreateDialog(false);
      setNewGroup({
        name: "",
        description: "",
        group_type: "work",
        company_name: "",
        logo_url: ""
      });
      alert('✅ Group created successfully!');
    },
  });

  const handleLogoUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }

    setUploading(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      setNewGroup({ ...newGroup, logo_url: response.file_url });
      alert('✅ Logo uploaded!');
    } catch (error) {
      alert('❌ Upload failed: ' + (error.message || "Unknown error"));
    } finally {
      setUploading(false);
      event.target.value = '';
    }
  };

  const handleCreateGroup = () => {
    if (!newGroup.name || !newGroup.description) {
      alert('Please fill in all required fields');
      return;
    }

    const meetingRoomId = Math.random().toString(36).substring(7);

    createGroupMutation.mutate({
      ...newGroup,
      admin_emails: [user.email],
      members: [{
        user_email: user.email,
        full_name: user.full_name || user.email,
        employee_number: "",
        joined_date: new Date().toISOString(),
        role: "admin"
      }],
      meeting_room_url: meetingRoomId
    });
  };

  const handleRequestJoin = () => {
    if (joinType === "teacher") {
      if (!joinForm.full_name || !joinForm.title || !joinForm.specialization) {
        alert("Please fill in all required teacher fields");
        return;
      }

      const teacherData = {
        user_email: user.email,
        full_name: joinForm.full_name,
        title: joinForm.title,
        specialization: joinForm.specialization,
        bio: joinForm.bio,
        subjects: joinForm.subjects.split(',').map(s => s.trim()).filter(Boolean),
        group_id: selectedGroup.id,
        status: "pending"
      };

      registerTeacherMutation.mutate(teacherData);
    } else {
      if (!joinForm.full_name || !joinForm.employee_number) {
        alert("Please fill in all fields");
        return;
      }

      const request = {
        user_email: user.email,
        full_name: joinForm.full_name,
        employee_number: joinForm.employee_number,
        request_date: new Date().toISOString(),
        status: "pending"
      };

      requestJoinMutation.mutate({ groupId: selectedGroup.id, request });
    }
  };

  const getGroupIcon = (type) => {
    switch(type) {
      case 'work': return Building2;
      case 'university': return GraduationCap;
      case 'community': return Star;
      default: return Users;
    }
  };

  const isUserMember = (group) => {
    if (!user?.email || !group?.members) return false;
    const members = group.members || [];
    const userEmailLower = user.email.toLowerCase().trim();
    return members.some(m => m.user_email?.toLowerCase().trim() === userEmailLower);
  };

  const hasPendingRequest = (group) => {
    if (!user?.email || !group?.pending_requests) return false;
    return group.pending_requests.some(r => r.user_email === user.email && r.status === "pending");
  };

  const groupTypeColors = {
    work: "from-blue-500 to-indigo-600",
    university: "from-green-500 to-emerald-600",
    community: "from-purple-500 to-pink-600"
  };

  const canCreateGroup = user?.admin_level === 'top_tier_admin' || 
                         user?.admin_level === 'super_admin' || 
                         user?.admin_level === 'supervisor_admin';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Professional Header */}
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          <Card className="border-none shadow-2xl overflow-hidden bg-white">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 opacity-10"></div>
              <CardContent className="relative p-8 lg:p-12">
                <div className="flex items-center justify-between flex-wrap gap-6">
                  <div className="flex items-center gap-6">
                    <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-xl">
                      <Users className="w-10 h-10 text-white" />
                    </div>
                    <div>
                      <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-2">
                        Join Groups
                      </h1>
                      <p className="text-lg text-slate-600">
                        Connect with communities for learning together
                      </p>
                    </div>
                  </div>
                  
                  {canCreateGroup && (
                    <Button
                      onClick={() => setShowCreateDialog(true)}
                      className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg"
                      size="lg"
                    >
                      <Plus className="w-5 h-5 mr-2" />
                      Create Group
                    </Button>
                  )}
                </div>
              </CardContent>
            </div>
          </Card>
        </motion.div>

        {/* Groups Grid */}
        {isLoading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600 mx-auto"></div>
            <p className="text-slate-500 mt-4 font-medium">Loading groups...</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {groups.map((group, index) => {
              const Icon = getGroupIcon(group.group_type);
              const isMember = isUserMember(group);
              const pending = hasPendingRequest(group);

              return (
                <motion.div
                  key={group.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ y: -8 }}
                >
                  <Card className="border-none shadow-lg hover:shadow-2xl transition-all overflow-hidden h-full flex flex-col bg-white">
                    <div className={`h-32 bg-gradient-to-r ${groupTypeColors[group.group_type]} relative overflow-hidden`}>
                      {group.logo_url ? (
                        <div className="absolute inset-0">
                          <img src={group.logo_url} alt={group.name} className="w-full h-full object-cover opacity-30" />
                          <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-black/20" />
                        </div>
                      ) : null}
                      <div className="relative h-full flex items-center justify-center">
                        <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                          <Icon className="w-8 h-8 text-white" />
                        </div>
                      </div>
                      {isMember && (
                        <Badge className="absolute top-4 right-4 bg-green-500 text-white border-none shadow-lg">
                          <Check className="w-3 h-3 mr-1" />
                          Member
                        </Badge>
                      )}
                      {!isMember && pending && (
                        <Badge className="absolute top-4 right-4 bg-yellow-500 text-white border-none shadow-lg">
                          <Clock className="w-3 h-3 mr-1" />
                          Pending
                        </Badge>
                      )}
                    </div>

                    <CardHeader>
                      <CardTitle className="text-xl text-slate-900">{group.name}</CardTitle>
                      {group.company_name && (
                        <p className="text-sm text-slate-500">{group.company_name}</p>
                      )}
                    </CardHeader>

                    <CardContent className="flex-1 flex flex-col space-y-4">
                      <p className="text-slate-600 text-sm line-clamp-3 flex-1">
                        {group.description}
                      </p>

                      <div className="flex items-center gap-2 text-sm text-slate-500">
                        <Users className="w-4 h-4" />
                        <span>{group.members?.length || 0} members</span>
                      </div>

                      {isMember ? (
                        <a href={`${createPageUrl("GroupDashboard")}?groupId=${group.id}`}>
                          <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                            Open Group
                            <ArrowRight className="w-4 h-4 ml-2" />
                          </Button>
                        </a>
                      ) : pending ? (
                        <Button className="w-full" variant="outline" disabled>
                          <Clock className="w-4 h-4 mr-2" />
                          Request Pending
                        </Button>
                      ) : (
                        <Button 
                          className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                          onClick={() => {
                            setSelectedGroup(group);
                            setShowJoinDialog(true);
                          }}
                        >
                          <UserPlus className="w-4 h-4 mr-2" />
                          Request to Join
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Create Group Dialog */}
      {canCreateGroup && (
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogContent className="sm:max-w-2xl bg-white">
            <DialogHeader>
              <DialogTitle className="text-slate-900">Create New Group</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="group-name" className="text-slate-700">Group Name *</Label>
                <Input
                  id="group-name"
                  placeholder="e.g., Sales Team Netherlands"
                  value={newGroup.name}
                  onChange={(e) => setNewGroup({ ...newGroup, name: e.target.value })}
                  className="border-2"
                />
              </div>

              <div>
                <Label htmlFor="group-desc" className="text-slate-700">Description *</Label>
                <Textarea
                  id="group-desc"
                  placeholder="What is this group about?"
                  value={newGroup.description}
                  onChange={(e) => setNewGroup({ ...newGroup, description: e.target.value })}
                  className="min-h-[100px] border-2"
                />
              </div>

              <div>
                <Label htmlFor="group-type" className="text-slate-700">Group Type *</Label>
                <Select
                  value={newGroup.group_type}
                  onValueChange={(value) => setNewGroup({ ...newGroup, group_type: value })}
                >
                  <SelectTrigger className="border-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white">
                    <SelectItem value="work">Work/Company</SelectItem>
                    <SelectItem value="university">University/School</SelectItem>
                    <SelectItem value="community">Community</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {newGroup.group_type === 'work' && (
                <div>
                  <Label htmlFor="company-name" className="text-slate-700">Company Name</Label>
                  <Input
                    id="company-name"
                    placeholder="e.g., Acme Corporation"
                    value={newGroup.company_name}
                    onChange={(e) => setNewGroup({ ...newGroup, company_name: e.target.value })}
                    className="border-2"
                  />
                </div>
              )}

              <div>
                <Label className="text-slate-700">Group Logo</Label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="hidden"
                  id="logo-upload"
                  disabled={uploading}
                />
                <Button
                  type="button"
                  variant="outline"
                  className="w-full border-2"
                  disabled={uploading}
                  onClick={() => document.getElementById('logo-upload').click()}
                >
                  {uploading ? (
                    <>Uploading...</>
                  ) : newGroup.logo_url ? (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
                      Logo Uploaded
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Logo
                    </>
                  )}
                </Button>
                {newGroup.logo_url && (
                  <div className="mt-2">
                    <img src={newGroup.logo_url} alt="Logo" className="w-24 h-24 object-cover rounded-lg" />
                  </div>
                )}
              </div>

              <Button
                onClick={handleCreateGroup}
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600"
                disabled={!newGroup.name || !newGroup.description}
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Group
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Join Group Dialog */}
      <Dialog open={showJoinDialog} onOpenChange={setShowJoinDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-white">
          <DialogHeader>
            <DialogTitle className="text-slate-900">Join {selectedGroup?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-slate-600">
              Submit your request to join this exclusive group. Choose your role below.
            </p>

            <div>
              <Label className="text-slate-700">Join As</Label>
              <Select value={joinType} onValueChange={setJoinType}>
                <SelectTrigger className="border-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white">
                  <SelectItem value="student">Student / Member</SelectItem>
                  <SelectItem value="teacher">Teacher / Professor</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-slate-700">Full Name</Label>
              <Input
                value={joinForm.full_name}
                onChange={(e) => setJoinForm({...joinForm, full_name: e.target.value})}
                placeholder="Your full name"
                className="border-2"
              />
            </div>

            {joinType === "student" ? (
              <div>
                <Label className="text-slate-700">Employee Number / Student ID</Label>
                <Input
                  value={joinForm.employee_number}
                  onChange={(e) => setJoinForm({...joinForm, employee_number: e.target.value})}
                  placeholder="Your ID number"
                  className="border-2"
                />
              </div>
            ) : (
              <>
                <div>
                  <Label className="text-slate-700">Title (Dr. / Prof. / Mr. / Ms.)</Label>
                  <Input
                    value={joinForm.title}
                    onChange={(e) => setJoinForm({...joinForm, title: e.target.value})}
                    placeholder="e.g., Dr., Professor"
                    className="border-2"
                  />
                </div>

                <div>
                  <Label className="text-slate-700">Specialization / Department</Label>
                  <Input
                    value={joinForm.specialization}
                    onChange={(e) => setJoinForm({...joinForm, specialization: e.target.value})}
                    placeholder="e.g., Mathematics, Computer Science"
                    className="border-2"
                  />
                </div>

                <div>
                  <Label className="text-slate-700">Subjects (comma separated)</Label>
                  <Input
                    value={joinForm.subjects}
                    onChange={(e) => setJoinForm({...joinForm, subjects: e.target.value})}
                    placeholder="e.g., Calculus, Linear Algebra, Statistics"
                    className="border-2"
                  />
                </div>

                <div>
                  <Label className="text-slate-700">Bio (Optional)</Label>
                  <Textarea
                    value={joinForm.bio}
                    onChange={(e) => setJoinForm({...joinForm, bio: e.target.value})}
                    placeholder="Tell us about yourself..."
                    rows={3}
                    className="border-2"
                  />
                </div>
              </>
            )}

            <Button 
              onClick={handleRequestJoin}
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600"
              disabled={joinType === "student" ? (!joinForm.full_name || !joinForm.employee_number) : (!joinForm.full_name || !joinForm.title || !joinForm.specialization)}
            >
              {joinType === "teacher" ? (
                <>
                  <GraduationCapIcon className="w-4 h-4 mr-2" />
                  Submit Teacher Application
                </>
              ) : (
                "Submit Request"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
