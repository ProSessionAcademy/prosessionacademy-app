
import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  BookOpen,
  TrendingUp,
  Award,
  Calendar,
  ArrowRight,
  Users,
  Target,
  Clock,
  Sparkles,
  Play,
  LogIn,
  Brain,
  Flame,
  Trophy,
  Zap,
  Briefcase
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useLanguage } from "@/components/LanguageSelector";
import { Badge } from "@/components/ui/badge"; // Import Badge component

export default function Dashboard() {
  const { t } = useLanguage();
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [daysLeftInTrial, setDaysLeftInTrial] = useState(0);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const authenticated = await base44.auth.isAuthenticated();
        setIsAuthenticated(authenticated);
        if (authenticated) {
          const currentUser = await base44.auth.me();

          if (currentUser.student_study_streak === undefined || currentUser.student_study_streak === null) {
            await base44.auth.updateMe({
              student_study_streak: 0
            });
            currentUser.student_study_streak = 0;
          }

          if (currentUser.trial_end_date) {
            const now = new Date();
            const trialEnd = new Date(currentUser.trial_end_date);
            const diffTime = trialEnd - now;
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            setDaysLeftInTrial(Math.max(0, diffDays));
          }

          setUser(currentUser);
        }
      } catch (error) {
        console.error("Error:", error);
      }
    };
    fetchUser();
  }, []);

  const { data: courses = [] } = useQuery({
    queryKey: ['courses'],
    queryFn: () => base44.entities.Course.list('-created_date'),
    initialData: [],
  });

  const { data: myProgress = [] } = useQuery({
    queryKey: ['myProgress', user?.email],
    queryFn: () => base44.entities.UserProgress.filter({ user_email: user?.email }),
    initialData: [],
    enabled: !!user?.email
  });

  const { data: events = [] } = useQuery({
    queryKey: ['upcomingEvents'],
    queryFn: () => base44.entities.Event.filter({ status: 'approved' }, 'date', 5),
    initialData: []
  });

  const { data: posts = [] } = useQuery({
    queryKey: ['recentPosts'],
    queryFn: () => base44.entities.Post.list('-created_date', 5),
    initialData: []
  });

  const activeCourses = myProgress?.filter((p) => p.progress_percentage < 100 && p.progress_percentage > 0) || [];
  const completedCourses = myProgress?.filter((p) => p.progress_percentage === 100) || [];

  const totalLearningHours = completedCourses.length * 2.5 + activeCourses.length * 1.2;
  const learningStreak = user?.student_study_streak || 0;

  const isPremium = user?.subscription_status === 'premium';
  const isFreeTrial = user?.subscription_status === 'free_trial';

  const totalEnrolled = myProgress.length;
  const achievements = Math.floor(completedCourses.length / 2);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Section with Video Background */}
      <div className="relative min-h-[380px] overflow-hidden">
        {/* YouTube Video Background */}
        <div className="absolute inset-0 w-full h-full overflow-hidden">
          <iframe
            src="https://www.youtube.com/embed/ZXsQAXx_ao0?autoplay=1&mute=1&loop=1&controls=0&showinfo=0&rel=0&modestbranding=1&playlist=ZXsQAXx_ao0"
            allow="autoplay; encrypted-media"
            className="absolute pointer-events-none"
            style={{
              width: '100vw',
              height: '56.25vw',
              minHeight: '100vh',
              minWidth: '177.77vh',
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              filter: 'brightness(0.6)',
              border: 'none'
            }}
          />
        </div>
        
        <div className="absolute inset-0 bg-black/30" />
        
        <div className="relative max-w-7xl mx-auto p-8 lg:p-10 z-10">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-5 h-5 text-yellow-400" />
            <span className="text-yellow-400 font-semibold text-xs uppercase tracking-wide">
              Professional Development Platform
            </span>
          </div>
          
          {/* FIXED: Show "Welcome back" when not logged in, "Welcome back, Name" when logged in */}
          <h1 className="text-4xl lg:text-5xl font-bold text-white mb-2 leading-tight">
            {!isAuthenticated || !user ? (
              'Welcome back!'
            ) : (
              <>
                Welcome back, <span className="text-yellow-300">{user.full_name?.split(' ')[0] || 'there'}</span>!
              </>
            )}
          </h1>
          <p className="text-white text-2xl mb-4">👋</p>
          
          <p className="text-base text-white/90 mb-6 max-w-2xl">
            Continue your journey towards professional excellence
          </p>
          
          <div className="flex gap-3 flex-wrap mb-6">
            <Link to={createPageUrl("Courses")}>
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white shadow-xl">
                <Play className="w-4 h-4 mr-2" />
                Continue Learning
              </Button>
            </Link>
            <Link to={createPageUrl("AssessmentTest")}>
              <Button size="lg" className="bg-purple-600 hover:bg-purple-700 text-white shadow-xl">
                <Brain className="w-4 h-4 mr-2" />
                Take Knowledge Test
              </Button>
            </Link>
            <Link to={createPageUrl("CareerTest")}>
              <Button size="lg" className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white shadow-xl">
                <Briefcase className="w-4 h-4 mr-2" />
                Career Test
              </Button>
            </Link>
          </div>

          {/* Quick Stats - Inline */}
          <div className="flex gap-8 text-white">
            <div className="text-center">
              <p className="text-3xl font-bold">{activeCourses.length}</p>
              <p className="text-xs text-white/80">Active Courses</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold">{completedCourses.length}</p>
              <p className="text-xs text-white/80">Completed</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold">{courses.length}</p>
              <p className="text-xs text-white/80">Available</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-6 space-y-6">
        
        {/* NEW: Business Game Promo */}
        <Link to={createPageUrl("XPShop")}>
          <Card className="border-none shadow-2xl bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 hover:shadow-yellow-500/50 transition-all cursor-pointer transform hover:scale-[1.02]">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                    <Trophy className="w-10 h-10 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-white mb-1">🎮 The Ultimate Business Game</h3>
                    <p className="text-white/90">Build your empire • Invest • Compete on leaderboard</p>
                  </div>
                </div>
                <Badge className="bg-white text-orange-600 px-6 py-2 text-lg font-bold shadow-xl">
                  PLAY NOW
                </Badge>
              </div>
            </CardContent>
          </Card>
        </Link>
        
        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="border-none shadow-lg bg-gradient-to-br from-blue-600 to-blue-700 text-white">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <BookOpen className="w-5 h-5" />
                <p className="text-xs font-semibold">Active Courses 📖</p>
              </div>
              <p className="text-4xl font-bold mb-1">{activeCourses.length}</p>
              <p className="text-xs text-blue-200">In progress</p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-purple-600 to-purple-700 text-white">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Award className="w-5 h-5" />
                <p className="text-xs font-semibold">Completed 🏆</p>
              </div>
              <p className="text-4xl font-bold mb-1">{completedCourses.length}</p>
              <p className="text-xs text-purple-200">Courses finished</p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-green-600 to-green-700 text-white">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-5 h-5" />
                <p className="text-xs font-semibold">Available 🎯</p>
              </div>
              <p className="text-4xl font-bold mb-1">{courses.length}</p>
              <p className="text-xs text-green-200">Ready to learn</p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-red-600 to-orange-600 text-white">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="w-5 h-5" />
                <p className="text-xs font-semibold">Upcoming Events 📅</p>
              </div>
              <p className="text-4xl font-bold mb-1">{events.length}</p>
              <p className="text-xs text-orange-200">Don't miss out</p>
            </CardContent>
          </Card>
        </div>

        {/* Large Stats Card with Motivation */}
        <Card className="border-none shadow-2xl bg-gradient-to-br from-purple-900 via-indigo-900 to-purple-900 text-white">
          <CardContent className="p-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6">
              <div className="text-center">
                <Flame className="w-8 h-8 mx-auto mb-2 text-orange-400" />
                <p className="text-4xl font-bold mb-1">{learningStreak}</p>
                <p className="text-sm text-white/80">Day Streak 🔥</p>
              </div>
              <div className="text-center">
                <Clock className="w-8 h-8 mx-auto mb-2 text-blue-400" />
                <p className="text-4xl font-bold mb-1">{Math.round(totalLearningHours)}</p>
                <p className="text-sm text-white/80">Hours Learned ⏰</p>
              </div>
              <div className="text-center">
                <Trophy className="w-8 h-8 mx-auto mb-2 text-yellow-400" />
                <p className="text-4xl font-bold mb-1">{achievements}</p>
                <p className="text-sm text-white/80">Achievements 🏆</p>
              </div>
              <div className="text-center">
                <Zap className="w-8 h-8 mx-auto mb-2 text-green-400" />
                <p className="text-4xl font-bold mb-1">{totalEnrolled}</p>
                <p className="text-sm text-white/80">Total Enrolled ⚡</p>
              </div>
            </div>
            
            <div className="bg-white/10 rounded-xl p-4 backdrop-blur-sm flex items-center justify-between">
              <div>
                {/* FIXED: Show motivational message based on login status */}
                <h3 className="text-xl font-bold mb-1">
                  {!isAuthenticated || !user ? (
                    'Ready to Start Learning? 🚀'
                  ) : (
                    <>Keep Going, {user.full_name?.split(' ')[0] || 'there'}! 🚀</>
                  )}
                </h3>
                <p className="text-sm text-white/80">
                  {!isAuthenticated || !user 
                    ? 'Login to unlock your personalized dashboard and track your progress'
                    : "You're crushing it! Complete more courses to unlock achievements."}
                </p>
              </div>
              <Link to={createPageUrl("Courses")}>
                <Button className="bg-green-600 hover:bg-green-700 shadow-lg">
                  Browse Courses
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Two Column Layout */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Continue Learning */}
            {isAuthenticated && activeCourses.length > 0 && (
              <Card className="border-none shadow-xl bg-white">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <ArrowRight className="w-5 h-5 text-blue-600" />
                      Continue Learning
                    </CardTitle>
                    <Link to={createPageUrl("Courses")}>
                      <Button variant="ghost" size="sm">
                        View All
                        <ArrowRight className="w-4 h-4 ml-1" />
                      </Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {activeCourses.slice(0, 3).map((progress) => {
                    const course = courses.find((c) => c.id === progress.course_id);
                    if (!course) return null;

                    return (
                      <Link key={progress.id} to={createPageUrl(`Learning?courseId=${course.id}`)}>
                        <div className="p-4 border-2 rounded-xl hover:border-blue-400 hover:shadow-md transition-all cursor-pointer">
                          <div className="flex gap-4">
                            <div className="w-16 h-16 rounded-lg overflow-hidden bg-gradient-to-br from-blue-500 to-purple-600 flex-shrink-0">
                              {course.thumbnail_url ?
                                <img src={course.thumbnail_url} alt={course.title} className="w-full h-full object-cover" /> :
                                <div className="w-full h-full flex items-center justify-center">
                                  <BookOpen className="w-6 h-6 text-white" />
                                </div>
                              }
                            </div>
                            
                            <div className="flex-1 min-w-0">
                              <h3 className="font-semibold text-slate-900 mb-1 text-sm">{course.title}</h3>
                              <p className="text-xs text-slate-500 mb-2">{course.category?.replace(/_/g, ' ')}</p>
                              <div className="flex items-center gap-2">
                                <Progress value={progress.progress_percentage} className="h-2 flex-1" />
                                <span className="text-xs font-medium text-blue-600">{progress.progress_percentage}%</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </Link>
                    );
                  })}
                </CardContent>
              </Card>
            )}
            {!isAuthenticated && (
              <Card className="border-none shadow-xl bg-white">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <LogIn className="w-5 h-5 text-blue-600" />
                    Join Us!
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-700 mb-4">Log in or sign up to start your learning journey and track your progress.</p>
                  <Button onClick={() => base44.auth.redirectToLogin()} className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-lg" size="lg">
                    <LogIn className="w-5 h-5 mr-2" />
                    Sign In / Login
                  </Button>
                </CardContent>
              </Card>
            )}
            {isAuthenticated && activeCourses.length === 0 && (
              <Card className="border-none shadow-xl bg-white">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-blue-600" />
                    Start Learning
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-700 mb-4">You haven't started any courses yet. Explore our catalog and begin your journey!</p>
                  <Link to={createPageUrl("Courses")}>
                    <Button>Browse Courses</Button>
                  </Link>
                </CardContent>
              </Card>
            )}

            {/* Find Perfect Learning Path */}
            <Card className="border-none shadow-xl bg-gradient-to-br from-red-900 to-purple-900 text-white">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center flex-shrink-0">
                    <Brain className="w-8 h-8" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-2">🎯 Find Your Perfect Learning Path</h3>
                    <p className="text-sm text-white/90 mb-4">
                      Take our personalized assessment to discover courses matched to your goals and skill level
                    </p>
                    <Link to={createPageUrl("AssessmentTest")}>
                      <Button className="bg-white text-purple-900 hover:bg-white/90">
                        Take Test
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Upcoming Events */}
            <Card className="border-none shadow-xl bg-white">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Calendar className="w-5 h-5 text-purple-600" />
                    Upcoming Events
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {events.length > 0 ? (
                  events.slice(0, 3).map((event) => (
                    <div key={event.id} className="p-3 bg-slate-50 rounded-lg">
                      <h4 className="font-semibold text-sm text-slate-900">{event.title}</h4>
                      <p className="text-xs text-slate-500">📅 {new Date(event.date).toLocaleDateString()}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-slate-500">No upcoming events</p>
                )}
                <Link to={createPageUrl("Events")}>
                  <Button variant="ghost" size="sm" className="w-full">
                    View All Events
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Community */}
            <Card className="border-none shadow-xl bg-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Users className="w-5 h-5 text-green-600" />
                  Community
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {posts.length > 0 ? (
                  posts.slice(0, 2).map((post) => (
                    <div key={post.id} className="p-3 bg-slate-50 rounded-lg">
                      <h4 className="font-semibold text-sm text-slate-900 line-clamp-1">{post.title}</h4>
                      <p className="text-xs text-slate-500">{post.author_name}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-slate-500">No recent posts</p>
                )}
                <Link to={createPageUrl("Community")}>
                  <Button variant="ghost" size="sm" className="w-full">
                    View Community
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* IQ & Personality Tests */}
        <div className="grid md:grid-cols-2 gap-6">
          <Link to={createPageUrl("PersonalityTest")}>
            <Card className="border-none shadow-xl hover:shadow-2xl transition-all cursor-pointer bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200">
              <CardContent className="p-8">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <Brain className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-slate-900">Personality Test</h3>
                    <p className="text-sm text-purple-600 font-semibold">16 Personalities</p>
                  </div>
                </div>
                <p className="text-slate-600 mb-4">Discover your unique personality type through interactive questions</p>
                <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                  <Play className="w-4 h-4 mr-2" />
                  Take Personality Test
                </Button>
              </CardContent>
            </Card>
          </Link>

          <Link to={createPageUrl("IQTest")}>
            <Card className="border-none shadow-xl hover:shadow-2xl transition-all cursor-pointer bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200">
              <CardContent className="p-8">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <Brain className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-slate-900">IQ Challenge</h3>
                    <p className="text-sm text-blue-600 font-semibold">Test Your Intelligence</p>
                  </div>
                </div>
                <p className="text-slate-600 mb-4">Test your cognitive abilities with engaging questions</p>
                <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                  <Play className="w-4 h-4 mr-2" />
                  Take IQ Test
                </Button>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>
    </div>
  );
}
