import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, ExternalLink, RefreshCw, Maximize2 } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function UniversityPortal() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching user:", error);
        setLoading(false);
      }
    };
    fetchUser();
  }, []);

  const UNIVERSITY_PORTALS = {
    thomas_more: {
      name: 'Thomas More',
      portal: 'Canvas',
      url: 'https://thomasmore.instructure.com',
      iframe: true,
      icon: '📚',
      color: 'from-green-500 to-emerald-600'
    }
  };

  const userUniversity = user?.university ? UNIVERSITY_PORTALS[user.university] : null;

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!userUniversity || !userUniversity.iframe) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-12 text-center">
            <p className="text-slate-600 mb-6">Your university portal is not available in-app.</p>
            <Link to={createPageUrl("StudentSpace")}>
              <Button>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Student Space
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col">
      {/* Header */}
      <div className={`bg-gradient-to-r ${userUniversity.color} p-4 shadow-lg`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("StudentSpace")}>
              <Button variant="outline" className="bg-white/20 border-white/30 text-white hover:bg-white/30">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <span className="text-4xl">{userUniversity.icon}</span>
              <div>
                <h1 className="text-2xl font-bold text-white">{userUniversity.portal}</h1>
                <p className="text-sm text-white/90">{userUniversity.name}</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Badge className="bg-white/30 text-white border-white/50">
              Embedded Portal
            </Badge>
            <a href={userUniversity.url} target="_blank" rel="noopener noreferrer">
              <Button variant="outline" className="bg-white/20 border-white/30 text-white hover:bg-white/30">
                <ExternalLink className="w-4 h-4 mr-2" />
                Open External
              </Button>
            </a>
          </div>
        </div>
      </div>

      {/* Iframe Container */}
      <div className="flex-1 bg-white">
        <iframe
          src={userUniversity.url}
          className="w-full h-full border-none"
          title={userUniversity.portal}
          sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
        />
      </div>
    </div>
  );
}