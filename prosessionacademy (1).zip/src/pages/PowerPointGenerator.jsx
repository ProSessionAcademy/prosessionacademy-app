
import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from '@/components/ui/tabs';
import {
  Presentation,
  Sparkles,
  Download,
  Loader2,
  Upload,
  FileText,
  X,
  Check,
  Palette,
  Layout,
  Zap,
  BarChart3,
  Image as ImageIcon,
  ArrowLeft,
  Share2,
  MessageSquare,
  Users,
  Eye,
  Save,
  Folder,
  Clock,
  Edit,
  Trash2,
  Send,
  Plus,
  Wand2,
  AlignLeft,
  Maximize2,
  RefreshCw,
  CheckCircle2,
  FileType,
  Layers,
  Lock,
  Crown,
  AlertTriangle
} from 'lucide-react';

// Assuming 'Link' is from react-router-dom or a similar routing library.
// If your project uses a different routing library (e.g., Next.js 'next/link'),
// please adjust the import accordingly.
import { Link } from 'react-router-dom';

// This utility function is implied by the outline.
// In a full application, this would typically be a shared helper or part of a routing setup.
const createPageUrl = (pageName) => {
  // This is a basic example mapping a page name to a URL path.
  // Adjust according to your application's actual routing structure.
  switch (pageName) {
    case "Subscription":
      return "/subscription"; // Example: path to your subscription page
    // Add other page mappings as needed
    default:
      console.warn(`createPageUrl: No known path for pageName "${pageName}". Returning root path.`);
      return "/";
  }
};

const THEMES = [
  {
    value: 'professional',
    label: 'Professional Blue',
    bg: '#1E3A8A',
    text: '#FFFFFF',
    accent: '#3B82F6',
    preview: 'linear-gradient(135deg, #1E3A8A 0%, #3B82F6 100%)',
    description: 'Classic, corporate, trustworthy'
  },
  {
    value: 'vibrant',
    label: 'Vibrant Purple',
    bg: '#9333EA',
    text: '#FFFFFF',
    accent: '#EC4899',
    preview: 'linear-gradient(135deg, #9333EA 0%, #EC4899 100%)',
    description: 'Creative, energetic, modern'
  },
  {
    value: 'minimal',
    label: 'Minimal White',
    bg: '#F8FAFC',
    text: '#1E293B',
    accent: '#3B82F6',
    preview: 'linear-gradient(135deg, #F8FAFC 0%, #E2E8F0 100%)',
    description: 'Clean, simple, elegant'
  },
  {
    value: 'dark',
    label: 'Dark Mode',
    bg: '#0F172A',
    text: '#FFFFFF',
    accent: '#6366F1',
    preview: 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)',
    description: 'Modern, sleek, professional'
  },
  {
    value: 'nature',
    label: 'Nature Green',
    bg: '#047857',
    text: '#FFFFFF',
    accent: '#10B981',
    preview: 'linear-gradient(135deg, #047857 0%, #10B981 100%)',
    description: 'Fresh, organic, sustainable'
  },
  {
    value: 'sunset',
    label: 'Sunset Orange',
    bg: '#DC2626',
    text: '#FFFFFF',
    accent: '#F97316',
    preview: 'linear-gradient(135deg, #DC2626 0%, #F97316 100%)',
    description: 'Bold, energetic, attention-grabbing'
  }
];

const TEMPLATES = [
  {
    id: 'business_pitch',
    name: 'Business Pitch',
    description: 'Perfect for investor presentations and business proposals',
    icon: '💼',
    theme: 'professional',
    structure: 'problem_solution',
    defaultSlides: 12,
    sampleSlides: ['Problem Statement', 'Market Opportunity', 'Solution Overview', 'Business Model', 'Competitive Analysis', 'Financial Projections']
  },
  {
    id: 'training_session',
    name: 'Training Session',
    description: 'Ideal for employee training and educational content',
    icon: '📚',
    theme: 'vibrant',
    structure: 'chronological',
    defaultSlides: 15,
    sampleSlides: ['Introduction', 'Learning Objectives', 'Key Concepts', 'Practical Examples', 'Exercises', 'Summary & Quiz']
  },
  {
    id: 'product_launch',
    name: 'Product Launch',
    description: 'Showcase new products with impact',
    icon: '🚀',
    theme: 'sunset',
    structure: 'storytelling',
    defaultSlides: 10,
    sampleSlides: ['The Big Reveal', 'Problem We Solve', 'Features & Benefits', 'Demo', 'Pricing', 'Call to Action']
  },
  {
    id: 'quarterly_review',
    name: 'Quarterly Review',
    description: 'Data-driven performance and metrics review',
    icon: '📊',
    theme: 'minimal',
    structure: 'data_driven',
    defaultSlides: 18,
    sampleSlides: ['Executive Summary', 'Key Metrics', 'Performance Analysis', 'Goals vs Actuals', 'Challenges', 'Next Quarter Plan']
  },
  {
    id: 'research_findings',
    name: 'Research Findings',
    description: 'Present research results and insights',
    icon: '🔬',
    theme: 'dark',
    structure: 'cause_effect',
    defaultSlides: 20,
    sampleSlides: ['Research Question', 'Methodology', 'Data Collection', 'Analysis', 'Findings', 'Conclusions']
  },
  {
    id: 'marketing_strategy',
    name: 'Marketing Strategy',
    description: 'Comprehensive marketing plans and campaigns',
    icon: '📈',
    theme: 'nature',
    structure: 'comparison',
    defaultSlides: 14,
    sampleSlides: ['Market Analysis', 'Target Segments', 'Campaign Strategy', 'Channel Mix', 'Budget Allocation', 'Success Metrics']
  }
];

const SLIDE_STRUCTURES = [
  { value: 'problem_solution', label: 'Problem → Solution', description: 'Identify issues and present solutions' },
  { value: 'chronological', label: 'Chronological', description: 'Timeline-based progression' },
  { value: 'comparison', label: 'Comparison', description: 'Compare options or scenarios' },
  { value: 'cause_effect', label: 'Cause & Effect', description: 'Show relationships and outcomes' },
  { value: 'storytelling', label: 'Storytelling', description: 'Narrative-driven approach' },
  { value: 'data_driven', label: 'Data-Driven', description: 'Focus on metrics and analytics' }
];

const PRESENTATION_LENGTHS = [
  { value: '5min', label: '5 minutes', slides: 5 },
  { value: '10min', label: '10 minutes', slides: 8 },
  { value: '15min', label: '15 minutes', slides: 12 },
  { value: '30min', label: '30 minutes', slides: 20 },
  { value: '45min', label: '45 minutes', slides: 30 },
  { value: '60min', label: '60 minutes', slides: 40 }
];

export default function PowerPointGenerator() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const [userPlan, setUserPlan] = useState(null);
  const [limitReached, setLimitReached] = useState(false);
  const [activeTab, setActiveTab] = useState('create');

  const [topic, setTopic] = useState('');
  const [description, setDescription] = useState('');
  const [targetAudience, setTargetAudience] = useState('');
  const [presentationLength, setPresentationLength] = useState('15min');
  const [slideStructure, setSlideStructure] = useState('problem_solution');
  const [slideCount, setSlideCount] = useState(10);
  const [theme, setTheme] = useState('professional');
  const [showThemePreview, setShowThemePreview] = useState(false);
  const [showTemplatePreview, setShowTemplatePreview] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [generating, setGenerating] = useState(false); // Reusing for both AI generation and PDF download
  const [generationStatus, setGenerationStatus] = useState('');
  const [generatedHTML, setGeneratedHTML] = useState('');
  const [presentationTitle, setPresentationTitle] = useState('');
  const [currentPresentationId, setCurrentPresentationId] = useState(null);

  const [showShareDialog, setShowShareDialog] = useState(false);
  const [shareEmail, setShareEmail] = useState('');
  const [sharePermission, setSharePermission] = useState('view');
  const [selectedPresentation, setSelectedPresentation] = useState(null);
  const [showCommentDialog, setShowCommentDialog] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [commentSlideNumber, setCommentSlideNumber] = useState(1);

  const [showAIEnhanceDialog, setShowAIEnhanceDialog] = useState(false);
  const [enhanceAction, setEnhanceAction] = useState('summarize');
  const [enhanceInput, setEnhanceInput] = useState('');
  const [enhanceAudience, setEnhanceAudience] = useState('executive');
  const [enhancing, setEnhancing] = useState(false);
  const [enhancedResult, setEnhancedResult] = useState('');

  useEffect(() => {
    const fetchUser = async () => {
      try {
        let currentUser = await base44.auth.me();

        // Reset usage if needed
        const now = new Date();
        const resetDate = currentUser.usage_reset_date ? new Date(currentUser.usage_reset_date) : null;

        if (!resetDate || now >= resetDate) {
          const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);
          await base44.auth.updateMe({
            monthly_practice_sessions_used: 0,
            monthly_ai_images_used: 0,
            monthly_ppt_generations_used: 0,
            monthly_group_posts_used: 0,
            monthly_community_posts_used: 0,
            monthly_file_uploads_used: 0,
            usage_reset_date: nextMonth.toISOString()
          });
          // Update the local currentUser object after reset
          currentUser = {
            ...currentUser,
            monthly_ppt_generations_used: 0,
            monthly_ai_images_used: 0,
            monthly_group_posts_used: 0,
            monthly_community_posts_used: 0,
            monthly_file_uploads_used: 0,
            usage_reset_date: nextMonth.toISOString()
          };
        }

        setUser(currentUser);

        if (currentUser && currentUser.subscription_plan_id) {
          const plans = await base44.entities.SubscriptionPlan.filter({ id: currentUser.subscription_plan_id });
          const plan = plans[0];
          setUserPlan(plan);
          setHasAccess(plan?.features?.access_ppt_generator === true);

          const maxPPT = plan?.features?.max_ppt_generations || 0;
          const used = currentUser.monthly_ppt_generations_used || 0;
          if (maxPPT !== -1 && used >= maxPPT) {
            setLimitReached(true);
          } else {
            setLimitReached(false);
          }
        } else {
          setHasAccess(false);
          setLimitReached(true); // If no plan or no access, limit reached for free tier users
        }

        setLoading(false);
      } catch (error) {
        console.error('Error fetching user or subscription:', error);
        setHasAccess(false);
        setLimitReached(true); // Assume limited/no access on error
        setLoading(false);
      }
    };
    fetchUser();
  }, []);

  const { data: presentations = [] } = useQuery({
    queryKey: ['presentations', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      const myPresentations = await base44.entities.Presentation.filter({ created_by: user.email }, '-created_date');
      const sharedPresentations = await base44.entities.Presentation.list('-created_date');
      return [
        ...myPresentations,
        ...sharedPresentations.filter(p =>
          p.shared_with?.some(s => s.email === user.email) &&
          !myPresentations.find(mp => mp.id === p.id)
        )
      ];
    },
    enabled: !!user?.email && hasAccess,
    initialData: []
  });

  const savePresentationMutation = useMutation({
    mutationFn: (data) => base44.entities.Presentation.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['presentations'] });
      alert('✅ Presentation saved!');
      setActiveTab('my_presentations');
    }
  });

  const sharePresentationMutation = useMutation({
    mutationFn: async ({ presentationId, shareData }) => {
      try {
        const presentation = presentations.find(p => p.id === presentationId);
        if (!presentation) throw new Error('Presentation not found');

        console.log('🔍 Sharing presentation:', presentation.title);
        console.log('📧 To email:', shareData.email);

        // First update the database
        const sharedWith = [...(presentation.shared_with || [])];
        if (!sharedWith.find(s => s.email === shareData.email)) {
          sharedWith.push(shareData);
        }

        await base44.entities.Presentation.update(presentationId, { shared_with: sharedWith });
        console.log('✅ Database updated');

        // Then send email
        const appUrl = window.location.origin + window.location.pathname;
        const presentationUrl = appUrl.replace(/\/[^/]*$/, '') + '#/PowerPointGenerator';

        console.log('📧 Sending email to:', shareData.email);

        const emailResult = await base44.integrations.Core.SendEmail({
          to: shareData.email,
          subject: `📊 ${user.full_name || user.email} shared a presentation with you`,
          body: `Hello!

${user.full_name || user.email} has shared a presentation with you on Pro-Session.

📊 PRESENTATION DETAILS:
━━━━━━━━━━━━━━━━━━━━━━━━
📌 Title: ${presentation.title}
${presentation.topic ? `🎯 Topic: ${presentation.topic}` : ''}
📄 Slides: ${presentation.slide_count}
🎨 Theme: ${presentation.theme}
${presentation.target_audience ? `👥 Audience: ${presentation.target_audience}` : ''}
${presentation.presentation_length ? `⏱️ Length: ${presentation.presentation_length}` : ''}

🔑 YOUR ACCESS LEVEL:
${shareData.permission === 'view' ? '👁️ View Only - You can view the presentation' : ''}
${shareData.permission === 'comment' ? '💬 Comment - You can view and leave comments' : ''}
${shareData.permission === 'edit' ? '✏️ Edit - You can view, comment, and edit' : ''}

━━━━━━━━━━━━━━━━━━━━━━━━
🎯 HOW TO ACCESS:
━━━━━━━━━━━━━━━━━━━━━━━━

1. Go to: ${presentationUrl}
2. Login with your Pro-Session account
3. Click "My Presentations" tab
4. Find "${presentation.title}"
5. Click "View" to open it

━━━━━━━━━━━━━━━━━━━━━━━━

✅ The presentation is now in your "My Presentations" library
✅ You can access it anytime from the PowerPoint Generator page

---
Shared on: ${new Date().toLocaleString()}
From: ${user.full_name || user.email} (${user.email})

This is a Pro-Session Platform notification.`
        });

        console.log('✅ Email send result:', emailResult);

        return { success: true, emailSent: true };
      } catch (error) {
        console.error('❌ Sharing error:', error);
        throw error;
      }
    },
    onSuccess: (result) => {
      console.log('✅ Share mutation success:', result);
      queryClient.invalidateQueries({ queryKey: ['presentations'] });
      setShowShareDialog(false);
      setShareEmail('');
      setSharePermission('view');
      alert('✅ Presentation shared successfully!\n\n📧 Email notification sent to recipient.\n\nCheck browser console for detailed logs.\n\nRecipient will see it in their "My Presentations" tab.');
    },
    onError: (error) => {
      console.error('❌ Share mutation error:', error);
      alert(`❌ Failed to share presentation!\n\nError: ${error.message}\n\nCheck browser console for details.`);
    }
  });

  const addCommentMutation = useMutation({
    mutationFn: async ({ presentationId, comment }) => {
      const presentation = presentations.find(p => p.id === presentationId);
      if (!presentation) throw new Error('Presentation not found');

      const comments = [...(presentation.comments || []), comment];
      await base44.entities.Presentation.update(presentationId, { comments });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['presentations'] });
      setShowCommentDialog(false);
      setNewComment('');
      alert('✅ Comment added!');
    }
  });

  const deletePresentationMutation = useMutation({
    mutationFn: (id) => base44.entities.Presentation.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['presentations'] });
      setSelectedPresentation(null);
    }
  });

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setUploading(true);
    try {
      const fileUrls = [];
      for (let file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        fileUrls.push({ name: file.name, url: file_url });
      }
      setUploadedFiles([...uploadedFiles, ...fileUrls]);
      alert(`✅ ${files.length} file(s) uploaded!`);
    } catch (error) {
      alert('❌ Upload failed: ' + error.message);
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleDownload = async () => {
    if (!generatedHTML || !presentationTitle) return;

    setGenerating(true);
    try {
      const slidesData = JSON.parse(sessionStorage.getItem('lastGeneratedSlides') || '[]');
      const presentationData = JSON.parse(sessionStorage.getItem('lastGeneratedData') || '{}');
      const selectedTheme = THEMES.find(t => t.value === theme) || THEMES[0];

      const response = await base44.functions.invoke('generatePowerPointPDF', {
        presentationData: presentationData,
        slidesData: slidesData,
        theme: selectedTheme
      });

      if (response.data.pdfBase64) {
        const binary = atob(response.data.pdfBase64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        const blob = new Blob([bytes], { type: 'application/pdf' });
        
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = response.data.filename || `Presentation_${presentationTitle.replace(/[^a-z0-9]/gi, '_').substring(0, 50)}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);

        alert('✅ PDF Downloaded!');
      } else {
        throw new Error('No PDF data received from the server.');
      }
    } catch (error) {
      console.error('PDF error:', error);
      alert('❌ Failed: ' + error.message);
    } finally {
      setGenerating(false);
    }
  };

  const handleApplyTemplate = (template) => {
    setTheme(template.theme);
    setSlideStructure(template.structure);
    setSlideCount(template.defaultSlides);
    const length = PRESENTATION_LENGTHS.find(l => l.slides >= template.defaultSlides) || PRESENTATION_LENGTHS[2];
    setPresentationLength(length.value);
    setShowTemplatePreview(false);
    alert(`✅ Template "${template.name}" applied!\n\nYou can now customize and generate.`);
  };

  const handleAIEnhance = async () => {
    if (!enhanceInput.trim()) {
      alert('Please enter content to enhance');
      return;
    }

    setEnhancing(true);
    setEnhancedResult('');

    try {
      let prompt = '';

      if (enhanceAction === 'summarize') {
        prompt = `Summarize this presentation content into 3-5 key takeaways:

${enhanceInput}

Make it concise and impactful.`;
      } else if (enhanceAction === 'expand') {
        prompt = `Expand on these bullet points with more detail and examples:

${enhanceInput}

Add context, explanations, and real-world examples. Make each point 2-3 sentences.`;
      } else if (enhanceAction === 'rephrase') {
        prompt = `Rephrase this content for a ${enhanceAudience} audience:

${enhanceInput}

${enhanceAudience === 'executive' ? 'Make it high-level, strategic, and concise. Focus on impact and ROI.' : ''}
${enhanceAudience === 'technical' ? 'Make it detailed, technical, and comprehensive. Include specifics and methodologies.' : ''}
${enhanceAudience === 'general' ? 'Make it simple, accessible, and easy to understand. Avoid jargon.' : ''}
${enhanceAudience === 'academic' ? 'Make it formal, research-based, and well-structured. Use academic language.' : ''}`;
      } else if (enhanceAction === 'grammar') {
        prompt = `Check this content for grammar, spelling, and clarity issues. Fix any errors and suggest improvements:

${enhanceInput}

Return the corrected version and list the changes made.`;
      }

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: prompt
      });

      setEnhancedResult(result);
    } catch (error) {
      alert('❌ Enhancement failed: ' + error.message);
    } finally {
      setEnhancing(false);
    }
  };

  const handleGenerate = async () => {
    if (!topic.trim()) {
      alert('Please enter a presentation topic');
      return;
    }

    // CHECK USAGE LIMIT
    const maxPPT = userPlan?.features?.max_ppt_generations || 0;
    const used = user?.monthly_ppt_generations_used || 0;

    if (maxPPT !== -1 && used >= maxPPT) {
      alert(`🚫 Monthly Limit Reached!\n\nYou've generated ${used}/${maxPPT} presentations this month.\n\nUpgrade to get unlimited generations!`);
      setLimitReached(true);
      return;
    }

    setGenerating(true);
    setGenerationStatus('🤖 Creating detailed slides...');

    try {
      const selectedTheme = THEMES.find(t => t.value === theme) || THEMES[0];
      const structureGuide = SLIDE_STRUCTURES.find(s => s.value === slideStructure);

      const aiPrompt = `Create a professional, DETAILED presentation about: "${topic}"

${description ? `Context: ${description}` : ''}

TARGET AUDIENCE: ${targetAudience || 'General audience'}
PRESENTATION LENGTH: ${presentationLength} (aim for concise, impactful content)
SLIDE STRUCTURE: ${structureGuide?.label} - ${structureGuide?.description}

Generate exactly ${(slideCount || 10) - 2} content slides following the ${slideStructure} structure.

For each slide provide:
- title: clear, engaging heading (max 60 chars)
- content: 4-6 detailed bullet points (each 80-150 chars) tailored to ${targetAudience || 'the audience'}
- detailed_explanation: 2-3 sentences elaborating on the key message (max 300 chars)
- icon_suggestion: relevant emoji that fits the slide content
- image_keyword: 2-4 specific keywords separated by commas

Structure guidance:
${slideStructure === 'problem_solution' ? '- Start with problem identification\n- Present multiple solutions\n- Show implementation steps' : ''}
${slideStructure === 'chronological' ? '- Follow timeline order\n- Show progression\n- Highlight key milestones' : ''}
${slideStructure === 'comparison' ? '- Present options side-by-side\n- Show pros and cons\n- Provide recommendation' : ''}
${slideStructure === 'cause_effect' ? '- Identify root causes\n- Show impact chain\n- Present outcomes' : ''}
${slideStructure === 'storytelling' ? '- Begin with hook\n- Build narrative\n- Conclude with impact' : ''}
${slideStructure === 'data_driven' ? '- Lead with data\n- Support with evidence\n- Draw insights' : ''}

Make it professional, engaging, and perfectly suited for ${targetAudience || 'the audience'}.`;

      const aiData = await base44.integrations.Core.InvokeLLM({
        prompt: aiPrompt,
        file_urls: uploadedFiles.length > 0 ? uploadedFiles.map(f => f.url) : undefined,
        response_json_schema: {
          type: "object",
          properties: {
            presentation_title: { type: "string" },
            subtitle: { type: "string" },
            slides: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  content: { type: "array", items: { type: "string" } },
                  detailed_explanation: { type: "string" },
                  icon_suggestion: { type: "string" },
                  image_keyword: { type: "string" }
                },
                required: ["title", "content"]
              }
            }
          },
          required: ["presentation_title", "slides"]
        }
      });

      setPresentationTitle(aiData.presentation_title);
      setGenerationStatus('🎨 Adding stock photos...');

      const slidesWithImages = aiData.slides.map((slide) => {
        if (slide.image_keyword) {
          const keywords = slide.image_keyword.split(',').map(k => k.trim()).join(',');
          const unsplashUrl = `https://source.unsplash.com/featured/1200x600/?${keywords}`;
          return { ...slide, image_url: unsplashUrl };
        }
        return slide;
      });

      // Store for PDF generation
      sessionStorage.setItem('lastGeneratedSlides', JSON.stringify(slidesWithImages));
      sessionStorage.setItem('lastGeneratedData', JSON.stringify(aiData));

      setGenerationStatus('📊 Designing beautiful slides...');

      const htmlContent = generateHTMLPresentation(aiData, slidesWithImages, selectedTheme);

      setGeneratedHTML(htmlContent);
      setGenerationStatus('');

      // INCREMENT USAGE COUNTER AFTER SUCCESSFUL GENERATION
      const newCount = (user.monthly_ppt_generations_used || 0) + 1;
      await base44.auth.updateMe({
        monthly_ppt_generations_used: newCount
      });
      setUser({ ...user, monthly_ppt_generations_used: newCount });

      if (maxPPT !== -1 && newCount >= maxPPT) {
        setLimitReached(true);
      }

    } catch (error) {
      console.error('Generation error:', error);
      alert('❌ Failed: ' + error.message);
      setGenerationStatus('');
    } finally {
      setGenerating(false);
    }
  };

  const generateHTMLPresentation = (aiData, slidesWithImages, selectedTheme) => {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${aiData.presentation_title}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
        }
        .presentation { max-width: 1200px; margin: 0 auto; }
        .slide {
            background: white;
            border-radius: 20px;
            padding: 60px;
            margin-bottom: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            page-break-inside: avoid;
            min-height: 600px;
            display: flex;
            flex-direction: column;
            position: relative;
        }
        .slide-number {
            position: absolute;
            bottom: 20px;
            right: 30px;
            font-size: 14px;
            color: #888;
            font-weight: 600;
        }
        .title-slide {
            background: ${selectedTheme.preview};
            color: ${selectedTheme.text};
            justify-content: center;
            text-align: center;
        }
        .title-slide h1 { font-size: 56px; font-weight: 800; margin-bottom: 20px; }
        .title-slide .subtitle { font-size: 28px; opacity: 0.9; }
        .content-slide h2 {
            font-size: 42px;
            color: ${selectedTheme.bg};
            margin-bottom: 30px;
            font-weight: 700;
            border-left: 6px solid ${selectedTheme.accent};
            padding-left: 20px;
        }
        .slide-icon { font-size: 48px; margin-bottom: 20px; }
        .slide-image {
            width: 100%;
            height: 280px;
            object-fit: cover;
            border-radius: 15px;
            margin: 20px 0;
            box-shadow: 0 8px 24px rgba(0,0,0,0.15);
        }
        .content-list { list-style: none; margin: 20px 0; }
        .content-list li {
            font-size: 20px;
            line-height: 1.8;
            margin-bottom: 12px;
            padding-left: 40px;
            position: relative;
            color: #333;
        }
        .content-list li:before {
            content: "▸";
            position: absolute;
            left: 0;
            color: ${selectedTheme.accent};
            font-size: 28px;
            font-weight: bold;
        }
        .detailed-explanation {
            background: #f8fafc;
            padding: 20px;
            border-radius: 12px;
            margin-top: 20px;
            border-left: 4px solid ${selectedTheme.accent};
            font-size: 18px;
            color: #475569;
        }
        .closing-slide {
            background: ${selectedTheme.preview};
            color: ${selectedTheme.text};
            justify-content: center;
            text-align: center;
        }
        .closing-slide h2 { font-size: 64px; color: ${selectedTheme.text}; }
        @media print {
            body { background: white; padding: 0; }
            .slide { page-break-after: always; margin: 0; }
        }
    </style>
</head>
<body>
    <div class="presentation">
        <div class="slide title-slide">
            <div>
                <h1>${aiData.presentation_title}</h1>
                ${aiData.subtitle ? `<div class="subtitle">${aiData.subtitle}</div>` : ''}
            </div>
        </div>

        ${slidesWithImages.map((slide, idx) => {
            return `
        <div class="slide content-slide">
            ${slide.icon_suggestion ? `<div class="slide-icon">${slide.icon_suggestion}</div>` : ''}
            <h2>${slide.title}</h2>
            ${slide.image_url ? `<img src="${slide.image_url}" alt="${slide.title}" class="slide-image" onerror="this.src='https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=1200&h=600'; this.onerror=null;" />` : ''}
            <ul class="content-list">
                ${slide.content.map(item => `<li>${item}</li>`).join('')}
            </ul>
            ${slide.detailed_explanation ? `<div class="detailed-explanation"><strong>💡 Key Insight:</strong> ${slide.detailed_explanation}</div>` : ''}
            <div class="slide-number">${idx + 2}</div>
        </div>
            `;
        }).join('')}

        <div class="slide closing-slide">
            <div><h2>Thank You! 🎉</h2><p>Questions?</p></div>
        </div>
    </div>
</body>
</html>`;
  };

  const handleSavePresentation = () => {
    if (!generatedHTML || !user) return;

    savePresentationMutation.mutate({
      title: presentationTitle,
      created_by: user.email,
      created_by_name: user.full_name || user.email,
      topic: topic,
      description: description,
      html_content: generatedHTML,
      slide_count: slideCount,
      theme: theme,
      target_audience: targetAudience,
      presentation_length: presentationLength,
      slide_structure: slideStructure,
      shared_with: [],
      comments: [],
      tags: [],
      last_edited_by: user.email,
      last_edited_date: new Date().toISOString()
    });
  };

  const handleSharePresentation = async () => {
    if (!shareEmail.trim() || !selectedPresentation) {
      alert('Please enter an email address');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(shareEmail)) {
      alert('⚠️ Please enter a valid email address');
      return;
    }

    console.log('🚀 Starting share process...');
    console.log('📊 Presentation:', selectedPresentation.title);
    console.log('📧 Recipient:', shareEmail);
    console.log('🔑 Permission:', sharePermission);

    sharePresentationMutation.mutate({
      presentationId: selectedPresentation.id,
      shareData: {
        email: shareEmail,
        name: shareEmail,
        permission: sharePermission,
        shared_date: new Date().toISOString()
      }
    });
  };

  const handleAddComment = () => {
    if (!newComment.trim() || !selectedPresentation || !user) return;

    addCommentMutation.mutate({
      presentationId: selectedPresentation.id,
      comment: {
        id: Date.now().toString(),
        user_email: user.email,
        user_name: user.full_name || user.email,
        slide_number: commentSlideNumber,
        comment: newComment,
        timestamp: new Date().toISOString(),
        resolved: false
      }
    });
  };

  const handleReset = () => {
    setGeneratedHTML('');
    setPresentationTitle('');
    setTopic('');
    setDescription('');
    setTargetAudience('');
    setUploadedFiles([]);
    setCurrentPresentationId(null);
  };

  const handleLoadPresentation = (presentation) => {
    setGeneratedHTML(presentation.html_content);
    setPresentationTitle(presentation.title);
    setCurrentPresentationId(presentation.id);
    setActiveTab('create');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-purple-600 animate-spin" />
      </div>
    );
  }

  // ACCESS CONTROL - Check BEFORE everything else
  if (!hasAccess && user) { // Only show locked screen for logged-in users without access
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-pink-900 flex items-center justify-center p-6">
        <Card className="max-w-2xl border-none shadow-2xl">
          <CardContent className="p-12 text-center">
            <div className="w-24 h-24 bg-purple-600/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Lock className="w-12 h-12 text-purple-500" />
            </div>
            <h2 className="text-3xl font-bold text-slate-900 mb-4">🔒 PowerPoint Generator Locked</h2>
            <p className="text-slate-600 mb-8">Upgrade to access AI-powered presentation creation!</p>

            <Link to={createPageUrl("Subscription")}>
              <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 py-6 px-8 text-xl font-bold shadow-xl">
                <Crown className="w-6 h-6 mr-2" />
                View Plans & Upgrade
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  // USAGE LIMIT REACHED SCREEN
  if (limitReached && user) {
    const used = user.monthly_ppt_generations_used || 0;
    const maxPPT = userPlan?.features?.max_ppt_generations || 0;

    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-900 via-red-900 to-rose-900 flex items-center justify-center p-6">
        <Card className="max-w-2xl border-none shadow-2xl">
          <CardContent className="p-12 text-center">
            <div className="w-24 h-24 bg-orange-600/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertTriangle className="w-12 h-12 text-orange-500" />
            </div>
            <h2 className="text-3xl font-bold text-slate-900 mb-4">⚠️ Monthly PPT Limit Reached</h2>
            <p className="text-slate-700 mb-2">
              You've generated <span className="font-black text-2xl text-red-600">{used}/{maxPPT}</span> presentations this month.
            </p>
            <p className="text-slate-600 mb-8">Upgrade to get unlimited presentations!</p>

            <Link to={createPageUrl("Subscription")}>
              <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 py-6 px-8 text-xl font-bold shadow-xl">
                <Crown className="w-6 h-6 mr-2" />
                Upgrade Now
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (generatedHTML && presentationTitle) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 p-4 md:p-6">
        <div className="max-w-3xl mx-auto">
          <Card className="border-none shadow-2xl bg-white">
            <CardContent className="p-6 md:p-12 text-center">
              <div className="w-20 h-20 md:w-32 md:h-32 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce shadow-2xl">
                <Check className="w-10 h-10 md:w-16 md:h-16 text-white" />
              </div>

              <h1 className="text-3xl md::text-5xl font-bold text-green-900 mb-4">
                ✅ Success!
              </h1>

              <p className="text-xl md::text-2xl text-green-800 mb-8">
                "{presentationTitle}"
              </p>

              <div className="flex gap-3 mb-6">
                <Button
                  onClick={handleDownload}
                  size="lg"
                  className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white py-6 text-lg font-bold"
                  disabled={generating} // Disable while PDF is generating/downloading
                >
                  {generating ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Generating PDF...
                    </>
                  ) : (
                    <>
                      <Download className="w-5 h-5 mr-2" />
                      Download PDF
                    </>
                  )}
                </Button>

                {user && (
                  <Button
                    onClick={handleSavePresentation}
                    size="lg"
                    variant="outline"
                    className="flex-1 py-6 text-lg font-bold"
                    disabled={savePresentationMutation.isPending}
                  >
                    <Save className="w-5 h-5 mr-2" />
                    Save & Share
                  </Button>
                )}
              </div>

              <Button
                onClick={handleReset}
                variant="outline"
                className="w-full"
                size="lg"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Create Another
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 p-4 md:p-6">
      <div className="max-w-6xl mx-auto">
        {/* Usage Counter Banner */}
        {user && userPlan && (
          <Card className="mb-6 border-none shadow-lg bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Presentation className="w-6 h-6" />
                  <div>
                    <p className="font-bold">Monthly Usage</p>
                    <p className="text-sm text-blue-100">
                      {user.monthly_ppt_generations_used || 0}/{userPlan.features?.max_ppt_generations === -1 ? '∞' : userPlan.features?.max_ppt_generations || 0} presentations generated
                    </p>
                  </div>
                </div>
                <Badge className="bg-white text-blue-600">
                  {userPlan.features?.max_ppt_generations === -1 ? 'Unlimited' : `${(userPlan.features?.max_ppt_generations || 0) - (user.monthly_ppt_generations_used || 0)} left`}
                </Badge>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="text-center mb-6">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-3">
            Training & Report Generator
          </h1>
          <p className="text-lg text-slate-600">AI-powered presentations with collaboration</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="create">
              <Plus className="w-4 h-4 mr-2" />
              Create New
            </TabsTrigger>
            <TabsTrigger value="my_presentations">
              <Folder className="w-4 h-4 mr-2" />
              My Presentations ({presentations.length})
            </TabsTrigger>
            <TabsTrigger value="ai_tools">
              <Wand2 className="w-4 h-4 mr-2" />
              AI Tools
            </TabsTrigger>
          </TabsList>

          <TabsContent value="create" className="space-y-6">
            <Card className="border-none shadow-xl bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-slate-900 mb-1">🎨 Start with a Template</h3>
                    <p className="text-sm text-slate-600">Pre-designed layouts and structures</p>
                  </div>
                  <Button onClick={() => setShowTemplatePreview(true)} className="bg-gradient-to-r from-purple-600 to-pink-600">
                    <Layers className="w-4 h-4 mr-2" />
                    Browse Templates
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-2xl">
              <CardContent className="p-6 space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-lg font-semibold mb-3 block">Topic *</Label>
                    <Input
                      value={topic}
                      onChange={(e) => setTopic(e.target.value)}
                      placeholder="e.g., Digital Marketing Strategy 2024"
                      className="h-12"
                      disabled={generating}
                    />
                  </div>

                  <div>
                    <Label className="text-lg font-semibold mb-3 block">Target Audience *</Label>
                    <Input
                      value={targetAudience}
                      onChange={(e) => setTargetAudience(e.target.value)}
                      placeholder="e.g., Marketing Managers, Executives"
                      className="h-12"
                      disabled={generating}
                    />
                  </div>
                </div>

                <div>
                  <Label className="text-lg font-semibold mb-3 block">Description</Label>
                  <Textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Key points, objectives, specific requirements..."
                    rows={3}
                    disabled={generating}
                  />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-sm font-semibold mb-2 block">Presentation Length</Label>
                    <Select value={presentationLength} onValueChange={(v) => {
                      setPresentationLength(v);
                      const length = PRESENTATION_LENGTHS.find(l => l.value === v);
                      if (length) setSlideCount(length.slides);
                    }} disabled={generating}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PRESENTATION_LENGTHS.map(l => (
                          <SelectItem key={l.value} value={l.value}>
                            {l.label} (~{l.slides} slides)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-sm font-semibold mb-2 block">Slide Structure</Label>
                    <Select value={slideStructure} onValueChange={setSlideStructure} disabled={generating}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {SLIDE_STRUCTURES.map(s => (
                          <SelectItem key={s.value} value={s.value}>
                            {s.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-slate-500 mt-1">
                      {SLIDE_STRUCTURES.find(s => s.value === slideStructure)?.description}
                    </p>
                  </div>

                  <div>
                    <Label className="text-sm font-semibold mb-2 block flex items-center justify-between">
                      Theme
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowThemePreview(true)}
                        className="h-6 text-xs"
                      >
                        <Eye className="w-3 h-3 mr-1" />
                        Preview
                      </Button>
                    </Label>
                    <Select value={theme} onValueChange={setTheme} disabled={generating}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {THEMES.map(t => (
                          <SelectItem key={t.value} value={t.value}>
                            <div className="flex items-center gap-2">
                              <div className="w-4 h-4 rounded" style={{ background: t.preview }} />
                              {t.label}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button
                  onClick={handleGenerate}
                  disabled={generating || !topic.trim() || !targetAudience.trim() || limitReached}
                  className="w-full bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 py-6 text-xl font-bold"
                  size="lg"
                >
                  {generating ? (
                    <>
                      <Loader2 className="w-6 h-6 mr-3 animate-spin" />
                      {generationStatus}
                    </>
                  ) : (
                    <>
                      <Zap className="w-6 h-6 mr-3" />
                      Generate Presentation
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="my_presentations">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {presentations.map((pres) => {
                const isOwner = pres.created_by === user?.email;
                const sharedWithMe = pres.shared_with?.find(s => s.email === user?.email);

                return (
                  <Card key={pres.id} className="border-none shadow-lg hover:shadow-xl transition-all">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg mb-1 line-clamp-2">{pres.title}</h3>
                          <p className="text-xs text-slate-500 mb-2">{pres.slide_count} slides</p>
                          {isOwner && pres.shared_with?.length > 0 && (
                            <Badge variant="outline" className="text-xs">
                              <Users className="w-3 h-3 mr-1" />
                              Shared with {pres.shared_with.length}
                            </Badge>
                          )}
                        </div>
                        {isOwner && (
                          <Button
                            onClick={() => {
                              if (confirm('Delete this presentation?')) {
                                deletePresentationMutation.mutate(pres.id);
                              }
                            }}
                            size="icon"
                            variant="ghost"
                            className="text-red-600"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>

                      <div className="flex flex-wrap gap-2 mb-4">
                        <Badge variant="outline" className="text-xs">
                          <Clock className="w-3 h-3 mr-1" />
                          {pres.presentation_length}
                        </Badge>
                        {sharedWithMe && (
                          <Badge className="bg-blue-100 text-blue-700 text-xs">
                            Shared • {sharedWithMe.permission}
                          </Badge>
                        )}
                      </div>

                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleLoadPresentation(pres)}
                          size="sm"
                          className="flex-1"
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                        {isOwner && (
                          <Button
                            onClick={() => {
                              setSelectedPresentation(pres);
                              setShowShareDialog(true);
                            }}
                            size="sm"
                            variant="outline"
                          >
                            <Share2 className="w-4 h-4" />
                          </Button>
                        )}
                        <Button
                          onClick={() => {
                            setSelectedPresentation(pres);
                            setShowCommentDialog(true);
                          }}
                          size="sm"
                          variant="outline"
                        >
                          <MessageSquare className="w-4 h-4" />
                          {pres.comments?.length > 0 && (
                            <span className="ml-1">{pres.comments.length}</span>
                          )}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {presentations.length === 0 && (
              <Card className="border-none shadow-lg">
                <CardContent className="p-16 text-center">
                  <Folder className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-2">No presentations yet</h3>
                  <p className="text-slate-600 mb-6">Create your first presentation to get started</p>
                  <Button onClick={() => setActiveTab('create')}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Presentation
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="ai_tools" className="space-y-6">
            <Card className="border-none shadow-xl">
              <CardContent className="p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center">
                    <Wand2 className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">AI Content Tools</h2>
                    <p className="text-slate-600">Enhance, rephrase, and refine your content</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4 mb-6">
                  <Button
                    onClick={() => {
                      setEnhanceAction('summarize');
                      setShowAIEnhanceDialog(true);
                    }}
                    variant="outline"
                    className="h-24 flex-col gap-2"
                  >
                    <AlignLeft className="w-8 h-8 text-blue-600" />
                    <div className="text-center">
                      <p className="font-bold">Summarize</p>
                      <p className="text-xs text-slate-500">Condense to key points</p>
                    </div>
                  </Button>

                  <Button
                    onClick={() => {
                      setEnhanceAction('expand');
                      setShowAIEnhanceDialog(true);
                    }}
                    variant="outline"
                    className="h-24 flex-col gap-2"
                  >
                    <Maximize2 className="w-8 h-8 text-purple-600" />
                    <div className="text-center">
                      <p className="font-bold">Expand</p>
                      <p className="text-xs text-slate-500">Add more detail</p>
                    </div>
                  </Button>

                  <Button
                    onClick={() => {
                      setEnhanceAction('rephrase');
                      setShowAIEnhanceDialog(true);
                    }}
                    variant="outline"
                    className="h-24 flex-col gap-2"
                  >
                    <RefreshCw className="w-8 h-8 text-green-600" />
                    <div className="text-center">
                      <p className="font-bold">Rephrase</p>
                      <p className="text-xs text-slate-500">Adapt to audience</p>
                    </div>
                  </Button>

                  <Button
                    onClick={() => {
                      setEnhanceAction('grammar');
                      setShowAIEnhanceDialog(true);
                    }}
                    variant="outline"
                    className="h-24 flex-col gap-2"
                  >
                    <CheckCircle2 className="w-8 h-8 text-orange-600" />
                    <div className="text-center">
                      <p className="font-bold">Grammar Check</p>
                      <p className="text-xs text-slate-500">Fix errors</p>
                    </div>
                  </Button>
                </div>

                <Card className="bg-blue-50 border-2 border-blue-200">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Sparkles className="w-5 h-5 text-blue-600 flex-shrink-0 mt-1" />
                      <div>
                        <p className="font-bold text-blue-900 mb-2">💡 How to Use AI Tools:</p>
                        <ul className="text-sm text-blue-800 space-y-1">
                          <li>✅ Copy slide content and paste it into the tool</li>
                          <li>✅ Choose the enhancement you need</li>
                          <li>✅ Copy the improved result back to your slides</li>
                          <li>✅ Perfect for refining existing presentations!</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Template Preview Dialog */}
        <Dialog open={showTemplatePreview} onOpenChange={setShowTemplatePreview}>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl flex items-center gap-2">
                <Layers className="w-6 h-6 text-purple-600" />
                Choose a Template
              </DialogTitle>
            </DialogHeader>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 py-4">
              {TEMPLATES.map((template) => {
                const templateTheme = THEMES.find(t => t.value === template.theme) || THEMES[0];

                return (
                  <Card
                    key={template.id}
                    className="cursor-pointer transition-all border-2 border-transparent hover:border-purple-500 hover:shadow-xl"
                    onClick={() => handleApplyTemplate(template)}
                  >
                    <CardContent className="p-6">
                      <div className="text-5xl mb-4 text-center">{template.icon}</div>
                      <div className="h-32 rounded-lg mb-4 p-4" style={{ background: templateTheme.preview }}>
                        <div className="text-white space-y-2">
                          <div className="font-bold text-sm">{template.name}</div>
                          {template.sampleSlides.slice(0, 3).map((slide, idx) => (
                            <div key={idx} className="text-xs opacity-80">• {slide}</div>
                          ))}
                        </div>
                      </div>
                      <h4 className="font-bold text-lg mb-2">{template.name}</h4>
                      <p className="text-sm text-slate-600 mb-3">{template.description}</p>
                      <div className="flex flex-wrap gap-2 mb-3">
                        <Badge variant="outline" className="text-xs">{template.defaultSlides} slides</Badge>
                        <Badge variant="outline" className="text-xs">{SLIDE_STRUCTURES.find(s => s.value === template.structure)?.label}</Badge>
                      </div>
                      <Button size="sm" className="w-full bg-gradient-to-r from-purple-600 to-pink-600">
                        Use Template
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </DialogContent>
        </Dialog>

        {/* Theme Preview Dialog */}
        <Dialog open={showThemePreview} onOpenChange={setShowThemePreview}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Preview Themes</DialogTitle>
            </DialogHeader>
            <div className="grid md:grid-cols-2 gap-4">
              {THEMES.map((t) => (
                <Card
                  key={t.value}
                  className={`cursor-pointer transition-all border-2 ${theme === t.value ? 'border-blue-500 shadow-lg' : 'border-transparent'}`}
                  onClick={() => {
                    setTheme(t.value);
                    setShowThemePreview(false);
                  }}
                >
                  <CardContent className="p-6">
                    <div className="h-32 rounded-lg mb-4" style={{ background: t.preview }} />
                    <h4 className="font-bold text-lg mb-1">{t.label}</h4>
                    <p className="text-sm text-slate-600 mb-3">{t.description}</p>
                    <Button size="sm" className="w-full">
                      {theme === t.value ? 'Selected' : 'Select Theme'}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </DialogContent>
        </Dialog>

        {/* AI Enhancement Dialog */}
        <Dialog open={showAIEnhanceDialog} onOpenChange={setShowAIEnhanceDialog}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Wand2 className="w-6 h-6 text-purple-600" />
                {enhanceAction === 'summarize' && 'Summarize Content'}
                {enhanceAction === 'expand' && 'Expand Content'}
                {enhanceAction === 'rephrase' && 'Rephrase for Audience'}
                {enhanceAction === 'grammar' && 'Grammar & Spelling Check'}
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <Label className="font-semibold mb-2 block">
                  {enhanceAction === 'grammar' ? 'Paste Content to Check' : 'Original Content'}
                </Label>
                <Textarea
                  value={enhanceInput}
                  onChange={(e) => setEnhanceInput(e.target.value)}
                  placeholder={
                    enhanceAction === 'summarize' ? 'Paste your slide content here...' :
                    enhanceAction === 'expand' ? 'Paste bullet points to expand...' :
                    enhanceAction === 'rephrase' ? 'Paste content to rephrase...' :
                    'Paste content to check...'
                  }
                  rows={8}
                  className="font-mono text-sm"
                />
              </div>

              {enhanceAction === 'rephrase' && (
                <div>
                  <Label className="font-semibold mb-2 block">Target Audience</Label>
                  <Select value={enhanceAudience} onValueChange={setEnhanceAudience}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="executive">👔 Executive Summary (High-level, strategic)</SelectItem>
                      <SelectItem value="technical">🔧 Technical Deep-Dive (Detailed, technical)</SelectItem>
                      <SelectItem value="general">👥 General Audience (Simple, accessible)</SelectItem>
                      <SelectItem value="academic">📚 Academic (Formal, research-based)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              <Button
                onClick={handleAIEnhance}
                disabled={enhancing || !enhanceInput.trim()}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600"
                size="lg"
              >
                {enhancing ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 mr-2" />
                    {enhanceAction === 'summarize' && 'Summarize'}
                    {enhanceAction === 'expand' && 'Expand'}
                    {enhanceAction === 'rephrase' && 'Rephrase'}
                    {enhanceAction === 'grammar' && 'Check & Fix'}
                  </>
                )}
              </Button>

              {enhancedResult && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label className="font-semibold">Result</Label>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        navigator.clipboard.writeText(enhancedResult);
                        alert('✅ Copied to clipboard!');
                      }}
                    >
                      <FileType className="w-4 h-4 mr-1" />
                      Copy
                    </Button>
                  </div>
                  <div className="bg-green-50 border-2 border-green-200 rounded-lg p-4 max-h-96 overflow-y-auto">
                    <p className="text-sm text-slate-800 whitespace-pre-wrap font-mono leading-relaxed">
                      {enhancedResult}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>

        {/* Share Dialog */}
        <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Share Presentation</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {selectedPresentation?.shared_with && selectedPresentation.shared_with.length > 0 && (
                <div className="mb-4">
                  <Label className="text-sm font-semibold mb-2 block">Currently Shared With:</Label>
                  <div className="space-y-2">
                    {selectedPresentation.shared_with.map((share, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                        <div>
                          <p className="font-semibold text-sm">{share.name}</p>
                          <p className="text-xs text-slate-500">{share.email}</p>
                        </div>
                        <Badge variant="outline">{share.permission}</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <Label>Email Address</Label>
                <Input
                  value={shareEmail}
                  onChange={(e) => setShareEmail(e.target.value)}
                  placeholder="colleague@company.com"
                />
              </div>
              <div>
                <Label>Permission Level</Label>
                <Select value={sharePermission} onValueChange={setSharePermission}>
                  <SelectTrigger>
                    <SelectValue />
                    </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="view">👁️ View Only - Can view the presentation</SelectItem>
                    <SelectItem value="comment">💬 Can Comment - View and leave feedback</SelectItem>
                    <SelectItem value="edit">✏️ Can Edit - Full editing access</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button
                onClick={handleSharePresentation}
                className="w-full"
                disabled={sharePresentationMutation.isPending}
              >
                {sharePresentationMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Send className="w-4 h-4 mr-2" />
                )}
                Share Presentation
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Comment Dialog */}
        <Dialog open={showCommentDialog} onOpenChange={setShowCommentDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Comments & Feedback</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {selectedPresentation?.comments && selectedPresentation.comments.length > 0 && (
                <div className="max-h-64 overflow-y-auto space-y-3 mb-4">
                  {selectedPresentation.comments.map((comment) => (
                    <Card key={comment.id} className="bg-slate-50">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <p className="font-semibold text-sm">{comment.user_name}</p>
                          <Badge variant="outline" className="text-xs">Slide {comment.slide_number}</Badge>
                        </div>
                        <p className="text-sm text-slate-700">{comment.comment}</p>
                        <p className="text-xs text-slate-500 mt-2">{new Date(comment.timestamp).toLocaleString()}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              <div>
                <Label>Slide Number</Label>
                <Input
                  type="number"
                  min="1"
                  value={commentSlideNumber}
                  onChange={(e) => setCommentSlideNumber(Number(e.target.value))}
                />
              </div>
              <div>
                <Label>Comment</Label>
                <Textarea
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Add your feedback..."
                  rows={4}
                />
              </div>
              <Button onClick={handleAddComment} className="w-full" disabled={addCommentMutation.isPending}>
                <MessageSquare className="w-4 h-4 mr-2" />
                Add Comment
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
