import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  Bell, 
  BellOff, 
  Mail, 
  MessageSquare, 
  Calendar, 
  CheckSquare,
  Users,
  BookOpen,
  Video,
  Save,
  Loader2,
  Check
} from "lucide-react";

export default function NotificationSettings() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const queryClient = useQueryClient();

  const [emailEnabled, setEmailEnabled] = useState(false);
  const [preferences, setPreferences] = useState({
    new_posts: true,
    new_events: true,
    task_assignments: true,
    course_updates: true,
    group_announcements: true,
    private_messages: true,
    meeting_reminders: true
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        setEmailEnabled(currentUser.email_notifications_enabled || false);
        
        if (currentUser.notification_preferences) {
          setPreferences(currentUser.notification_preferences);
        }
        
        setLoading(false);
      } catch (error) {
        console.error("Error fetching user:", error);
        setLoading(false);
      }
    };
    fetchUser();
  }, []);

  const updateSettingsMutation = useMutation({
    mutationFn: async (settings) => {
      return await base44.auth.updateMe(settings);
    },
    onSuccess: () => {
      queryClient.invalidateQueries();
      alert("✅ Settings saved successfully!");
      setSaving(false);
    },
    onError: (error) => {
      console.error("Error saving settings:", error);
      alert("❌ Failed to save settings: " + error.message);
      setSaving(false);
    }
  });

  const handleSaveSettings = async () => {
    setSaving(true);
    try {
      await updateSettingsMutation.mutateAsync({
        email_notifications_enabled: emailEnabled,
        notification_preferences: preferences
      });
    } catch (error) {
      console.error("Save error:", error);
    }
  };

  const handleTogglePreference = (key) => {
    setPreferences(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const notificationTypes = [
    {
      key: 'new_posts',
      icon: MessageSquare,
      title: 'New Posts',
      description: 'Get notified when someone posts in your groups'
    },
    {
      key: 'new_events',
      icon: Calendar,
      title: 'New Events',
      description: 'Notifications about new events and workshops'
    },
    {
      key: 'task_assignments',
      icon: CheckSquare,
      title: 'Task Assignments',
      description: 'When tasks are assigned to you'
    },
    {
      key: 'course_updates',
      icon: BookOpen,
      title: 'Course Updates',
      description: 'New courses and learning content'
    },
    {
      key: 'group_announcements',
      icon: Users,
      title: 'Group Announcements',
      description: 'Important announcements from group admins'
    },
    {
      key: 'private_messages',
      icon: Mail,
      title: 'Private Messages',
      description: 'When you receive a private message'
    },
    {
      key: 'meeting_reminders',
      icon: Video,
      title: 'Meeting Reminders',
      description: 'Reminders about upcoming meetings'
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Notification Settings</h1>
            <p className="text-slate-600">Manage how you receive notifications</p>
          </div>
          <Button
            onClick={handleSaveSettings}
            disabled={saving}
            className="bg-gradient-to-r from-blue-600 to-purple-600"
          >
            {saving ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Save Settings
              </>
            )}
          </Button>
        </div>

        {/* Email Notifications Toggle */}
        <Card className="border-none shadow-xl">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50">
            <CardTitle className="flex items-center gap-3">
              {emailEnabled ? (
                <Bell className="w-6 h-6 text-blue-600" />
              ) : (
                <BellOff className="w-6 h-6 text-slate-400" />
              )}
              Email Notifications
            </CardTitle>
            <CardDescription>
              Receive notifications via email at <strong>{user?.email}</strong>
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
              <div>
                <p className="font-semibold text-slate-900">Enable Email Notifications</p>
                <p className="text-sm text-slate-600">Send me notifications to my email</p>
              </div>
              <Switch
                checked={emailEnabled}
                onCheckedChange={setEmailEnabled}
                className="data-[state=checked]:bg-blue-600"
              />
            </div>
            
            {!emailEnabled && (
              <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg text-sm text-yellow-800">
                ⚠️ You won't receive any email notifications. You'll only see in-app notifications.
              </div>
            )}
          </CardContent>
        </Card>

        {/* Notification Preferences */}
        <Card className="border-none shadow-xl">
          <CardHeader>
            <CardTitle>Notification Preferences</CardTitle>
            <CardDescription>
              Choose which notifications you want to receive
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {notificationTypes.map((type) => {
              const IconComponent = type.icon;
              return (
                <div 
                  key={type.key}
                  className="flex items-center justify-between p-4 border-2 border-slate-200 rounded-xl hover:border-blue-300 transition-all"
                >
                  <div className="flex items-start gap-4 flex-1">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      preferences[type.key] 
                        ? 'bg-gradient-to-br from-blue-500 to-purple-600 text-white' 
                        : 'bg-slate-200 text-slate-500'
                    }`}>
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-900 mb-1">{type.title}</h3>
                      <p className="text-sm text-slate-600">{type.description}</p>
                    </div>
                  </div>
                  <Switch
                    checked={preferences[type.key]}
                    onCheckedChange={() => handleTogglePreference(type.key)}
                    className="data-[state=checked]:bg-blue-600 ml-4"
                  />
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* Summary */}
        <Card className="border-none shadow-xl bg-gradient-to-r from-blue-50 to-purple-50">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                <Check className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-slate-900 mb-2">Current Settings Summary</h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Badge className={emailEnabled ? "bg-green-600" : "bg-slate-400"}>
                      {emailEnabled ? "Email: ON" : "Email: OFF"}
                    </Badge>
                    <Badge className="bg-blue-600">
                      {Object.values(preferences).filter(Boolean).length} / {notificationTypes.length} enabled
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-700">
                    {emailEnabled 
                      ? "You'll receive both in-app and email notifications for enabled categories."
                      : "You'll only receive in-app notifications."}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Save Button (Mobile) */}
        <div className="sm:hidden fixed bottom-6 left-6 right-6 z-50">
          <Button
            onClick={handleSaveSettings}
            disabled={saving}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 shadow-2xl py-6 text-lg font-bold"
          >
            {saving ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-5 h-5 mr-2" />
                Save Settings
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}