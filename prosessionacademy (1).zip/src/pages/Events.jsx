
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Calendar,
  MapPin,
  Users,
  Plus,
  Video,
  Building,
  CheckCircle,
  Clock,
  ExternalLink
} from "lucide-react";
import { format, isSameDay } from "date-fns";
import { motion } from "framer-motion";

export default function Events() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [filterType, setFilterType] = useState("all");
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [viewMode, setViewMode] = useState("grid");

  const [newEvent, setNewEvent] = useState({
    title: "",
    description: "",
    type: "live_session",
    date: "",
    location: "",
    organizer_email: "",
    organizer_name: "",
    max_participants: 50,
    is_online: true,
    thumbnail_url: "",
    meeting_url: ""
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const authenticated = await base44.auth.isAuthenticated();
        setIsAuthenticated(authenticated);
        if (authenticated) {
          const currentUser = await base44.auth.me();
          setUser(currentUser);
          setNewEvent({
            ...newEvent,
            organizer_email: currentUser.email,
            organizer_name: currentUser.full_name || currentUser.email
          });
        }
      } catch (error) {
        console.error("Error:", error);
      }
    };
    fetchUser();
  }, []);

  const { data: events = [] } = useQuery({
    queryKey: ['events'],
    queryFn: () => base44.entities.Event.filter({ status: 'approved' }, 'date'),
    initialData: [],
  });

  const createEventMutation = useMutation({
    mutationFn: (data) => base44.entities.Event.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['events'] });
      setShowCreateDialog(false);
      setNewEvent({
        title: "",
        description: "",
        type: "live_session",
        date: "",
        location: "",
        organizer_email: user.email,
        organizer_name: user.full_name || user.email,
        max_participants: 50,
        is_online: true,
        thumbnail_url: "",
        meeting_url: ""
      });
      alert('✅ Event created successfully!');
    },
  });

  const registerEventMutation = useMutation({
    mutationFn: ({ eventId, userEmail }) => {
      const event = events.find(e => e.id === eventId);
      return base44.entities.Event.update(eventId, {
        registered_users: [...(event.registered_users || []), userEmail]
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['events'] });
      alert('✅ Successfully registered!');
    },
  });

  const handleCreateEvent = () => {
    if (!newEvent.title || !newEvent.date || !newEvent.location) {
      alert('Please fill all required fields');
      return;
    }
    createEventMutation.mutate(newEvent);
  };

  const handleRegister = (eventId) => {
    if (!isAuthenticated) {
      base44.auth.redirectToLogin();
      return;
    }
    registerEventMutation.mutate({ eventId, userEmail: user.email });
  };

  const isUserRegistered = (event) => {
    return event.registered_users?.includes(user?.email);
  };

  const filteredEvents = events.filter(event => {
    if (filterType === "all") return true;
    return event.type === filterType;
  });

  const upcomingEvents = filteredEvents.filter(e => new Date(e.date) >= new Date());
  const pastEvents = filteredEvents.filter(e => new Date(e.date) < new Date());

  const eventsOnSelectedDate = upcomingEvents.filter(event => 
    isSameDay(new Date(event.date), selectedDate)
  );

  const eventDates = upcomingEvents.map(e => new Date(e.date));

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          <Card className="border-none shadow-2xl overflow-hidden bg-white">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 opacity-10"></div>
              <CardContent className="relative p-8 lg:p-12">
                <div className="flex items-center justify-between flex-wrap gap-6">
                  <div className="flex items-center gap-6">
                    <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-xl">
                      <Calendar className="w-10 h-10 text-white" />
                    </div>
                    <div>
                      <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-2">
                        Events & Webinars
                      </h1>
                      <p className="text-lg text-slate-600">
                        Join live sessions • Network • Learn together
                      </p>
                    </div>
                  </div>

                  {isAuthenticated && (
                    <Button onClick={() => setShowCreateDialog(true)} className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg" size="lg">
                      <Plus className="w-5 h-5 mr-2" />
                      Create Event
                    </Button>
                  )}
                </div>
              </CardContent>
            </div>
          </Card>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          <Card className="border-none shadow-lg bg-white">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-3xl font-bold text-slate-900">{upcomingEvents.length}</div>
                  <p className="text-sm text-slate-600 font-medium">Upcoming</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-white">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-3xl font-bold text-slate-900">{events.reduce((sum, e) => sum + (e.registered_users?.length || 0), 0)}</div>
                  <p className="text-sm text-slate-600 font-medium">Registrations</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-white">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
                  <Clock className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-3xl font-bold text-slate-900">{pastEvents.length}</div>
                  <p className="text-sm text-slate-600 font-medium">Completed</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="border-none shadow-xl bg-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-4">
              <Tabs value={filterType} onValueChange={setFilterType}>
                <TabsList className="bg-slate-100 p-2 rounded-xl">
                  <TabsTrigger value="all">All Events</TabsTrigger>
                  <TabsTrigger value="live_session">Live Sessions</TabsTrigger>
                  <TabsTrigger value="workshop">Workshops</TabsTrigger>
                  <TabsTrigger value="webinar">Webinars</TabsTrigger>
                  <TabsTrigger value="company_tour">Company Tours</TabsTrigger>
                </TabsList>
              </Tabs>
              <div className="flex gap-2">
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  onClick={() => setViewMode("grid")}
                  size="sm"
                >
                  Grid
                </Button>
                <Button
                  variant={viewMode === "calendar" ? "default" : "outline"}
                  onClick={() => setViewMode("calendar")}
                  size="sm"
                >
                  Calendar
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {viewMode === "calendar" ? (
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="border-none shadow-xl bg-white lg:col-span-2">
              <CardHeader>
                <CardTitle>Event Calendar</CardTitle>
              </CardHeader>
              <CardContent className="flex justify-center">
                <CalendarComponent
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border"
                  modifiers={{
                    event: eventDates
                  }}
                  modifiersStyles={{
                    event: {
                      fontWeight: 'bold',
                      color: 'blue'
                    }
                  }}
                />
              </CardContent>
            </Card>

            <Card className="border-none shadow-xl bg-white">
              <CardHeader>
                <CardTitle>
                  Events on {format(selectedDate, 'MMM d, yyyy')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {eventsOnSelectedDate.length > 0 ? (
                  <div className="space-y-3">
                    {eventsOnSelectedDate.map((event) => (
                      <Card key={event.id} className="border-2 hover:border-blue-500 transition-all cursor-pointer">
                        <CardContent className="p-4">
                          <h4 className="font-bold text-slate-900 mb-2">{event.title}</h4>
                          <div className="space-y-1 text-sm text-slate-600">
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4" />
                              <span>{format(new Date(event.date), 'h:mm a')}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              {event.is_online ? <Video className="w-4 h-4" /> : <Building className="w-4 h-4" />}
                              <span className="truncate">{event.is_online ? 'Online' : event.location}</span>
                            </div>
                          </div>
                          {isUserRegistered(event) ? (
                            <Badge className="mt-2 bg-green-600">Registered</Badge>
                          ) : (
                            <Button
                              onClick={() => handleRegister(event.id)}
                              size="sm"
                              className="mt-2 w-full"
                            >
                              Register
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-slate-500 py-8">No events on this date</p>
                )}
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {upcomingEvents.map((event, index) => {
              const isRegistered = isUserRegistered(event);
              const isFull = event.max_participants && event.registered_users?.length >= event.max_participants;

              // Helper function to format ISO date string for Google Calendar
              const formatGoogleCalendarDate = (date) => {
                const d = new Date(date);
                // Google Calendar expects YYYYMMDDTHHMMSSZ for UTC, or YYYYMMDDTHHMMSS for local time
                // Using toISOString and removing non-digits, then adding Z for UTC
                return d.toISOString().replace(/[-:]|\.\d{3}/g, '') + 'Z';
              };

              // Helper function to format ISO date string for Outlook
              const formatOutlookDate = (date) => {
                return new Date(date).toISOString();
              };

              // Google Calendar link
              const googleCalLink = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(event.title)}&dates=${formatGoogleCalendarDate(event.date)}/${formatGoogleCalendarDate(new Date(new Date(event.date).getTime() + 3600000))}&details=${encodeURIComponent(event.description || '')}&location=${encodeURIComponent(event.location || '')}`;

              // Outlook Calendar link
              const outlookCalLink = `https://outlook.live.com/calendar/0/deeplink/compose?subject=${encodeURIComponent(event.title)}&body=${encodeURIComponent(event.description || '')}&location=${encodeURIComponent(event.location || '')}&startdt=${formatOutlookDate(event.date)}&enddt=${formatOutlookDate(new Date(new Date(event.date).getTime() + 3600000))}`;


              return (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ y: -8 }}
                >
                  <Card className="border-none shadow-lg hover:shadow-2xl transition-all h-full flex flex-col bg-white">
                    <div className="h-48 bg-gradient-to-br from-blue-500 to-indigo-600 relative overflow-hidden">
                      {event.thumbnail_url ? (
                        <img src={event.thumbnail_url} alt={event.title} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Calendar className="w-16 h-16 text-white/30" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                      <Badge className="absolute top-4 right-4 bg-white/90 text-slate-900 shadow-lg">
                        {event.type?.replace(/_/g, ' ')}
                      </Badge>
                    </div>

                    <CardHeader>
                      <CardTitle className="text-xl text-slate-900 line-clamp-2">{event.title}</CardTitle>
                      <div className="space-y-2 text-sm text-slate-600">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          <span>{format(new Date(event.date), 'MMM d, yyyy • h:mm a')}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {event.is_online ? <Video className="w-4 h-4" /> : <Building className="w-4 h-4" />}
                          <span className="truncate">{event.is_online ? 'Online Event' : event.location}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4" />
                          <span>{event.registered_users?.length || 0} / {event.max_participants || '∞'} registered</span>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="flex-1 flex flex-col space-y-4">
                      <p className="text-slate-600 text-sm line-clamp-3 flex-1">{event.description}</p>

                      {/* Calendar Sync Buttons */}
                      <div className="grid grid-cols-2 gap-2">
                        <a 
                          href={googleCalLink}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <Button size="sm" variant="outline" className="w-full">
                            <Calendar className="w-4 h-4 mr-1" /> {/* Using Calendar from lucide-react */}
                            Google Cal
                          </Button>
                        </a>
                        <a 
                          href={outlookCalLink}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <Button size="sm" variant="outline" className="w-full">
                            <Calendar className="w-4 h-4 mr-1" /> {/* Using Calendar from lucide-react */}
                            Outlook
                          </Button>
                        </a>
                      </div>

                      {isRegistered ? (
                        <Button className="w-full bg-green-600 hover:bg-green-700" disabled>
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Registered
                        </Button>
                      ) : isFull ? (
                        <Button className="w-full" variant="outline" disabled>
                          Event Full
                        </Button>
                      ) : (
                        <Button
                          onClick={() => handleRegister(event.id)}
                          className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                        >
                          Register Now
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        )}

        {upcomingEvents.length === 0 && (
          <Card className="border-none shadow-xl bg-white">
            <CardContent className="p-16 text-center">
              <Calendar className="w-20 h-20 text-slate-300 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-slate-900 mb-2">No upcoming events</h3>
              <p className="text-slate-500">Check back soon for new events!</p>
            </CardContent>
          </Card>
        )}
      </div>

      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Create New Event</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Event Title *</Label>
              <Input
                value={newEvent.title}
                onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                placeholder="e.g., React Workshop"
              />
            </div>
            <div>
              <Label>Description *</Label>
              <Textarea
                value={newEvent.description}
                onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                placeholder="Describe the event..."
                rows={4}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Event Type</Label>
                <Select value={newEvent.type} onValueChange={(value) => setNewEvent({ ...newEvent, type: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="live_session">Live Session</SelectItem>
                    <SelectItem value="workshop">Workshop</SelectItem>
                    <SelectItem value="webinar">Webinar</SelectItem>
                    <SelectItem value="company_tour">Company Tour</SelectItem>
                    <SelectItem value="networking">Networking</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Date & Time *</Label>
                <Input
                  type="datetime-local"
                  value={newEvent.date}
                  onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                />
              </div>
            </div>
            <div>
              <Label>Location *</Label>
              <Input
                value={newEvent.location}
                onChange={(e) => setNewEvent({ ...newEvent, location: e.target.value })}
                placeholder="Zoom link, address, etc."
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={newEvent.is_online}
                onChange={(e) => setNewEvent({ ...newEvent, is_online: e.target.checked })}
                className="w-4 h-4"
              />
              <Label>This is an online event</Label>
            </div>
            <div>
              <Label>Max Participants</Label>
              <Input
                type="number"
                value={newEvent.max_participants}
                onChange={(e) => setNewEvent({ ...newEvent, max_participants: parseInt(e.target.value) })}
                min="1"
              />
            </div>
            <Button onClick={handleCreateEvent} className="w-full" disabled={createEventMutation.isPending}>
              Create Event
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
