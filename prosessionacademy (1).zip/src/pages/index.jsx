import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Courses from "./Courses";

import Learning from "./Learning";

import Pathways from "./Pathways";

import Community from "./Community";

import Events from "./Events";

import Companies from "./Companies";

import Resources from "./Resources";

import AIChat from "./AIChat";

import CourseAdmin from "./CourseAdmin";

import MeetingRooms from "./MeetingRooms";

import MeetingRoom from "./MeetingRoom";

import PersonalityTest from "./PersonalityTest";

import IQTest from "./IQTest";

import StudentSpace from "./StudentSpace";

import ChapterBuilder from "./ChapterBuilder";

import AssessmentTest from "./AssessmentTest";

import CourseRequest from "./CourseRequest";

import Subscription from "./Subscription";

import AdminSettings from "./AdminSettings";

import Groups from "./Groups";

import GroupDashboard from "./GroupDashboard";

import PathwayDetail from "./PathwayDetail";

import AdminApprovals from "./AdminApprovals";

import Practice from "./Practice";

import CareerTest from "./CareerTest";

import PsaOotAdmin from "./PsaOotAdmin";

import PsaOotHost from "./PsaOotHost";

import PsaOotPlay from "./PsaOotPlay";

import NotificationSettings from "./NotificationSettings";

import CareerLink from "./CareerLink";

import ExamFocusSpace from "./ExamFocusSpace";

import AIContentGenerator from "./AIContentGenerator";

import UsageMonitor from "./UsageMonitor";

import CegidDiscovery from "./CegidDiscovery";

import ProfessionalSpace from "./ProfessionalSpace";

import ToolLauncher from "./ToolLauncher";

import ToolViewer from "./ToolViewer";

import ProfessionalOnboarding from "./ProfessionalOnboarding";

import PowerPointGenerator from "./PowerPointGenerator";

import AIChapterBuilder from "./AIChapterBuilder";

import UniversityPortal from "./UniversityPortal";

import PathwayCertificate from "./PathwayCertificate";

import StudentAITeacher from "./StudentAITeacher";

import AccountStrikes from "./AccountStrikes";

import SubscriptionPlanAdmin from "./SubscriptionPlanAdmin";

import UserSubscriptionAdmin from "./UserSubscriptionAdmin";

import UnblockImageAccess from "./UnblockImageAccess";

import AIImageGenerator from "./AIImageGenerator";

import CVGenerator from "./CVGenerator";

import Certificates from "./Certificates";

import TwilioVideoDemo from "./TwilioVideoDemo";

import XPShop from "./XPShop";

import PageRenderer from "./PageRenderer";

import GroupCegidAdmin from "./GroupCegidAdmin";

import RestMode from "./RestMode";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Courses: Courses,
    
    Learning: Learning,
    
    Pathways: Pathways,
    
    Community: Community,
    
    Events: Events,
    
    Companies: Companies,
    
    Resources: Resources,
    
    AIChat: AIChat,
    
    CourseAdmin: CourseAdmin,
    
    MeetingRooms: MeetingRooms,
    
    MeetingRoom: MeetingRoom,
    
    PersonalityTest: PersonalityTest,
    
    IQTest: IQTest,
    
    StudentSpace: StudentSpace,
    
    ChapterBuilder: ChapterBuilder,
    
    AssessmentTest: AssessmentTest,
    
    CourseRequest: CourseRequest,
    
    Subscription: Subscription,
    
    AdminSettings: AdminSettings,
    
    Groups: Groups,
    
    GroupDashboard: GroupDashboard,
    
    PathwayDetail: PathwayDetail,
    
    AdminApprovals: AdminApprovals,
    
    Practice: Practice,
    
    CareerTest: CareerTest,
    
    PsaOotAdmin: PsaOotAdmin,
    
    PsaOotHost: PsaOotHost,
    
    PsaOotPlay: PsaOotPlay,
    
    NotificationSettings: NotificationSettings,
    
    CareerLink: CareerLink,
    
    ExamFocusSpace: ExamFocusSpace,
    
    AIContentGenerator: AIContentGenerator,
    
    UsageMonitor: UsageMonitor,
    
    CegidDiscovery: CegidDiscovery,
    
    ProfessionalSpace: ProfessionalSpace,
    
    ToolLauncher: ToolLauncher,
    
    ToolViewer: ToolViewer,
    
    ProfessionalOnboarding: ProfessionalOnboarding,
    
    PowerPointGenerator: PowerPointGenerator,
    
    AIChapterBuilder: AIChapterBuilder,
    
    UniversityPortal: UniversityPortal,
    
    PathwayCertificate: PathwayCertificate,
    
    StudentAITeacher: StudentAITeacher,
    
    AccountStrikes: AccountStrikes,
    
    SubscriptionPlanAdmin: SubscriptionPlanAdmin,
    
    UserSubscriptionAdmin: UserSubscriptionAdmin,
    
    UnblockImageAccess: UnblockImageAccess,
    
    AIImageGenerator: AIImageGenerator,
    
    CVGenerator: CVGenerator,
    
    Certificates: Certificates,
    
    TwilioVideoDemo: TwilioVideoDemo,
    
    XPShop: XPShop,
    
    PageRenderer: PageRenderer,
    
    GroupCegidAdmin: GroupCegidAdmin,
    
    RestMode: RestMode,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Courses" element={<Courses />} />
                
                <Route path="/Learning" element={<Learning />} />
                
                <Route path="/Pathways" element={<Pathways />} />
                
                <Route path="/Community" element={<Community />} />
                
                <Route path="/Events" element={<Events />} />
                
                <Route path="/Companies" element={<Companies />} />
                
                <Route path="/Resources" element={<Resources />} />
                
                <Route path="/AIChat" element={<AIChat />} />
                
                <Route path="/CourseAdmin" element={<CourseAdmin />} />
                
                <Route path="/MeetingRooms" element={<MeetingRooms />} />
                
                <Route path="/MeetingRoom" element={<MeetingRoom />} />
                
                <Route path="/PersonalityTest" element={<PersonalityTest />} />
                
                <Route path="/IQTest" element={<IQTest />} />
                
                <Route path="/StudentSpace" element={<StudentSpace />} />
                
                <Route path="/ChapterBuilder" element={<ChapterBuilder />} />
                
                <Route path="/AssessmentTest" element={<AssessmentTest />} />
                
                <Route path="/CourseRequest" element={<CourseRequest />} />
                
                <Route path="/Subscription" element={<Subscription />} />
                
                <Route path="/AdminSettings" element={<AdminSettings />} />
                
                <Route path="/Groups" element={<Groups />} />
                
                <Route path="/GroupDashboard" element={<GroupDashboard />} />
                
                <Route path="/PathwayDetail" element={<PathwayDetail />} />
                
                <Route path="/AdminApprovals" element={<AdminApprovals />} />
                
                <Route path="/Practice" element={<Practice />} />
                
                <Route path="/CareerTest" element={<CareerTest />} />
                
                <Route path="/PsaOotAdmin" element={<PsaOotAdmin />} />
                
                <Route path="/PsaOotHost" element={<PsaOotHost />} />
                
                <Route path="/PsaOotPlay" element={<PsaOotPlay />} />
                
                <Route path="/NotificationSettings" element={<NotificationSettings />} />
                
                <Route path="/CareerLink" element={<CareerLink />} />
                
                <Route path="/ExamFocusSpace" element={<ExamFocusSpace />} />
                
                <Route path="/AIContentGenerator" element={<AIContentGenerator />} />
                
                <Route path="/UsageMonitor" element={<UsageMonitor />} />
                
                <Route path="/CegidDiscovery" element={<CegidDiscovery />} />
                
                <Route path="/ProfessionalSpace" element={<ProfessionalSpace />} />
                
                <Route path="/ToolLauncher" element={<ToolLauncher />} />
                
                <Route path="/ToolViewer" element={<ToolViewer />} />
                
                <Route path="/ProfessionalOnboarding" element={<ProfessionalOnboarding />} />
                
                <Route path="/PowerPointGenerator" element={<PowerPointGenerator />} />
                
                <Route path="/AIChapterBuilder" element={<AIChapterBuilder />} />
                
                <Route path="/UniversityPortal" element={<UniversityPortal />} />
                
                <Route path="/PathwayCertificate" element={<PathwayCertificate />} />
                
                <Route path="/StudentAITeacher" element={<StudentAITeacher />} />
                
                <Route path="/AccountStrikes" element={<AccountStrikes />} />
                
                <Route path="/SubscriptionPlanAdmin" element={<SubscriptionPlanAdmin />} />
                
                <Route path="/UserSubscriptionAdmin" element={<UserSubscriptionAdmin />} />
                
                <Route path="/UnblockImageAccess" element={<UnblockImageAccess />} />
                
                <Route path="/AIImageGenerator" element={<AIImageGenerator />} />
                
                <Route path="/CVGenerator" element={<CVGenerator />} />
                
                <Route path="/Certificates" element={<Certificates />} />
                
                <Route path="/TwilioVideoDemo" element={<TwilioVideoDemo />} />
                
                <Route path="/XPShop" element={<XPShop />} />
                
                <Route path="/PageRenderer" element={<PageRenderer />} />
                
                <Route path="/GroupCegidAdmin" element={<GroupCegidAdmin />} />
                
                <Route path="/RestMode" element={<RestMode />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}