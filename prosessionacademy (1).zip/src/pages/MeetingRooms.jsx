
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Video,
  Plus,
  Users,
  Calendar,
  Clock,
  Play,
  CheckCircle,
  Lock,
  Shield,
  Sparkles
} from "lucide-react";
import { format } from "date-fns";

export default function MeetingRooms() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newMeeting, setNewMeeting] = useState({
    title: "",
    description: "",
    scheduled_time: "",
    duration_minutes: 60,
    max_participants: 50,
    is_public: false
  });

  useEffect(() => {
    const fetchUser = async () => {
      const authenticated = await base44.auth.isAuthenticated();
      setIsAuthenticated(authenticated);
      if (authenticated) {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      }
    };
    fetchUser();
  }, []);

  const isAdmin = user?.role === 'admin';

  const { data: meetings = [] } = useQuery({
    queryKey: ['meetings'],
    queryFn: () => base44.entities.MeetingRoom.list('-scheduled_time'),
    initialData: [],
  });

  const createMeetingMutation = useMutation({
    mutationFn: (data) => base44.entities.MeetingRoom.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['meetings'] });
      setShowCreateDialog(false);
      setNewMeeting({
        title: "",
        description: "",
        scheduled_time: "",
        duration_minutes: 60,
        max_participants: 50,
        is_public: false
      });
    },
  });

  const joinMeetingMutation = useMutation({
    mutationFn: ({ meetingId, currentParticipants }) => {
      return base44.entities.MeetingRoom.update(meetingId, {
        participants: [...currentParticipants, user.email]
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['meetings'] });
    },
  });

  const handleCreateMeeting = () => {
    if (!isAdmin) {
      alert('Only admins can create meetings');
      return;
    }
    
    if (!newMeeting.title || !newMeeting.scheduled_time) return;
    
    // Generate unique room ID for Jitsi
    const roomId = `prosession-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    createMeetingMutation.mutate({
      ...newMeeting,
      meeting_url: roomId,
      host_email: user.email,
      host_name: user.full_name || user.email,
      status: 'scheduled'
    });
  };

  const handleJoinMeeting = (meeting) => {
    if (!isAuthenticated) {
      base44.auth.redirectToLogin();
      return;
    }

    const participants = meeting.participants || [];
    if (!participants.includes(user.email)) {
      joinMeetingMutation.mutate({
        meetingId: meeting.id,
        currentParticipants: participants
      });
    }
  };

  const upcomingMeetings = meetings.filter(m => 
    new Date(m.scheduled_time) >= new Date() && m.status === 'scheduled'
  );

  const pastMeetings = meetings.filter(m => 
    new Date(m.scheduled_time) < new Date() || m.status === 'completed'
  );

  return (
    <div className="min-h-screen bg-slate-950 relative overflow-hidden">
      {/* Animated background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 -right-40 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-40 -left-40 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:24px_24px]"></div>
      </div>

      <div className="relative z-10 p-6 lg:p-8 space-y-8">
        {/* Premium Header */}
        <div className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-3xl blur-xl opacity-75 group-hover:opacity-100 transition duration-1000 animate-pulse"></div>
          <div className="relative bg-gradient-to-r from-slate-900/90 via-slate-800/90 to-slate-900/90 backdrop-blur-2xl rounded-3xl p-8 border border-white/10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center shadow-2xl">
                  <Video className="w-9 h-9 text-white" />
                </div>
                <div>
                  <h1 className="text-4xl lg:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400">
                    Meeting Rooms
                  </h1>
                  <p className="text-blue-200 text-lg">Connect instantly • Collaborate • Meet in-app</p>
                </div>
              </div>
              
              {isAdmin && (
                <Button 
                  onClick={() => setShowCreateDialog(true)}
                  className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white shadow-2xl hover:shadow-blue-500/50 transition-all transform hover:scale-105"
                  size="lg"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Schedule Meeting
                </Button>
              )}
            </div>
            
            {!isAuthenticated && (
              <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-xl">
                <p className="text-blue-300 text-sm">
                  <button onClick={() => base44.auth.redirectToLogin()} className="underline font-semibold">Login</button> to join meetings
                </p>
              </div>
            )}
            {isAuthenticated && !isAdmin && (
              <div className="mt-6 p-4 bg-orange-500/10 border border-orange-500/30 rounded-xl">
                <p className="text-orange-300 text-sm flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  Only admins can schedule meetings
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="relative group">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-2xl blur opacity-25 group-hover:opacity-75 transition"></div>
            <Card className="relative border border-white/10 bg-slate-900/80 backdrop-blur-xl">
              <CardContent className="p-6">
                <Video className="w-10 h-10 text-blue-400 mb-3" />
                <h3 className="text-3xl font-black text-white">{upcomingMeetings.length}</h3>
                <p className="text-sm text-slate-400">Upcoming Meetings</p>
              </CardContent>
            </Card>
          </div>

          <div className="relative group">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-green-600 to-emerald-600 rounded-2xl blur opacity-25 group-hover:opacity-75 transition"></div>
            <Card className="relative border border-white/10 bg-slate-900/80 backdrop-blur-xl">
              <CardContent className="p-6">
                <Users className="w-10 h-10 text-green-400 mb-3" />
                <h3 className="text-3xl font-black text-white">
                  {meetings.reduce((sum, m) => sum + (m.participants?.length || 0), 0)}
                </h3>
                <p className="text-sm text-slate-400">Total Participants</p>
              </CardContent>
            </Card>
          </div>

          <div className="relative group">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl blur opacity-25 group-hover:opacity-75 transition"></div>
            <Card className="relative border border-white/10 bg-slate-900/80 backdrop-blur-xl">
              <CardContent className="p-6">
                <CheckCircle className="w-10 h-10 text-purple-400 mb-3" />
                <h3 className="text-3xl font-black text-white">{pastMeetings.length}</h3>
                <p className="text-sm text-slate-400">Completed</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Upcoming Meetings */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <Calendar className="w-4 h-4 text-white" />
            </div>
            Upcoming Meetings
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {upcomingMeetings.map((meeting) => {
              const isHost = meeting.host_email === user?.email;
              const isJoined = meeting.participants?.includes(user?.email);
              const isFull = meeting.max_participants && meeting.participants?.length >= meeting.max_participants;
              
              return (
                <Card key={meeting.id} className="relative border border-white/10 bg-slate-900/80 backdrop-blur-xl shadow-lg hover:shadow-2xl transition-all transform hover:-translate-y-1">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between mb-3">
                      <Badge className={meeting.is_public ? "bg-green-700/20 text-green-300" : "bg-blue-700/20 text-blue-300"}>
                        {meeting.is_public ? '🌐 Public' : '🔒 Private'}
                      </Badge>
                      {isHost && (
                        <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-white">⭐ Host</Badge>
                      )}
                    </div>
                    <CardTitle className="text-xl text-white">{meeting.title}</CardTitle>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <p className="text-slate-300 text-sm line-clamp-2">
                      {meeting.description}
                    </p>
                    
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-slate-300 bg-slate-800 p-2 rounded-lg">
                        <Calendar className="w-4 h-4 text-blue-400" />
                        <span>{format(new Date(meeting.scheduled_time), 'MMM d, yyyy')}</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-300 bg-slate-800 p-2 rounded-lg">
                        <Clock className="w-4 h-4 text-purple-400" />
                        <span>{format(new Date(meeting.scheduled_time), 'h:mm a')} ({meeting.duration_minutes} min)</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-300 bg-slate-800 p-2 rounded-lg">
                        <Users className="w-4 h-4 text-green-400" />
                        <span>
                          {meeting.participants?.length || 0} / {meeting.max_participants} joined
                        </span>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-700">
                      <p className="text-xs text-slate-400 mb-3">
                        Hosted by <span className="font-semibold text-white">{meeting.host_name}</span>
                      </p>
                      
                      {isJoined || isHost ? (
                        <Link to={`${createPageUrl("MeetingRoom")}?roomId=${meeting.meeting_url}&meetingId=${meeting.id}`}>
                          <Button
                            onClick={() => handleJoinMeeting(meeting)}
                            className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 shadow-md"
                          >
                            <Play className="w-4 h-4 mr-2" />
                            Join Meeting
                          </Button>
                        </Link>
                      ) : isFull ? (
                        <Button disabled className="w-full text-slate-400 bg-slate-800 border-slate-700 hover:bg-slate-700">
                          Meeting Full
                        </Button>
                      ) : meeting.is_public || isAuthenticated ? (
                        <Link to={`${createPageUrl("MeetingRoom")}?roomId=${meeting.meeting_url}&meetingId=${meeting.id}`}>
                          <Button
                            onClick={() => handleJoinMeeting(meeting)}
                            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-md"
                          >
                            {isAuthenticated ? 'Join Meeting' : 'Login to Join'}
                          </Button>
                        </Link>
                      ) : (
                        <Button disabled className="w-full text-slate-400 bg-slate-800 border-slate-700 hover:bg-slate-700">
                          <Lock className="w-4 h-4 mr-2" />
                          Private Meeting
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {upcomingMeetings.length === 0 && (
            <Card className="relative border border-white/10 bg-slate-900/80 backdrop-blur-xl shadow-lg">
              <CardContent className="p-12 text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-800/20 to-purple-800/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Video className="w-10 h-10 text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">No upcoming meetings</h3>
                <p className="text-slate-400">{isAdmin ? 'Schedule your first meeting!' : 'Check back soon for new meetings'}</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Past Meetings */}
        {pastMeetings.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold text-white mb-4">Past Meetings</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {pastMeetings.slice(0, 6).map((meeting) => (
                <Card key={meeting.id} className="relative border border-white/10 bg-slate-900/80 backdrop-blur-xl shadow-lg opacity-75 hover:opacity-100 transition-all">
                  <CardHeader>
                    <Badge variant="outline" className="w-fit mb-2 text-xs text-slate-400 border-slate-700">
                      Completed
                    </Badge>
                    <CardTitle className="text-lg text-white">{meeting.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 text-sm text-slate-300">
                      <Calendar className="w-4 h-4" />
                      <span>{format(new Date(meeting.scheduled_time), 'MMM d, yyyy')}</span>
                    </div>
                    {meeting.recording_url && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="w-full mt-3 text-slate-300 border-slate-700 hover:bg-slate-800 hover:text-white"
                        onClick={() => window.open(meeting.recording_url, '_blank')}
                      >
                        <Play className="w-3 h-3 mr-2" />
                        Watch Recording
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>

      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="sm:max-w-2xl bg-slate-900/90 backdrop-blur-xl border border-white/10 text-white">
          <DialogHeader>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <DialogTitle className="text-2xl text-white">Schedule New Meeting</DialogTitle>
            </div>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-sm font-semibold text-slate-300">Meeting Title</Label>
              <Input
                placeholder="e.g., Leadership Team Sync"
                value={newMeeting.title}
                onChange={(e) => setNewMeeting({...newMeeting, title: e.target.value})}
                className="mt-1 bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>

            <div>
              <Label className="text-sm font-semibold text-slate-300">Description</Label>
              <Textarea
                placeholder="What will this meeting be about?"
                value={newMeeting.description}
                onChange={(e) => setNewMeeting({...newMeeting, description: e.target.value})}
                rows={3}
                className="mt-1 bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-semibold text-slate-300">Date & Time</Label>
                <Input
                  type="datetime-local"
                  value={newMeeting.scheduled_time}
                  onChange={(e) => setNewMeeting({...newMeeting, scheduled_time: e.target.value})}
                  className="mt-1 bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>

              <div>
                <Label className="text-sm font-semibold text-slate-300">Duration (minutes)</Label>
                <Input
                  type="number"
                  value={newMeeting.duration_minutes}
                  onChange={(e) => setNewMeeting({...newMeeting, duration_minutes: parseInt(e.target.value)})}
                  className="mt-1 bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
            </div>

            <div>
              <Label className="text-sm font-semibold text-slate-300">Max Participants</Label>
              <Input
                type="number"
                value={newMeeting.max_participants}
                onChange={(e) => setNewMeeting({...newMeeting, max_participants: parseInt(e.target.value)})}
                className="mt-1 bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>

            <div className="flex items-center gap-3 p-3 bg-slate-800 rounded-lg">
              <input
                type="checkbox"
                id="is_public"
                checked={newMeeting.is_public}
                onChange={(e) => setNewMeeting({...newMeeting, is_public: e.target.checked})}
                className="w-5 h-5 rounded accent-blue-600"
              />
              <Label htmlFor="is_public" className="font-medium cursor-pointer text-white">
                Public meeting - anyone can join
              </Label>
            </div>

            <div className="p-4 bg-blue-500/10 rounded-xl border-2 border-blue-500/30">
              <p className="text-sm text-blue-300 font-medium flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                Meeting happens right in the app - no external links needed!
              </p>
            </div>

            <Button
              onClick={handleCreateMeeting}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-lg"
              disabled={!newMeeting.title || !newMeeting.scheduled_time}
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Schedule Meeting
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
