import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input'; // Added Input component
import {
  Home,
  FileText,
  CheckSquare,
  BarChart3,
  Bot,
  Calendar,
  MessageSquare,
  Settings,
  Loader2,
  Briefcase,
  Search,
  Plus,
  Clock,
  Target,
  Sparkles,
  Zap,
  Mail,
  BarChart2,
  ExternalLink,
  Users,
  Trash2,
  X,
  CheckCircle,
  Star,
  Lock,
  Crown,
  Building2, // Added Building2 icon
  TrendingUp, // Added TrendingUp icon
  Waves, // Added Waves icon
  Volume2 // Added Volume2 icon for Voice Summarizer
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate, Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// Import module components with .jsx extension
import HomeModule from '@/components/professional/HomeModule.jsx';
import DocumentsModule from '@/components/professional/DocumentsModule.jsx';
import TasksModule from '@/components/professional/TasksModule.jsx';
import AnalyticsModule from '@/components/professional/AnalyticsModule.jsx';
import AIStudioModule from '@/components/professional/AIStudioModule.jsx';
import MeetingsModule from '@/components/professional/MeetingsModule.jsx';
import CommunicationModule from '@/components/professional/CommunicationModule.jsx';
import SettingsModule from '@/components/professional/SettingsModule.jsx';
import OfficeViewer from '@/components/professional/OfficeViewer.jsx';
import BusinessPlanGenerator from '@/components/professional/BusinessPlanGenerator.jsx';
import MarketingPlanGenerator from '@/components/professional/MarketingPlanGenerator.jsx';
import MindRest from '@/components/MindRest';
import VoiceSummarizer from '@/components/VoiceSummarizer'; // NEW

const MODULES = [
  { id: 'home', label: 'Home', icon: Home, component: HomeModule },
  { id: 'documents', label: 'Documents', icon: FileText, component: DocumentsModule },
  { id: 'tasks', label: 'Tasks', icon: CheckSquare, component: TasksModule },
  { id: 'analytics', label: 'Analytics', icon: BarChart3, component: AnalyticsModule },
  { id: 'ai_studio', label: 'AI Studio', icon: Bot, component: AIStudioModule },
  { id: 'meetings', label: 'Meetings', icon: Calendar, component: MeetingsModule },
  { id: 'communication', label: 'Messages', icon: MessageSquare, component: CommunicationModule },
  { id: 'settings', label: 'Settings', icon: Settings, component: SettingsModule }
];

const THEMES = {
  minimal_zen: {
    bg: 'from-slate-50 to-slate-100',
    sidebar: 'bg-white border-slate-200',
    accent: 'from-slate-600 to-slate-700'
  },
  dynamic_visual: {
    bg: 'from-blue-50 via-purple-50 to-pink-50',
    sidebar: 'bg-white/90 backdrop-blur-xl border-blue-200',
    accent: 'from-blue-600 to-purple-600'
  },
  dark_executive: {
    bg: 'from-slate-900 to-slate-800',
    sidebar: 'bg-slate-800/90 backdrop-blur-xl border-slate-700',
    accent: 'from-slate-600 to-slate-500',
    dark: true
  },
  vibrant_energetic: {
    bg: 'from-orange-50 via-pink-50 to-rose-50',
    sidebar: 'bg-white/90 backdrop-blur-xl border-orange-200',
    accent: 'from-orange-600 to-pink-600'
  }
};

const QUICK_APPS = [
  {
    name: 'Voice Summarizer',
    icon: Volume2,
    onClick: 'voice_summarizer',
    color: 'from-red-500 to-pink-600',
    description: 'Audio to text',
    emoji: '🎤'
  },
  {
    name: 'Interview Prep',
    icon: Briefcase,
    url: createPageUrl('Practice') + '?module=interview_preparation',
    color: 'from-indigo-500 to-purple-600',
    description: 'CV Analysis',
    emoji: '💼'
  },
  {
    name: 'Rest Mode',
    icon: Waves,
    url: createPageUrl('RestMode'),
    color: 'from-teal-500 to-emerald-600',
    description: '5min calm',
    emoji: '🧘'
  },
  // Google Apps (Embedded)
  {
    name: 'Google Docs',
    icon: FileText,
    appKey: 'google_docs',
    color: 'from-blue-500 to-blue-600',
    description: 'Documents',
    emoji: '📝',
    embedded: true
  },
  {
    name: 'Google Sheets',
    icon: BarChart2,
    appKey: 'google_sheets',
    color: 'from-green-500 to-green-600',
    description: 'Spreadsheets',
    emoji: '📊',
    embedded: true
  },
  {
    name: 'Google Slides',
    icon: Briefcase,
    appKey: 'google_slides',
    color: 'from-yellow-500 to-orange-600',
    description: 'Presentations',
    emoji: '🎨',
    embedded: true
  },
  {
    name: 'Google Drive',
    icon: FileText,
    appKey: 'google_drive',
    color: 'from-purple-500 to-purple-600',
    description: 'Cloud Files',
    emoji: '📁',
    embedded: true
  },
  // Microsoft Apps (New Tab)
  {
    name: 'Outlook',
    icon: Mail,
    externalUrl: 'https://outlook.office.com',
    color: 'from-blue-600 to-blue-700',
    description: 'Email',
    emoji: '📧',
    embedded: false
  },
  {
    name: 'Office 365',
    icon: FileText,
    externalUrl: 'https://www.office.com',
    color: 'from-orange-600 to-red-600',
    description: 'MS Office',
    emoji: '📄',
    embedded: false
  },
  {
    name: 'Power BI',
    icon: BarChart2,
    externalUrl: 'https://app.powerbi.com',
    color: 'from-yellow-600 to-yellow-700',
    description: 'Analytics',
    emoji: '📈',
    embedded: false
  },
  {
    name: 'Teams',
    icon: Users,
    externalUrl: 'https://teams.microsoft.com',
    color: 'from-purple-600 to-indigo-600',
    description: 'Collaborate',
    emoji: '👥',
    embedded: false
  },
  // Internal Pages
  {
    name: 'Meet',
    icon: Calendar,
    url: createPageUrl('MeetingRooms'),
    color: 'from-green-600 to-emerald-600',
    description: 'Join',
    emoji: '📹'
  },
  {
    name: 'Career',
    icon: Users,
    url: createPageUrl('CareerLink'),
    color: 'from-pink-600 to-purple-600',
    description: 'Network',
    emoji: '💼'
  },
  {
    name: 'Training',
    icon: Briefcase,
    url: createPageUrl('PowerPointGenerator'),
    color: 'from-indigo-600 to-purple-600',
    description: 'Reports',
    emoji: '📊'
  }
];

export default function ProfessionalSpace() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const [userPlan, setUserPlan] = useState(null);
  const [activeModule, setActiveModule] = useState('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [showActionPlanGenerator, setShowActionPlanGenerator] = useState(false);
  const [actionPlanMode, setActionPlanMode] = useState(null); // NEW: 'simple' or 'advanced' or null for selection
  const [openOfficeApp, setOpenOfficeApp] = useState(null);
  const [showBusinessPlan, setShowBusinessPlan] = useState(false);
  const [showMarketingPlan, setShowMarketingPlan] = useState(false);
  const [showMindRest, setShowMindRest] = useState(false);
  const [showVoiceSummarizer, setShowVoiceSummarizer] = useState(false); // NEW

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        // CHECK SUBSCRIPTION ACCESS - WAIT FOR THIS TO COMPLETE
        if (currentUser.subscription_plan_id) {
          const plans = await base44.entities.SubscriptionPlan.filter({ id: currentUser.subscription_plan_id });
          const plan = plans[0];
          setUserPlan(plan);
          setHasAccess(plan?.features?.access_professional_space === true);
        } else {
          setHasAccess(false);
        }
        
        // Only set loading to false AFTER access check completes
        setLoading(false);
      } catch (error) {
        console.error('Error:', error);
        setHasAccess(false);
        setLoading(false);
      }
    };
    fetchUser();
  }, []);

  const { data: config } = useQuery({
    queryKey: ['workspaceConfig', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const configs = await base44.entities.WorkspaceConfig.filter({ user_email: user.email });
      return configs[0] || null;
    },
    enabled: !!user?.email
  });

  // Redirect to onboarding if not completed
  useEffect(() => {
    // Only redirect if user is loaded, not loading, and has access
    if (!loading && hasAccess && user && config === null) {
      navigate(createPageUrl('ProfessionalOnboarding'));
    } else if (!loading && hasAccess && user && config && !config.onboarding_completed) {
      navigate(createPageUrl('ProfessionalOnboarding'));
    }
  }, [user, config, navigate, loading, hasAccess]);

  const handleStartInstantMeeting = () => {
    // Switch to meetings module to trigger instant meeting
    setActiveModule('meetings');
    // Small delay to allow module to render, then trigger instant meeting
    setTimeout(() => {
      // Find the meetings module and trigger its instant meeting function
      const meetingsButton = document.querySelector('[data-instant-meeting]');
      if (meetingsButton) {
        meetingsButton.click();
      }
    }, 100);
  };

  const handleOpenApp = (app) => {
    if (app.onClick === 'voice_summarizer') { // NEW
      setShowVoiceSummarizer(true); // NEW
    } else if (app.embedded && app.appKey) {
      // Open embedded viewer INSIDE the app
      setOpenOfficeApp(app.appKey);
    } else if (app.externalUrl) {
      // Open Microsoft apps in new tab
      window.open(app.externalUrl, '_blank', 'noopener,noreferrer');
    } else if (app.url) {
      // Navigate to internal page
      navigate(app.url);
    }
  };

  // ACCESS CONTROL - Check BEFORE loading check
  if (!loading && !hasAccess && user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-purple-900 flex items-center justify-center p-6">
        <Card className="max-w-2xl border-none shadow-2xl">
          <CardContent className="p-12 text-center">
            <div className="w-24 h-24 bg-indigo-600/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Lock className="w-12 h-12 text-indigo-500" />
            </div>
            <h2 className="text-3xl font-bold text-slate-900 mb-4">🔒 Professional Space Locked</h2>
            <p className="text-slate-600 mb-8">Upgrade to access Professional Space with all productivity tools!</p>
            
            <Link to={createPageUrl("Subscription")}>
              <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 py-6 px-8 text-xl font-bold shadow-xl">
                <Crown className="w-6 h-6 mr-2" />
                View Plans & Upgrade
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading || !user || !config) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-white animate-spin" />
      </div>
    );
  }

  const theme = THEMES[config.theme] || THEMES.dynamic_visual;
  const ActiveComponent = MODULES.find(m => m.id === activeModule)?.component || HomeModule;

  const textColor = theme.dark ? 'text-white' : 'text-slate-900';
  const textSecondary = theme.dark ? 'text-slate-300' : 'text-slate-600';

  return (
    <div className={`min-h-screen bg-gradient-to-br ${theme.bg}`}>
      <MindRest isOpen={showMindRest} onClose={() => setShowMindRest(false)} />
      <VoiceSummarizer isOpen={showVoiceSummarizer} onClose={() => setShowVoiceSummarizer(false)} /> {/* NEW */}
      
      {/* Top Bar - REDESIGNED & CLEANER */}
      <div className={`${theme.dark ? 'bg-slate-800/90' : 'bg-white/90'} backdrop-blur-xl border-b ${theme.dark ? 'border-slate-700' : 'border-slate-200'} shadow-lg sticky top-0 z-40`}>
        <div className="px-6 py-4">
          <div className="flex items-center justify-between gap-6">
            {/* Left: Logo + Search */}
            <div className="flex items-center gap-4 flex-1 max-w-2xl">
              <div className={`w-12 h-12 bg-gradient-to-br ${theme.accent} rounded-xl flex items-center justify-center shadow-lg flex-shrink-0`}>
                <Briefcase className="w-6 h-6 text-white" />
              </div>
              
              <div className="flex-1">
                <div className="relative">
                  <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 ${textSecondary}`} />
                  <input
                    type="text"
                    placeholder="Ask your workspace anything..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className={`w-full pl-11 pr-4 py-3 rounded-xl border-2 ${
                      theme.dark 
                        ? 'bg-slate-700/50 border-slate-600 text-white placeholder-slate-400' 
                        : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-500'
                    } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base`}
                  />
                </div>
              </div>
            </div>

            {/* Right: MIND REST + Plan Generators + Time + User */}
            <div className="flex items-center gap-3">
              {/* 🎤 VOICE SUMMARIZER 🎤 */}
              <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-red-600 via-pink-600 to-rose-600 rounded-xl blur opacity-75"></div>
                <Button
                  onClick={() => setShowVoiceSummarizer(true)}
                  className="relative bg-gradient-to-r from-red-600 via-pink-600 to-rose-600 hover:from-red-700 hover:via-pink-700 hover:to-rose-700 text-white shadow-2xl transform hover:scale-105 transition-all font-black px-6 py-6 border-2 border-white"
                  size="lg"
                >
                  <Volume2 className="w-6 h-6 mr-2" />
                  <div className="text-left">
                    <div className="text-base leading-tight">Voice</div>
                    <div className="text-sm leading-tight">Summary 🎤</div>
                  </div>
                </Button>
              </div>

              {/* 🌊 MIND REST 🌊 */}
              <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-teal-600 via-emerald-600 to-green-600 rounded-xl blur opacity-75"></div>
                <Button
                  onClick={() => setShowMindRest(true)}
                  className="relative bg-gradient-to-r from-teal-600 via-emerald-600 to-green-600 hover:from-teal-700 hover:via-emerald-700 hover:to-green-700 text-white shadow-2xl transform hover:scale-105 transition-all font-black px-6 py-6 border-2 border-white"
                  size="lg"
                >
                  <Waves className="w-6 h-6 mr-2" />
                  <div className="text-left">
                    <div className="text-base leading-tight">Mind</div>
                    <div className="text-sm leading-tight">Rest 🌊</div>
                  </div>
                </Button>
              </div>

              {/* ✨ ACTION PLAN ✨ */}
              <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 rounded-xl blur opacity-75 animate-pulse"></div>
                <Button
                  onClick={() => setShowActionPlanGenerator(true)}
                  className="relative bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 hover:from-green-700 hover:via-emerald-700 hover:to-teal-700 text-white shadow-2xl transform hover:scale-105 transition-all font-black px-6 py-6 border-2 border-white"
                  size="lg"
                >
                  <Target className="w-6 h-6 mr-2" />
                  <div className="text-left">
                    <div className="text-base leading-tight">Action</div>
                    <div className="text-sm leading-tight">Plan 🎯</div>
                  </div>
                </Button>
              </div>

              {/* 🏢 BUSINESS PLAN 🏢 */}
              <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-xl blur opacity-75"></div>
                <Button
                  onClick={() => setShowBusinessPlan(true)}
                  className="relative bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:via-indigo-700 hover:to-purple-700 text-white shadow-2xl transform hover:scale-105 transition-all font-black px-6 py-6 border-2 border-white"
                  size="lg"
                >
                  <Building2 className="w-6 h-6 mr-2" />
                  <div className="text-left">
                    <div className="text-base leading-tight">Business</div>
                    <div className="text-sm leading-tight">Plan 🏢</div>
                  </div>
                </Button>
              </div>

              {/* 📈 MARKETING PLAN 📈 */}
              <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-pink-600 via-purple-600 to-fuchsia-600 rounded-xl blur opacity-75"></div>
                <Button
                  onClick={() => setShowMarketingPlan(true)}
                  className="relative bg-gradient-to-r from-pink-600 via-purple-600 to-fuchsia-600 hover:from-pink-700 hover:via-purple-700 hover:to-fuchsia-700 text-white shadow-2xl transform hover:scale-105 transition-all font-black px-6 py-6 border-2 border-white"
                  size="lg"
                >
                  <TrendingUp className="w-6 h-6 mr-2" />
                  <div className="text-left">
                    <div className="text-base leading-tight">Marketing</div>
                    <div className="text-sm leading-tight">Plan 📈</div>
                  </div>
                </Button>
              </div>

              <div className={`px-4 py-2 rounded-xl ${theme.dark ? 'bg-slate-700' : 'bg-slate-100'} flex-shrink-0`}>
                <div className="flex items-center gap-2">
                  <Clock className={`w-4 h-4 ${textSecondary}`} />
                  <span className={`text-sm font-semibold ${textColor}`}>
                    {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>

              <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${theme.accent} flex items-center justify-center text-white font-bold text-lg shadow-lg flex-shrink-0`}>
                {user.full_name?.charAt(0) || 'U'}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex">
        {/* Left Sidebar - CLEANER */}
        <div className={`w-64 ${theme.sidebar} border-r ${theme.dark ? 'border-slate-700' : 'border-slate-200'} h-[calc(100vh-80px)] sticky top-20 shadow-xl`}>
          <div className="p-4 space-y-2">
            <div className="mb-4">
              <h3 className={`text-xs font-bold ${textSecondary} uppercase tracking-wider mb-2`}>
                Navigation
              </h3>
            </div>

            {/* 📄 CV GENERATOR BUTTON - PROMINENT! */}
            <Link to={createPageUrl("CVGenerator")}>
              <button className="w-full flex items-center gap-3 px-4 py-4 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:shadow-xl transition-all transform hover:scale-105 mb-4">
                <FileText className="w-5 h-5" />
                <div className="flex-1 text-left">
                  <span className="font-bold block">Generate CV</span>
                  <span className="text-xs text-white/80">Professional templates</span>
                </div>
                <Badge className="bg-white/20 text-white text-xs">NEW</Badge>
              </button>
            </Link>

            {MODULES.filter(m => config.enabled_modules?.includes(m.id) || m.id === 'home' || m.id === 'settings').map(module => {
              const Icon = module.icon;
              const isActive = activeModule === module.id;
              
              return (
                <motion.button
                  key={module.id}
                  onClick={() => setActiveModule(module.id)}
                  whileHover={{ scale: 1.02, x: 4 }}
                  whileTap={{ scale: 0.98 }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                    isActive 
                      ? `bg-gradient-to-r ${theme.accent} text-white shadow-lg` 
                      : `${theme.dark ? 'hover:bg-slate-700/50 text-slate-300' : 'hover:bg-slate-100 text-slate-700'}`
                  }`}
                >
                  <Icon className="w-5 h-5 flex-shrink-0" />
                  <span className="font-semibold text-sm">{module.label}</span>
                  {module.badge && (
                    <Badge className="ml-auto text-xs">{module.badge}</Badge>
                  )}
                </motion.button>
              );
            })}
          </div>

          {/* AI Personality Indicator */}
          <div className={`absolute bottom-4 left-4 right-4 p-3 rounded-xl ${theme.dark ? 'bg-slate-700/50' : 'bg-slate-100'}`}>
            <div className="flex items-center gap-2">
              <Sparkles className={`w-4 h-4 ${textSecondary}`} />
              <div>
                <p className={`text-xs font-semibold ${textColor}`}>AI Assistant</p>
                <p className={`text-xs ${textSecondary}`}>
                  {config.ai_personality?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6 overflow-auto">
          <motion.div
            key={activeModule}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <ActiveComponent 
              user={user} 
              config={config} 
              theme={theme}
              searchQuery={searchQuery}
              onStartInstantMeeting={activeModule === 'home' ? handleStartInstantMeeting : undefined}
              onOpenOfficeApp={activeModule === 'home' ? handleOpenApp : undefined}
            />
          </motion.div>
        </div>

        {/* Right Sidebar - REDESIGNED QUICK ACCESS */}
        <div className={`w-80 ${theme.sidebar} border-l ${theme.dark ? 'border-slate-700' : 'border-slate-200'} h-[calc(100vh-80px)] sticky top-20 shadow-xl p-4 overflow-y-auto`}>
          <div className="flex items-center gap-2 mb-4">
            <Bot className={`w-5 h-5 ${textColor}`} />
            <h3 className={`font-bold ${textColor}`}>AI Companion</h3>
          </div>

          <Card className={`border-none ${theme.dark ? 'bg-slate-700/50' : 'bg-gradient-to-br from-blue-50 to-purple-50'} shadow-lg mb-6`}>
            <CardContent className="p-4">
              <p className={`text-sm ${textColor} mb-3 leading-relaxed`}>
                {activeModule === 'home' && "Good to see you! Ready to tackle today's priorities?"}
                {activeModule === 'documents' && "I can help summarize, tag, or analyze your documents."}
                {activeModule === 'tasks' && "Want me to prioritize your tasks or suggest a schedule?"}
                {activeModule === 'analytics' && "I can help you build custom KPIs or spot trends."}
                {activeModule === 'ai_studio' && "What would you like me to help you create today?"}
                {activeModule === 'meetings' && "I can generate agendas or extract action items from notes."}
                {activeModule === 'communication' && "Need help drafting a reply or summarizing messages?"}
                {activeModule === 'settings' && "You can customize my personality and your workspace here."}
              </p>
              <Button size="sm" className={`w-full bg-gradient-to-r ${theme.accent} text-white`}>
                <Zap className="w-4 h-4 mr-1" />
                Ask AI
              </Button>
            </CardContent>
          </Card>

          {/* Quick Access - UPDATED */}
          <div className="mb-6">
            <h4 className={`text-xs font-bold ${textSecondary} uppercase tracking-wider mb-3 flex items-center gap-2`}>
              <Sparkles className="w-3 h-3" />
              Quick Access
            </h4>
            <div className="grid grid-cols-2 gap-3">
              {QUICK_APPS.map(app => {
                return (
                  <button
                    key={app.name}
                    onClick={() => handleOpenApp(app)}
                    className={`group flex flex-col items-center gap-2 p-4 rounded-xl ${
                      theme.dark ? 'bg-slate-700/50 hover:bg-slate-700' : 'bg-slate-50 hover:bg-slate-100'
                    } transition-all hover:scale-105 hover:shadow-lg border ${
                      theme.dark ? 'border-slate-600' : 'border-slate-200'
                    } cursor-pointer relative`}
                  >
                    {!app.embedded && app.externalUrl && (
                      <ExternalLink className="w-3 h-3 absolute top-2 right-2 text-slate-400" />
                    )}
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${app.color} flex items-center justify-center shadow-md group-hover:shadow-xl transition-all`}>
                      <span className="text-2xl">{app.emoji}</span>
                    </div>
                    <div className="text-center">
                      <p className={`text-xs font-bold ${textColor} truncate w-full`}>{app.name}</p>
                      <p className={`text-[10px] ${textSecondary} truncate w-full`}>{app.description}</p>
                    </div>
                  </button>
                );
              })}
            </div>
            
            <div className={`mt-4 p-3 rounded-lg ${theme.dark ? 'bg-slate-700/50' : 'bg-blue-50'} border ${theme.dark ? 'border-slate-600' : 'border-blue-200'}`}>
              <p className={`text-xs ${theme.dark ? 'text-slate-300' : 'text-slate-600'}`}>
                <span className="font-semibold">✅ Google apps</span> = Open in app
                <br />
                <ExternalLink className="w-3 h-3 inline mr-1" />
                <span className="font-semibold">Microsoft apps</span> = New tab
              </p>
            </div>
          </div>

          {/* Quick Actions - CLEANER */}
          <div className="space-y-2">
            <h4 className={`text-xs font-bold ${textSecondary} uppercase tracking-wider mb-3 flex items-center gap-2`}>
              <Target className="w-3 h-3" />
              Quick Actions
            </h4>
            {[
              { icon: Target, label: 'New Task', action: () => setActiveModule('tasks') },
              { icon: FileText, label: 'Upload Doc', action: () => setActiveModule('documents') },
              { icon: Calendar, label: 'Schedule Meeting', action: () => setActiveModule('meetings') },
              { icon: BarChart3, label: 'View Analytics', action: () => setActiveModule('analytics') }
            ].map((item, idx) => {
              const Icon = item.icon;
              return (
                <button
                  key={idx}
                  onClick={item.action}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl ${
                    theme.dark ? 'hover:bg-slate-700/50 text-slate-300' : 'hover:bg-slate-100 text-slate-700'
                  } transition-all hover:scale-102 border ${
                    theme.dark ? 'border-transparent hover:border-slate-600' : 'border-transparent hover:border-slate-200'
                  }`}
                >
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  <span className="text-sm font-medium">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Office Viewer Overlay - RENDERS INSIDE APP */}
      {openOfficeApp && (
        <OfficeViewer
          appKey={openOfficeApp}
          onClose={() => setOpenOfficeApp(null)}
          theme={theme}
        />
      )}

      {/* Action Plan Generator Dialog - UPDATED WITH MODE SELECTION */}
      {showActionPlanGenerator && (
        <ActionPlanGenerator
          user={user}
          theme={theme}
          mode={actionPlanMode}
          onClose={() => {
            setShowActionPlanGenerator(false);
            setActionPlanMode(null);
          }}
          onSelectMode={(mode) => setActionPlanMode(mode)}
        />
      )}

      {/* Business Plan Generator Dialog */}
      {showBusinessPlan && (
        <BusinessPlanGenerator
          user={user}
          onClose={() => setShowBusinessPlan(false)}
        />
      )}

      {/* Marketing Plan Generator Dialog */}
      {showMarketingPlan && (
        <MarketingPlanGenerator
          user={user}
          onClose={() => setShowMarketingPlan(false)}
        />
      )}
    </div>
  );
}

// UPDATED Action Plan Generator - Simple = current form, Advanced = MORE questions
function ActionPlanGenerator({ user, theme, mode, onClose, onSelectMode }) {
  const [step, setStep] = useState(mode ? 1 : 0); // Step 0 = mode selection
  const [generating, setGenerating] = useState(false);
  
  // Simple mode uses the CURRENT form (same as before)
  const [formData, setFormData] = useState({
    problem: '',
    goal: '',
    industry: '',
    timeline: '3 months',
    currentMetrics: '',
    whatsWorking: '',
    whatsNotWorking: '',
    teamSize: '1',
    budget: '',
    availableTools: ''
  });

  // Advanced mode has ADDITIONAL fields
  const [advancedData, setAdvancedData] = useState({
    problem: '',
    goal: '',
    industry: '',
    timeline: '3 months',
    currentMetrics: '',
    whatsWorking: '',
    whatsNotWorking: '',
    company_name: '', // NEW
    teamSize: '1',
    team_members: [], // NEW: [{name: "", role: "", strengths: ""}]
    budget: '',
    availableTools: '',
    current_revenue: '',
    revenue_goal: '',
    main_competitors: '',
    unique_value_proposition: '',
    biggest_bottleneck: '',
    past_attempts: '',
    customer_feedback: ''
  });
  
  const [generatedPlan, setGeneratedPlan] = useState(null);

  // Update team members array when team size changes
  const handleTeamSizeChange = (size) => {
    const numSize = parseInt(size) || 1;
    const currentMembers = advancedData.team_members || [];
    
    // Add or remove team members to match size
    const newMembers = [];
    for (let i = 0; i < numSize; i++) {
      newMembers.push(currentMembers[i] || { name: '', role: '', strengths: '' });
    }
    
    setAdvancedData({ 
      ...advancedData, 
      teamSize: size,
      team_members: newMembers 
    });
  };

  const updateTeamMember = (index, field, value) => {
    const updated = [...advancedData.team_members];
    updated[index] = { ...updated[index], [field]: value };
    setAdvancedData({ ...advancedData, team_members: updated });
  };

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const dataToUse = mode === 'simple' ? formData : advancedData;
      
      let prompt = `Create a SPECIFIC, TAILORED ACTION PLAN.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 SITUATION:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${mode === 'advanced' && dataToUse.company_name ? `COMPANY: ${dataToUse.company_name}\n` : ''}PROBLEM: ${dataToUse.problem}
GOAL: ${dataToUse.goal}
Industry: ${dataToUse.industry || 'General'}
Timeline: ${dataToUse.timeline}

CURRENT METRICS:
${dataToUse.currentMetrics || 'Not provided'}

✅ WHAT'S WORKING:
${dataToUse.whatsWorking || 'Not specified'}

❌ WHAT'S NOT WORKING:
${dataToUse.whatsNotWorking || 'Not specified'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👥 RESOURCES:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Team Size: ${dataToUse.teamSize}
Budget: ${dataToUse.budget || 'Limited'}
Available Tools: ${dataToUse.availableTools || 'Standard business tools'}`;

      // Add ADVANCED-only context
      if (mode === 'advanced') {
        prompt += `

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 ADVANCED DETAILS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TEAM STRUCTURE:
${advancedData.team_members?.filter(t => t.name || t.role).map(t => 
  `• ${t.name || 'Team Member'} - ${t.role || 'Role TBD'}${t.strengths ? ` (Strengths: ${t.strengths})` : ''}`
).join('\n') || 'Generic team'}

FINANCIAL CONTEXT:
Current Revenue: ${advancedData.current_revenue || 'Not provided'}
Revenue Goal: ${advancedData.revenue_goal || 'Not provided'}

MARKET POSITION:
Main Competitors: ${advancedData.main_competitors || 'Not specified'}
Unique Value Proposition: ${advancedData.unique_value_proposition || 'Not specified'}

CONSTRAINTS:
Biggest Bottleneck: ${advancedData.biggest_bottleneck || 'Not specified'}
Past Failed Attempts: ${advancedData.past_attempts || 'None mentioned'}
Customer Feedback: ${advancedData.customer_feedback || 'Not provided'}

CRITICAL INSTRUCTIONS:
1. Assign action items to SPECIFIC team members by name and role
2. Leverage each person's strengths for their assigned tasks
3. Include revenue-focused strategies
4. Address competitor positioning directly
5. Avoid repeating past failures
6. Use customer insights to guide decisions`;
      }

      prompt += `

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 CREATE SMART ACTION PLAN:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE:
- SWOT based on THEIR data
- 3-5 SMART goals addressing REAL problems
- 5-8 specific action steps ${mode === 'advanced' ? '(assign to SPECIFIC team members by NAME and ROLE)' : ''}
- Milestones
- KPIs to track`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            executive_summary: { type: "string" },
            swot: {
              type: "object",
              properties: {
                strengths: { type: "array", items: { type: "string" } },
                weaknesses: { type: "array", items: { type: "string" } },
                opportunities: { type: "array", items: { type: "string" } },
                threats: { type: "array", items: { type: "string" } }
              }
            },
            smart_goals: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  specific: { type: "string" },
                  measurable: { type: "string" },
                  achievable: { type: "string" },
                  relevant: { type: "string" },
                  time_bound: { type: "string" }
                }
              }
            },
            action_steps: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  step_number: { type: "number" },
                  action: { type: "string" },
                  responsible: { type: "string" },
                  timeline: { type: "string" },
                  resources: { type: "string" }
                }
              }
            },
            milestones: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  target_date: { type: "string" },
                  metrics: { type: "string" }
                }
              }
            },
            kpis: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  metric: { type: "string" },
                  target: { type: "string" },
                  frequency: { type: "string" }
                }
              }
            }
          }
        }
      });

      setGeneratedPlan(result);
      setStep(mode === 'simple' ? 3 : 4); // Simple goes to step 3 (download), Advanced goes to step 4
    } catch (error) {
      alert('❌ Failed to generate: ' + error.message);
    } finally {
      setGenerating(false);
    }
  };

  const handleDownloadPDF = async () => {
    if (!generatedPlan) return;

    setGenerating(true);
    try {
      const dataToUse = mode === 'simple' ? formData : advancedData;

      const response = await base44.functions.invoke('generateActionPlanPDF', {
        planData: generatedPlan,
        formData: dataToUse,
        mode: mode
      });

      // FIXED: Properly decode Base64 PDF
      const base64 = response.data.pdfBase64;
      const binaryString = atob(base64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'application/pdf' });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `ActionPlan_${dataToUse.goal.replace(/[^a-z0-9]/gi, '_').substring(0, 50)}.pdf`;
      link.click();
      window.URL.revokeObjectURL(url);

      alert('✅ PDF Downloaded Successfully!');
    } catch (error) {
      alert('❌ Download failed: ' + error.message);
    } finally {
      setGenerating(false);
    }
  };

  // Step 0: MODE SELECTION
  if (step === 0) {
    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-5xl w-full"
        >
          {/* Close button */}
          <div className="flex justify-end mb-4">
            <Button onClick={onClose} variant="ghost" className="text-white hover:bg-white/20" size="icon">
              <X className="w-6 h-6" />
            </Button>
          </div>

          {/* Animated glow effect */}
          <div className="relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 rounded-3xl blur-lg opacity-75 animate-pulse"></div>
            
            <Card className="relative border-none shadow-2xl bg-white overflow-hidden">
              {/* Top Banner */}
              <div className="bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 text-white text-center py-6">
                <div className="flex items-center justify-center gap-3">
                  <Sparkles className="w-10 h-10 animate-bounce" />
                  <h2 className="text-4xl font-black uppercase tracking-wide">
                    🎯 Choose Your Plan Mode 🚀
                  </h2>
                  <p className="text-white/90 text-xl mt-2 font-semibold">
                    Standard OR Super Detailed?
                  </p>
                </div>
              </div>

              <CardContent className="p-0">
                <div className="grid md:grid-cols-2 gap-0">
                  {/* ⚡ SIMPLE MODE - LEFT */}
                  <div
                    onClick={() => {
                      onSelectMode('simple');
                      setStep(1);
                    }}
                    className="group p-10 hover:bg-gradient-to-br hover:from-green-50 hover:to-emerald-50 transition-all cursor-pointer border-r-4 border-white relative overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-emerald-500/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    
                    <div className="relative z-10">
                      <div className="flex items-center gap-4 mb-6">
                        <div className="w-24 h-24 bg-gradient-to-br from-green-500 to-emerald-600 rounded-3xl flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform">
                          <Zap className="w-12 h-12 text-white" />
                        </div>
                        <div>
                          <Badge className="bg-green-600 text-white mb-2 text-sm px-4 py-1.5">
                            ⚡ STANDARD
                          </Badge>
                          <h3 className="text-4xl font-black text-slate-900 mb-1">
                            Simple Mode
                          </h3>
                          <p className="text-slate-600 font-bold text-lg">
                            Comprehensive Plan
                          </p>
                        </div>
                      </div>

                      <ul className="space-y-4 mb-8">
                        <li className="flex items-center gap-3 text-slate-700">
                          <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-md">
                            <CheckCircle className="w-5 h-5 text-white" />
                          </div>
                          <span className="font-bold text-lg">✅ Problem & Goal analysis</span>
                        </li>
                        <li className="flex items-center gap-3 text-slate-700">
                          <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-md">
                            <CheckCircle className="w-5 h-5 text-white" />
                          </div>
                          <span className="font-bold text-lg">✅ SWOT + SMART goals</span>
                        </li>
                        <li className="flex items-center gap-3 text-slate-700">
                          <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-md">
                            <CheckCircle className="w-5 h-5 text-white" />
                          </div>
                          <span className="font-bold text-lg">✅ Action steps & KPIs</span>
                        </li>
                      </ul>

                      <Button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectMode('simple');
                          setStep(1);
                        }}
                        className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white shadow-2xl py-10 text-2xl font-black group-hover:scale-105 transition-transform"
                        size="lg"
                      >
                        <Zap className="w-8 h-8 mr-3" />
                        Start Simple ⚡
                      </Button>
                    </div>
                  </div>

                  {/* 🎯 ADVANCED MODE - RIGHT */}
                  <div
                    onClick={() => {
                      onSelectMode('advanced');
                      setStep(1);
                    }}
                    className="group p-10 hover:bg-gradient-to-br hover:from-purple-50 hover:to-pink-50 transition-all cursor-pointer relative overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    
                    <div className="relative z-10">
                      <div className="flex items-center gap-4 mb-6">
                        <div className="w-24 h-24 bg-gradient-to-br from-purple-600 to-pink-600 rounded-3xl flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform">
                          <Target className="w-12 h-12 text-white" />
                        </div>
                        <div>
                          <Badge className="bg-purple-600 text-white mb-2 text-sm px-4 py-1.5">
                            🎯 PREMIUM
                          </Badge>
                          <h3 className="text-4xl font-black text-slate-900 mb-1">
                            Advanced Mode
                          </h3>
                          <p className="text-slate-600 font-bold text-lg">
                            Ultra-Detailed Plan
                          </p>
                        </div>
                      </div>

                      <ul className="space-y-4 mb-8">
                        <li className="flex items-center gap-3 text-slate-700">
                          <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-md">
                            <Star className="w-5 h-5 text-white" />
                          </div>
                          <span className="font-bold text-lg">⭐ Everything in Standard +</span>
                        </li>
                        <li className="flex items-center gap-3 text-slate-700">
                          <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-md">
                            <Star className="w-5 h-5 text-white" />
                          </div>
                          <span className="font-bold text-lg">⭐ Team role assignments & strengths</span>
                        </li>
                        <li className="flex items-center gap-3 text-slate-700">
                          <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-md">
                            <Star className="w-5 h-5 text-white" />
                          </div>
                          <span className="font-bold text-lg">⭐ Competitor & Financial Analysis</span>
                        </li>
                      </ul>

                      <Button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectMode('advanced');
                          setStep(1);
                        }}
                        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-2xl py-10 text-2xl font-black group-hover:scale-105 transition-transform"
                        size="lg"
                      >
                        <Target className="w-8 h-8 mr-3" />
                        Go Advanced 🎯
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </div>
    );
  }

  // SIMPLE MODE - Step 1: Problem & Current Situation
  if (mode === 'simple' && step === 1) {
    const canProceed = formData.problem.trim() && formData.goal.trim();
    const totalSteps = 2;

    return (
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 overflow-y-auto">
        <div className="min-h-screen flex items-start justify-center p-4 py-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-3xl w-full"
          >
            <Card className="border-none shadow-2xl">
              <CardHeader className="bg-gradient-to-r from-green-600 to-emerald-600 text-white p-6 sticky top-0 z-10">
                <div className="flex items-center justify-between">
                  <div>
                    <Badge className="bg-white/20 text-white px-3 py-1 mb-2">Step 1 of {totalSteps}</Badge>
                    <CardTitle className="text-2xl mb-1">🎯 Your Situation</CardTitle>
                    <p className="text-white/90 text-sm">What's the problem and goal?</p>
                  </div>
                  <Button onClick={onClose} variant="ghost" className="text-white hover:bg-white/20" size="icon">
                    <X className="w-6 h-6" />
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-bold mb-2 text-slate-900">
                    Problem/Challenge *
                  </label>
                  <textarea
                    value={formData.problem}
                    onChange={(e) => setFormData({ ...formData, problem: e.target.value })}
                    placeholder="e.g., Traffic is good but conversion is low"
                    rows={3}
                    className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-green-500 focus:outline-none text-sm"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-2 text-slate-900">
                    Goal *
                  </label>
                  <textarea
                    value={formData.goal}
                    onChange={(e) => setFormData({ ...formData, goal: e.target.value })}
                    placeholder="e.g., Increase conversion to 3% in 3 months"
                    rows={3}
                    className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-green-500 focus:outline-none text-sm"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-bold mb-2 text-slate-900">Industry</label>
                    <input
                      type="text"
                      value={formData.industry}
                      onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                      placeholder="e.g., SaaS"
                      className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-green-500 focus:outline-none text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold mb-2 text-slate-900">Timeline</label>
                    <select
                      value={formData.timeline}
                      onChange={(e) => setFormData({ ...formData, timeline: e.target.value })}
                      className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-green-500 focus:outline-none text-sm"
                    >
                      <option>1 month</option>
                      <option>3 months</option>
                      <option>6 months</option>
                      <option>1 year</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold mb-2 text-slate-900">
                    Current Numbers (if available)
                  </label>
                  <textarea
                    value={formData.currentMetrics}
                    onChange={(e) => setFormData({ ...formData, currentMetrics: e.target.value })}
                    placeholder="e.g., Traffic: 10K/month, Conversion: 1.2%, Sales: $50K/month"
                    rows={3}
                    className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-green-500 focus:outline-none text-xs"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-bold mb-2 text-green-900">
                      ✅ What's Working?
                    </label>
                    <textarea
                      value={formData.whatsWorking}
                      onChange={(e) => setFormData({ ...formData, whatsWorking: e.target.value })}
                      placeholder="e.g., Email marketing works well"
                      rows={3}
                      className="w-full px-2 py-2 border-2 border-green-200 rounded-lg focus:border-green-500 focus:outline-none text-xs bg-green-50"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold mb-2 text-red-900">
                      ❌ What's NOT Working?
                    </label>
                    <textarea
                      value={formData.whatsNotWorking}
                      onChange={(e) => setFormData({ ...formData, whatsNotWorking: e.target.value })}
                      placeholder="e.g., Landing page has high bounce"
                      rows={3}
                      className="w-full px-2 py-2 border-2 border-red-200 rounded-lg focus:border-red-500 focus:outline-none text-xs bg-red-50"
                    />
                  </div>
                </div>

                <div className="sticky bottom-0 bg-white pt-4 pb-2 border-t-2 flex justify-between items-center">
                  <Button
                    onClick={() => {
                      setStep(0); // Go back to mode selection
                      onSelectMode(null);
                    }}
                    variant="outline"
                    className="text-slate-700 hover:bg-slate-100"
                  >
                    ← Back to Mode
                  </Button>
                  <div className="flex gap-2">
                    {[1, 2].map(s => (
                      <div key={s} className={`w-2 h-2 rounded-full transition-all ${s === 1 ? 'bg-green-600 w-6' : 'bg-slate-300'}`} />
                    ))}
                  </div>
                  
                  <Button
                    onClick={() => setStep(2)}
                    disabled={!canProceed}
                    className={`px-6 py-3 text-base font-bold ${
                      canProceed 
                        ? 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700' 
                        : 'bg-slate-300 cursor-not-allowed'
                    }`}
                  >
                    Next: Resources →
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  }

  // SIMPLE MODE - Step 2: Resources
  if (mode === 'simple' && step === 2) {
    const totalSteps = 2;

    return (
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 overflow-y-auto">
        <div className="min-h-screen flex items-start justify-center p-4 py-8">
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            className="max-w-3xl w-full"
          >
            <Card className="border-none shadow-2xl">
              <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-6 sticky top-0 z-10">
                <div className="flex items-center justify-between">
                  <div>
                    <Badge className="bg-white/20 text-white px-3 py-1 mb-2">Step 2 of {totalSteps}</Badge>
                    <CardTitle className="text-2xl mb-1">💼 Your Resources</CardTitle>
                    <p className="text-white/90 text-sm">What do you have to work with?</p>
                  </div>
                  <Button onClick={onClose} variant="ghost" className="text-white hover:bg-white/20" size="icon">
                    <X className="w-6 h-6" />
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold mb-2 text-slate-900">Team Size</label>
                    <input
                      type="text"
                      value={formData.teamSize}
                      onChange={(e) => setFormData({ ...formData, teamSize: e.target.value })}
                      placeholder="e.g., 5 people, Solo"
                      className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-purple-500 focus:outline-none text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold mb-2 text-slate-900">Budget</label>
                    <input
                      type="text"
                      value={formData.budget}
                      onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                      placeholder="e.g., $10K, Limited"
                      className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-purple-500 focus:outline-none text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold mb-2 text-slate-900">
                    Available Tools & Resources
                  </label>
                  <textarea
                    value={formData.availableTools}
                    onChange={(e) => setFormData({ ...formData, availableTools: e.target.value })}
                    placeholder="e.g., CRM (Salesforce), Email tool (Mailchimp), Analytics (Google)"
                    rows={4}
                    className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-purple-500 focus:outline-none text-sm"
                  />
                  <p className="text-xs text-slate-500 mt-1">💡 AI will infer roles from team size</p>
                </div>

                <Card className="bg-blue-50 border-2 border-blue-300">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Sparkles className="w-5 h-5 text-blue-600 flex-shrink-0 mt-1" />
                      <div>
                        <p className="font-bold text-blue-900 text-sm mb-2">AI Will Auto-Generate:</p>
                        <ul className="text-xs text-blue-800 space-y-1">
                          <li>✅ Detailed SWOT analysis</li>
                          <li>✅ Specific action steps with owners</li>
                          <li>✅ Timeline and milestones</li>
                          <li>✅ KPI tracking Framework</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="sticky bottom-0 bg-white pt-4 pb-2 border-t-2 flex justify-between items-center">
                  <Button onClick={() => setStep(1)} variant="outline" className="px-5 py-3 text-sm">
                    ← Back
                  </Button>
                  <div className="flex gap-2">
                    {[1, 2].map(s => (
                      <div key={s} className={`w-2 h-2 rounded-full transition-all ${s === 2 ? 'bg-purple-600 w-6' : 'bg-green-400'}`} />
                    ))}
                  </div>
                  <Button
                    onClick={handleGenerate}
                    disabled={generating}
                    className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 px-8 py-4 text-lg font-bold shadow-xl"
                  >
                    {generating ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Generate Plan
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  }

  // ADVANCED MODE - Step 1: Company & Goals
  if (mode === 'advanced' && step === 1) {
    const canProceed = advancedData.problem.trim() && advancedData.goal.trim();
    const totalSteps = 3;

    return (
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 overflow-y-auto">
        <div className="min-h-screen flex items-start justify-center p-4 py-8">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-3xl w-full">
            <Card className="border-none shadow-2xl">
              <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Badge className="bg-white/20 text-white px-3 py-1 mb-2">Step 1 of {totalSteps}</Badge>
                    <CardTitle className="text-2xl mb-1">🏢 Company & Goals</CardTitle>
                    <p className="text-white/90 text-sm">Tell us about your business and objectives</p>
                  </div>
                  <Button onClick={onClose} variant="ghost" className="text-white hover:bg-white/20" size="icon">
                    <X className="w-6 h-6" />
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-bold mb-2 text-slate-900">Company Name</label>
                  <Input value={advancedData.company_name} onChange={(e) => setAdvancedData({ ...advancedData, company_name: e.target.value })} placeholder="Your company name" className="border-2" />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-2 text-slate-900">Problem/Challenge *</label>
                  <textarea value={advancedData.problem} onChange={(e) => setAdvancedData({ ...advancedData, problem: e.target.value })} placeholder="e.g., Traffic is good but conversion is low" rows={3} className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-purple-500 focus:outline-none text-sm" />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-2 text-slate-900">Goal *</label>
                  <textarea value={advancedData.goal} onChange={(e) => setAdvancedData({ ...advancedData, goal: e.target.value })} placeholder="e.g., Increase conversion to 3% in 3 months" rows={3} className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-purple-500 focus:outline-none text-sm" />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-bold mb-2">Industry</label>
                    <Input value={advancedData.industry} onChange={(e) => setAdvancedData({ ...advancedData, industry: e.target.value })} placeholder="e.g., SaaS" className="border-2" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-2">Timeline</label>
                    <select value={advancedData.timeline} onChange={(e) => setAdvancedData({ ...advancedData, timeline: e.target.value })} className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-purple-500 focus:outline-none">
                      <option>1 month</option>
                      <option>3 months</option>
                      <option>6 months</option>
                      <option>1 year</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold mb-2">Current Numbers</label>
                  <textarea value={advancedData.currentMetrics} onChange={(e) => setAdvancedData({ ...advancedData, currentMetrics: e.target.value })} placeholder="e.g., Traffic: 10K/mo, Conv: 1.2%, Revenue: $50K/mo" rows={2} className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-purple-500 focus:outline-none text-xs" />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-bold mb-2 text-green-900">✅ What's Working?</label>
                    <textarea value={advancedData.whatsWorking} onChange={(e) => setAdvancedData({ ...advancedData, whatsWorking: e.target.value })} rows={3} className="w-full px-2 py-2 border-2 border-green-200 rounded-lg focus:border-green-500 focus:outline-none text-xs bg-green-50" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-2 text-red-900">❌ What's NOT Working?</label>
                    <textarea value={advancedData.whatsNotWorking} onChange={(e) => setAdvancedData({ ...advancedData, whatsNotWorking: e.target.value })} rows={3} className="w-full px-2 py-2 border-2 border-red-200 rounded-lg focus:border-red-500 focus:outline-none text-xs bg-red-50" />
                  </div>
                </div>

                <div className="flex justify-between pt-4 border-t-2">
                  <Button onClick={() => { setStep(0); onSelectMode(null); }} variant="outline">← Back to Mode</Button>
                  <div className="flex gap-2">
                    {[1, 2, 3].map(s => (
                      <div key={s} className={`w-2 h-2 rounded-full transition-all ${s === 1 ? 'bg-purple-600 w-6' : 'bg-slate-300'}`} />
                    ))}
                  </div>
                  <Button onClick={() => setStep(2)} disabled={!canProceed} className="bg-gradient-to-r from-blue-600 to-purple-600">Next: Team & Resources →</Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  }

  // ADVANCED MODE - Step 2: TEAM MEMBERS + RESOURCES (PROFESSIONAL)
  if (mode === 'advanced' && step === 2) {
    const teamNum = parseInt(advancedData.teamSize) || 1;
    const totalSteps = 3;

    return (
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 overflow-y-auto">
        <div className="min-h-screen flex items-start justify-center p-4 py-8">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-4xl w-full">
            <Card className="border-none shadow-2xl">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Badge className="bg-white/20 text-white px-3 py-1 mb-2">Step 2 of {totalSteps}</Badge>
                    <CardTitle className="text-2xl mb-1">👥 Team & Resources</CardTitle>
                    <p className="text-white/90 text-sm">Define your team structure & available resources</p>
                  </div>
                  <Button onClick={onClose} variant="ghost" className="text-white hover:bg-white/20" size="icon">
                    <X className="w-6 h-6" />
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="p-6 space-y-6">
                {/* Team Size Selector */}
                <Card className="bg-blue-50 border-2 border-blue-300">
                  <CardContent className="p-4">
                    <label className="block text-sm font-bold mb-3 text-blue-900">How many people on your team?</label>
                    <div className="grid grid-cols-5 gap-2">
                      {[1, 2, 3, 5, 10].map(num => (
                        <Button
                          key={num}
                          variant={parseInt(advancedData.teamSize) === num ? 'default' : 'outline'}
                          onClick={() => handleTeamSizeChange(num.toString())}
                          className={parseInt(advancedData.teamSize) === num ? 'bg-blue-600 text-white' : 'text-slate-700 hover:bg-slate-100'}
                        >
                          {num}
                        </Button>
                      ))}
                    </div>
                    <Input
                      type="number"
                      value={advancedData.teamSize}
                      onChange={(e) => handleTeamSizeChange(e.target.value)}
                      placeholder="Or enter custom number"
                      className="mt-3 border-2"
                      min="1"
                    />
                  </CardContent>
                </Card>

                {/* Team Members Details */}
                {teamNum > 0 && (
                  <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-300">
                    <CardHeader>
                      <CardTitle className="text-lg">👨‍💼 Team Member Details</CardTitle>
                      <p className="text-sm text-slate-600">Help AI assign the right tasks to the right people (optional)</p>
                    </CardHeader>
                    <CardContent className="p-4">
                      {advancedData.team_members.slice(0, teamNum).map((member, idx) => (
                        <Card key={idx} className="bg-white border border-slate-300 mb-3">
                          <CardContent className="p-4">
                            <p className="font-bold text-sm mb-3 text-purple-900">Team Member #{idx + 1}</p>
                            <div className="grid grid-cols-3 gap-3">
                              <Input
                                placeholder="Name"
                                value={member.name || ''}
                                onChange={(e) => updateTeamMember(idx, 'name', e.target.value)}
                                className="border-2"
                              />
                              <Input
                                placeholder="Role/Position"
                                value={member.role || ''}
                                onChange={(e) => updateTeamMember(idx, 'role', e.target.value)}
                                className="border-2"
                              />
                              <Input
                                placeholder="Strengths (e.g., 'data analysis')"
                                value={member.strengths || ''}
                                onChange={(e) => updateTeamMember(idx, 'strengths', e.target.value)}
                                className="border-2"
                              />
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </CardContent>
                  </Card>
                )}

                {/* Budget & Tools */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold mb-2">Monthly Budget</label>
                    <Input value={advancedData.budget} onChange={(e) => setAdvancedData({ ...advancedData, budget: e.target.value })} placeholder="e.g., $10,000" className="border-2" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-2">Available Tools</label>
                    <Input value={advancedData.availableTools} onChange={(e) => setAdvancedData({ ...advancedData, availableTools: e.target.value })} placeholder="e.g., CRM, Analytics" className="border-2" />
                  </div>
                </div>

                <div className="flex justify-between pt-4 border-t-2">
                  <Button onClick={() => setStep(1)} variant="outline">← Back</Button>
                  <div className="flex gap-2">
                    {[1, 2, 3].map(s => (
                      <div key={s} className={`w-2 h-2 rounded-full transition-all ${s === 2 ? 'bg-blue-600 w-6' : 'bg-slate-300'}`} />
                    ))}
                  </div>
                  <Button onClick={() => setStep(3)} className="bg-gradient-to-r from-blue-600 to-purple-600">Next: Market Analysis →</Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  }

  // ADVANCED MODE - Step 3: Market & Financial Details
  if (mode === 'advanced' && step === 3 && !generatedPlan) {
    const totalSteps = 3;

    return (
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 overflow-y-auto">
        <div className="min-h-screen flex items-start justify-center p-4 py-8">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-3xl w-full">
            <Card className="border-none shadow-2xl">
              <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Badge className="bg-white/20 text-white px-3 py-1 mb-2">Step 3 of {totalSteps} - Market Intelligence</Badge>
                    <CardTitle className="text-2xl mb-1">📊 Deep Dive</CardTitle>
                    <p className="text-white/90 text-sm">Financial & competitive landscape for tailored strategies</p>
                  </div>
                  <Button onClick={onClose} variant="ghost" className="text-white hover:bg-white/20" size="icon">
                    <X className="w-6 h-6" />
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold mb-2">Current Revenue</label>
                    <Input value={advancedData.current_revenue} onChange={(e) => setAdvancedData({ ...advancedData, current_revenue: e.target.value })} placeholder="e.g., $50K/month" className="border-2" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-2">Revenue Goal</label>
                    <Input value={advancedData.revenue_goal} onChange={(e) => setAdvancedData({ ...advancedData, revenue_goal: e.target.value })} placeholder="e.g., $100K/month" className="border-2" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold mb-2">Main Competitors</label>
                  <Input value={advancedData.main_competitors} onChange={(e) => setAdvancedData({ ...advancedData, main_competitors: e.target.value })} placeholder="e.g., CompanyA, CompanyB, CompanyC" className="border-2" />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-2">Your Unique Value Proposition</label>
                  <textarea value={advancedData.unique_value_proposition} onChange={(e) => setAdvancedData({ ...advancedData, unique_value_proposition: e.target.value })} rows={2} placeholder="What makes you different from competitors?" className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-purple-500 focus:outline-none text-sm" />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-2">Biggest Bottleneck Right Now</label>
                  <Input value={advancedData.biggest_bottleneck} onChange={(e) => setAdvancedData({ ...advancedData, biggest_bottleneck: e.target.value })} placeholder="e.g., Not enough qualified leads" className="border-2" />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-2">Past Failed Attempts</label>
                  <textarea value={advancedData.past_attempts} onChange={(e) => setAdvancedData({ ...advancedData, past_attempts: e.target.value })} rows={2} placeholder="What strategies didn't work before?" className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-purple-500 focus:outline-none text-sm" />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-2">Customer Feedback / Pain Points</label>
                  <textarea value={advancedData.customer_feedback} onChange={(e) => setAdvancedData({ ...advancedData, customer_feedback: e.target.value })} rows={2} placeholder="What do customers say about you?" className="w-full px-3 py-2 border-2 border-slate-300 rounded-lg focus:border-purple-500 focus:outline-none text-sm" />
                </div>

                <Card className="bg-purple-50 border-2 border-purple-300">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-2">
                      <Sparkles className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-purple-900 font-bold">AI will use ALL this data to create ultra-specific action items with team member assignments!</p>
                    </div>
                  </CardContent>
                </Card>

                <div className="flex justify-between pt-4 border-t-2">
                  <Button onClick={() => setStep(2)} variant="outline">← Back</Button>
                  <div className="flex gap-2">
                    {[1, 2, 3].map(s => (
                      <div key={s} className={`w-2 h-2 rounded-full transition-all ${s === 3 ? 'bg-pink-600 w-6' : 'bg-slate-300'}`} />
                    ))}
                  </div>
                  <Button onClick={handleGenerate} disabled={generating} className="bg-gradient-to-r from-green-600 to-emerald-600 px-8 py-4 text-lg font-bold shadow-xl">
                    {generating ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Generate Plan 🎯
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  }

  // Step 3 (Simple) or Step 4 (Advanced): Success & Download
  if ((mode === 'simple' && step === 3) || (mode === 'advanced' && step === 4)) {
    if (!generatedPlan) return null;

    return (
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-6 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-2xl w-full"
        >
          <Card className="border-none shadow-2xl">
            <CardHeader className="bg-gradient-to-r from-green-600 to-emerald-600 text-white p-8 text-center">
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-10 h-10 text-white" />
              </div>
              <CardTitle className="text-4xl mb-2">✅ Action Plan Ready!</CardTitle>
              <p className="text-white/90 text-lg">
                {mode === 'simple' ? 'Comprehensive strategic roadmap' : 'Hyper-personalized strategic roadmap'}
              </p>
            </CardHeader>
            <CardContent className="p-8 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <Card className="bg-blue-50 border-2 border-blue-300">
                  <CardContent className="p-4 text-center">
                    <p className="text-3xl font-bold text-blue-600 mb-1">
                      {generatedPlan.smart_goals?.length || 0}
                    </p>
                    <p className="text-sm text-slate-600">SMART Goals</p>
                  </CardContent>
                </Card>
                <Card className="bg-purple-50 border-2 border-purple-300">
                  <CardContent className="p-4 text-center">
                    <p className="text-3xl font-bold text-purple-600 mb-1">
                      {generatedPlan.action_steps?.length || 0}
                    </p>
                    <p className="text-sm text-slate-600">Action Steps</p>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-green-50 border-2 border-green-300">
                <CardContent className="p-6">
                  <h3 className="font-bold text-green-900 mb-3 flex items-center gap-2">
                    <Sparkles className="w-5 h-5" />
                    Includes:
                  </h3>
                  <ul className="space-y-2 text-sm text-green-800">
                    <li>✅ SWOT Analysis</li>
                    <li>✅ SMART Goals</li>
                    <li>✅ Action Items {mode === 'advanced' && '(with specific team assignments)'}</li>
                    <li>✅ Milestones</li>
                    <li>✅ KPI Framework</li>
                  </ul>
                </CardContent>
              </Card>

              <Button
                onClick={handleDownloadPDF}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-8 text-2xl font-bold shadow-2xl"
                size="lg"
              >
                <FileText className="w-8 h-8 mr-3" />
                DOWNLOAD PLAN 📄
              </Button>

              <div className="flex gap-3">
                <Button
                  onClick={() => {
                    setStep(0);
                    onSelectMode(null);
                    setGeneratedPlan(null);
                    setFormData({ // Reset simple mode form
                      problem: '', goal: '', industry: '', timeline: '3 months',
                      currentMetrics: '', whatsWorking: '', whatsNotWorking: '',
                      teamSize: '1', budget: '', availableTools: ''
                    });
                    setAdvancedData({ // Reset advanced mode form
                      problem: '', goal: '', industry: '', timeline: '3 months',
                      currentMetrics: '', whatsWorking: '', whatsNotWorking: '',
                      company_name: '', // NEW
                      teamSize: '1',
                      team_members: [], // NEW
                      budget: '',
                      availableTools: '',
                      current_revenue: '', revenue_goal: '',
                      main_competitors: '', unique_value_proposition: '',
                      biggest_bottleneck: '', past_attempts: '', customer_feedback: ''
                    });
                  }}
                  variant="outline"
                  className="flex-1"
                >
                  Create Another
                </Button>
                <Button onClick={onClose} variant="outline" className="flex-1">Close</Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return null;
}