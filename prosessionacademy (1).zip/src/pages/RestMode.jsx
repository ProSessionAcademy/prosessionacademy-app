import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Settings, Volume2, ArrowLeft, Sparkles, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const VISUALS = [
  { id: 'rain', name: 'Rain on Glass', video: 'https://assets.mixkit.co/videos/preview/mixkit-rain-falling-on-a-window-4011-large.mp4' },
  { id: 'clouds', name: 'Clouds', video: 'https://assets.mixkit.co/videos/preview/mixkit-white-clouds-in-blue-sky-2408-large.mp4' },
  { id: 'ocean', name: 'Ocean Waves', video: 'https://assets.mixkit.co/videos/preview/mixkit-ocean-waves-from-above-2880-large.mp4' },
  { id: 'forest', name: 'Forest Mist', video: 'https://assets.mixkit.co/videos/preview/mixkit-mysterious-forest-in-the-fog-2469-large.mp4' },
  { id: 'sunset', name: 'Sunset Clouds', video: 'https://assets.mixkit.co/videos/preview/mixkit-sunset-seen-between-the-clouds-2405-large.mp4' },
  { id: 'gradient', name: 'Soft Gradients', video: null }
];

const AUDIO_TRACKS = [
  { id: 'rain', name: '🌧 Rain', url: 'https://cdn.pixabay.com/audio/2022/03/10/audio_c7b8c1c8e5.mp3' },
  { id: 'ocean', name: '🌊 Ocean Waves', url: 'https://cdn.pixabay.com/audio/2022/03/24/audio_7c2f1a2c1e.mp3' },
  { id: 'fireplace', name: '🔥 Fireplace', url: 'https://cdn.pixabay.com/audio/2022/03/10/audio_8a2e9f5a0e.mp3' },
  { id: 'forest', name: '🍃 Forest', url: 'https://cdn.pixabay.com/audio/2022/05/27/audio_1808fbf07a.mp3' },
  { id: 'wind', name: '🌬 Wind', url: 'https://cdn.pixabay.com/audio/2022/03/12/audio_d1718ab41b.mp3' },
  { id: 'instrumental', name: '🎼 Soft Piano', url: 'https://cdn.pixabay.com/audio/2022/03/15/audio_6c8c8b5e5c.mp3' }
];

const DURATIONS = [
  { value: 3, label: '3 minutes' },
  { value: 5, label: '5 minutes' },
  { value: 10, label: '10 minutes' },
  { value: 15, label: '15 minutes' }
];

const MESSAGES = [
  "Take a deep breath...",
  "You're doing great.",
  "Your mind deserves peace.",
  "Everything is okay right now.",
  "Just relax and enjoy.",
  "No rush. No pressure.",
  "This moment is yours."
];

export default function RestMode({ onComplete }) {
  const [user, setUser] = useState(null);
  const [step, setStep] = useState('entry'); // entry, transition, session, complete
  const [showSettings, setShowSettings] = useState(false);
  
  // User preferences
  const [selectedVisual, setSelectedVisual] = useState('rain');
  const [selectedAudio, setSelectedAudio] = useState('rain');
  const [volume, setVolume] = useState(50);
  const [duration, setDuration] = useState(5);
  const [showBreathing, setShowBreathing] = useState(true);
  const [showMessages, setShowMessages] = useState(true);
  const [showTimer, setShowTimer] = useState(false);
  
  // Session state
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [showExitWarning, setShowExitWarning] = useState(false);
  const [currentMessage, setCurrentMessage] = useState('');
  const [breathPhase, setBreathPhase] = useState('inhale'); // inhale, exhale
  const [sessionCount, setSessionCount] = useState(0);
  
  const videoRef = useRef(null);
  const audioRef = useRef(null);
  const timerRef = useRef(null);
  const breathTimerRef = useRef(null);
  const messageTimerRef = useRef(null);
  const tapCountRef = useRef(0);

  useEffect(() => {
    const fetchUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      if (currentUser.rest_mode_settings) {
        const settings = currentUser.rest_mode_settings;
        setSelectedVisual(settings.visual || 'rain');
        setSelectedAudio(settings.audio || 'rain');
        setVolume(settings.volume || 50);
        setDuration(settings.duration || 5);
        setShowBreathing(settings.showBreathing ?? true);
        setShowMessages(settings.showMessages ?? true);
        setShowTimer(settings.showTimer ?? false);
      }
      
      setSessionCount(currentUser.rest_sessions_completed || 0);
    };
    fetchUser();
  }, []);

  const saveSettings = async () => {
    await base44.auth.updateMe({
      rest_mode_settings: {
        visual: selectedVisual,
        audio: selectedAudio,
        volume,
        duration,
        showBreathing,
        showMessages,
        showTimer
      }
    });
  };

  const startSession = async () => {
    await saveSettings();
    setStep('transition');
    
    setTimeout(() => {
      setStep('session');
      setTimeRemaining(duration * 60);
      startTimer();
      startBreathingCycle();
      if (showMessages) scheduleRandomMessage();
    }, 3000);
  };

  const startTimer = () => {
    timerRef.current = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          completeSession();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const startBreathingCycle = () => {
    let phase = 'inhale';
    breathTimerRef.current = setInterval(() => {
      setBreathPhase(phase);
      phase = phase === 'inhale' ? 'exhale' : 'inhale';
    }, 5000); // 5 seconds per phase
  };

  const scheduleRandomMessage = () => {
    const showMessage = () => {
      const randomMsg = MESSAGES[Math.floor(Math.random() * MESSAGES.length)];
      setCurrentMessage(randomMsg);
      setTimeout(() => setCurrentMessage(''), 5000);
    };
    
    showMessage();
    messageTimerRef.current = setInterval(showMessage, 60000); // Every minute
  };

  const handleSessionTap = () => {
    tapCountRef.current += 1;
    
    if (tapCountRef.current === 1) {
      setShowExitWarning(true);
      setTimeout(() => {
        tapCountRef.current = 0;
        setShowExitWarning(false);
      }, 3000);
    } else if (tapCountRef.current === 2) {
      exitSession();
    }
  };

  const exitSession = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (breathTimerRef.current) clearInterval(breathTimerRef.current);
    if (messageTimerRef.current) clearInterval(messageTimerRef.current);
    
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    
    tapCountRef.current = 0;
    setStep('entry');
  };

  const completeSession = async () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (breathTimerRef.current) clearInterval(breathTimerRef.current);
    if (messageTimerRef.current) clearInterval(messageTimerRef.current);
    
    if (audioRef.current) {
      const fadeOut = setInterval(() => {
        if (audioRef.current.volume > 0.1) {
          audioRef.current.volume -= 0.1;
        } else {
          clearInterval(fadeOut);
          audioRef.current.pause();
        }
      }, 150);
    }
    
    await base44.auth.updateMe({
      rest_sessions_completed: sessionCount + 1,
      last_rest_session: new Date().toISOString()
    });
    
    setSessionCount(sessionCount + 1);
    setStep('complete');
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const visual = VISUALS.find(v => v.id === selectedVisual);
  const audio = AUDIO_TRACKS.find(a => a.id === selectedAudio);

  if (step === 'entry') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 flex items-center justify-center p-6 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl w-full relative z-10"
        >
          {onComplete && (
            <Button
              onClick={onComplete}
              variant="ghost"
              className="mb-6 text-white/70 hover:text-white"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          )}

          <Card className="border-none shadow-2xl bg-white/10 backdrop-blur-xl">
            <CardContent className="p-12 text-center">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <Sparkles className="w-12 h-12 text-white" />
              </div>

              <h1 className="text-5xl font-black text-white mb-4">Rest Mode</h1>
              <p className="text-2xl text-purple-200 mb-8">{duration} minutes of calm. No phone. No movement. Just breathe.</p>

              {sessionCount > 0 && (
                <div className="bg-green-600/20 rounded-lg p-4 mb-6">
                  <p className="text-green-300 font-semibold">
                    🌟 You've completed {sessionCount} rest session{sessionCount > 1 ? 's' : ''}
                  </p>
                </div>
              )}

              <Button
                onClick={startSession}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 py-8 text-2xl font-bold mb-4"
              >
                Start Session
              </Button>

              <Button
                onClick={() => setShowSettings(true)}
                variant="outline"
                className="w-full border-white/20 text-white hover:bg-white/10"
              >
                <Settings className="w-5 h-5 mr-2" />
                Settings
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        <Dialog open={showSettings} onOpenChange={setShowSettings}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Rest Mode Settings</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div>
                <Label>Visual Theme</Label>
                <Select value={selectedVisual} onValueChange={setSelectedVisual}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {VISUALS.map(v => (
                      <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Background Audio</Label>
                <Select value={selectedAudio} onValueChange={setSelectedAudio}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {AUDIO_TRACKS.map(a => (
                      <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="flex items-center gap-2">
                  <Volume2 className="w-4 h-4" />
                  Volume: {volume}%
                </Label>
                <Slider value={[volume]} onValueChange={(v) => setVolume(v[0])} max={100} step={5} className="mt-2" />
              </div>

              <div>
                <Label>Duration</Label>
                <Select value={duration.toString()} onValueChange={(v) => setDuration(parseInt(v))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {DURATIONS.map(d => (
                      <SelectItem key={d.value} value={d.value.toString()}>{d.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label>Show Breathing Guide</Label>
                <Switch checked={showBreathing} onCheckedChange={setShowBreathing} />
              </div>

              <div className="flex items-center justify-between">
                <Label>Show Positive Messages</Label>
                <Switch checked={showMessages} onCheckedChange={setShowMessages} />
              </div>

              <div className="flex items-center justify-between">
                <Label>Show Timer</Label>
                <Switch checked={showTimer} onCheckedChange={setShowTimer} />
              </div>

              <Button onClick={() => { saveSettings(); setShowSettings(false); }} className="w-full">
                Save Settings
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  if (step === 'transition') {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="min-h-screen bg-black flex items-center justify-center"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5, duration: 1 }}
          className="text-center"
        >
          <p className="text-4xl text-white font-light mb-8">Take a deep breath...</p>
          <div className="w-32 h-32 border-4 border-white/30 rounded-full mx-auto animate-pulse" />
        </motion.div>
      </motion.div>
    );
  }

  if (step === 'session') {
    return (
      <div
        className="min-h-screen bg-black relative overflow-hidden cursor-pointer"
        onClick={handleSessionTap}
      >
        {visual.video ? (
          <video
            ref={videoRef}
            autoPlay
            loop
            muted
            playsInline
            className="absolute inset-0 w-full h-full object-cover opacity-60"
            src={visual.video}
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-blue-900 via-purple-900 to-pink-900 animate-gradient" />
        )}

        <audio
          ref={audioRef}
          autoPlay
          loop
          src={audio.url}
          volume={volume / 100}
        />

        <AnimatePresence>
          {showExitWarning && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="absolute top-8 left-1/2 transform -translate-x-1/2 bg-white/90 backdrop-blur-lg px-6 py-3 rounded-full shadow-xl z-50"
            >
              <p className="text-slate-900 font-semibold">Tap again to exit</p>
            </motion.div>
          )}
        </AnimatePresence>

        {showTimer && (
          <div className="absolute top-8 right-8 text-white/50 text-sm">
            {formatTime(timeRemaining)}
          </div>
        )}

        {showBreathing && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <motion.div
              animate={{
                scale: breathPhase === 'inhale' ? 1.2 : 0.8,
                opacity: breathPhase === 'inhale' ? 0.6 : 0.3
              }}
              transition={{ duration: 5, ease: 'easeInOut' }}
              className="w-32 h-32 rounded-full border-2 border-white/40"
            />
            <p className="absolute text-white/70 text-lg mt-48">
              {breathPhase === 'inhale' ? 'Inhale...' : 'Exhale...'}
            </p>
          </div>
        )}

        <AnimatePresence>
          {currentMessage && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute bottom-1/4 left-0 right-0 text-center pointer-events-none"
            >
              <p className="text-3xl text-white font-light px-6">{currentMessage}</p>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="absolute inset-0 bg-gradient-radial from-transparent to-black/40" />
      </div>
    );
  }

  if (step === 'complete') {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="min-h-screen bg-gradient-to-br from-green-900 via-emerald-900 to-teal-900 flex items-center justify-center p-6"
      >
        <Card className="max-w-2xl w-full border-none shadow-2xl bg-white/10 backdrop-blur-xl">
          <CardContent className="p-12 text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', delay: 0.2 }}
              className="w-32 h-32 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6"
            >
              <Check className="w-16 h-16 text-white" />
            </motion.div>

            <h2 className="text-5xl font-black text-white mb-4">Well done.</h2>
            <p className="text-2xl text-green-200 mb-8">You just gave your mind a break.</p>

            <div className="bg-white/10 rounded-xl p-6 mb-8">
              <p className="text-3xl font-bold text-white mb-2">{duration} minutes</p>
              <p className="text-green-300">of peaceful rest</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Button
                onClick={startSession}
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10 py-6"
              >
                Rest Again
              </Button>
              <Button
                onClick={() => onComplete ? onComplete() : setStep('entry')}
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 py-6"
              >
                Return
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  return null;
}