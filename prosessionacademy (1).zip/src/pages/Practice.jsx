
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Phone,
  MessageSquare,
  Users,
  ShoppingCart,
  MessageCircle,
  Briefcase,
  UserCheck,
  ArrowLeft,
  Sparkles,
  Target,
  Image as ImageIcon,
  Wand2,
  Languages,
  Shield,
  Video,
  Lock,
  Crown,
  AlertTriangle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import RealVoiceCallSimulator from '@/components/learning/RealVoiceCallSimulator';
import DifficultConversationSimulator from '@/components/learning/DifficultConversationSimulator';
import PublicSpeakingSimulator from '@/components/learning/PublicSpeakingSimulator';
import RetailSalesPractice from '@/components/learning/RetailSalesPractice';
import ObjectionVoiceSimulator from '@/components/learning/ObjectionVoiceSimulator';
import JobInterviewSimulator from '@/components/learning/JobInterviewSimulator';
import ManagerInterviewSimulator from '@/components/learning/ManagerInterviewSimulator';
import LanguageTeacherSimulator from '@/components/learning/LanguageTeacherSimulator';
import ConfidenceBootcamp from '@/components/learning/ConfidenceBootcamp';
import SalesLiveRolePlay from '@/components/learning/SalesLiveRolePlay';
import VideoPresentationAnalysis from '@/components/learning/VideoPresentationAnalysis';
import InterviewPreparation from '@/components/learning/InterviewPreparation';
import { motion } from 'framer-motion';

// Modules array moved outside the component to be static and accessible across effects
const staticModules = [
  {
    id: 'sales_call',
    title: 'Sales Call Practice',
    description: 'Real AI customers • Voice interaction • Instant feedback',
    icon: Phone,
    color: 'from-blue-500 via-blue-600 to-cyan-600',
    bgPattern: 'from-blue-50 to-cyan-50',
    component: RealVoiceCallSimulator,
    emoji: '📞'
  },
  {
    id: 'sales_live_roleplay',
    title: 'Sales Live Role Play',
    description: 'Camera & Mic ON • Two-person view • Continuous AI feedback',
    icon: Video,
    color: 'from-cyan-500 via-teal-600 to-blue-600',
    bgPattern: 'from-cyan-50 to-blue-50',
    component: SalesLiveRolePlay,
    emoji: '🎭'
  },
  {
    id: 'interview_preparation',
    title: 'Interview Preparation',
    description: 'Upload CV • Get tailored questions • Interviewer or Interviewee mode',
    icon: Briefcase,
    color: 'from-indigo-500 via-purple-600 to-pink-600',
    bgPattern: 'from-indigo-50 to-pink-50',
    component: InterviewPreparation,
    emoji: '💼'
  },
  {
    id: 'difficult_conversation',
    title: 'Difficult Conversations',
    description: 'Handle workplace conflicts • 3D avatars • Real scenarios',
    icon: MessageSquare,
    color: 'from-red-500 via-rose-600 to-pink-600',
    bgPattern: 'from-red-50 to-pink-50',
    component: DifficultConversationSimulator,
    emoji: '💬'
  },
  {
    id: 'public_speaking',
    title: 'Public Speaking',
    description: 'Solo AI • 2-Person live • Video upload analysis',
    icon: Users,
    color: 'from-purple-500 via-purple-600 to-violet-600',
    bgPattern: 'from-purple-50 to-violet-50',
    component: PublicSpeakingSimulator,
    emoji: '🎤'
  },
  {
    id: 'retail_sales',
    title: 'Retail Sales',
    description: 'In-store practice • Customer service • Upselling',
    icon: ShoppingCart,
    color: 'from-green-500 via-emerald-600 to-teal-600',
    bgPattern: 'from-green-50 to-teal-50',
    component: RetailSalesPractice,
    emoji: '🛒'
  },
  {
    id: 'objection_handling',
    title: 'Objection Handling',
    description: 'Overcome objections • Sales psychology • Win deals',
    icon: MessageCircle,
    color: 'from-orange-500 via-orange-600 to-amber-600',
    bgPattern: 'from-orange-50 to-amber-50',
    component: ObjectionVoiceSimulator,
    emoji: '🎯'
  },
  {
    id: 'job_interview',
    title: 'Job Interview Practice',
    description: 'ANY job role • Paste job description • Real AI interviewer',
    icon: Briefcase,
    color: 'from-indigo-500 via-indigo-600 to-blue-600',
    bgPattern: 'from-indigo-50 to-blue-50',
    component: JobInterviewSimulator,
    emoji: '💼'
  },
  {
    id: 'manager_interview',
    title: 'Interview Skills (Manager)',
    description: 'Interview candidates • Assess talent • Hiring practice',
    icon: UserCheck,
    color: 'from-pink-500 via-pink-600 to-rose-600',
    bgPattern: 'from-pink-50 to-rose-50',
    component: ManagerInterviewSimulator,
    requiresRoleSelection: true,
    emoji: '👔',
    roles: [
      { value: 'Salesman', label: 'Salesman' },
      { value: 'Assistant Store Manager', label: 'Assistant Store Manager' },
      { value: 'Store Manager', label: 'Store Manager' },
      { value: 'Business Developer', label: 'Business Developer' },
      { value: 'Teacher', label: 'Teacher' }
    ]
  },
  {
    id: 'language_teacher',
    title: 'AI Language Teacher',
    description: 'Learn languages • Voice conversations • Real-time corrections',
    icon: Languages,
    color: 'from-teal-500 via-cyan-600 to-blue-600',
    bgPattern: 'from-teal-50 to-cyan-50',
    component: LanguageTeacherSimulator,
    emoji: '🌍'
  },
  {
    id: 'confidence_bootcamp',
    title: 'Confidence Bootcamp',
    description: 'Train composure under pressure • Master calm confidence • AI stress simulation',
    icon: Shield,
    color: 'from-purple-500 via-pink-600 to-rose-600',
    bgPattern: 'from-purple-50 to-pink-50',
    component: ConfidenceBootcamp,
    emoji: '🧠'
  }
];

export default function Practice() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedModule, setSelectedModule] = useState(null);
  const [selectedRole, setSelectedRole] = useState(null);
  const [hasAccess, setHasAccess] = useState(false);
  const [userPlan, setUserPlan] = useState(null);
  const [limitReached, setLimitReached] = useState(false);
  const [initialModuleParam, setInitialModuleParam] = useState(null);

  // Alias staticModules back to 'modules' for the rest of the component for consistency
  const modules = staticModules;

  const handleComplete = useCallback(() => {
    setSelectedModule(null);
    setSelectedRole(null);
  }, []);

  const handleRoleSelect = useCallback((role) => {
    setSelectedRole(role);
  }, []);

  // handleModuleSelect wrapped in useCallback to ensure stable function reference
  // and captures the latest state values when called
  const handleModuleSelect = useCallback(async (module) => {
    // Check if practice session limit reached BEFORE attempting to start a practice module
    if (limitReached) {
      alert("⚠️ You've reached your monthly practice session limit. Please upgrade for unlimited access.");
      return;
    }

    // Increment usage counter for practice sessions
    // and if there's a specific limit (not -1 for unlimited)
    if (userPlan?.features?.max_practice_sessions !== -1) {
      try {
        // Ensure user is not null before accessing its properties
        const newCount = (user?.monthly_practice_sessions_used || 0) + 1;
        await base44.auth.updateMe({
          monthly_practice_sessions_used: newCount
        });
        // Update local user state immediately
        setUser(prevUser => ({ ...prevUser, monthly_practice_sessions_used: newCount }));

        // Re-check limit after incrementing to update the UI correctly if this session was the last one
        const maxSessions = userPlan?.features?.max_practice_sessions || 0;
        if (maxSessions !== -1 && newCount >= maxSessions) {
          setLimitReached(true); // This will trigger the limitReached UI on next render
        }
      } catch (error) {
        console.error('Usage tracking error:', error);
        // Still allow the module to start, but log the error
      }
    }
    
    if (module.requiresRoleSelection) {
      setSelectedModule(module);
    } else {
      setSelectedModule(module);
      setSelectedRole(null);
    }
  }, [limitReached, userPlan, user, setUser, setLimitReached, setSelectedModule, setSelectedRole]);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        
        // Reset usage if needed (first of month)
        const now = new Date();
        const resetDate = currentUser.usage_reset_date ? new Date(currentUser.usage_reset_date) : null;
        
        if (!resetDate || now.getTime() >= resetDate.getTime()) {
          const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);
          await base44.auth.updateMe({
            monthly_practice_sessions_used: 0,
            monthly_ai_images_used: 0,
            monthly_ppt_generations_used: 0,
            monthly_group_posts_used: 0,
            monthly_community_posts_used: 0,
            monthly_file_uploads_used: 0,
            usage_reset_date: nextMonth.toISOString()
          });
          // Update the local currentUser object so the rest of the logic uses fresh data
          currentUser.monthly_practice_sessions_used = 0;
          currentUser.monthly_ai_images_used = 0;
          currentUser.monthly_ppt_generations_used = 0;
          currentUser.monthly_group_posts_used = 0;
          currentUser.monthly_community_posts_used = 0;
          currentUser.monthly_file_uploads_used = 0;
          currentUser.usage_reset_date = nextMonth.toISOString();
        }
        
        setUser(currentUser);

        // CHECK SUBSCRIPTION ACCESS - WAIT FOR THIS TO COMPLETE
        if (currentUser.subscription_plan_id) {
          const plans = await base44.entities.SubscriptionPlan.filter({ id: currentUser.subscription_plan_id });
          const plan = plans[0];
          setUserPlan(plan);
          setHasAccess(plan?.features?.access_practice_hub === true);
          
          // Check if practice session limit reached
          const maxSessions = plan?.features?.max_practice_sessions || 0;
          const used = currentUser.monthly_practice_sessions_used || 0;
          if (maxSessions !== -1 && used >= maxSessions) {
            setLimitReached(true);
          } else {
            setLimitReached(false);
          }
        } else {
          // No subscription plan means no access or limited free access
          setHasAccess(false);
          // Assuming free tier might also have limits or no access to practice hub
          setLimitReached(true); 
        }
        
        // Only set loading to false AFTER access check completes
        setLoading(false);

        // Check for direct module parameter in URL and store it
        const urlParams = new URLSearchParams(window.location.search);
        const moduleParam = urlParams.get('module');
        if (moduleParam) {
          setInitialModuleParam(moduleParam);
        }
      } catch (error) {
        console.error('Error:', error);
        setHasAccess(false);
        setLimitReached(true); // If error, assume no access or limit reached
        setLoading(false);
      }
    };
    fetchUser();
  }, []); // Empty dependency array means this effect runs once on mount

  // New useEffect to handle the initial module selection from URL param
  useEffect(() => {
    // Only process if a module param was found, loading is complete,
    // modules list is available, and no module is currently selected.
    if (initialModuleParam && !loading && modules.length > 0 && selectedModule === null) {
      const module = modules.find(m => m.id === initialModuleParam);
      if (module) {
        handleModuleSelect(module);
        // Clean up the URL parameter after processing to prevent re-triggering on future renders
        const urlParams = new URLSearchParams(window.location.search);
        urlParams.delete('module');
        window.history.replaceState({}, document.title, `${window.location.pathname}${urlParams.toString() ? `?${urlParams.toString()}` : ''}`);
      }
      setInitialModuleParam(null); // Clear the initial param after processing
    }
  }, [initialModuleParam, loading, handleModuleSelect, modules, selectedModule]); // Dependencies for this effect

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-pink-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-white"></div>
      </div>
    );
  }

  // ACCESS CONTROL - Check BEFORE module selection logic
  if (!hasAccess && user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-red-900 to-rose-900 flex items-center justify-center p-6">
        <Card className="max-w-2xl border-none shadow-2xl">
          <CardContent className="p-12 text-center">
            <div className="w-24 h-24 bg-red-600/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Lock className="w-12 h-12 text-red-500" />
            </div>
            <h2 className="text-3xl font-bold text-slate-900 mb-4">🔒 Practice Hub Locked</h2>
            <p className="text-slate-600 mb-2">Your current plan doesn't include access to Practice Hub.</p>
            <p className="text-slate-700 font-semibold mb-8">Upgrade to unlock unlimited practice sessions!</p>
            
            <Link to={createPageUrl("Subscription")}>
              <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 py-6 px-8 text-xl font-bold shadow-xl">
                <Crown className="w-6 h-6 mr-2" />
                View Plans & Upgrade
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  // LIMIT REACHED CHECK for practice sessions
  if (limitReached && user && userPlan) {
    const maxSessions = userPlan.features?.max_practice_sessions || 0;
    const used = user.monthly_practice_sessions_used || 0;
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-900 via-red-900 to-rose-900 flex items-center justify-center p-6">
        <Card className="max-w-2xl border-none shadow-2xl">
          <CardContent className="p-12 text-center">
            <div className="w-24 h-24 bg-orange-600/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertTriangle className="w-12 h-12 text-orange-500" />
            </div>
            <h2 className="text-3xl font-bold text-slate-900 mb-4">⚠️ Monthly Limit Reached</h2>
            <p className="text-slate-700 mb-2">You've used <span className="font-black text-2xl text-red-600">{used}/{maxSessions}</span> practice sessions this month.</p>
            <p className="text-slate-600 mb-8">Upgrade to get unlimited access!</p>
            
            <Link to={createPageUrl("Subscription")}>
              <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 py-6 px-8 text-xl font-bold shadow-xl">
                <Crown className="w-6 h-6 mr-2" />
                Upgrade Now
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (selectedModule && (selectedRole || !selectedModule.requiresRoleSelection)) {
    const ModuleComponent = selectedModule.component;
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50">
        <ModuleComponent
          onComplete={handleComplete}
          onExit={handleComplete}
          selectedRole={selectedRole}
        />
      </div>
    );
  }

  if (selectedModule && selectedModule.requiresRoleSelection && !selectedRole) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 p-6">
        <div className="max-w-4xl mx-auto">
          <Button
            onClick={() => setSelectedModule(null)}
            variant="outline"
            className="mb-6"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Modules
          </Button>

          <Card className="border-none shadow-2xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center bg-gradient-to-br ${selectedModule.color} shadow-xl`}>
                  <selectedModule.icon className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-3xl font-bold text-slate-900">{selectedModule.emoji} {selectedModule.title}</h2>
                  <p className="text-slate-600">{selectedModule.description}</p>
                </div>
              </div>

              <h3 className="text-lg font-semibold text-slate-900 mb-4">Select a Role to Practice:</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {selectedModule.roles.map((role) => (
                  <motion.div
                    key={role.value}
                    whileHover={{ scale: 1.02, y: -4 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Card
                      className="border-2 border-slate-200 hover:border-blue-500 hover:shadow-xl transition-all cursor-pointer bg-gradient-to-br from-white to-blue-50"
                      onClick={() => handleRoleSelect(role.value)}
                    >
                      <CardContent className="p-6">
                        <h4 className="font-bold text-slate-900 text-lg">{role.label}</h4>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 relative overflow-hidden">
      
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 -right-40 w-[600px] h-[600px] bg-blue-500/30 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-40 -left-40 w-[600px] h-[600px] bg-purple-500/30 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 w-[600px] h-[600px] bg-pink-500/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
      </div>

      <div className="relative z-10 p-6 lg:p-8 space-y-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-3xl blur-2xl opacity-75 group-hover:opacity-100 transition duration-1000 animate-pulse"></div>
            <div className="relative bg-gradient-to-r from-slate-900/95 via-slate-800/95 to-slate-900/95 backdrop-blur-2xl rounded-3xl p-8 lg:p-12 border border-white/10 shadow-2xl">
              <div className="flex items-center justify-between flex-wrap gap-6">
                <div className="flex items-center gap-6">
                  <div className="relative">
                    <div className="absolute -inset-2 bg-gradient-to-r from-blue-400 to-purple-400 rounded-3xl blur-xl opacity-75 animate-pulse"></div>
                    <div className="relative w-20 h-20 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-3xl flex items-center justify-center shadow-2xl">
                      <Target className="w-11 h-11 text-white" />
                    </div>
                  </div>
                  <div>
                    <h1 className="text-5xl lg:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 mb-2">
                      Practice Hub
                    </h1>
                    <p className="text-xl text-blue-200">Master Real-World Skills with AI</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {modules.map((module, index) => {
            const Icon = module.icon;
            
            return (
              <motion.div
                key={module.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05, y: -8 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="relative group h-full">
                  <div className={`absolute -inset-1 bg-gradient-to-r ${module.color} rounded-2xl blur-lg opacity-0 group-hover:opacity-75 transition duration-500`}></div>
                  <Card
                    className="relative border-none shadow-2xl overflow-hidden transition-all h-full flex flex-col cursor-pointer"
                    onClick={() => handleModuleSelect(module)}
                  >
                    <div className={`h-3 bg-gradient-to-r ${module.color}`}></div>
                    <div className={`absolute inset-0 bg-gradient-to-br ${module.bgPattern} opacity-50`}></div>
                    
                    <CardContent className="relative p-6 flex-1 flex flex-col">
                      <div className="flex items-start justify-between mb-4">
                        <div className={`w-16 h-16 rounded-2xl flex items-center justify-center bg-gradient-to-br ${module.color} shadow-xl transform group-hover:rotate-6 transition-transform`}>
                          <Icon className="w-8 h-8 text-white" />
                        </div>
                      </div>
                      
                      <div className="flex-1">
                        <span className="text-3xl mb-2 block">{module.emoji}</span>
                        <h3 className="text-xl font-black text-slate-900 mb-2 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-600 group-hover:to-purple-600 transition-all">
                          {module.title}
                        </h3>
                        <p className="text-sm text-slate-600 leading-relaxed mb-4">
                          {module.description}
                        </p>
                      </div>
                      
                      <Badge className={`bg-gradient-to-r ${module.color} text-white w-full justify-center py-2 shadow-lg`}>
                        <Sparkles className="w-4 h-4 mr-2" />
                        Start Practice
                      </Badge>
                    </CardContent>
                  </Card>
                </div>
              </motion.div>
            );
          })}
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="border border-white/10 shadow-2xl bg-slate-900/80 backdrop-blur-xl text-white">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
              <CardContent className="p-6 relative">
                <Sparkles className="w-10 h-10 text-blue-400 mb-4" />
                <h3 className="font-bold text-xl mb-3 text-white">How It Works</h3>
                <ul className="space-y-2 text-blue-200 text-sm">
                  <li className="flex items-start gap-2">
                    <span className="text-blue-300 font-bold text-lg">1</span>
                    <span>Choose your practice module</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-purple-300 font-bold text-lg">2</span>
                    <span>Interact with AI in real scenarios</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-pink-300 font-bold text-lg">3</span>
                    <span>Get instant AI-powered feedback</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-cyan-300 font-bold text-lg">4</span>
                    <span>Improve and master the skill</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="border border-white/10 shadow-2xl bg-slate-900/80 backdrop-blur-xl text-white">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
              <CardContent className="p-6 relative">
                <Target className="w-10 h-10 text-green-400 mb-4" />
                <h3 className="font-bold text-xl mb-3 text-white">✨ {userPlan ? 'Your Plan' : 'Access'}</h3>
                {userPlan && user ? (
                  <ul className="space-y-2 text-green-200 text-sm">
                    <li className="flex items-center gap-2">
                      <span className="text-green-300">✓</span>
                      <span>Plan: {userPlan.plan_name}</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-300">✓</span>
                      <span>Practice Sessions: {user.monthly_practice_sessions_used || 0}/{userPlan.features?.max_practice_sessions === -1 ? 'Unlimited' : `${userPlan.features?.max_practice_sessions}`}</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-300">✓</span>
                      <span>AI Images: {user.monthly_ai_images_used || 0}/{userPlan.features?.max_ai_generations === -1 ? 'Unlimited' : `${userPlan.features?.max_ai_generations}`}</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-300">✓</span>
                      <span>All modules available 24/7</span>
                    </li>
                  </ul>
                ) : ( // This part is for users without a specific plan object, perhaps free tier without explicit features
                  <ul className="space-y-2 text-green-200 text-sm">
                    <li className="flex items-center gap-2">
                      <span className="text-green-300">✓</span>
                      <span>Practice as much as you want</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-300">✓</span>
                      <span>No session limits or restrictions</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-300">✓</span>
                      <span>All modules available 24/7</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-300">✓</span>
                      <span>Improve at your own pace</span>
                    </li>
                  </ul>
                )}
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="border border-white/10 shadow-2xl bg-slate-900/80 backdrop-blur-xl text-white">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
              <CardContent className="p-6 relative">
                <Sparkles className="w-10 h-10 text-purple-400 mb-4" />
                <h3 className="font-bold text-xl mb-3 text-white">Why Practice?</h3>
                <ul className="space-y-2 text-purple-200 text-sm">
                  <li className="flex items-start gap-2">
                    <span className="text-purple-300">✓</span>
                    <span>Build confidence in real scenarios</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-pink-300">✓</span>
                    <span>Safe space to make mistakes</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-fuchsia-300">✓</span>
                    <span>Instant AI feedback & tips</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-violet-300">✓</span>
                    <span>Master skills faster than ever</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4"
        >
          <Card className="border-none shadow-xl bg-gradient-to-br from-blue-600 to-cyan-600 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-4xl font-black mb-2">{modules.length}</div>
              <p className="text-sm text-blue-100">AI Modules</p>
            </CardContent>
          </Card>
          
          <Card className="border-none shadow-xl bg-gradient-to-br from-purple-600 to-pink-600 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-4xl font-black mb-2">
                {userPlan?.features?.max_practice_sessions === -1 ? '∞' : userPlan?.features?.max_practice_sessions || '0'}
              </div>
              <p className="text-sm text-purple-100">Sessions/Month</p>
            </CardContent>
          </Card>
          
          <Card className="border-none shadow-xl bg-gradient-to-br from-green-600 to-emerald-600 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-4xl font-black mb-2">24/7</div>
              <p className="text-sm text-green-100">Always Available</p>
            </CardContent>
          </Card>
          
          <Card className="border-none shadow-xl bg-gradient-to-br from-orange-600 to-red-600 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-4xl font-black mb-2">100%</div>
              <p className="text-sm text-orange-100">AI Powered</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
