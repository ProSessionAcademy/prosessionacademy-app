
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Route,
  Search,
  BookOpen,
  ArrowRight,
  Clock,
  Award,
  CheckCircle,
  Users,
  Trophy,
  Target,
  Sparkles
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function Pathways() {
  const [searchQuery, setSearchQuery] = useState("");
  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error:", error);
      }
    };
    fetchUser();
  }, []);

  const { data: pathways = [] } = useQuery({
    queryKey: ['pathways'],
    queryFn: () => base44.entities.Pathway.list('-created_date'),
    initialData: [],
  });

  const { data: courses = [] } = useQuery({
    queryKey: ['courses'],
    queryFn: () => base44.entities.Course.list(),
    initialData: [],
  });

  const { data: userProgress = [] } = useQuery({
    queryKey: ['userProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      return await base44.entities.UserProgress.filter({ user_email: user.email });
    },
    enabled: !!user?.email,
    initialData: [],
  });

  const filteredPathways = pathways.filter(pathway =>
    pathway.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    pathway.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getPathwayProgress = (pathway) => {
    // Get actual courses that exist in the database for progress calculation
    const pathwayCourses = pathway.courses?.map(pc =>
      courses.find(c => c.id === pc.course_id)
    ).filter(Boolean) || [];

    if (pathwayCourses.length === 0) return 0;

    const completedCount = pathwayCourses.filter(course => {
      const progress = userProgress.find(up => up.course_id === course.id);
      return progress?.progress_percentage === 100;
    }).length;

    return Math.round((completedCount / pathwayCourses.length) * 100);
  };

  const getPathwayStats = (pathway) => {
    // Get actual courses that exist in the database
    const pathwayCourses = pathway.courses?.map(pc =>
      courses.find(c => c.id === pc.course_id)
    ).filter(Boolean) || []; // Use filter(Boolean) to remove null/undefined entries

    const totalCourses = pathwayCourses.length;

    const completedCourses = pathwayCourses.filter(course => {
      const progress = userProgress.find(up => up.course_id === course.id);
      return progress?.progress_percentage === 100;
    }).length;

    // Calculate total duration from actual existing courses
    const totalHours = pathwayCourses.reduce((sum, course) => {
      return sum + (course?.duration_hours || 0);
    }, 0);

    return {
      totalCourses,
      completedCourses,
      totalHours: Math.round(totalHours)
    };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          <Card className="border-none shadow-2xl overflow-hidden bg-white">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 opacity-10"></div>
              <CardContent className="relative p-8 lg:p-12">
                <div className="flex items-center gap-6">
                  <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-xl">
                    <Route className="w-10 h-10 text-white" />
                  </div>
                  <div>
                    <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-2">
                      Learning Pathways
                    </h1>
                    <p className="text-lg text-slate-600">
                      Structured learning journeys from beginner to expert
                    </p>
                  </div>
                </div>
              </CardContent>
            </div>
          </Card>
        </motion.div>

        <Card className="border-none shadow-xl bg-white">
          <CardContent className="p-6">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
              <Input
                type="text"
                placeholder="Search pathways..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-14 text-lg border-2 border-slate-200 focus:border-blue-500 rounded-xl shadow-sm"
              />
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          {filteredPathways.map((pathway, index) => {
            const progress = getPathwayProgress(pathway);
            const stats = getPathwayStats(pathway);

            return (
              <motion.div
                key={pathway.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Link to={`${createPageUrl("PathwayDetail")}?pathwayId=${pathway.id}`}>
                  <Card className="border-none shadow-lg hover:shadow-2xl transition-all h-full flex flex-col bg-white cursor-pointer group">
                    <div className="h-48 bg-gradient-to-br from-slate-900 to-slate-800 relative overflow-hidden">
                      {pathway.thumbnail_url ? (
                        <img src={pathway.thumbnail_url} alt={pathway.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Route className="w-16 h-16 text-white/20" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                      
                      <div className="absolute bottom-4 left-4 right-4">
                        <Badge className="mb-2 bg-white/20 backdrop-blur-md text-white border-white/30">
                          {pathway.category?.replace(/_/g, ' ')}
                        </Badge>
                        <h3 className="text-2xl font-bold text-white group-hover:text-blue-300 transition-colors">
                          {pathway.title}
                        </h3>
                      </div>
                    </div>

                    <CardContent className="flex-1 flex flex-col p-6 space-y-4">
                      <p className="text-slate-600 text-sm line-clamp-2 flex-1">
                        {pathway.description}
                      </p>

                      <div className="grid grid-cols-3 gap-3">
                        <div className="text-center p-3 bg-blue-50 rounded-lg">
                          <BookOpen className="w-5 h-5 text-blue-600 mx-auto mb-1" />
                          <div className="text-2xl font-bold text-slate-900">{stats.totalCourses}</div>
                          <p className="text-xs text-slate-600">Courses</p>
                        </div>
                        <div className="text-center p-3 bg-green-50 rounded-lg">
                          <Trophy className="w-5 h-5 text-green-600 mx-auto mb-1" />
                          <div className="text-2xl font-bold text-slate-900">{stats.completedCourses}</div>
                          <p className="text-xs text-slate-600">Completed</p>
                        </div>
                        <div className="text-center p-3 bg-purple-50 rounded-lg">
                          <Clock className="w-5 h-5 text-purple-600 mx-auto mb-1" />
                          <div className="text-2xl font-bold text-slate-900">{stats.totalHours}</div>
                          <p className="text-xs text-slate-600">hours total</p>
                        </div>
                      </div>

                      {user && progress > 0 && (
                        <div className="space-y-2">
                          <div className="flex justify-between text-xs">
                            <span className="text-slate-600 font-medium">Your Progress</span>
                            <span className="font-bold text-blue-600">{progress}%</span>
                          </div>
                          <Progress value={progress} className="h-2" />
                        </div>
                      )}

                      <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg group-hover:shadow-xl transition-all">
                        {progress === 100 ? (
                          <>
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Review Pathway
                          </>
                        ) : progress > 0 ? (
                          <>
                            <Target className="w-4 h-4 mr-2" />
                            Continue Journey
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4 mr-2" />
                            Start Pathway
                          </>
                        )}
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            );
          })}
        </div>

        {filteredPathways.length === 0 && (
          <Card className="border-none shadow-xl bg-white">
            <CardContent className="p-16 text-center">
              <Route className="w-20 h-20 text-slate-300 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-slate-900 mb-2">No pathways found</h3>
              <p className="text-slate-500">Try adjusting your search</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
