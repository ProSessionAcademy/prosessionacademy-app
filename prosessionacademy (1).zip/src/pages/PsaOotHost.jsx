
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Users,
  Play,
  SkipForward,
  Trophy,
  QrCode,
  Copy,
  CheckCircle,
  Crown,
  Sliders, // Added Sliders icon
  Type // Added Type icon
} from "lucide-react";

export default function PsaOotHost() {
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const gameId = urlParams.get('gameId');

  const [qrCodeUrl, setQrCodeUrl] = useState("");
  const [showResults, setShowResults] = useState(false);
  const [timer, setTimer] = useState(0);
  const [timerActive, setTimerActive] = useState(false);

  const { data: game, refetch } = useQuery({
    queryKey: ['psaOotGame', gameId],
    queryFn: async () => {
      const games = await base44.entities.PsaOotGame.filter({ id: gameId });
      return games[0];
    },
    enabled: !!gameId,
    refetchInterval: 2000, // Poll every 2 seconds for player updates
  });

  useEffect(() => {
    if (game && game.status === 'waiting') {
      const joinUrl = `${window.location.origin}${window.location.pathname.replace('/PsaOotHost', '/PsaOotPlay')}?gameCode=${game.game_code}`;
      // Use Google Charts API for QR code generation
      setQrCodeUrl(`https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl=${encodeURIComponent(joinUrl)}`);
    }
  }, [game]);

  useEffect(() => {
    if (timerActive && timer > 0) {
      const interval = setInterval(() => {
        setTimer(t => {
          if (t <= 1) {
            setTimerActive(false);
            setShowResults(true);
            return 0;
          }
          return t - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [timerActive, timer]);

  const updateGameMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PsaOotGame.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['psaOotGame'] });
    },
  });

  const startWaiting = () => {
    updateGameMutation.mutate({
      id: gameId,
      data: { status: 'waiting' }
    });
  };

  const startGame = () => {
    updateGameMutation.mutate({
      id: gameId,
      data: { 
        status: 'active',
        current_question: 0,
        started_at: new Date().toISOString()
      }
    });
    startQuestion();
  };

  const startQuestion = () => {
    const currentQ = game?.questions?.[game?.current_question || 0];
    if (currentQ) {
      setTimer(currentQ.time_limit);
      setTimerActive(true);
      setShowResults(false);
    }
  };

  const nextQuestion = () => {
    const nextIndex = (game?.current_question || 0) + 1;
    if (nextIndex < game?.questions?.length) {
      updateGameMutation.mutate({
        id: gameId,
        data: { current_question: nextIndex }
      });
      setTimeout(() => startQuestion(), 500);
    } else {
      // Game finished
      updateGameMutation.mutate({
        id: gameId,
        data: { 
          status: 'completed',
          completed_at: new Date().toISOString()
        }
      });
    }
  };

  const copyGameCode = () => {
    navigator.clipboard.writeText(game?.game_code);
    alert('✅ Game code copied!');
  };

  if (!game) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 to-pink-900">
        <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-white"></div>
      </div>
    );
  }

  const currentQuestion = game.questions?.[game.current_question];
  const sortedPlayers = [...(game.players || [])].sort((a, b) => b.score - a.score);

  // Waiting Screen
  if (game.status === 'draft') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-pink-900 to-purple-900 text-white flex items-center justify-center p-6">
        <Card className="max-w-2xl w-full bg-white/10 backdrop-blur-xl border-none shadow-2xl">
          <CardContent className="p-12 text-center">
            <h1 className="text-5xl font-bold mb-4">{game.title}</h1>
            <p className="text-2xl mb-8 text-white/80">{game.questions?.length} Questions</p>
            <Button
              onClick={startWaiting}
              size="lg"
              className="bg-green-600 hover:bg-green-700 text-white px-12 py-6 text-2xl"
            >
              <Play className="w-8 h-8 mr-3" />
              Open Lobby
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (game.status === 'waiting') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-pink-900 to-purple-900 text-white p-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-6xl font-bold mb-4">{game.title}</h1>
            <p className="text-2xl text-white/80">Waiting for players to join...</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <Card className="bg-white/10 backdrop-blur-xl border-none">
              <CardContent className="p-8 text-center">
                <h2 className="text-2xl font-bold mb-4">Join at:</h2>
                <p className="text-4xl font-mono mb-2">prosession.app</p>
                <div className="flex items-center justify-center gap-3 mb-6">
                  <p className="text-6xl font-bold tracking-wider">{game.game_code}</p>
                  <Button
                    onClick={copyGameCode}
                    variant="ghost"
                    className="text-white hover:bg-white/20"
                  >
                    <Copy className="w-6 h-6" />
                  </Button>
                </div>
                {qrCodeUrl && (
                  <div className="bg-white p-4 rounded-xl inline-block">
                    <img src={qrCodeUrl} alt="QR Code" className="w-48 h-48" />
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-xl border-none">
              <CardContent className="p-8">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold flex items-center gap-2">
                    <Users className="w-8 h-8" />
                    Players ({game.players?.length || 0})
                  </h2>
                </div>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {game.players?.map((player, idx) => (
                    <div key={idx} className="bg-white/20 rounded-lg p-3 flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center font-bold">
                        {idx + 1}
                      </div>
                      <p className="text-lg font-semibold">{player.player_name}</p>
                    </div>
                  ))}
                  {(!game.players || game.players.length === 0) && (
                    <p className="text-center text-white/60 py-8">No players yet...</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <Button
              onClick={startGame}
              disabled={!game.players || game.players.length === 0}
              size="lg"
              className="bg-green-600 hover:bg-green-700 text-white px-16 py-8 text-3xl"
            >
              <Play className="w-10 h-10 mr-4" />
              Start Game
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (game.status === 'active') {
    if (showResults) {
      // Show results for current question
      const questionResults = sortedPlayers.map(player => {
        const answer = player.answers?.find(a => a.question_index === game.current_question);
        return {
          ...player,
          currentAnswer: answer
        };
      });

      return (
        <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-pink-900 text-white p-6">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold text-center mb-8">Question {game.current_question + 1} Results</h1>
            
            <Card className="bg-white/10 backdrop-blur-xl border-none mb-8">
              <CardContent className="p-8">
                <p className="text-2xl mb-6">{currentQuestion?.question}</p>
                <div className="grid grid-cols-2 gap-4">
                  {currentQuestion?.options.map((option, idx) => (
                    <div
                      key={idx}
                      className={`p-4 rounded-xl ${
                        idx === currentQuestion.correct_answer
                          ? 'bg-green-600'
                          : 'bg-white/20'
                      }`}
                    >
                      <p className="font-semibold">{option}</p>
                      {idx === currentQuestion.correct_answer && (
                        <CheckCircle className="w-6 h-6 mt-2" />
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-xl border-none mb-8">
              <CardContent className="p-8">
                <h2 className="text-3xl font-bold mb-6 flex items-center gap-3">
                  <Trophy className="w-8 h-8 text-yellow-400" />
                  Leaderboard
                </h2>
                <div className="space-y-3">
                  {questionResults.slice(0, 5).map((player, idx) => (
                    <div
                      key={idx}
                      className={`p-4 rounded-xl flex items-center justify-between ${
                        idx === 0 ? 'bg-gradient-to-r from-yellow-600 to-orange-600' :
                        idx === 1 ? 'bg-gradient-to-r from-slate-400 to-slate-500' :
                        idx === 2 ? 'bg-gradient-to-r from-amber-700 to-amber-800' :
                        'bg-white/20'
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center font-bold text-2xl">
                          {idx === 0 ? <Crown className="w-8 h-8" /> : idx + 1}
                        </div>
                        <div>
                          <p className="text-xl font-bold">{player.player_name}</p>
                          <p className="text-sm text-white/80">
                            {player.currentAnswer?.is_correct ? '✅ Correct' : '❌ Wrong'}
                            {player.currentAnswer?.is_correct && ` (+${player.currentAnswer?.points_earned} pts)`}
                          </p>
                        </div>
                      </div>
                      <p className="text-2xl font-bold">{player.score}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="text-center">
              <Button
                onClick={nextQuestion}
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 text-white px-12 py-6 text-2xl"
              >
                {game.current_question + 1 < game.questions.length ? (
                  <>
                    <SkipForward className="w-8 h-8 mr-3" />
                    Next Question
                  </>
                ) : (
                  <>
                    <Trophy className="w-8 h-8 mr-3" />
                    Show Final Results
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      );
    }

    // Show current question
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-pink-900 to-red-900 text-white p-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <Badge className="text-2xl px-6 py-3 bg-white/20">
              Question {game.current_question + 1} / {game.questions.length}
            </Badge>
            <div className="text-center">
              <div className="text-6xl font-bold mb-2">{timer}</div>
              <Progress value={(timer / currentQuestion?.time_limit) * 100} className="w-32 h-3" />
            </div>
            <Badge className="text-2xl px-6 py-3 bg-white/20">
              <Users className="w-6 h-6 mr-2" />
              {game.players?.length}
            </Badge>
          </div>

          <Card className="bg-white/10 backdrop-blur-xl border-none mb-8">
            <CardContent className="p-12 text-center">
              <p className="text-5xl font-bold">{currentQuestion?.question}</p>
            </CardContent>
          </Card>

          {/* Multiple Choice / True False */}
          {(currentQuestion?.question_type === "multiple_choice" || currentQuestion?.question_type === "true_false") && (
            <div className="grid grid-cols-2 gap-6">
              {currentQuestion?.options.map((option, idx) => (
                <Card key={idx} className="bg-white/20 backdrop-blur-xl border-2 border-white/30">
                  <CardContent className="p-8 text-center">
                    <p className="text-3xl font-bold mb-2">
                      {['🔴', '🔵', '🟡', '🟢'][idx]}
                    </p>
                    <p className="text-2xl">{option}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Picture Choice */}
          {currentQuestion?.question_type === "picture_choice" && (
            <div className="grid grid-cols-2 gap-6">
              {currentQuestion?.picture_options?.map((picUrl, idx) => (
                <Card key={idx} className="bg-white/20 backdrop-blur-xl border-2 border-white/30 overflow-hidden">
                  <CardContent className="p-0">
                    <div className="relative">
                      <img src={picUrl} alt={`Option ${idx}`} className="w-full h-64 object-cover" />
                      <div className="absolute top-4 left-4 w-12 h-12 bg-white/90 rounded-full flex items-center justify-center">
                        <p className="text-2xl font-bold text-purple-600">{String.fromCharCode(65 + idx)}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Slider */}
          {currentQuestion?.question_type === "slider" && (
            <Card className="bg-white/10 backdrop-blur-xl border-none">
              <CardContent className="p-12 text-center">
                <div className="space-y-4">
                  <div className="flex justify-between text-3xl font-bold">
                    <span>{currentQuestion.slider_min}</span>
                    <span>{currentQuestion.slider_max}</span>
                  </div>
                  <div className="h-12 bg-white/30 rounded-full relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Sliders className="w-8 h-8" />
                    </div>
                  </div>
                  <p className="text-lg text-white/80">Players: Drag the slider to your answer</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Open Ended */}
          {currentQuestion?.question_type === "open_ended" && (
            <Card className="bg-white/10 backdrop-blur-xl border-none">
              <CardContent className="p-12 text-center">
                <Type className="w-16 h-16 mx-auto mb-4 text-white/60" />
                <p className="text-2xl text-white/80">Players: Type your answer</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    );
  }

  // Final Results
  if (game.status === 'completed') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-pink-900 to-blue-900 text-white p-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <Trophy className="w-24 h-24 text-yellow-400 mx-auto mb-6" />
            <h1 className="text-6xl font-bold mb-4">Game Over!</h1>
            <p className="text-2xl text-white/80">{game.title}</p>
          </div>

          <Card className="bg-white/10 backdrop-blur-xl border-none">
            <CardContent className="p-8">
              <h2 className="text-4xl font-bold mb-8 text-center">Final Leaderboard</h2>
              <div className="space-y-4">
                {sortedPlayers.map((player, idx) => (
                  <div
                    key={idx}
                    className={`p-6 rounded-xl flex items-center justify-between ${
                      idx === 0 ? 'bg-gradient-to-r from-yellow-600 to-orange-600 scale-105' :
                      idx === 1 ? 'bg-gradient-to-r from-slate-400 to-slate-500' :
                      idx === 2 ? 'bg-gradient-to-r from-amber-700 to-amber-800' :
                      'bg-white/20'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-16 h-16 rounded-full flex items-center justify-center font-bold text-3xl ${
                        idx === 0 ? 'bg-white/20' : 'bg-white/30'
                      }`}>
                        {idx === 0 ? <Crown className="w-10 h-10" /> : idx + 1}
                      </div>
                      <div>
                        <p className="text-3xl font-bold">{player.player_name}</p>
                        <p className="text-lg text-white/80">
                          {player.answers?.filter(a => a.is_correct).length} / {game.questions.length} correct
                        </p>
                      </div>
                    </div>
                    <p className="text-4xl font-bold">{player.score}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return null;
}
